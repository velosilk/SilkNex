<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

/*
|--------------------------------------------------------------------------
| SilkNex API
|--------------------------------------------------------------------------
| Upload this file with index.html, style.css, app.js and config.php.
| Tables are created automatically on the first request.
|--------------------------------------------------------------------------
*/

define('SILKNEX_COMMUNITY_LOADED', true);
require_once __DIR__ . '/community.php';

const MAX_USERNAME = 24;
const MAX_DISPLAY_NAME = 40;
const MAX_ABOUT = 160;
const MAX_MESSAGE = 4000;
const MAX_GROUP_NAME = 60;
const MAX_GROUP_MEMBERS = 30;
const MAX_IMAGE_UPLOAD = 12 * 1024 * 1024;
const MAX_VIDEO_UPLOAD = 40 * 1024 * 1024;
const MAX_AUDIO_UPLOAD = 20 * 1024 * 1024;
const SCHEMA_VERSION = '59';
const FOUNDER_USERNAME = 'MatteoBarreno';
const COFOUNDER_USERNAME = 'T0K3N';
// Bootstrap hash only; the plaintext password is never stored in the release.
const COFOUNDER_BOOTSTRAP_HASH = '$2a$12$F85zflRCQz3mLnT0mq0jLuQRjjx5DeACGF6xgGKt0QWzCEAmQj2F6';
const FOUNDER_BOOTSTRAP_HASH = '$2y$12$UCf4KZyuu0MF2zbei8OgTOZmY/WlYZJNLDfP5d8GdFbKiA6QWWQQ6';
const TEXT_ENCRYPTION_PREFIX = 'enc:v1:';
const COMPACT_BODY_MAGIC = 'NCB1';
const FILE_ENCRYPTION_MAGIC = 'NEOFILE1';
const FILE_ENCRYPTION_HEADER_BYTES = 24;
const FILE_ENCRYPTION_CHUNK = 1024 * 1024;
const CALL_RING_TTL_SECONDS = 90;
const CALL_HEARTBEAT_GRACE_SECONDS = 120;
const PASSWORD_HASH_PREFIX = 'neo:pwd:v1:';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store, no-cache, max-age=0, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Permissions-Policy: camera=(self), microphone=(self), speaker-selection=(self), picture-in-picture=(self), display-capture=(self), geolocation=(), accelerometer=(), gyroscope=(), magnetometer=(), payment=(), usb=(), browsing-topics=(), interest-cohort=()');
header('Cross-Origin-Opener-Policy: same-origin');
header('Cross-Origin-Resource-Policy: same-origin');
header('X-Permitted-Cross-Domain-Policies: none');
header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet');
header('X-XSS-Protection: 0');
header('X-DNS-Prefetch-Control: off');
header('Origin-Agent-Cluster: ?1');
if (request_is_https()) {
    header('Strict-Transport-Security: max-age=63072000; includeSubDomains');
}

function fail(string $message, int $status = 400): never {
    http_response_code($status);
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function ok(array $data = [], int $status = 200): never {
    http_response_code($status);
    echo json_encode(['ok' => true] + $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function config(): array {
    static $config = null;
    if (is_array($config)) return $config;

    $path = __DIR__ . '/config.php';
    if (!is_file($path)) fail('Missing config.php.', 500);

    $loaded = require $path;
    if (!is_array($loaded)) fail('Invalid config.php.', 500);

    foreach (['host', 'name', 'user', 'pass'] as $key) {
        if (!array_key_exists($key, $loaded)) fail("Missing database setting: {$key}", 500);
    }

    if (
        str_contains((string)$loaded['host'], 'YOUR_') ||
        str_contains((string)$loaded['name'], 'YOUR_') ||
        str_contains((string)$loaded['user'], 'YOUR_')
    ) {
        fail('Edit config.php with your SilkNex MySQL details first.', 503);
    }

    return $config = $loaded;
}

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $cfg = config();
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        (string)$cfg['host'],
        (string)$cfg['name']
    );

    try {
        $pdo = new PDO($dsn, (string)$cfg['user'], (string)$cfg['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_STRINGIFY_FETCHES => false,
            PDO::ATTR_TIMEOUT => 5,
        ]);
    } catch (PDOException $e) {
        fail('Database connection failed. Check the four values in config.php.', 500);
    }

    ensure_schema($pdo);
    return $pdo;
}

function ensure_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;

    // Polling endpoints run often, so avoid re-proving an unchanged schema on
    // every request. Cache readiness briefly per login session and, when
    // available, across PHP workers with APCu. The cache identity includes the
    // database target and schema contract, so deploys/config changes invalidate
    // it automatically.
    $cfg = config();
    $cacheIdentity = implode('|', [
        __DIR__,
        (string)$cfg['host'],
        (string)$cfg['name'],
        (string)$cfg['user'],
        SCHEMA_VERSION,
    ]);
    $runtimeCacheKey = 'neochat-ready:' . hash('sha256', $cacheIdentity);
    $sessionCacheKey = 'schema:' . hash('sha256', $cacheIdentity);
    $runtimeCacheEnabled =
        function_exists('apcu_fetch') &&
        filter_var((string)ini_get('apc.enabled'), FILTER_VALIDATE_BOOL);

    if (session_status() === PHP_SESSION_ACTIVE) {
        $sessionReadyAt = (int)($_SESSION['schema_ready'][$sessionCacheKey] ?? 0);
        if ($sessionReadyAt >= time() - 300) {
            $done = true;
            return;
        }
    }

    if ($runtimeCacheEnabled) {
        $cacheHit = false;
        $cachedReady = @apcu_fetch($runtimeCacheKey, $cacheHit);
        if ($cacheHit && $cachedReady === 1) {
            if (session_status() === PHP_SESSION_ACTIVE) {
                $_SESSION['schema_ready'][$sessionCacheKey] = time();
            }
            $done = true;
            return;
        }
    }

    $rememberReady = static function () use (
        $runtimeCacheEnabled,
        $runtimeCacheKey,
        $sessionCacheKey
    ): void {
        if ($runtimeCacheEnabled) {
            @apcu_store($runtimeCacheKey, 1, 300);
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            if (!isset($_SESSION['schema_ready']) || !is_array($_SESSION['schema_ready'])) {
                $_SESSION['schema_ready'] = [];
            }
            // Keep only the current marker so stale deploy/database identities
            // cannot accumulate in long-lived sessions.
            $_SESSION['schema_ready'] = [$sessionCacheKey => time()];
        }
    };

    $needsSetup = false;
    try {
        $stmt = $pdo->prepare("SELECT meta_value FROM app_meta WHERE meta_key = 'schema_version' LIMIT 1");
        $stmt->execute();
        $version = $stmt->fetchColumn();
        $needsSetup = ((string)$version !== SCHEMA_VERSION);
        if (!$needsSetup) {
            $pdo->query('SELECT online_until, disabled_at, session_version, account_role FROM users LIMIT 0');
        }
    } catch (Throwable $e) {
        $needsSetup = true;
    }

    // The schema version is the migration contract. Older builds performed a
    // full information_schema table/column/index audit on every API request,
    // which made chat polling and login noticeably slower on shared MySQL
    // hosting. A mismatched/missing version still runs the complete idempotent
    // migration below; a current version takes the fast path.
    if (!$needsSetup) {
        ensure_encryption_migrations($pdo);
        // A fresh phpMyAdmin import can already carry the current schema
        // marker. Ensure the built-in founder identity is still initialized
        // instead of only doing it on the runtime DDL path.
        ensure_founder_account($pdo);
        ensure_cofounder_account($pdo);
        $rememberReady();
        $done = true;
        return;
    }

    // Serialize migrations across PHP workers. Prefer MySQL advisory locking,
    // but shared-host providers sometimes disable GET_LOCK(). Falling back to
    // flock keeps first-run/import migrations working on those hosts instead of
    // turning an unsupported advisory lock into a permanent 503.
    $migrationLockName = 'neochat_schema_' . substr(hash('sha256', $cacheIdentity), 0, 32);
    $migrationLockHeld = false;
    $migrationDbLockHeld = false;
    $migrationFileHandle = null;

    try {
        $lockStmt = $pdo->prepare('SELECT GET_LOCK(?, 15)');
        $lockStmt->execute([$migrationLockName]);
        $migrationDbLockHeld = (int)$lockStmt->fetchColumn() === 1;
        $migrationLockHeld = $migrationDbLockHeld;
    } catch (Throwable $e) {
        $migrationDbLockHeld = false;
    }

    if (!$migrationLockHeld) {
        $fileLockCandidates = [
            __DIR__ . '/private/.schema-migration.lock',
            rtrim((string)sys_get_temp_dir(), DIRECTORY_SEPARATOR) .
                DIRECTORY_SEPARATOR . $migrationLockName . '.lock',
        ];

        foreach ($fileLockCandidates as $lockPath) {
            $handle = @fopen($lockPath, 'c+');
            if (!is_resource($handle)) continue;
            @chmod($lockPath, 0600);

            $deadline = microtime(true) + 15.0;
            do {
                if (@flock($handle, LOCK_EX | LOCK_NB)) {
                    $migrationFileHandle = $handle;
                    $migrationLockHeld = true;
                    break 2;
                }
                usleep(100000);
            } while (microtime(true) < $deadline);

            @fclose($handle);
        }
    }

    if (!$migrationLockHeld) {
        fail('SilkNex could not lock the database upgrade. Retry this request.', 503);
    }

    $releaseMigrationLock = static function () use (
        $pdo,
        $migrationLockName,
        &$migrationLockHeld,
        &$migrationDbLockHeld,
        &$migrationFileHandle
    ): void {
        if (!$migrationLockHeld) return;

        if (is_resource($migrationFileHandle)) {
            @flock($migrationFileHandle, LOCK_UN);
            @fclose($migrationFileHandle);
            $migrationFileHandle = null;
        }

        if ($migrationDbLockHeld) {
            try {
                $stmt = $pdo->prepare('SELECT RELEASE_LOCK(?)');
                $stmt->execute([$migrationLockName]);
            } catch (Throwable $e) {
                // MySQL also releases named locks when the connection closes.
            }
        }

        $migrationDbLockHeld = false;
        $migrationLockHeld = false;
    };

    // Another worker may have completed the migration while this request was
    // waiting on the lock. Recheck before issuing any DDL.
    try {
        $stmt = $pdo->prepare("SELECT meta_value FROM app_meta WHERE meta_key = 'schema_version' LIMIT 1");
        $stmt->execute();
        if ((string)$stmt->fetchColumn() === SCHEMA_VERSION) {
            $pdo->query('SELECT online_until, disabled_at, session_version, account_role FROM users LIMIT 0');
            ensure_encryption_migrations($pdo);
            ensure_cofounder_account($pdo);
            $releaseMigrationLock();
            $rememberReady();
            $done = true;
            return;
        }
    } catch (Throwable $e) {
        // Missing app_meta is normal on first install; the idempotent schema
        // creation below will create it while this worker owns the lock.
    }

    $schema = [
        "CREATE TABLE IF NOT EXISTS users (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(24) NOT NULL,
            display_name VARCHAR(40) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            username_changed_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            about VARCHAR(160) NOT NULL DEFAULT '',
            accent VARCHAR(16) NOT NULL DEFAULT 'silver',
            avatar_url VARCHAR(255) NOT NULL DEFAULT '',
            avatar_style TEXT NULL,
            profile_banner_url VARCHAR(255) NOT NULL DEFAULT '',
            public_profile TINYINT(1) NOT NULL DEFAULT 1,
            theme ENUM('system','dark','light','amoled') NOT NULL DEFAULT 'dark',
            app_icon_style ENUM('auto','dark','light') NOT NULL DEFAULT 'auto',
            wallpaper VARCHAR(24) NOT NULL DEFAULT 'neo',
            wallpaper_url VARCHAR(255) NOT NULL DEFAULT '',
            font_scale ENUM('small','normal','large') NOT NULL DEFAULT 'normal',
            font_family ENUM('system','rounded','serif','mono','humanist','condensed','book') NOT NULL DEFAULT 'system',
            ui_accent ENUM('silver','blue','green','purple','orange') NOT NULL DEFAULT 'silver',
            bubble_style ENUM('rounded','soft','square') NOT NULL DEFAULT 'rounded',
            message_density ENUM('compact','normal','spacious') NOT NULL DEFAULT 'normal',
            chat_width ENUM('narrow','normal','wide') NOT NULL DEFAULT 'normal',
            reduce_motion TINYINT(1) NOT NULL DEFAULT 0,
            easy_mode TINYINT(1) NOT NULL DEFAULT 0,
            notifications_enabled TINYINT(1) NOT NULL DEFAULT 0,
            kid_mode TINYINT(1) NOT NULL DEFAULT 0,
            kid_pin_hash VARCHAR(255) NULL,
            kid_blocked_words TEXT NULL,
            passkey_user_handle CHAR(64) NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            last_seen_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            online_until BIGINT UNSIGNED NOT NULL DEFAULT 0,
            session_version INT UNSIGNED NOT NULL DEFAULT 1,
            account_role VARCHAR(24) NOT NULL DEFAULT 'member',
            disabled_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_users_username (username),
            KEY idx_users_last_seen (last_seen_at, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS user_realtime_state (
            user_id BIGINT UNSIGNED NOT NULL,
            inbox_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
            friend_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
            call_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (user_id),
            KEY idx_realtime_updated (updated_at),
            CONSTRAINT fk_realtime_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS conversations (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            kind ENUM('dm','group') NOT NULL,
            direct_key VARCHAR(64) NULL,
            name VARCHAR(60) NULL,
            created_by BIGINT UNSIGNED NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            change_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
            disappearing_seconds INT UNSIGNED NOT NULL DEFAULT 0,
            avatar_url VARCHAR(255) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            UNIQUE KEY uq_conversations_direct_key (direct_key),
            KEY idx_conversations_updated (updated_at),
            CONSTRAINT fk_conversations_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS conversation_members (
            conversation_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            joined_at BIGINT UNSIGNED NOT NULL,
            hidden_at BIGINT UNSIGNED NULL,
            cleared_before_message_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            pinned_at BIGINT UNSIGNED NULL,
            favorite_at BIGINT UNSIGNED NULL,
            archived_at BIGINT UNSIGNED NULL,
            muted_until BIGINT UNSIGNED NULL,
            manual_unread TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (conversation_id, user_id),
            KEY idx_members_user (user_id, conversation_id),
            KEY idx_members_user_pinned (user_id, pinned_at, conversation_id),
            KEY idx_members_user_favorite (user_id, favorite_at, conversation_id),
            KEY idx_members_user_archived (user_id, archived_at, conversation_id),
            KEY idx_members_user_hidden (user_id, hidden_at, conversation_id),
            CONSTRAINT fk_members_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_members_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS messages (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            sender_id BIGINT UNSIGNED NOT NULL,
            body TEXT NOT NULL,
            body_encrypted TINYINT(1) NOT NULL DEFAULT 1,
            body_compact MEDIUMBLOB NULL,
            body_format TINYINT UNSIGNED NOT NULL DEFAULT 0,
            repeat_count SMALLINT UNSIGNED NOT NULL DEFAULT 1,
            e2ee_payload MEDIUMTEXT NULL,
            reply_to_id BIGINT UNSIGNED NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            client_nonce CHAR(32) NULL,
            message_type ENUM('text','image','gif','video','audio','video_note','sticker') NOT NULL DEFAULT 'text',
            attachment_url VARCHAR(1200) NULL,
            attachment_token CHAR(48) NULL,
            attachment_mime VARCHAR(100) NULL,
            attachment_name VARCHAR(180) NULL,
            attachment_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
            duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
            expires_at BIGINT UNSIGNED NULL,
            edited_at BIGINT UNSIGNED NULL,
            deleted_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_messages_sender_nonce (sender_id, client_nonce),
            KEY idx_messages_conversation (conversation_id, id),
            KEY idx_messages_feed_cover (conversation_id, id, deleted_at, expires_at, sender_id),
            KEY idx_messages_updated (conversation_id, updated_at, id),
            KEY idx_messages_sender (sender_id, id),
            KEY idx_messages_created (created_at, id),
            KEY idx_messages_sender_created (sender_id, created_at, id),
            KEY idx_messages_reply (reply_to_id),
            KEY idx_messages_attachment_token (attachment_token),
            KEY idx_messages_expires (expires_at, conversation_id, id),
            CONSTRAINT fk_messages_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_messages_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_messages_reply FOREIGN KEY (reply_to_id) REFERENCES messages(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS conversation_reads (
            conversation_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            last_read_message_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            read_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (conversation_id, user_id),
            CONSTRAINT fk_reads_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_reads_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS rate_limits (
            ip_hash CHAR(64) NOT NULL,
            action_name VARCHAR(32) NOT NULL,
            attempts INT UNSIGNED NOT NULL DEFAULT 0,
            window_started_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (ip_hash, action_name),
            KEY idx_rate_window (window_started_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS auth_tokens (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            selector CHAR(24) NOT NULL,
            token_hash CHAR(64) NOT NULL,
            client_hash CHAR(64) NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            last_used_at BIGINT UNSIGNED NOT NULL,
            expires_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_auth_tokens_selector (selector),
            KEY idx_auth_tokens_user (user_id),
            KEY idx_auth_tokens_expiry (expires_at),
            CONSTRAINT fk_auth_tokens_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS conversation_settings (
            conversation_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            wallpaper VARCHAR(24) NOT NULL DEFAULT 'default',
            wallpaper_url VARCHAR(255) NOT NULL DEFAULT '',
            ringtone VARCHAR(24) NOT NULL DEFAULT 'classic',
            bubble_style ENUM('default','rounded','soft','square') NOT NULL DEFAULT 'default',
            density ENUM('default','compact','normal','spacious') NOT NULL DEFAULT 'default',
            chat_font_scale ENUM('default','small','normal','large') NOT NULL DEFAULT 'default',
            call_banner_text VARCHAR(80) NOT NULL DEFAULT '',
            call_banner_style ENUM('glass','dark','light','accent') NOT NULL DEFAULT 'glass',
            PRIMARY KEY (conversation_id, user_id),
            CONSTRAINT fk_chat_settings_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_chat_settings_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS conversation_deliveries (
            conversation_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            last_delivered_message_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            delivered_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (conversation_id, user_id),
            CONSTRAINT fk_delivery_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_delivery_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS uploads (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            token CHAR(48) NOT NULL,
            purpose ENUM('message','message_e2ee','avatar','wallpaper','story','sticker','ad') NOT NULL,
            media_type ENUM('image','gif','video','audio','video_note','sticker') NOT NULL,
            file_url VARCHAR(255) NOT NULL,
            mime_type VARCHAR(100) NOT NULL,
            original_name VARCHAR(180) NOT NULL,
            file_size BIGINT UNSIGNED NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            used_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_upload_token (token),
            KEY idx_upload_user (user_id, created_at),
            CONSTRAINT fk_upload_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS push_subscriptions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            endpoint_hash CHAR(64) NOT NULL,
            endpoint TEXT NOT NULL,
            p256dh VARCHAR(255) NOT NULL,
            auth VARCHAR(255) NOT NULL,
            user_agent VARCHAR(255) NOT NULL DEFAULT '',
            icon_style ENUM('dark','light') NOT NULL DEFAULT 'dark',
            created_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            last_success_at BIGINT UNSIGNED NULL,
            fail_count INT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY uq_push_endpoint_hash (endpoint_hash),
            KEY idx_push_user (user_id, id),
            CONSTRAINT fk_push_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS push_jobs (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            actor_id BIGINT UNSIGNED NOT NULL,
            conversation_id BIGINT UNSIGNED NOT NULL,
            event_type ENUM('message','call') NOT NULL,
            message_id BIGINT UNSIGNED NULL,
            call_id BIGINT UNSIGNED NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            attempts INT UNSIGNED NOT NULL DEFAULT 0,
            locked_until BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_push_jobs_actor (actor_id, id),
            KEY idx_push_jobs_claim (actor_id, locked_until, id),
            KEY idx_push_jobs_created (created_at),
            CONSTRAINT fk_push_jobs_actor FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_push_jobs_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS passkeys (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            credential_id VARCHAR(512) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
            public_key_cose TEXT NOT NULL,
            sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
            transports VARCHAR(255) NOT NULL DEFAULT '',
            created_at BIGINT UNSIGNED NOT NULL,
            last_used_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY uq_passkey_credential (credential_id),
            KEY idx_passkey_user (user_id),
            CONSTRAINT fk_passkey_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS calls (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            caller_id BIGINT UNSIGNED NOT NULL,
            callee_id BIGINT UNSIGNED NOT NULL,
            call_type ENUM('audio','video') NOT NULL,
            status ENUM('ringing','active','ended','declined') NOT NULL DEFAULT 'ringing',
            created_at BIGINT UNSIGNED NOT NULL,
            answered_at BIGINT UNSIGNED NULL,
            ended_at BIGINT UNSIGNED NULL,
            caller_heartbeat BIGINT UNSIGNED NOT NULL DEFAULT 0,
            callee_heartbeat BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_calls_callee_status (callee_id, status, created_at),
            KEY idx_calls_callee_status_id (callee_id, status, created_at, id),
            KEY idx_calls_caller_status (caller_id, status, created_at),
            KEY idx_calls_status_created (status, created_at, id),
            KEY idx_calls_conversation (conversation_id, created_at),
            CONSTRAINT fk_calls_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_calls_caller FOREIGN KEY (caller_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_calls_callee FOREIGN KEY (callee_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS call_signals (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            call_id BIGINT UNSIGNED NOT NULL,
            sender_id BIGINT UNSIGNED NOT NULL,
            signal_type ENUM('offer','answer','ice','restart') NOT NULL,
            payload TEXT NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_call_signals_call (call_id, id),
            CONSTRAINT fk_call_signals_call FOREIGN KEY (call_id) REFERENCES calls(id) ON DELETE CASCADE,
            CONSTRAINT fk_call_signals_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS stories (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            media_token CHAR(48) NOT NULL,
            media_type ENUM('image','gif','video') NOT NULL,
            caption VARCHAR(500) NOT NULL DEFAULT '',
            visibility ENUM('public','friends','custom') NOT NULL DEFAULT 'friends',
            audience_json TEXT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            expires_at BIGINT UNSIGNED NOT NULL,
            deleted_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            KEY idx_stories_user_expiry (user_id, expires_at, id),
            KEY idx_stories_expiry (expires_at),
            KEY idx_stories_visibility_expiry (visibility, expires_at, user_id, id),
            KEY idx_stories_live (deleted_at, expires_at, visibility, user_id, id),
            KEY idx_stories_media (media_token),
            CONSTRAINT fk_stories_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS story_views (
            story_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            viewed_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (story_id, user_id),
            KEY idx_story_views_user (user_id, viewed_at),
            CONSTRAINT fk_story_views_story FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
            CONSTRAINT fk_story_views_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS friendships (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            pair_key VARCHAR(64) NOT NULL,
            requester_id BIGINT UNSIGNED NOT NULL,
            addressee_id BIGINT UNSIGNED NOT NULL,
            status ENUM('pending','accepted','declined') NOT NULL DEFAULT 'pending',
            created_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            responded_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_friendships_pair (pair_key),
            KEY idx_friendships_requester (requester_id, status, updated_at),
            KEY idx_friendships_addressee (addressee_id, status, updated_at),
            CONSTRAINT fk_friendships_requester FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_friendships_addressee FOREIGN KEY (addressee_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS friend_nicknames (
            viewer_id BIGINT UNSIGNED NOT NULL,
            friend_id BIGINT UNSIGNED NOT NULL,
            nickname VARCHAR(40) NOT NULL DEFAULT '',
            updated_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (viewer_id, friend_id),
            KEY idx_friend_nicknames_friend (friend_id, viewer_id),
            CONSTRAINT fk_nickname_viewer FOREIGN KEY (viewer_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_nickname_friend FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS scheduled_messages (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            sender_id BIGINT UNSIGNED NOT NULL,
            body MEDIUMBLOB NOT NULL,
            e2ee_payload MEDIUMTEXT NULL,
            reply_to_id BIGINT UNSIGNED NULL,
            scheduled_at BIGINT UNSIGNED NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            status ENUM('pending','sent','cancelled') NOT NULL DEFAULT 'pending',
            sent_message_id BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            KEY idx_scheduled_due (status, scheduled_at, id),
            KEY idx_scheduled_sender (sender_id, status, scheduled_at),
            CONSTRAINT fk_scheduled_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_scheduled_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_scheduled_reply FOREIGN KEY (reply_to_id) REFERENCES messages(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS group_change_proposals (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            proposed_by BIGINT UNSIGNED NOT NULL,
            change_type ENUM('name','avatar') NOT NULL,
            proposed_name VARCHAR(60) NULL,
            proposed_avatar_token CHAR(48) NULL,
            status ENUM('open','approved','rejected','expired') NOT NULL DEFAULT 'open',
            created_at BIGINT UNSIGNED NOT NULL,
            expires_at BIGINT UNSIGNED NOT NULL,
            resolved_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            KEY idx_group_proposals_open (conversation_id, status, expires_at),
            CONSTRAINT fk_group_proposal_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_group_proposal_user FOREIGN KEY (proposed_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS group_change_votes (
            proposal_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            vote ENUM('yes','no') NOT NULL,
            voted_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (proposal_id, user_id),
            CONSTRAINT fk_group_vote_proposal FOREIGN KEY (proposal_id) REFERENCES group_change_proposals(id) ON DELETE CASCADE,
            CONSTRAINT fk_group_vote_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS message_reactions (
            message_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            reaction VARCHAR(16) NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (message_id, user_id),
            KEY idx_message_reactions_user (user_id, updated_at),
            CONSTRAINT fk_message_reaction_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            CONSTRAINT fk_message_reaction_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS saved_messages (
            user_id BIGINT UNSIGNED NOT NULL,
            message_id BIGINT UNSIGNED NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (user_id, message_id),
            KEY idx_saved_messages_user_created (user_id, created_at, message_id),
            KEY idx_saved_messages_message (message_id, user_id),
            CONSTRAINT fk_saved_messages_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_saved_messages_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS message_pins (
            conversation_id BIGINT UNSIGNED NOT NULL,
            message_id BIGINT UNSIGNED NOT NULL,
            pinned_by BIGINT UNSIGNED NOT NULL,
            pinned_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (conversation_id, message_id),
            KEY idx_message_pins_conversation (conversation_id, pinned_at, message_id),
            KEY idx_message_pins_user (pinned_by, pinned_at),
            CONSTRAINT fk_message_pins_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_message_pins_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            CONSTRAINT fk_message_pins_user FOREIGN KEY (pinned_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS message_stars (
            user_id BIGINT UNSIGNED NOT NULL,
            message_id BIGINT UNSIGNED NOT NULL,
            conversation_id BIGINT UNSIGNED NOT NULL,
            starred_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (user_id, message_id),
            KEY idx_message_stars_user (user_id, starred_at, message_id),
            KEY idx_message_stars_conversation (conversation_id, user_id, starred_at),
            CONSTRAINT fk_message_stars_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_message_stars_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            CONSTRAINT fk_message_stars_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS message_reminders (
            user_id BIGINT UNSIGNED NOT NULL,
            message_id BIGINT UNSIGNED NOT NULL,
            conversation_id BIGINT UNSIGNED NOT NULL,
            remind_at BIGINT UNSIGNED NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (user_id, message_id),
            KEY idx_message_reminders_due (user_id, remind_at, message_id),
            KEY idx_message_reminders_conversation (conversation_id, user_id, remind_at),
            CONSTRAINT fk_message_reminders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_message_reminders_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
            CONSTRAINT fk_message_reminders_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS user_notification_preferences (
            user_id BIGINT UNSIGNED NOT NULL,
            quiet_enabled TINYINT(1) NOT NULL DEFAULT 0,
            quiet_start_minute SMALLINT UNSIGNED NOT NULL DEFAULT 1320,
            quiet_end_minute SMALLINT UNSIGNED NOT NULL DEFAULT 420,
            timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
            updated_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (user_id),
            CONSTRAINT fk_notification_preferences_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS owner_audit_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            owner_user_id BIGINT UNSIGNED NOT NULL,
            action VARCHAR(64) NOT NULL,
            target VARCHAR(120) NOT NULL DEFAULT '',
            details_json TEXT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_owner_audit_created (created_at, id),
            KEY idx_owner_audit_owner (owner_user_id, created_at, id),
            CONSTRAINT fk_owner_audit_user FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS owner_access_blocks (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            starts_at BIGINT UNSIGNED NOT NULL,
            ends_at BIGINT UNSIGNED NOT NULL,
            note VARCHAR(120) NOT NULL DEFAULT '',
            created_by BIGINT UNSIGNED NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_access_blocks_time (starts_at, ends_at),
            CONSTRAINT fk_access_blocks_owner FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS profile_posts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            media_token CHAR(48) NULL,
            media_type VARCHAR(16) NOT NULL DEFAULT 'text',
            body TEXT NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_profile_posts_user (user_id, id),
            CONSTRAINT fk_profile_post_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS message_repeat_nonces (
            sender_id BIGINT UNSIGNED NOT NULL,
            client_nonce CHAR(32) NOT NULL,
            message_id BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (sender_id, client_nonce),
            KEY idx_repeat_message (message_id),
            CONSTRAINT fk_repeat_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_repeat_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS saved_stickers (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            upload_token CHAR(48) NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_saved_sticker_user_token (user_id, upload_token),
            KEY idx_saved_stickers_user (user_id, created_at, id),
            CONSTRAINT fk_saved_stickers_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",


        "CREATE TABLE IF NOT EXISTS custom_emojis (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            upload_token CHAR(48) NOT NULL,
            shortcode VARCHAR(24) NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_custom_emoji_user_shortcode (user_id, shortcode),
            UNIQUE KEY uq_custom_emoji_user_token (user_id, upload_token),
            KEY idx_custom_emoji_user (user_id, created_at, id),
            CONSTRAINT fk_custom_emoji_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_custom_emoji_upload FOREIGN KEY (upload_token) REFERENCES uploads(token) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS feature_requests (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            title VARCHAR(100) NOT NULL,
            details TEXT NOT NULL,
            status ENUM('submitted','reviewing','planned','closed') NOT NULL DEFAULT 'submitted',
            created_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_feature_requests_user (user_id, created_at, id),
            KEY idx_feature_requests_status (status, updated_at, id),
            CONSTRAINT fk_feature_requests_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS e2ee_devices (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            device_id CHAR(32) NOT NULL,
            public_key_jwk TEXT NOT NULL,
            label VARCHAR(80) NOT NULL DEFAULT '',
            created_at BIGINT UNSIGNED NOT NULL,
            last_seen_at BIGINT UNSIGNED NOT NULL,
            revoked_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_e2ee_user_device (user_id, device_id),
            KEY idx_e2ee_user_active (user_id, revoked_at, last_seen_at),
            CONSTRAINT fk_e2ee_device_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS typing_state (
            conversation_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            expires_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (conversation_id, user_id),
            KEY idx_typing_expiry (expires_at),
            CONSTRAINT fk_typing_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_typing_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS user_ad_state (
            user_id BIGINT UNSIGNED NOT NULL,
            rewarded_count TINYINT UNSIGNED NOT NULL DEFAULT 0,
            ad_pass_until BIGINT UNSIGNED NOT NULL DEFAULT 0,
            subscription_status VARCHAR(24) NOT NULL DEFAULT 'inactive',
            subscription_plan VARCHAR(32) NOT NULL DEFAULT '',
            subscription_started_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            subscription_current_period_end BIGINT UNSIGNED NOT NULL DEFAULT 0,
            stripe_customer_id VARCHAR(255) NULL,
            stripe_subscription_id VARCHAR(255) NULL,
            story_view_counter INT UNSIGNED NOT NULL DEFAULT 0,
            last_interstitial_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (user_id),
            UNIQUE KEY uq_ad_stripe_subscription (stripe_subscription_id),
            CONSTRAINT fk_ad_state_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS ad_reward_sessions (
            id CHAR(48) NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            started_at BIGINT UNSIGNED NOT NULL,
            complete_after BIGINT UNSIGNED NOT NULL,
            expires_at BIGINT UNSIGNED NOT NULL,
            completed_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            KEY idx_ad_reward_user (user_id, expires_at),
            CONSTRAINT fk_ad_reward_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS ad_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            provider VARCHAR(24) NOT NULL DEFAULT 'adsense',
            placement VARCHAR(40) NOT NULL,
            event_type VARCHAR(32) NOT NULL,
            client_key CHAR(32) NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_ad_events_user_time (user_id, created_at),
            KEY idx_ad_events_placement_time (placement, created_at),
            CONSTRAINT fk_ad_events_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS ad_campaigns (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            upload_token CHAR(48) NOT NULL,
            headline VARCHAR(60) NOT NULL,
            destination_url VARCHAR(1000) NOT NULL,
            days TINYINT UNSIGNED NOT NULL,
            price_cents INT UNSIGNED NOT NULL,
            status ENUM('pending','active','expired','cancelled') NOT NULL DEFAULT 'pending',
            stripe_checkout_session_id VARCHAR(255) NULL,
            stripe_payment_intent_id VARCHAR(255) NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            paid_at BIGINT UNSIGNED NULL,
            starts_at BIGINT UNSIGNED NULL,
            ends_at BIGINT UNSIGNED NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_ad_campaign_checkout (stripe_checkout_session_id),
            UNIQUE KEY uq_ad_campaign_payment (stripe_payment_intent_id),
            KEY idx_ad_campaign_user (user_id, created_at, id),
            KEY idx_ad_campaign_active (status, ends_at, starts_at, id),
            KEY idx_ad_campaign_serving (status, starts_at, ends_at, id, user_id),
            KEY idx_ad_campaign_upload (upload_token),
            CONSTRAINT fk_ad_campaign_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_ad_campaign_upload FOREIGN KEY (upload_token) REFERENCES uploads(token) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",


        "CREATE TABLE IF NOT EXISTS conversation_board_items (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            conversation_id BIGINT UNSIGNED NOT NULL,
            created_by BIGINT UNSIGNED NOT NULL,
            kind ENUM('note','task','decision') NOT NULL DEFAULT 'note',
            payload_e2ee MEDIUMTEXT NOT NULL,
            payload_nonce VARCHAR(96) NOT NULL,
            status ENUM('open','done','archived') NOT NULL DEFAULT 'open',
            priority ENUM('low','normal','high') NOT NULL DEFAULT 'normal',
            due_at BIGINT UNSIGNED NULL,
            assigned_user_id BIGINT UNSIGNED NULL,
            created_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY idx_board_conversation (conversation_id, status, updated_at, id),
            KEY idx_board_assignee (assigned_user_id, status, due_at),
            CONSTRAINT fk_board_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_board_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE,
            CONSTRAINT fk_board_assignee FOREIGN KEY (assigned_user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS conversation_canvas (
            conversation_id BIGINT UNSIGNED NOT NULL,
            revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
            payload_e2ee MEDIUMTEXT NOT NULL,
            payload_nonce VARCHAR(96) NOT NULL,
            updated_by BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (conversation_id),
            CONSTRAINT fk_canvas_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_canvas_user FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS conversation_pulses (
            conversation_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            payload_e2ee MEDIUMTEXT NOT NULL,
            payload_nonce VARCHAR(96) NOT NULL,
            expires_at BIGINT UNSIGNED NOT NULL,
            updated_at BIGINT UNSIGNED NOT NULL,
            PRIMARY KEY (conversation_id, user_id),
            KEY idx_pulses_expiry (expires_at),
            CONSTRAINT fk_pulse_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
            CONSTRAINT fk_pulse_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS app_meta (
            meta_key VARCHAR(64) NOT NULL,
            meta_value MEDIUMTEXT NOT NULL,
            PRIMARY KEY (meta_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];

    try {

        foreach (array_merge($schema, v77_schema()) as $sql) $pdo->exec($sql);

        $messageColumns = [
            'body_encrypted' => "TINYINT(1) NOT NULL DEFAULT 0 AFTER body",
            'body_compact' => "MEDIUMBLOB NULL AFTER body_encrypted",
            'body_format' => "TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER body_compact",
            'repeat_count' => "SMALLINT UNSIGNED NOT NULL DEFAULT 1 AFTER body_format",
            'message_type' => "ENUM('text','image','gif','video','audio','video_note','sticker') NOT NULL DEFAULT 'text'",
            'attachment_url' => "VARCHAR(1200) NULL AFTER message_type",
            'attachment_token' => "CHAR(48) NULL AFTER attachment_url",
            'attachment_mime' => "VARCHAR(100) NULL AFTER attachment_url",
            'attachment_name' => "VARCHAR(180) NULL AFTER attachment_mime",
            'attachment_size' => "BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER attachment_name",
            'duration_ms' => "INT UNSIGNED NOT NULL DEFAULT 0 AFTER attachment_size",
            'expires_at' => "BIGINT UNSIGNED NULL AFTER duration_ms",
        ];

        foreach ($messageColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM messages LIKE " . $pdo->quote($columnName)
            )->fetch();

            if (!$exists) {
                $pdo->exec(
                    "ALTER TABLE messages ADD COLUMN {$columnName} {$definition}"
                );
            }
        }

        $e2eeColumn = $pdo->query("SHOW COLUMNS FROM messages LIKE 'e2ee_payload'")->fetch();
        if (!$e2eeColumn) {
            $pdo->exec("ALTER TABLE messages ADD COLUMN e2ee_payload MEDIUMTEXT NULL AFTER body_format");
        }

        $scheduledE2eeColumn = $pdo->query("SHOW COLUMNS FROM scheduled_messages LIKE 'e2ee_payload'")->fetch();
        if (!$scheduledE2eeColumn) {
            $pdo->exec("ALTER TABLE scheduled_messages ADD COLUMN e2ee_payload MEDIUMTEXT NULL AFTER body");
        }

        // v39 adds a distinct encrypted-client upload purpose. MODIFY is safe
        // and idempotent on MySQL/MariaDB even when the enum already matches.
        $pdo->exec(
            "ALTER TABLE uploads
             MODIFY COLUMN purpose ENUM('message','message_e2ee','avatar','wallpaper','banner','story','sticker','ad') NOT NULL"
        );

        $column = $pdo->query("SHOW COLUMNS FROM messages LIKE 'updated_at'")->fetch();
        if (!$column) {
            $pdo->exec("ALTER TABLE messages ADD COLUMN updated_at BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER created_at");
        }

        $pdo->exec(
            "UPDATE messages
             SET updated_at = GREATEST(
               created_at * 1000,
               COALESCE(edited_at, 0) * 1000,
               COALESCE(deleted_at, 0) * 1000
             )
             WHERE updated_at = 0"
        );

        $sessionColumn = $pdo->query("SHOW COLUMNS FROM users LIKE 'session_version'")->fetch();
        if (!$sessionColumn) {
            $pdo->exec(
                "ALTER TABLE users
                 ADD COLUMN session_version INT UNSIGNED NOT NULL DEFAULT 1
                 AFTER last_seen_at"
            );
        }

        $nonceColumn = $pdo->query("SHOW COLUMNS FROM messages LIKE 'client_nonce'")->fetch();
        if (!$nonceColumn) {
            $pdo->exec(
                "ALTER TABLE messages
                 ADD COLUMN client_nonce CHAR(32) NULL
                 AFTER updated_at"
            );
        }

        $lastSeenIndex = $pdo->query(
            "SHOW INDEX FROM users WHERE Key_name = 'idx_users_last_seen'"
        )->fetch();
        if (!$lastSeenIndex) {
            $pdo->exec(
                "ALTER TABLE users
                 ADD KEY idx_users_last_seen (last_seen_at, id)"
            );
        }

        $nonceIndex = $pdo->query(
            "SHOW INDEX FROM messages WHERE Key_name = 'uq_messages_sender_nonce'"
        )->fetch();
        if (!$nonceIndex) {
            $pdo->exec(
                "ALTER TABLE messages
                 ADD UNIQUE KEY uq_messages_sender_nonce (sender_id, client_nonce)"
            );
        }

        $updatedIndex = $pdo->query(
            "SHOW INDEX FROM messages WHERE Key_name = 'idx_messages_updated'"
        )->fetch();

        if (!$updatedIndex) {
            $pdo->exec(
                "ALTER TABLE messages
                 ADD KEY idx_messages_updated (conversation_id, updated_at, id)"
            );
        }

        $attachmentTokenIndex = $pdo->query(
            "SHOW INDEX FROM messages WHERE Key_name = 'idx_messages_attachment_token'"
        )->fetch();

        if (!$attachmentTokenIndex) {
            $pdo->exec(
                "ALTER TABLE messages
                 ADD KEY idx_messages_attachment_token (attachment_token)"
            );
        }

        $expiresIndex = $pdo->query(
            "SHOW INDEX FROM messages WHERE Key_name = 'idx_messages_expires'"
        )->fetch();

        if (!$expiresIndex) {
            $pdo->exec(
                "ALTER TABLE messages
                 ADD KEY idx_messages_expires (expires_at, conversation_id, id)"
            );
        }

        $messageFeedCoverIndex = $pdo->query(
            "SHOW INDEX FROM messages WHERE Key_name = 'idx_messages_feed_cover'"
        )->fetch();

        if (!$messageFeedCoverIndex) {
            $pdo->exec(
                "ALTER TABLE messages
                 ADD KEY idx_messages_feed_cover
                   (conversation_id, id, deleted_at, expires_at, sender_id)"
            );
        }

        $callServingIndex = $pdo->query(
            "SHOW INDEX FROM calls WHERE Key_name = 'idx_calls_callee_status_id'"
        )->fetch();

        if (!$callServingIndex) {
            $pdo->exec(
                "ALTER TABLE calls
                 ADD KEY idx_calls_callee_status_id (callee_id, status, created_at, id)"
            );
        }

        $adServingIndex = $pdo->query(
            "SHOW INDEX FROM ad_campaigns WHERE Key_name = 'idx_ad_campaign_serving'"
        )->fetch();

        if (!$adServingIndex) {
            $pdo->exec(
                "ALTER TABLE ad_campaigns
                 ADD KEY idx_ad_campaign_serving (status, starts_at, ends_at, id, user_id)"
            );
        }

        $adStateColumns = [
            'subscription_plan' => "VARCHAR(32) NOT NULL DEFAULT '' AFTER subscription_status",
            'subscription_started_at' => "BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER subscription_plan",
        ];
        foreach ($adStateColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM user_ad_state LIKE " . $pdo->quote($columnName)
            )->fetch();
            if (!$exists) {
                $pdo->exec("ALTER TABLE user_ad_state ADD COLUMN {$columnName} {$definition}");
            }
        }

        $userColumns = [
            'username_changed_at' => "BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER username",
            'avatar_url' => "VARCHAR(255) NOT NULL DEFAULT '' AFTER accent",
            'avatar_style' => "TEXT NULL AFTER avatar_url",
            'profile_banner_url' => "VARCHAR(255) NOT NULL DEFAULT '' AFTER avatar_style",
            'public_profile' => "TINYINT(1) NOT NULL DEFAULT 1 AFTER profile_banner_url",
            'theme' => "ENUM('system','dark','light','amoled') NOT NULL DEFAULT 'dark' AFTER public_profile",
            'app_icon_style' => "ENUM('auto','dark','light') NOT NULL DEFAULT 'auto' AFTER theme",
            'wallpaper' => "VARCHAR(24) NOT NULL DEFAULT 'neo' AFTER theme",
            'wallpaper_url' => "VARCHAR(255) NOT NULL DEFAULT '' AFTER wallpaper",
            'font_scale' => "ENUM('small','normal','large') NOT NULL DEFAULT 'normal' AFTER wallpaper_url",
            'font_family' => "ENUM('system','rounded','serif','mono') NOT NULL DEFAULT 'system' AFTER font_scale",
            'ui_accent' => "ENUM('silver','blue','green','purple','orange') NOT NULL DEFAULT 'silver' AFTER font_family",
            'bubble_style' => "ENUM('rounded','soft','square') NOT NULL DEFAULT 'rounded' AFTER font_scale",
            'message_density' => "ENUM('compact','normal','spacious') NOT NULL DEFAULT 'normal' AFTER bubble_style",
            'chat_width' => "ENUM('narrow','normal','wide') NOT NULL DEFAULT 'normal' AFTER message_density",
            'reduce_motion' => "TINYINT(1) NOT NULL DEFAULT 0 AFTER chat_width",
            'easy_mode' => "TINYINT(1) NOT NULL DEFAULT 0 AFTER reduce_motion",
            'notifications_enabled' => "TINYINT(1) NOT NULL DEFAULT 0 AFTER easy_mode",
            'kid_mode' => "TINYINT(1) NOT NULL DEFAULT 0 AFTER notifications_enabled",
            'kid_pin_hash' => "VARCHAR(255) NULL AFTER kid_mode",
            'kid_blocked_words' => "TEXT NULL AFTER kid_pin_hash",
            'passkey_user_handle' => "CHAR(64) NULL AFTER kid_blocked_words",
            'account_role' => "VARCHAR(24) NOT NULL DEFAULT 'member' AFTER session_version",
            'disabled_at' => "BIGINT UNSIGNED NULL AFTER account_role",
            'online_until' => "BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER last_seen_at",
        ];

        foreach ($userColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM users LIKE " . $pdo->quote($columnName)
            )->fetch();

            if (!$exists) {
                $pdo->exec(
                    "ALTER TABLE users ADD COLUMN {$columnName} {$definition}"
                );
            }
        }
        $fontColumn = $pdo->query("SHOW COLUMNS FROM users LIKE 'font_family'")->fetch();
        if ($fontColumn && !str_contains((string)$fontColumn['Type'], "'humanist'")) {
            $pdo->exec("ALTER TABLE users MODIFY COLUMN font_family ENUM('system','rounded','serif','mono','humanist','condensed','book') NOT NULL DEFAULT 'system'");
        }

        $storyColumns = [
            'visibility' => "ENUM('public','friends','custom') NOT NULL DEFAULT 'friends' AFTER caption",
            'audience_json' => "TEXT NULL AFTER visibility",
        ];
        foreach ($storyColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM stories LIKE " . $pdo->quote($columnName)
            )->fetch();
            if (!$exists) {
                $pdo->exec("ALTER TABLE stories ADD COLUMN {$columnName} {$definition}");
            }
        }

        $storyVisibilityIndex = $pdo->query(
            "SHOW INDEX FROM stories WHERE Key_name = 'idx_stories_visibility_expiry'"
        )->fetch();
        if (!$storyVisibilityIndex) {
            $pdo->exec(
                "ALTER TABLE stories
                 ADD KEY idx_stories_visibility_expiry (visibility, expires_at, user_id, id)"
            );
        }

        // v59: the story reel reads only live, non-deleted rows. Put those
        // predicates first so a growing archive of expired stories does not
        // make every user's story tab more expensive over time.
        $storyLiveIndex = $pdo->query(
            "SHOW INDEX FROM stories WHERE Key_name = 'idx_stories_live'"
        )->fetch();
        if (!$storyLiveIndex) {
            $pdo->exec(
                "ALTER TABLE stories
                 ADD KEY idx_stories_live (deleted_at, expires_at, visibility, user_id, id)"
            );
        }

        // v22 introduced per-device light/dark notification icons. Existing
        // v21 installs already had push_subscriptions, so CREATE TABLE alone
        // could not add the new column. Keep this explicit migration before
        // the schema version is advanced.
        $pushIconColumn = $pdo->query(
            "SHOW COLUMNS FROM push_subscriptions LIKE 'icon_style'"
        )->fetch();
        if (!$pushIconColumn) {
            $pdo->exec(
                "ALTER TABLE push_subscriptions
                 ADD COLUMN icon_style ENUM('dark','light') NOT NULL DEFAULT 'dark'
                 AFTER user_agent"
            );
        }

        // v28 binds long-lived login tokens to a stable browser family
        // fingerprint. This resists copied-cookie replay without IP binding,
        // so normal Wi-Fi/cellular handoff keeps working.
        $authClientColumn = $pdo->query(
            "SHOW COLUMNS FROM auth_tokens LIKE 'client_hash'"
        )->fetch();
        if (!$authClientColumn) {
            $pdo->exec(
                "ALTER TABLE auth_tokens
                 ADD COLUMN client_hash CHAR(64) NULL
                 AFTER token_hash"
            );
        }

        // v29 claims queued push jobs before contacting push providers. Without
        // this lease, two overlapping flush requests can deliver the same OS
        // notification twice.
        $pushJobLockColumn = $pdo->query(
            "SHOW COLUMNS FROM push_jobs LIKE 'locked_until'"
        )->fetch();
        if (!$pushJobLockColumn) {
            $pdo->exec(
                "ALTER TABLE push_jobs
                 ADD COLUMN locked_until BIGINT UNSIGNED NOT NULL DEFAULT 0
                 AFTER attempts"
            );
        }

        $pushClaimIndex = $pdo->query(
            "SHOW INDEX FROM push_jobs WHERE Key_name = 'idx_push_jobs_claim'"
        )->fetch();
        if (!$pushClaimIndex) {
            $pdo->exec(
                "ALTER TABLE push_jobs
                 ADD INDEX idx_push_jobs_claim (actor_id, locked_until, id)"
            );
        }

        $conversationChangeColumn = $pdo->query(
            "SHOW COLUMNS FROM conversations LIKE 'change_seq'"
        )->fetch();

        if (!$conversationChangeColumn) {
            $pdo->exec(
                "ALTER TABLE conversations
                 ADD COLUMN change_seq BIGINT UNSIGNED NOT NULL DEFAULT 0
                 AFTER updated_at"
            );
        }

        $conversationColumns = [
            'disappearing_seconds' => "INT UNSIGNED NOT NULL DEFAULT 0 AFTER change_seq",
        ];

        foreach ($conversationColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM conversations LIKE " . $pdo->quote($columnName)
            )->fetch();

            if (!$exists) {
                $pdo->exec(
                    "ALTER TABLE conversations ADD COLUMN {$columnName} {$definition}"
                );
            }
        }

        $memberColumns = [
            'hidden_at' => "BIGINT UNSIGNED NULL AFTER joined_at",
            'cleared_before_message_id' => "BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER hidden_at",
            'pinned_at' => "BIGINT UNSIGNED NULL AFTER cleared_before_message_id",
            'favorite_at' => "BIGINT UNSIGNED NULL AFTER pinned_at",
            'archived_at' => "BIGINT UNSIGNED NULL AFTER favorite_at",
            'muted_until' => "BIGINT UNSIGNED NULL AFTER archived_at",
            'manual_unread' => "TINYINT(1) NOT NULL DEFAULT 0 AFTER muted_until",
        ];

        foreach ($memberColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM conversation_members LIKE " . $pdo->quote($columnName)
            )->fetch();

            if (!$exists) {
                $pdo->exec(
                    "ALTER TABLE conversation_members ADD COLUMN {$columnName} {$definition}"
                );
            }
        }

        $memberPinnedIndex = $pdo->query(
            "SHOW INDEX FROM conversation_members WHERE Key_name = 'idx_members_user_pinned'"
        )->fetch();
        if (!$memberPinnedIndex) {
            $pdo->exec(
                "ALTER TABLE conversation_members
                 ADD KEY idx_members_user_pinned (user_id, pinned_at, conversation_id)"
            );
        }

        foreach ([
            'idx_members_user_favorite' => 'ADD KEY idx_members_user_favorite (user_id, favorite_at, conversation_id)',
            'idx_members_user_archived' => 'ADD KEY idx_members_user_archived (user_id, archived_at, conversation_id)',
        ] as $indexName => $indexDefinition) {
            $exists = $pdo->query(
                "SHOW INDEX FROM conversation_members WHERE Key_name = " . $pdo->quote($indexName)
            )->fetch();
            if (!$exists) {
                $pdo->exec("ALTER TABLE conversation_members {$indexDefinition}");
            }
        }

        $messageCreatedIndex = $pdo->query(
            "SHOW INDEX FROM messages WHERE Key_name = 'idx_messages_created'"
        )->fetch();
        if (!$messageCreatedIndex) {
            $pdo->exec(
                "ALTER TABLE messages ADD KEY idx_messages_created (created_at, id)"
            );
        }

        $messageSenderCreatedIndex = $pdo->query(
            "SHOW INDEX FROM messages WHERE Key_name = 'idx_messages_sender_created'"
        )->fetch();
        if (!$messageSenderCreatedIndex) {
            $pdo->exec(
                "ALTER TABLE messages ADD KEY idx_messages_sender_created (sender_id, created_at, id)"
            );
        }

        $userCreatedIndex = $pdo->query(
            "SHOW INDEX FROM users WHERE Key_name = 'idx_users_created'"
        )->fetch();
        if (!$userCreatedIndex) {
            $pdo->exec(
                "ALTER TABLE users ADD KEY idx_users_created (created_at, id)"
            );
        }

        $conversationColumns = [
            'avatar_url' => "VARCHAR(255) NOT NULL DEFAULT '' AFTER disappearing_seconds",
        ];

        foreach ($conversationColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM conversations LIKE " . $pdo->quote($columnName)
            )->fetch();

            if (!$exists) {
                $pdo->exec(
                    "ALTER TABLE conversations ADD COLUMN {$columnName} {$definition}"
                );
            }
        }

        $chatSettingColumns = [
            'ringtone' => "VARCHAR(24) NOT NULL DEFAULT 'classic' AFTER wallpaper_url",
            'bubble_style' => "ENUM('default','rounded','soft','square') NOT NULL DEFAULT 'default' AFTER ringtone",
            'density' => "ENUM('default','compact','normal','spacious') NOT NULL DEFAULT 'default' AFTER bubble_style",
            'chat_font_scale' => "ENUM('default','small','normal','large') NOT NULL DEFAULT 'default' AFTER density",
            'call_banner_text' => "VARCHAR(80) NOT NULL DEFAULT '' AFTER chat_font_scale",
            'call_banner_style' => "ENUM('glass','dark','light','accent') NOT NULL DEFAULT 'glass' AFTER call_banner_text",
        ];

        foreach ($chatSettingColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM conversation_settings LIKE " . $pdo->quote($columnName)
            )->fetch();

            if (!$exists) {
                $pdo->exec(
                    "ALTER TABLE conversation_settings ADD COLUMN {$columnName} {$definition}"
                );
            }
        }

        $pdo->exec(
            "ALTER TABLE users
             MODIFY theme ENUM('system','dark','light','amoled') NOT NULL DEFAULT 'dark'"
        );

        $pdo->exec(
            "ALTER TABLE users
             MODIFY app_icon_style ENUM('auto','dark','light') NOT NULL DEFAULT 'auto'"
        );

        $pdo->exec(
            "ALTER TABLE messages
             MODIFY message_type ENUM('text','image','gif','video','audio','video_note','sticker')
             NOT NULL DEFAULT 'text'"
        );

        $pdo->exec(
            "ALTER TABLE messages
             MODIFY attachment_url VARCHAR(1200) NULL"
        );

        $pdo->exec(
            "ALTER TABLE uploads
             MODIFY purpose ENUM('message','message_e2ee','avatar','wallpaper','banner','story','sticker','ad')
             NOT NULL"
        );

        $pdo->exec(
            "ALTER TABLE uploads
             MODIFY media_type ENUM('image','gif','video','audio','video_note','sticker')
             NOT NULL"
        );

        $callColumns = [
            'caller_heartbeat' => "BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER ended_at",
            'callee_heartbeat' => "BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER caller_heartbeat",
        ];

        foreach ($callColumns as $columnName => $definition) {
            $exists = $pdo->query(
                "SHOW COLUMNS FROM calls LIKE " . $pdo->quote($columnName)
            )->fetch();

            if (!$exists) {
                $pdo->exec(
                    "ALTER TABLE calls ADD COLUMN {$columnName} {$definition}"
                );
            }
        }

        // v24 added ICE restart signaling in the browser but older databases
        // still had an ENUM that rejected the new value. Keep the migration
        // explicit so network changes can recover instead of silently failing.
        $pdo->exec(
            "ALTER TABLE call_signals
             MODIFY signal_type ENUM('offer','answer','ice','restart') NOT NULL"
        );

        // The busy-call lookup checks both caller and callee participation.
        // Existing installs already index callee/status; add the symmetric
        // caller index so large call histories do not turn this into a scan.
        $callerCallIndex = $pdo->query(
            "SHOW INDEX FROM calls WHERE Key_name = 'idx_calls_caller_status'"
        )->fetch();
        if (!$callerCallIndex) {
            $pdo->exec(
                "ALTER TABLE calls
                 ADD INDEX idx_calls_caller_status (caller_id, status, created_at)"
            );
        }

        $callStatusCreatedIndex = $pdo->query(
            "SHOW INDEX FROM calls WHERE Key_name = 'idx_calls_status_created'"
        )->fetch();
        if (!$callStatusCreatedIndex) {
            $pdo->exec(
                "ALTER TABLE calls
                 ADD INDEX idx_calls_status_created (status, created_at, id)"
            );
        }

        $memberHiddenIndex = $pdo->query(
            "SHOW INDEX FROM conversation_members WHERE Key_name = 'idx_members_user_hidden'"
        )->fetch();
        if (!$memberHiddenIndex) {
            $pdo->exec(
                "ALTER TABLE conversation_members
                 ADD INDEX idx_members_user_hidden (user_id, hidden_at, conversation_id)"
            );
        }

        $pushJobsCreatedIndex = $pdo->query(
            "SHOW INDEX FROM push_jobs WHERE Key_name = 'idx_push_jobs_created'"
        )->fetch();
        if (!$pushJobsCreatedIndex) {
            $pdo->exec(
                "ALTER TABLE push_jobs
                 ADD INDEX idx_push_jobs_created (created_at)"
            );
        }

        // v30 expands app_meta so encrypted recovery material and future
        // deployment metadata are not truncated by the old VARCHAR(255).
        $pdo->exec(
            "ALTER TABLE app_meta
             MODIFY meta_value MEDIUMTEXT NOT NULL"
        );

        // WebAuthn credential IDs are base64url and case-sensitive.
        $pdo->exec(
            "ALTER TABLE passkeys
             MODIFY credential_id VARCHAR(512)
             CHARACTER SET ascii COLLATE ascii_bin NOT NULL"
        );

    } catch (Throwable $e) {
        $releaseMigrationLock();
        error_log('[SilkNex schema] ' . $e->getMessage());
        fail('SilkNex could not create its database tables. Make sure the MySQL user can create tables.', 500);
    }

    // The schema marker is written only after storage/encryption migrations
    // succeed. A failed migration can therefore never make a later request
    // incorrectly take the fast path with a partially upgraded database.
    ensure_encryption_migrations($pdo);
    ensure_founder_account($pdo);
    ensure_cofounder_account($pdo);
    set_app_meta_value($pdo, 'schema_version', SCHEMA_VERSION);
    $releaseMigrationLock();
    $rememberReady();
    $done = true;
}

function app_meta_value(PDO $pdo, string $key): ?string {
    $stmt = $pdo->prepare(
        'SELECT meta_value FROM app_meta WHERE meta_key = ? LIMIT 1'
    );
    $stmt->execute([$key]);
    $value = $stmt->fetchColumn();
    return $value === false ? null : (string)$value;
}

function set_app_meta_value(PDO $pdo, string $key, string $value): void {
    $pdo->prepare(
        'INSERT INTO app_meta (meta_key, meta_value)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value)'
    )->execute([$key, $value]);
}


function ensure_founder_account(PDO $pdo): void {
    $lookup = $pdo->prepare(
        'SELECT id, account_role
         FROM users
         WHERE username = ?
         LIMIT 1'
    );
    $lookup->execute([FOUNDER_USERNAME]);
    $existing = $lookup->fetch();

    if ($existing) {
        if ((string)($existing['account_role'] ?? '') !== 'founder_ceo') {
            // Never grant CEO rights to a username that predates bootstrap.
            error_log('[SilkNex] Reserved founder username is already taken; no role changed.');
        }
        return;
    }

    $now = time();

    try {
        $pdo->prepare(
            "INSERT INTO users
             (username, display_name, password_hash, about, accent,
              created_at, updated_at, last_seen_at, session_version, account_role)
             VALUES (?, ?, ?, ?, 'silver', ?, ?, 0, 1, 'founder_ceo')"
        )->execute([
            FOUNDER_USERNAME,
            'Matteo Barreno',
            FOUNDER_BOOTSTRAP_HASH,
            'Founder & CEO of SilkNex',
            $now,
            $now,
        ]);
    } catch (PDOException $e) {
        // Unique username constraint decides a race. Never promote an
        // account inserted by another worker or an existing signup.
        if ((string)$e->getCode() !== '23000') {
            throw $e;
        }
    }
}

function ensure_cofounder_account(PDO $pdo): void {
    $lookup = $pdo->prepare('SELECT id, account_role FROM users WHERE username = ? LIMIT 1');
    $lookup->execute([COFOUNDER_USERNAME]);
    $existing = $lookup->fetch();
    if ($existing) {
        // A pre-existing member must never gain privileges through a deploy.
        if ((string)$existing['account_role'] !== 'cofounder_ceo') {
            error_log('[SilkNex] Reserved co-founder username is already taken; no role changed.');
        }
        return;
    }
    try {
        $now = time();
        $pdo->prepare(
            "INSERT INTO users
             (username, display_name, password_hash, about, accent,
              created_at, updated_at, last_seen_at, session_version, account_role)
             VALUES (?, ?, ?, ?, 'silver', ?, ?, 0, 1, 'cofounder_ceo')"
        )->execute([
            COFOUNDER_USERNAME, 'T0K3N', COFOUNDER_BOOTSTRAP_HASH,
            'Co-Founder & CEO of SilkNex', $now, $now,
        ]);
    } catch (PDOException $e) {
        if ((string)$e->getCode() !== '23000') throw $e;
        // A concurrent insert wins; never promote or reset that account.
    }
}

function migrate_plaintext_messages(PDO $pdo): void {
    if (app_meta_value($pdo, 'message_encryption_v1') === 'done') return;

    master_encryption_key();

    $select = $pdo->prepare(
        'SELECT id, body
         FROM messages
         WHERE body_encrypted = 0
         ORDER BY id ASC
         LIMIT 100'
    );

    $update = $pdo->prepare(
        'UPDATE messages
         SET body = ?, body_encrypted = 1
         WHERE id = ? AND body_encrypted = 0'
    );

    // Keep startup work bounded. Large histories continue migrating across
    // later requests instead of making one login/sync request run for minutes.
    $batches = 0;

    while ($batches < 5) {
        $select->execute();
        $rows = $select->fetchAll();

        if (!$rows) {
            set_app_meta_value($pdo, 'message_encryption_v1', 'done');
            return;
        }

        $pdo->beginTransaction();

        try {
            foreach ($rows as $row) {
                $body = (string)$row['body'];
                $encrypted = $body === '' ? '' : encrypted_message_value($body);
                $update->execute([$encrypted, (int)$row['id']]);
            }

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }

        $batches++;
    }
}

function migrate_compact_messages(PDO $pdo): void {
    if (app_meta_value($pdo, 'message_compact_v1') === 'done') return;

    // Old v9 messages are already encrypted, so this size-optimization
    // migration can be incremental. Limiting each request avoids a huge
    // first-load pause on shared/free hosting with large chat histories.
    $select = $pdo->prepare(
        'SELECT id, body, body_encrypted, body_compact, body_format
         FROM messages
         WHERE body_format = 0
         ORDER BY id ASC
         LIMIT 100'
    );

    $update = $pdo->prepare(
        "UPDATE messages
         SET body = '', body_compact = ?, body_format = 1, body_encrypted = 1
         WHERE id = ? AND body_format = 0"
    );

    $batches = 0;

    while ($batches < 5) {
        $select->execute();
        $rows = $select->fetchAll();

        if (!$rows) {
            set_app_meta_value($pdo, 'message_compact_v1', 'done');
            return;
        }

        $pdo->beginTransaction();

        try {
            foreach ($rows as $row) {
                $plain = decrypted_message_value(
                    (string)$row['body'],
                    (int)$row['body_encrypted']
                );

                $compact = $plain === '' ? '' : encrypted_message_blob($plain);
                $update->execute([$compact, (int)$row['id']]);
            }

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }

        $batches++;
    }
}

function migrate_legacy_media(PDO $pdo): void {
    if (app_meta_value($pdo, 'media_encryption_v1') === 'done') return;

    master_encryption_key();

    $stmt = $pdo->query(
        "SELECT id, token, file_url
         FROM uploads
         WHERE file_url LIKE 'uploads/%'
           AND file_url NOT LIKE '%.nenc'
         ORDER BY id ASC
         LIMIT 12"
    );
    $rows = $stmt->fetchAll();

    foreach ($rows as $row) {
        $uploadId = (int)$row['id'];
        $token = (string)$row['token'];
        $oldUrl = (string)$row['file_url'];

        if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
            error_log('[SilkNex media migration] Invalid upload token for row ' . $uploadId);
            $pdo->prepare(
                "UPDATE uploads SET file_url = ? WHERE id = ?"
            )->execute(['missing:invalid-' . $uploadId, $uploadId]);
            continue;
        }

        $source = resolve_upload_storage_path($oldUrl);

        if ($source === null || !is_file($source)) {
            // The file is already gone, so repeatedly retrying this row only
            // makes every later request slower. Remove stale UI references and
            // quarantine the metadata while preserving the upload row for audit.
            error_log('[SilkNex media migration] Missing or unsafe legacy file: ' . $oldUrl);
            $missingRef = 'missing:' . substr(hash('sha256', $token . '|' . $oldUrl), 0, 40);

            $pdo->beginTransaction();
            try {
                $pdo->prepare(
                    'UPDATE messages
                     SET attachment_url = NULL, attachment_token = NULL
                     WHERE attachment_url = ?'
                )->execute([$oldUrl]);
                $pdo->prepare(
                    "UPDATE users SET avatar_url = '' WHERE avatar_url = ?"
                )->execute([$oldUrl]);
                $pdo->prepare(
                    "UPDATE users SET wallpaper_url = '' WHERE wallpaper_url = ?"
                )->execute([$oldUrl]);
                $pdo->prepare(
                    "UPDATE conversation_settings SET wallpaper_url = '' WHERE wallpaper_url = ?"
                )->execute([$oldUrl]);
                $pdo->prepare(
                    'UPDATE uploads SET file_url = ? WHERE id = ?'
                )->execute([$missingRef, $uploadId]);
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            continue;
        }

        $directory = dirname($source);
        [$destination, $newFileName] = encrypted_media_path($directory);
        encrypt_media_file($source, $destination);

        $relativeDir = dirname($oldUrl);
        $newUrl = ($relativeDir === '.' ? '' : $relativeDir . '/') . $newFileName;
        $mediaRef = media_store_reference($token);

        $pdo->beginTransaction();

        try {
            $pdo->prepare(
                'UPDATE messages
                 SET attachment_token = ?, attachment_url = NULL
                 WHERE attachment_url = ?'
            )->execute([$token, $oldUrl]);

            $pdo->prepare(
                'UPDATE users SET avatar_url = ? WHERE avatar_url = ?'
            )->execute([$mediaRef, $oldUrl]);

            $pdo->prepare(
                'UPDATE users SET wallpaper_url = ? WHERE wallpaper_url = ?'
            )->execute([$mediaRef, $oldUrl]);

            $pdo->prepare(
                'UPDATE conversation_settings
                 SET wallpaper_url = ?
                 WHERE wallpaper_url = ?'
            )->execute([$mediaRef, $oldUrl]);

            $pdo->prepare(
                'UPDATE uploads SET file_url = ? WHERE id = ?'
            )->execute([$newUrl, $uploadId]);

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            @unlink($destination);
            throw $e;
        }

        // uploads/.htaccess blocks direct reads, so an unlink failure cannot
        // expose the old plaintext file. Log it for cleanup without taking the
        // application offline.
        if (!@unlink($source) && is_file($source)) {
            error_log('[SilkNex media migration] Could not remove legacy plaintext orphan: ' . $oldUrl);
        }
    }

    // Repair references from older interrupted migrations incrementally.
    $repairDone = app_meta_value($pdo, 'media_reference_repair_v1') === 'done';
    if (!$repairDone) {
        $cursor = max(0, (int)(app_meta_value($pdo, 'media_reference_repair_cursor_v1') ?? 0));
        $repairStmt = $pdo->prepare(
            "SELECT id, token, file_url
             FROM uploads
             WHERE id > ?
               AND file_url LIKE '%.nenc'
             ORDER BY id ASC
             LIMIT 100"
        );
        $repairStmt->execute([$cursor]);
        $repairRows = $repairStmt->fetchAll();

        foreach ($repairRows as $row) {
            $cursor = max($cursor, (int)$row['id']);
            $token = (string)$row['token'];
            if (!preg_match('/^[a-f0-9]{48}$/', $token)) continue;

            $mediaRef = media_store_reference($token);

            $pdo->prepare(
                'UPDATE messages m
                 INNER JOIN uploads u ON u.token = ?
                 SET m.attachment_token = u.token, m.attachment_url = NULL
                 WHERE m.attachment_url = u.file_url'
            )->execute([$token]);

            $pdo->prepare(
                "UPDATE users
                 SET avatar_url = ?
                 WHERE avatar_url = (SELECT file_url FROM uploads WHERE token = ? LIMIT 1)"
            )->execute([$mediaRef, $token]);

            $pdo->prepare(
                "UPDATE users
                 SET wallpaper_url = ?
                 WHERE wallpaper_url = (SELECT file_url FROM uploads WHERE token = ? LIMIT 1)"
            )->execute([$mediaRef, $token]);

            $pdo->prepare(
                "UPDATE conversation_settings
                 SET wallpaper_url = ?
                 WHERE wallpaper_url = (SELECT file_url FROM uploads WHERE token = ? LIMIT 1)"
            )->execute([$mediaRef, $token]);
        }

        if ($repairRows) {
            set_app_meta_value($pdo, 'media_reference_repair_cursor_v1', (string)$cursor);
        }

        if (count($repairRows) < 100) {
            set_app_meta_value($pdo, 'media_reference_repair_v1', 'done');
            $repairDone = true;
        }
    }

    $remaining = (bool)$pdo->query(
        "SELECT EXISTS(
            SELECT 1
            FROM uploads
            WHERE file_url LIKE 'uploads/%'
              AND file_url NOT LIKE '%.nenc'
            LIMIT 1
         )"
    )->fetchColumn();

    if (!$remaining && $repairDone) {
        set_app_meta_value($pdo, 'media_encryption_v1', 'done');
    }
}

function ensure_encryption_migrations(PDO $pdo): void {
    static $done = false;
    if ($done) return;

    if (!function_exists('openssl_encrypt') || !function_exists('openssl_decrypt')) {
        fail('This PHP server needs OpenSSL for encrypted SilkNex storage.', 503);
    }

    $keyInitTransaction = false;

    try {
        // Serialize key initialization even when database.sql already carries
        // the current schema version. Without this row lock, two simultaneous
        // first requests could generate different keys before either writes the
        // fingerprint/recovery record.
        $pdo->exec(
            "INSERT INTO app_meta (meta_key, meta_value)
             VALUES ('encryption_init_lock_v1', '1')
             ON DUPLICATE KEY UPDATE meta_value = meta_value"
        );
        $pdo->beginTransaction();
        $keyInitTransaction = true;
        $pdo->query(
            "SELECT meta_value
             FROM app_meta
             WHERE meta_key = 'encryption_init_lock_v1'
             FOR UPDATE"
        )->fetchColumn();

        $metaStmt = $pdo->query(
            "SELECT meta_key, meta_value
             FROM app_meta
             WHERE meta_key IN (
               'encryption_key_fingerprint',
               'encryption_key_backup_v1',
               'message_encryption_v1',
               'message_compact_v1',
               'media_encryption_v1'
             )"
        );

        $meta = [];
        foreach ($metaStmt->fetchAll() as $row) {
            $meta[(string)$row['meta_key']] = (string)$row['meta_value'];
        }

        $storedFingerprint = trim((string)($meta['encryption_key_fingerprint'] ?? ''));
        $storedBackup = trim((string)($meta['encryption_key_backup_v1'] ?? ''));

        $key = runtime_master_encryption_key();
        $keySource = $key !== null ? 'runtime' : '';

        if ($key === null) {
            $configured = configured_master_encryption_key();
            if ($configured !== null) {
                $key = $configured;
                $keySource = 'configured';
            }
        }

        if ($key === null) {
            $fileKey = load_master_key_file();
            if ($fileKey !== null) {
                $key = $fileKey;
                $keySource = 'file';
            }
        }

        if ($key === null && $storedBackup !== '') {
            $key = unwrap_master_key_from_database($storedBackup);
            $keySource = 'database-recovery';
        }

        // If there is no recoverable key, determine whether creating a new key
        // is safe. A stale fingerprint by itself is not proof that ciphertext
        // still exists (for example, an emptied/re-imported database).
        if ($key === null) {
            $hasEncryptedMessage = (bool)$pdo->query(
                "SELECT EXISTS(
                    SELECT 1
                    FROM messages
                    WHERE body_encrypted = 1
                      AND (
                        body <> ''
                        OR (body_format = 1 AND OCTET_LENGTH(body_compact) > 0)
                      )
                    LIMIT 1
                 )"
            )->fetchColumn();

            $hasEncryptedMedia = (bool)$pdo->query(
                "SELECT EXISTS(
                    SELECT 1
                    FROM uploads
                    WHERE file_url LIKE '%.nenc'
                    LIMIT 1
                 )"
            )->fetchColumn();

            // v36+ tagged password hashes use a pepper derived from the master
            // key, so they are key-bound even when a site has no messages yet.
            $hasKeyBoundPasswords = (bool)$pdo->query(
                "SELECT EXISTS(
                    SELECT 1
                    FROM users
                    WHERE password_hash LIKE 'neo:pwd:v1:%'
                    LIMIT 1
                 )"
            )->fetchColumn();

            if ($hasEncryptedMessage || $hasEncryptedMedia || $hasKeyBoundPasswords) {
                throw new RuntimeException(
                    'The master encryption key is missing but this database still contains key-bound data. ' .
                    'Restore private/neochat-key.php, SILKNEX_MASTER_KEY, or a v37 encryption_key_backup_v1 recovery record.'
                );
            }

            $key = random_bytes(32);
            $keySource = 'generated';
        }

        if (!is_string($key) || strlen($key) !== 32) {
            throw new RuntimeException('SilkNex resolved an invalid master encryption key.');
        }

        runtime_master_encryption_key($key);
        $fingerprint = hash('sha256', $key);

        if ($storedFingerprint !== '' && !hash_equals($storedFingerprint, $fingerprint)) {
            throw new RuntimeException(
                'The available SilkNex encryption key does not match this database. ' .
                'Do not overwrite the old key if encrypted messages, media, or v36+ password hashes exist.'
            );
        }

        // Older databases may contain encrypted records but no fingerprint.
        // Prove the candidate key against one message/media sample before
        // adopting it and writing recovery metadata.
        if ($storedFingerprint === '') {
            $sample = $pdo->query(
                "SELECT body, body_encrypted, body_compact, body_format
                 FROM messages
                 WHERE body_encrypted = 1
                   AND (
                     body <> ''
                     OR (body_format = 1 AND OCTET_LENGTH(body_compact) > 0)
                   )
                 ORDER BY id ASC
                 LIMIT 1"
            )->fetch();

            if ($sample) {
                message_plain_body(
                    (string)$sample['body'],
                    (int)$sample['body_encrypted'],
                    $sample['body_compact'],
                    (int)$sample['body_format']
                );
            }

            $samplePath = $pdo->query(
                "SELECT file_url
                 FROM uploads
                 WHERE file_url LIKE '%.nenc'
                 ORDER BY id ASC
                 LIMIT 1"
            )->fetchColumn();

            if (is_string($samplePath) && str_starts_with($samplePath, 'uploads/')) {
                $resolvedSample = resolve_upload_storage_path($samplePath);
                if ($resolvedSample === null) {
                    throw new RuntimeException('Encrypted media path is outside SilkNex storage.');
                }
                validate_encrypted_media_key($resolvedSample);
            }
        }

        $filePersisted = false;
        if ($keySource === 'file') {
            $filePersisted = true;
        } elseif ($keySource !== 'configured') {
            $filePersisted = persist_master_key_file($key);
            if (!$filePersisted) {
                error_log(
                    '[SilkNex encryption storage] private/neochat-key.php is not writable; ' .
                    'using the encrypted database recovery copy.'
                );
            }
        }

        // Keep a second encrypted recovery copy in app_meta. This fixes the
        // common shared-host deployment failure where replacing/uploading the
        // application removes private/neochat-key.php. The recovery copy is
        // AES-GCM protected with a key derived from server-side DB credentials.
        $backupStored = $storedBackup !== '';

        if (!$backupStored) {
            $wrapped = wrap_master_key_for_database($key);
            set_app_meta_value($pdo, 'encryption_key_backup_v1', $wrapped);
            $storedBackup = $wrapped;
            $backupStored = true;
        } elseif ($keySource !== 'database-recovery') {
            // Verify that an existing recovery record really belongs to this
            // key. If it is corrupt, replace it only after the fingerprint/key
            // verification above has succeeded.
            try {
                $backupKey = unwrap_master_key_from_database($storedBackup);
                if (!hash_equals($backupKey, $key)) {
                    $wrapped = wrap_master_key_for_database($key);
                    set_app_meta_value($pdo, 'encryption_key_backup_v1', $wrapped);
                    $storedBackup = $wrapped;
                }
            } catch (Throwable $e) {
                $wrapped = wrap_master_key_for_database($key);
                set_app_meta_value($pdo, 'encryption_key_backup_v1', $wrapped);
                $storedBackup = $wrapped;
            }
            $backupStored = true;
        }

        if (
            $keySource !== 'configured' &&
            !$filePersisted &&
            !$backupStored
        ) {
            throw new RuntimeException(
                'SilkNex generated an encryption key but could not persist a durable recovery copy.'
            );
        }

        if ($storedFingerprint === '') {
            set_app_meta_value($pdo, 'encryption_key_fingerprint', $fingerprint);
            $storedFingerprint = $fingerprint;
        }

        // Release the initialization lock before incremental migration routines,
        // which use their own short transactions.
        if ($keyInitTransaction && $pdo->inTransaction()) {
            $pdo->commit();
            $keyInitTransaction = false;
        }

        $migrationsReady =
            ($meta['message_encryption_v1'] ?? '') === 'done' &&
            ($meta['message_compact_v1'] ?? '') === 'done' &&
            ($meta['media_encryption_v1'] ?? '') === 'done';

        if (!$migrationsReady) {
            // Legacy migration must never make the entire product unusable.
            // Each routine is bounded/incremental. New writes already use the
            // current encrypted format, while old rows remain readable until
            // their migration batch succeeds.
            foreach ([
                'messages-at-rest' => 'migrate_plaintext_messages',
                'compact-messages' => 'migrate_compact_messages',
                'legacy-media' => 'migrate_legacy_media',
            ] as $label => $migration) {
                try {
                    $migration($pdo);
                } catch (Throwable $e) {
                    error_log(
                        '[SilkNex encryption migration/' . $label . '] ' .
                        $e->getMessage()
                    );
                }
            }
        }

        $done = true;
    } catch (Throwable $e) {
        if ($keyInitTransaction && $pdo->inTransaction()) {
            $pdo->rollBack();
            $keyInitTransaction = false;
        }

        error_log('[SilkNex encryption storage] ' . $e->getMessage());

        // Give a useful error without exposing paths, credentials, key
        // fingerprints, or ciphertext details to the browser.
        fail(
            'SilkNex encryption storage could not be opened. ' .
            'If this is an existing encrypted database, restore its original key. ' .
            'For a new install, SilkNex v37 can recover through app_meta automatically; check the PHP error log if this continues.',
            500
        );
    }
}

function normalize_vapid_material(mixed $value): ?array {
    if (!is_array($value)) return null;

    $privatePem = (string)($value['private_pem'] ?? '');
    $public = (string)($value['public'] ?? '');

    if ($privatePem === '' || $public === '') return null;
    if (!str_contains($privatePem, 'PRIVATE KEY')) return null;

    try {
        $publicBytes = b64url_decode_raw($public);
    } catch (Throwable $e) {
        return null;
    }

    // Uncompressed P-256 public point: 0x04 + X(32) + Y(32).
    if (strlen($publicBytes) !== 65 || ord($publicBytes[0]) !== 4) return null;

    $key = @openssl_pkey_get_private($privatePem);
    if ($key === false) return null;

    return [
        'private_pem' => $privatePem,
        'public' => $public,
    ];
}

function publish_private_identity_file(string $path, string $contents): bool {
    $directory = dirname($path);
    if (!is_dir($directory) || !is_writable($directory)) return false;
    // A separate persistent lock inode is required: unlinking the lock could
    // let a third worker bypass a process that already holds the old inode.
    $lock = @fopen($path . '.lock', 'c+b');
    if (!is_resource($lock)) return false;
    @chmod($path . '.lock', 0600);
    $temporary = null;
    $handle = null;
    try {
        if (!flock($lock, LOCK_EX)) return false;
        clearstatcache(true, $path);
        if (file_exists($path)) return false;
        $temporary = $path . '.tmp-' . bin2hex(random_bytes(8));
        $handle = @fopen($temporary, 'xb');
        if (!is_resource($handle)) return false;
        if (!@chmod($temporary, 0600)) return false;
        $offset = 0;
        $length = strlen($contents);
        while ($offset < $length) {
            $written = fwrite($handle, substr($contents, $offset));
            if ($written === false || $written === 0) return false;
            $offset += $written;
        }
        if (!fflush($handle)) return false;
        if (function_exists('fsync') && !@fsync($handle)) return false;
        fclose($handle);
        $handle = null;
        // Every v65 publisher rechecks existence under the same lock. Readers
        // only ever see the final, complete file after this atomic rename.
        if (!@rename($temporary, $path)) return false;
        $temporary = null;
        clearstatcache(true, $path);
        return true;
    } finally {
        if (is_resource($handle)) fclose($handle);
        if ($temporary !== null) @unlink($temporary);
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function persist_vapid_key_file(array $material): bool {
    $material = normalize_vapid_material($material);
    if ($material === null) return false;

    try {
        $path = private_storage_dir() . '/neochat-vapid.php';
    } catch (Throwable $e) {
        error_log('[SilkNex push storage] ' . $e->getMessage());
        return false;
    }

    if (is_file($path)) {
        try {
            $loaded = require $path;
            $existing = normalize_vapid_material($loaded);
            return $existing !== null &&
                hash_equals($existing['public'], $material['public']) &&
                hash_equals($existing['private_pem'], $material['private_pem']);
        } catch (Throwable $e) {
            return false;
        }
    }

    if (!is_writable(dirname($path))) return false;

    $php =
        "<?php\n" .
        "declare(strict_types=1);\n" .
        "if (isset(\$_SERVER['SCRIPT_FILENAME']) && realpath((string)\$_SERVER['SCRIPT_FILENAME']) === __FILE__) {\n" .
        "    http_response_code(404);\n" .
        "    exit;\n" .
        "}\n" .
        'return ' . var_export($material, true) . ";\n";

    if (publish_private_identity_file($path, $php)) return true;
    clearstatcache(true, $path);

    // A concurrent request may have won the exclusive-create race. Only treat
    // that as success when it persisted the same VAPID identity.
    if (is_file($path) && is_readable($path)) {
        try {
            $existing = normalize_vapid_material(require $path);
            return $existing !== null &&
                hash_equals($existing['public'], $material['public']) &&
                hash_equals($existing['private_pem'], $material['private_pem']);
        } catch (Throwable $e) {
            return false;
        }
    }

    return false;
}

function vapid_key_material(): array {
    static $material = null;
    if (is_array($material)) return $material;

    if (!defined('OPENSSL_KEYTYPE_EC')) {
        throw new RuntimeException('This PHP server cannot create Web Push keys.');
    }

    $pdo = db();
    $path = null;

    try {
        $path = private_storage_dir() . '/neochat-vapid.php';
    } catch (Throwable $e) {
        error_log('[SilkNex push storage] ' . $e->getMessage());
    }

    if (is_string($path) && is_file($path) && is_readable($path)) {
        try {
            $loaded = require $path;
            $normalized = normalize_vapid_material($loaded);
            if ($normalized !== null) {
                $material = $normalized;

                // Add the encrypted DB recovery copy when upgrading an older
                // installation that only had the private file.
                if (app_meta_value($pdo, 'vapid_key_backup_v1') === null) {
                    try {
                        set_app_meta_value(
                            $pdo,
                            'vapid_key_backup_v1',
                            protect_private_metadata(
                                'vapid-key',
                                json_encode($material, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)
                            )
                        );
                    } catch (Throwable $e) {
                        error_log('[SilkNex push storage] Could not add VAPID recovery copy: ' . $e->getMessage());
                    }
                }

                return $material;
            }
        } catch (Throwable $e) {
            error_log('[SilkNex push storage] Could not read VAPID key file: ' . $e->getMessage());
        }
    }

    // Recover push identity after a deployment replaces /private. Keeping the
    // same VAPID key avoids invalidating every browser's push subscription.
    $storedBackup = app_meta_value($pdo, 'vapid_key_backup_v1');
    if (is_string($storedBackup) && trim($storedBackup) !== '') {
        try {
            $decoded = json_decode(
                unprotect_private_metadata('vapid-key', $storedBackup),
                true,
                8,
                JSON_THROW_ON_ERROR
            );
            $normalized = normalize_vapid_material($decoded);
            if ($normalized !== null) {
                $material = $normalized;
                if (!persist_vapid_key_file($material)) {
                    error_log(
                        '[SilkNex push storage] VAPID key recovered from database; private file is not writable.'
                    );
                }
                return $material;
            }
        } catch (Throwable $e) {
            error_log('[SilkNex push storage] VAPID recovery failed: ' . $e->getMessage());
        }
    }

    $key = openssl_pkey_new([
        'private_key_type' => OPENSSL_KEYTYPE_EC,
        'curve_name' => 'prime256v1',
    ]);

    if ($key === false) {
        throw new RuntimeException('SilkNex could not create a Web Push key.');
    }

    $privatePem = '';
    if (!openssl_pkey_export($key, $privatePem)) {
        throw new RuntimeException('SilkNex could not export its Web Push key.');
    }

    $details = openssl_pkey_get_details($key);
    $x = $details['ec']['x'] ?? null;
    $y = $details['ec']['y'] ?? null;

    if (!is_string($x) || !is_string($y) || strlen($x) !== 32 || strlen($y) !== 32) {
        throw new RuntimeException('SilkNex could not read its Web Push public key.');
    }

    $candidate = [
        'private_pem' => $privatePem,
        'public' => b64url_encode("\x04" . $x . $y),
    ];

    $dbStored = false;

    try {
        $candidateBackup = protect_private_metadata(
            'vapid-key',
            json_encode($candidate, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)
        );

        // First writer wins. This is important on shared hosting where the
        // private directory may be read-only and two phones can request push
        // setup at the same time.
        $pdo->prepare(
            "INSERT INTO app_meta (meta_key, meta_value)
             VALUES ('vapid_key_backup_v1', ?)
             ON DUPLICATE KEY UPDATE meta_value = meta_value"
        )->execute([$candidateBackup]);

        $stored = app_meta_value($pdo, 'vapid_key_backup_v1');
        if (!is_string($stored) || $stored === '') {
            throw new RuntimeException('VAPID recovery row was not saved.');
        }

        $decoded = json_decode(
            unprotect_private_metadata('vapid-key', $stored),
            true,
            8,
            JSON_THROW_ON_ERROR
        );
        $winner = normalize_vapid_material($decoded);
        if ($winner === null) {
            throw new RuntimeException('Saved VAPID recovery material is invalid.');
        }

        $material = $winner;
        $dbStored = true;
    } catch (Throwable $e) {
        error_log('[SilkNex push storage] Could not save VAPID recovery copy: ' . $e->getMessage());
        $material = $candidate;
    }

    $fileStored = persist_vapid_key_file($material);

    if (!$fileStored && !$dbStored) {
        $material = null;
        throw new RuntimeException(
            'SilkNex generated Web Push keys but could not persist them.'
        );
    }

    return $material;
}

function asn1_read_length(string $der, int &$offset): int {
    if ($offset >= strlen($der)) throw new RuntimeException('Invalid DER.');

    $first = ord($der[$offset++]);
    if (($first & 0x80) === 0) return $first;

    $count = $first & 0x7f;
    if ($count < 1 || $count > 4 || $offset + $count > strlen($der)) {
        throw new RuntimeException('Invalid DER length.');
    }

    $length = 0;
    for ($i = 0; $i < $count; $i++) {
        $length = ($length << 8) | ord($der[$offset++]);
    }

    return $length;
}

function ecdsa_der_to_raw(string $der, int $partLength = 32): string {
    $offset = 0;

    if (($der[$offset++] ?? '') !== "\x30") {
        throw new RuntimeException('Invalid ECDSA signature.');
    }

    asn1_read_length($der, $offset);

    $parts = [];
    for ($part = 0; $part < 2; $part++) {
        if (($der[$offset++] ?? '') !== "\x02") {
            throw new RuntimeException('Invalid ECDSA integer.');
        }

        $length = asn1_read_length($der, $offset);
        $value = substr($der, $offset, $length);
        $offset += $length;

        $value = ltrim($value, "\x00");
        if (strlen($value) > $partLength) {
            throw new RuntimeException('ECDSA signature integer is too large.');
        }

        $parts[] = str_pad($value, $partLength, "\x00", STR_PAD_LEFT);
    }

    return $parts[0] . $parts[1];
}

function hkdf_expand_sha256(string $prk, string $info, int $length): string {
    $result = '';
    $previous = '';
    $counter = 1;

    while (strlen($result) < $length) {
        $previous = hash_hmac(
            'sha256',
            $previous . $info . chr($counter),
            $prk,
            true
        );
        $result .= $previous;
        $counter++;
    }

    return substr($result, 0, $length);
}

function p256_public_pem(string $uncompressed): string {
    if (strlen($uncompressed) !== 65 || $uncompressed[0] !== "\x04") {
        throw new RuntimeException('Invalid Push P-256 public key.');
    }

    $prefix = hex2bin(
        '3059301306072a8648ce3d020106082a8648ce3d030107034200'
    );

    $der = $prefix . $uncompressed;

    return "-----BEGIN PUBLIC KEY-----\n" .
        chunk_split(base64_encode($der), 64, "\n") .
        "-----END PUBLIC KEY-----\n";
}

function vapid_jwt(string $endpoint): array {
    $parts = parse_url($endpoint);

    if (
        !is_array($parts) ||
        strtolower((string)($parts['scheme'] ?? '')) !== 'https' ||
        empty($parts['host'])
    ) {
        throw new RuntimeException('Invalid Push endpoint.');
    }

    $aud = 'https://' . $parts['host'];
    if (isset($parts['port'])) $aud .= ':' . (int)$parts['port'];

    $host = preg_replace('/[^A-Za-z0-9.-]+/', '', request_host()) ?: 'example.com';
    $material = vapid_key_material();

    $header = b64url_encode(json_encode(
        ['typ' => 'JWT', 'alg' => 'ES256'],
        JSON_UNESCAPED_SLASHES
    ));
    $payload = b64url_encode(json_encode([
        'aud' => $aud,
        'exp' => time() + 43200,
        'sub' => 'mailto:neochat@' . $host,
    ], JSON_UNESCAPED_SLASHES));

    $unsigned = $header . '.' . $payload;
    $signatureDer = '';

    if (!openssl_sign(
        $unsigned,
        $signatureDer,
        $material['private_pem'],
        OPENSSL_ALGO_SHA256
    )) {
        throw new RuntimeException('SilkNex could not sign a Push request.');
    }

    return [
        'jwt' => $unsigned . '.' . b64url_encode(
            ecdsa_der_to_raw($signatureDer, 32)
        ),
        'public' => (string)$material['public'],
    ];
}

function encrypt_web_push_payload(
    string $payload,
    string $subscriberPublicB64,
    string $authB64
): string {
    $subscriberPublic = b64url_decode_raw($subscriberPublicB64);
    $authSecret = b64url_decode_raw($authB64);

    if (strlen($subscriberPublic) !== 65 || strlen($authSecret) < 16) {
        throw new RuntimeException('Invalid browser Push keys.');
    }

    $ephemeral = openssl_pkey_new([
        'private_key_type' => OPENSSL_KEYTYPE_EC,
        'curve_name' => 'prime256v1',
    ]);

    if ($ephemeral === false) {
        throw new RuntimeException('SilkNex could not create a Push encryption key.');
    }

    $details = openssl_pkey_get_details($ephemeral);
    $x = $details['ec']['x'] ?? null;
    $y = $details['ec']['y'] ?? null;

    if (!is_string($x) || !is_string($y)) {
        throw new RuntimeException('SilkNex could not read its Push encryption key.');
    }

    $serverPublic = "\x04" . $x . $y;
    $peer = openssl_pkey_get_public(p256_public_pem($subscriberPublic));

    if ($peer === false) {
        throw new RuntimeException('Invalid browser Push public key.');
    }

    $shared = openssl_pkey_derive($peer, $ephemeral, 32);

    if (!is_string($shared) || strlen($shared) < 32) {
        throw new RuntimeException('SilkNex could not derive a Push shared secret.');
    }

    $prkKey = hash_hmac('sha256', $shared, $authSecret, true);
    $keyInfo = "WebPush: info\x00" . $subscriberPublic . $serverPublic;
    $ikm = hkdf_expand_sha256($prkKey, $keyInfo, 32);

    $salt = random_bytes(16);
    $prk = hash_hmac('sha256', $ikm, $salt, true);
    $cek = hkdf_expand_sha256(
        $prk,
        "Content-Encoding: aes128gcm\x00",
        16
    );
    $nonce = hkdf_expand_sha256(
        $prk,
        "Content-Encoding: nonce\x00",
        12
    );

    $tag = '';
    $ciphertext = openssl_encrypt(
        $payload . "\x02",
        'aes-128-gcm',
        $cek,
        OPENSSL_RAW_DATA,
        $nonce,
        $tag,
        '',
        16
    );

    if (!is_string($ciphertext) || strlen($tag) !== 16) {
        throw new RuntimeException('SilkNex could not encrypt a Push payload.');
    }

    return $salt .
        pack('N', 4096) .
        chr(strlen($serverPublic)) .
        $serverPublic .
        $ciphertext .
        $tag;
}

function safe_push_target(string $endpoint): array {
    $parts = parse_url($endpoint);

    if (
        !is_array($parts) ||
        strtolower((string)($parts['scheme'] ?? '')) !== 'https' ||
        empty($parts['host'])
    ) {
        throw new RuntimeException('Invalid Web Push endpoint.');
    }

    $host = strtolower(rtrim((string)$parts['host'], '.'));
    $port = isset($parts['port']) ? (int)$parts['port'] : 443;

    if (
        $port !== 443 ||
        $host === 'localhost' ||
        str_ends_with($host, '.localhost') ||
        str_ends_with($host, '.local') ||
        filter_var($host, FILTER_VALIDATE_IP)
    ) {
        throw new RuntimeException('Unsafe Web Push endpoint.');
    }

    $addresses = [];

    if (function_exists('dns_get_record')) {
        $records = @dns_get_record($host, DNS_A | DNS_AAAA);

        if (is_array($records)) {
            foreach ($records as $record) {
                $candidate = (string)($record['ip'] ?? $record['ipv6'] ?? '');
                if ($candidate !== '') $addresses[] = $candidate;
            }
        }
    }

    if (!$addresses) {
        $ipv4 = @gethostbynamel($host);
        if (is_array($ipv4)) {
            $addresses = array_merge($addresses, $ipv4);
        }
    }

    $addresses = array_values(array_unique($addresses));

    usort(
        $addresses,
        static fn(string $a, string $b): int =>
            (int)str_contains($a, ':') <=> (int)str_contains($b, ':')
    );

    foreach ($addresses as $address) {
        if (
            filter_var(
                $address,
                FILTER_VALIDATE_IP,
                FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
            ) !== false
        ) {
            return [
                'host' => $host,
                'port' => $port,
                'ip' => $address,
            ];
        }
    }

    throw new RuntimeException('Web Push endpoint did not resolve to a public address.');
}

function send_web_push(array $subscription, array $payload): int {
    if (!function_exists('curl_init')) return 0;

    $endpoint = (string)$subscription['endpoint'];
    $target = safe_push_target($endpoint);
    $body = encrypt_web_push_payload(
        json_encode(
            $payload,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        ),
        (string)$subscription['p256dh'],
        (string)$subscription['auth']
    );

    $vapid = vapid_jwt($endpoint);
    $curl = curl_init($endpoint);

    curl_setopt_array($curl, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => [
            'Content-Encoding: aes128gcm',
            'Content-Type: application/octet-stream',
            'TTL: 90',
            'Urgency: high',
            'Authorization: vapid t=' . $vapid['jwt'] . ', k=' . $vapid['public'],
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => false,
        CURLOPT_CONNECTTIMEOUT => 2,
        CURLOPT_TIMEOUT => 4,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_RESOLVE => [
            $target['host'] . ':' .
            $target['port'] . ':' .
            (str_contains($target['ip'], ':')
                ? '[' . $target['ip'] . ']'
                : $target['ip'])
        ],
    ]);

    curl_exec($curl);
    $status = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    curl_close($curl);

    return $status;
}

function notification_preview(string $text, int $maxChars = 520): string {
    $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);

    if ($text === '') return '';

    $length = function_exists('mb_strlen')
        ? mb_strlen($text, 'UTF-8')
        : strlen($text);

    if ($length <= $maxChars) return $text;

    $short = function_exists('mb_substr')
        ? mb_substr($text, 0, $maxChars, 'UTF-8')
        : substr($text, 0, $maxChars);

    return rtrim($short) . '…';
}

function queue_push_job(
    PDO $pdo,
    int $actorId,
    int $conversationId,
    string $eventType,
    ?int $messageId = null,
    ?int $callId = null
): void {
    if (!in_array($eventType, ['message','call'], true)) return;

    $pdo->prepare(
        'INSERT INTO push_jobs
         (actor_id, conversation_id, event_type, message_id, call_id, created_at)
         VALUES (?, ?, ?, ?, ?, ?)'
    )->execute([
        $actorId,
        $conversationId,
        $eventType,
        $messageId,
        $callId,
        time()
    ]);
}

function process_push_jobs(PDO $pdo, int $actorId, int $limit = 5): int {
    $limit = min(10, max(1, $limit));

    // Drop poison jobs after several failed processing attempts so one corrupt
    // historical row cannot permanently starve every newer notification.
    $pdo->prepare(
        'DELETE FROM push_jobs WHERE actor_id = ? AND attempts >= 5 LIMIT 50'
    )->execute([$actorId]);

    // Claim jobs with a short database lease before doing network I/O. Message
    // sends can trigger overlapping flushes; unclaimed SELECTs allowed both
    // workers to send the same notification.
    $now = time();
    $leaseUntil = $now + 90;
    $jobs = [];

    $pdo->beginTransaction();
    try {
        $jobsStmt = $pdo->prepare(
            "SELECT pj.*,
                    c.kind AS notification_kind,
                    c.name AS notification_name,
                    c.avatar_url AS notification_avatar_url
             FROM push_jobs pj
             INNER JOIN conversations c ON c.id = pj.conversation_id
             WHERE pj.actor_id = ?
               AND pj.locked_until <= ?
               AND pj.attempts < 5
             ORDER BY pj.id ASC
             LIMIT {$limit}
             FOR UPDATE"
        );
        $jobsStmt->execute([$actorId, $now]);
        $jobs = $jobsStmt->fetchAll();

        if ($jobs) {
            $jobIds = array_map(static fn(array $row): int => (int)$row['id'], $jobs);
            $placeholders = implode(',', array_fill(0, count($jobIds), '?'));
            $pdo->prepare(
                "UPDATE push_jobs
                 SET locked_until = ?, attempts = attempts + 1
                 WHERE id IN ({$placeholders})"
            )->execute(array_merge([$leaseUntil], $jobIds));
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }

    if (!$jobs) return 0;

    $actorStmt = $pdo->prepare(
        'SELECT id, display_name, avatar_url
         FROM users
         WHERE id = ?
         LIMIT 1'
    );
    $actorStmt->execute([$actorId]);
    $actor = $actorStmt->fetch();

    if (!$actor) {
        $jobIds = array_map(static fn(array $row): int => (int)$row['id'], $jobs);
        if ($jobIds) {
            $placeholders = implode(',', array_fill(0, count($jobIds), '?'));
            $pdo->prepare("DELETE FROM push_jobs WHERE id IN ({$placeholders})")->execute($jobIds);
        }
        return 0;
    }

    $processed = 0;

    foreach ($jobs as $job) {
        $conversationId = (int)$job['conversation_id'];

        // Notification identity follows the conversation: DMs show the sender,
        // while groups show the group's name/photo so the OS notification is
        // immediately recognizable even when several members are active.
        $isGroupNotification = (string)($job['notification_kind'] ?? '') === 'group';
        $groupName = trim((string)($job['notification_name'] ?? ''));
        $groupIcon = notification_media_url((string)($job['notification_avatar_url'] ?? ''));

        $title = $isGroupNotification && $groupName !== ''
            ? $groupName
            : (string)$actor['display_name'];
        $body = 'New SilkNex activity';
        $tag = 'chat-' . $conversationId;
        $icon = $isGroupNotification && $groupIcon !== ''
            ? $groupIcon
            : notification_media_url((string)($actor['avatar_url'] ?? ''));
        $data = [
            'conversation_id' => $conversationId,
            'type' => (string)$job['event_type'],
            'conversation_kind' => $isGroupNotification ? 'group' : 'dm',
            'avatar_url' => $icon,
        ];
        $deliverySucceeded = false;
        $transientFailure = false;
        $hadSubscription = false;

        if ((string)$job['event_type'] === 'message') {
            $messageStmt = $pdo->prepare(
                'SELECT body, body_encrypted, body_compact, body_format, e2ee_payload,
                        message_type, deleted_at, expires_at
                 FROM messages
                 WHERE id = ? AND conversation_id = ?
                 LIMIT 1'
            );
            $messageStmt->execute([
                (int)$job['message_id'],
                $conversationId
            ]);
            $message = $messageStmt->fetch();

            if (
                !$message ||
                $message['deleted_at'] !== null ||
                (
                    $message['expires_at'] !== null &&
                    (int)$message['expires_at'] <= time()
                )
            ) {
                $pdo->prepare('DELETE FROM push_jobs WHERE id = ?')
                    ->execute([(int)$job['id']]);
                continue;
            }

            $plain = (string)($message['e2ee_payload'] ?? '') !== ''
                ? 'New message'
                : message_plain_body(
                    (string)$message['body'],
                    (int)$message['body_encrypted'],
                    $message['body_compact'],
                    (int)$message['body_format']
                );

            if ($plain === '') {
                $plain = match ((string)$message['message_type']) {
                    'image' => 'Photo',
                    'gif' => 'GIF',
                    'video' => 'Video',
                    'audio' => 'Voice message',
                    'video_note' => 'Video message',
                    'sticker' => 'Sticker',
                    default => 'New message',
                };
            }

            $body = $isGroupNotification
                ? notification_preview((string)$actor['display_name'] . ': ' . $plain)
                : notification_preview($plain);
            $data['message_id'] = (int)$job['message_id'];
        } elseif ((string)$job['event_type'] === 'call') {
            $callStmt = $pdo->prepare(
                'SELECT call_type, status
                 FROM calls
                 WHERE id = ? AND conversation_id = ?
                 LIMIT 1'
            );
            $callStmt->execute([(int)$job['call_id'], $conversationId]);
            $call = $callStmt->fetch();

            if (!$call || (string)$call['status'] !== 'ringing') {
                $pdo->prepare('DELETE FROM push_jobs WHERE id = ?')
                    ->execute([(int)$job['id']]);
                continue;
            }

            $body = (string)$call['call_type'] === 'video'
                ? 'Incoming video call'
                : 'Incoming audio call';
            $data['call_id'] = (int)$job['call_id'];
            $tag = 'call-' . (int)$job['call_id'];
        }

        $recipientStmt = $pdo->prepare(
            'SELECT u.id, u.kid_mode, u.kid_blocked_words,
                    u.theme, u.app_icon_style,
                    COALESCE(np.quiet_enabled, 0) AS quiet_enabled,
                    COALESCE(np.quiet_start_minute, 1320) AS quiet_start_minute,
                    COALESCE(np.quiet_end_minute, 420) AS quiet_end_minute,
                    COALESCE(np.timezone, \'UTC\') AS quiet_timezone
             FROM conversation_members cm
             INNER JOIN users u
               ON u.id = cm.user_id
              AND u.disabled_at IS NULL
              AND u.notifications_enabled = 1
             LEFT JOIN user_notification_preferences np
               ON np.user_id = u.id
             WHERE cm.conversation_id = ?
               AND cm.user_id <> ?
               AND (
                   ? <> \'message\'
                   OR cm.muted_until IS NULL
                   OR cm.muted_until <= ?
               )'
        );
        $recipientStmt->execute([
            $conversationId,
            $actorId,
            (string)$job['event_type'],
            time(),
        ]);
        $recipients = $recipientStmt->fetchAll();

        foreach ($recipients as $recipient) {
            if (
                (string)$job['event_type'] === 'message' &&
                quiet_hours_active($recipient)
            ) {
                continue;
            }

            $recipientBody = notification_preview(
                censor_for_kid($body, $recipient)
            );

            $recipientTheme = (string)($recipient['theme'] ?? 'dark');
            $defaultIconStyle = (string)($recipient['app_icon_style'] ?? 'auto');
            if ($defaultIconStyle === 'auto') {
                $defaultIconStyle = $recipientTheme === 'light' ? 'light' : 'dark';
            }
            if (!in_array($defaultIconStyle, ['dark','light'], true)) {
                $defaultIconStyle = 'dark';
            }

            $subsStmt = $pdo->prepare(
                'SELECT *
                 FROM push_subscriptions
                 WHERE user_id = ?
                 ORDER BY id DESC
                 LIMIT 8'
            );
            $subsStmt->execute([(int)$recipient['id']]);

            foreach ($subsStmt->fetchAll() as $subscription) {
                $hadSubscription = true;
                $subscriptionIconStyle = (string)($subscription['icon_style'] ?? $defaultIconStyle);
                if (!in_array($subscriptionIconStyle, ['dark','light'], true)) {
                    $subscriptionIconStyle = $defaultIconStyle;
                }
                $recipientIcon = $icon !== ''
                    ? $icon
                    : 'app-icon-' . $subscriptionIconStyle . '-192.png';
                $recipientBadge = 'favicon-' . $subscriptionIconStyle . '-32.png';

                try {
                    $status = send_web_push($subscription, [
                        'title' => $title,
                        'body' => $recipientBody,
                        'tag' => $tag,
                        'icon' => $recipientIcon,
                        'badge' => $recipientBadge,
                        'data' => $data,
                    ]);

                    if (in_array($status, [200,201,202], true)) {
                        $deliverySucceeded = true;
                        $pdo->prepare(
                            'UPDATE push_subscriptions
                             SET last_success_at = ?, fail_count = 0
                             WHERE id = ?'
                        )->execute([time(), (int)$subscription['id']]);
                    } elseif (in_array($status, [404,410], true)) {
                        $pdo->prepare(
                            'DELETE FROM push_subscriptions WHERE id = ?'
                        )->execute([(int)$subscription['id']]);
                    } elseif ($status > 0) {
                        if (
                            in_array($status, [408,425,429], true) ||
                            $status >= 500
                        ) {
                            $transientFailure = true;
                        }
                        $pdo->prepare(
                            'UPDATE push_subscriptions
                             SET fail_count = fail_count + 1
                             WHERE id = ?'
                        )->execute([(int)$subscription['id']]);
                    } else {
                        $transientFailure = true;
                    }
                } catch (Throwable $e) {
                    $transientFailure = true;
                    error_log('[SilkNex push] ' . $e->getMessage());
                }
            }
        }

        // Retry only when every attempted delivery failed transiently. If at
        // least one device already accepted the push, deleting the job avoids
        // duplicate notifications on that device during a partial outage.
        if ($hadSubscription && $transientFailure && !$deliverySucceeded) {
            $retryAt = time() + min(300, 10 * (2 ** min(4, max(0, (int)$job['attempts']))));
            $pdo->prepare(
                'UPDATE push_jobs SET locked_until = ? WHERE id = ?'
            )->execute([$retryAt, (int)$job['id']]);
            continue;
        }

        $pdo->prepare('DELETE FROM push_jobs WHERE id = ?')
            ->execute([(int)$job['id']]);
        $processed++;
    }

    // Global queue housekeeping is shared by the whole install rather than
    // repeated by every sender. The created_at index keeps the bounded sweep
    // cheap even when notification volume is high.
    if (claim_maintenance_slot($pdo, 'push_jobs', 60)) {
        $pdo->prepare(
            'DELETE FROM push_jobs
             WHERE created_at < ?
             ORDER BY created_at ASC
             LIMIT 500'
        )->execute([time() - 86400]);
    }

    return $processed;
}

function release_session_lock(): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
}

function start_session_securely(): void {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Strict');
    ini_set('session.gc_maxlifetime', (string)(60 * 60 * 12));

    $https = request_is_https();

    session_name('neochat_session');
    session_set_cookie_params([
        'lifetime' => 60 * 60 * 12,
        'path' => '/',
        'domain' => '',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);

    if (session_status() !== PHP_SESSION_ACTIVE) session_start();

    $obsoleteAfter = (int)($_SESSION['__obsolete_after'] ?? 0);

    if ($obsoleteAfter > 0 && time() > $obsoleteAfter) {
        // This is an old session ID retained briefly only so requests that
        // were already in flight during rotation do not randomly fail.
        $_SESSION = [];
        session_destroy();

        unset($_COOKIE[session_name()]);
        session_id('');
        session_start();
    }

    if (!isset($_SESSION['created_at'])) {
        session_regenerate_id(true);
        $_SESSION['created_at'] = time();
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        $_SESSION['rate_key'] = bin2hex(random_bytes(24));
    }

    if (empty($_SESSION['rate_key'])) {
        $_SESSION['rate_key'] = bin2hex(random_bytes(24));
    }
}

function rotate_session_id_safely(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) return;

    $now = time();

    // session_regenerate_id(false) keeps the old session file just long enough
    // for AJAX requests that were already sent with the previous cookie.
    // The old copy carries __obsolete_after; the new copy removes it.
    $_SESSION['rotated_at'] = $now;
    $_SESSION['__obsolete_after'] = $now + 20;

    if (!session_regenerate_id(false)) {
        unset($_SESSION['__obsolete_after']);
        throw new RuntimeException('Session ID rotation failed.');
    }

    unset($_SESSION['__obsolete_after']);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['csrf'];
}

function request_is_https(): bool {
    $httpsValue = strtolower(trim((string)($_SERVER['HTTPS'] ?? '')));
    if ($httpsValue !== '' && $httpsValue !== 'off' && $httpsValue !== '0') {
        return true;
    }

    // SERVER_PORT is server-controlled and covers hosts that terminate TLS
    // without populating HTTPS (a pattern seen on some shared-host setups).
    if ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443) {
        return true;
    }

    // Forwarded headers are attacker-controlled unless the origin server is
    // reachable only through a trusted reverse proxy. Opt in explicitly when
    // that deployment topology is in use.
    $trustForwardedProto = filter_var(
        getenv('SILKNEX_TRUST_FORWARDED_PROTO') ?: '0',
        FILTER_VALIDATE_BOOL
    );

    if (!$trustForwardedProto) return false;

    $forwarded = strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')));
    if (str_contains($forwarded, ',')) {
        $forwarded = trim(explode(',', $forwarded, 2)[0]);
    }

    return $forwarded === 'https';
}

function request_is_local_development(): bool {
    $remote = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    if (!in_array($remote, ['127.0.0.1', '::1'], true)) {
        return false;
    }

    $raw = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($raw === '' || preg_match('/[\r\n]/', $raw)) return false;

    $host = parse_url('http://' . $raw, PHP_URL_HOST);
    if (!is_string($host) || $host === '') return false;

    $host = strtolower(rtrim($host, '.'));
    return
        $host === 'localhost' ||
        $host === '127.0.0.1' ||
        $host === '::1' ||
        str_ends_with($host, '.localhost');
}

function require_secure_transport(): void {
    if (request_is_https() || request_is_local_development()) return;

    header('Upgrade: TLS/1.2, HTTP/1.1');
    fail('SilkNex requires HTTPS to protect your account and messages.', 426);
}

function remember_token_pepper(): string {
    $cfg = config();
    return hash(
        'sha256',
        'SilkNex remember token v2|' .
        (string)$cfg['name'] . '|' .
        (string)$cfg['user'] . '|' .
        (string)$cfg['pass']
    );
}

function client_fingerprint(): string {
    $ua = strtolower(trim(substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 512)));
    if ($ua === '') $ua = 'unknown-client';

    // Browser version updates should not sign a phone out. Keep the browser /
    // platform family while removing rapidly changing version sequences.
    $ua = preg_replace('/\d+(?:\.\d+){1,5}/', '#', $ua) ?? $ua;
    $ua = preg_replace('/\s+/', ' ', $ua) ?? $ua;

    return hash_hmac('sha256', 'SilkNex client v1|' . $ua, remember_token_pepper());
}

function remember_token_hash(string $validator): string {
    return hash_hmac('sha256', $validator, remember_token_pepper());
}

function set_remember_cookie(string $value, int $expiresAt): void {
    setcookie('neochat_remember', $value, [
        'expires' => $expiresAt,
        'path' => '/',
        'domain' => '',
        'secure' => request_is_https(),
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
}

function clear_remember_cookie(): void {
    setcookie('neochat_remember', '', [
        'expires' => time() - 3600,
        'path' => '/',
        'domain' => '',
        'secure' => request_is_https(),
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    unset($_COOKIE['neochat_remember']);
}

function issue_remember_token(int $userId): void {
    $pdo = db();
    $now = time();
    $expiresAt = $now + (60 * 60 * 24 * 30);

    $selector = bin2hex(random_bytes(12));
    $validator = bin2hex(random_bytes(32));
    $hash = remember_token_hash($validator);

    // Remove expired tokens and cap stored login devices per account.
    $pdo->prepare('DELETE FROM auth_tokens WHERE expires_at <= ?')->execute([$now]);

    $old = $pdo->prepare(
        'SELECT id FROM auth_tokens
         WHERE user_id = ?
         ORDER BY last_used_at DESC, id DESC
         LIMIT 100'
    );
    $old->execute([$userId]);
    $ids = array_map('intval', array_column($old->fetchAll(), 'id'));
    if (count($ids) >= 10) {
        $remove = array_slice($ids, 9);
        if ($remove) {
            $placeholders = implode(',', array_fill(0, count($remove), '?'));
            $pdo->prepare("DELETE FROM auth_tokens WHERE id IN ({$placeholders})")->execute($remove);
        }
    }

    $pdo->prepare(
        'INSERT INTO auth_tokens
         (user_id, selector, token_hash, client_hash, created_at, last_used_at, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    )->execute([$userId, $selector, $hash, client_fingerprint(), $now, $now, $expiresAt]);

    set_remember_cookie($selector . ':' . $validator, $expiresAt);
    $_COOKIE['neochat_remember'] = $selector . ':' . $validator;
}

function remember_cookie_parts(): ?array {
    $raw = (string)($_COOKIE['neochat_remember'] ?? '');
    if ($raw === '' || !str_contains($raw, ':')) return null;

    [$selector, $validator] = explode(':', $raw, 2);

    if (
        !preg_match('/^[a-f0-9]{24}$/', $selector) ||
        !preg_match('/^[a-f0-9]{64}$/', $validator)
    ) {
        return null;
    }

    return [$selector, $validator];
}

function restore_login_from_token(): bool {
    $parts = remember_cookie_parts();
    if ($parts === null) return false;

    [$selector, $validator] = $parts;
    $pdo = db();

    $stmt = $pdo->prepare(
        'SELECT t.id, t.user_id, t.token_hash, t.client_hash, t.expires_at, u.session_version
         FROM auth_tokens t
         INNER JOIN users u ON u.id = t.user_id
         WHERE t.selector = ?
           AND t.expires_at > ?
           AND u.disabled_at IS NULL
         LIMIT 1'
    );
    $stmt->execute([$selector, time()]);
    $token = $stmt->fetch();

    $storedHash = $token ? (string)$token['token_hash'] : '';
    $modernHash = remember_token_hash($validator);
    $legacyHash = hash('sha256', $validator);

    $storedClientHash = $token ? (string)($token['client_hash'] ?? '') : '';
    $currentClientHash = client_fingerprint();
    $clientMismatch =
        $storedClientHash !== '' &&
        !hash_equals($storedClientHash, $currentClientHash);

    if (
        !$token ||
        $clientMismatch ||
        (!hash_equals($storedHash, $modernHash) && !hash_equals($storedHash, $legacyHash))
    ) {
        if ($token) {
            $pdo->prepare('DELETE FROM auth_tokens WHERE id = ?')->execute([(int)$token['id']]);
        }
        clear_remember_cookie();
        return false;
    }

    // Rotate the secret on every restore so a copied old cookie stops working.
    $newValidator = bin2hex(random_bytes(32));
    $newHash = remember_token_hash($newValidator);
    $now = time();
    $expiresAt = $now + (60 * 60 * 24 * 30);

    $rotate = $pdo->prepare(
        'UPDATE auth_tokens
         SET token_hash = ?, client_hash = ?, last_used_at = ?, expires_at = ?
         WHERE id = ? AND token_hash = ?'
    );
    $rotate->execute([
        $newHash,
        $currentClientHash,
        $now,
        $expiresAt,
        (int)$token['id'],
        $storedHash
    ]);

    if ($rotate->rowCount() !== 1) {
        // A different request already consumed this validator. Never allow an
        // older copied cookie to win a concurrent token-rotation race.
        clear_remember_cookie();
        return false;
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$token['user_id'];
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    $_SESSION['created_at'] = $now;
    $_SESSION['rotated_at'] = $now;
    $_SESSION['last_activity'] = $now;
    $_SESSION['last_seen_touch'] = 0;
    $_SESSION['session_version'] = max(1, (int)($token['session_version'] ?? 1));
    $_SESSION['client_fingerprint'] = $currentClientHash;

    set_remember_cookie($selector . ':' . $newValidator, $expiresAt);
    $_COOKIE['neochat_remember'] = $selector . ':' . $newValidator;

    return true;
}

function revoke_current_remember_token(): void {
    $parts = remember_cookie_parts();

    if ($parts !== null) {
        [$selector] = $parts;
        try {
            db()->prepare('DELETE FROM auth_tokens WHERE selector = ?')->execute([$selector]);
        } catch (Throwable $e) {
            // Still clear the browser cookie even if DB cleanup has a transient failure.
        }
    }

    clear_remember_cookie();
}

function normalized_origin(string $value): string {
    $parts = parse_url(trim($value));
    if (!is_array($parts)) return '';

    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    $host = strtolower(rtrim((string)($parts['host'] ?? ''), '.'));
    if (!in_array($scheme, ['http','https'], true) || $host === '') return '';

    $port = isset($parts['port']) ? (int)$parts['port'] : null;
    if (($scheme === 'https' && $port === 443) || ($scheme === 'http' && $port === 80)) {
        $port = null;
    }

    return $scheme . '://' . $host . ($port ? ':' . $port : '');
}

function current_request_origin(): string {
    $configured = normalized_origin((string)(config()['app_origin'] ?? ''));
    if ($configured !== '') {
        return $configured;
    }

    $scheme = request_is_https() ? 'https' : 'http';
    $hostHeader = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($hostHeader === '' || preg_match('/[\r\n]/', $hostHeader)) return '';

    return normalized_origin($scheme . '://' . $hostHeader);
}

function require_same_origin(): void {
    $expected = current_request_origin();
    if ($expected === '') {
        fail('Invalid request host.', 400);
    }

    $origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? ''));
    if ($origin !== '') {
        $actual = normalized_origin($origin);
        if ($actual === '' || !hash_equals($expected, $actual)) {
            fail('Cross-site request blocked.', 403);
        }
        return;
    }

    // Some older/embedded browsers omit Origin on requests. Referer is a
    // secondary browser-provided fallback; CSRF-protected endpoints still
    // require the per-session token below.
    $referer = trim((string)($_SERVER['HTTP_REFERER'] ?? ''));
    if ($referer !== '') {
        $actual = normalized_origin($referer);
        if ($actual === '' || !hash_equals($expected, $actual)) {
            fail('Cross-site request blocked.', 403);
        }
    }
}

function enforce_fetch_metadata(): void {
    $site = strtolower(trim((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
    if (in_array($site, ['cross-site','same-site'], true)) {
        fail('Cross-site request blocked.', 403);
    }
}

function require_csrf(): void {
    require_same_origin();

    $given = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $expected = (string)($_SESSION['csrf'] ?? '');

    if ($given === '' || $expected === '' || !hash_equals($expected, $given)) {
        fail('Security token expired. Refresh SilkNex and try again.', 403);
    }
}

function body_json(): array {
    $contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);

    if ($contentLength > 65536) {
        fail('Request is too large.', 413);
    }

    $contentType = strtolower(trim((string)($_SERVER['CONTENT_TYPE'] ?? '')));
    if (
        $contentType !== '' &&
        !str_starts_with($contentType, 'application/json')
    ) {
        fail('This endpoint requires JSON.', 415);
    }

    $raw = file_get_contents('php://input', false, null, 0, 65537);
    if ($raw === false || trim($raw) === '') return [];

    if (strlen($raw) > 65536) {
        fail('Request is too large.', 413);
    }

    try {
        $data = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
    } catch (JsonException $e) {
        fail('Invalid JSON request.', 400);
    }

    if (!is_array($data)) {
        fail('Invalid request body.', 400);
    }

    return $data;
}

function clean(mixed $value, int $limit): string {
    $value = trim((string)$value);
    $value = str_replace("\0", '', $value);
    return function_exists('mb_substr')
        ? mb_substr($value, 0, $limit, 'UTF-8')
        : substr($value, 0, $limit);
}

function valid_username(string $username): bool {
    return (bool)preg_match('/^[A-Za-z0-9._-]{3,24}$/', $username);
}

function password_algorithm() {
    return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
}

function password_options(): array {
    if (defined('PASSWORD_ARGON2ID')) {
        // Stronger server-side work factor without asking users for longer
        // passwords. Existing hashes are upgraded transparently after login.
        return [
            'memory_cost' => 32768,
            'time_cost' => 3,
            'threads' => 1,
        ];
    }

    return ['cost' => 13];
}

function derived_password_pepper(): string {
    // Every SilkNex install already owns a private, randomly generated master
    // encryption key outside the public web surface. Derive a purpose-specific
    // secret so a database-only leak is not enough for offline password guesses.
    return bin2hex(encryption_subkey('password-pepper-v1'));
}

function password_pepper(): string {
    $configured = trim((string)(config()['password_pepper'] ?? ''));
    return $configured !== '' ? $configured : derived_password_pepper();
}

function password_material_with_pepper(string $password, string $pepper): string {
    return hash_hmac('sha256', $password, $pepper);
}

function password_material(string $password): string {
    return password_material_with_pepper($password, password_pepper());
}

function password_hash_payload(string $stored): array {
    if (str_starts_with($stored, PASSWORD_HASH_PREFIX)) {
        return [substr($stored, strlen(PASSWORD_HASH_PREFIX)), true];
    }

    return [$stored, false];
}

function hash_password_secure(string $password): string {
    $hash = password_hash(password_material($password), password_algorithm(), password_options());

    if (!is_string($hash) || $hash === '') {
        throw new RuntimeException('Password hashing failed.');
    }

    // Mark server-keyed hashes so normal failed logins do not need to repeat
    // expensive Argon2/bcrypt work against legacy representations.
    return PASSWORD_HASH_PREFIX . $hash;
}

function password_needs_rehash_secure(string $stored): bool {
    [$hash, $tagged] = password_hash_payload($stored);
    return !$tagged || password_needs_rehash($hash, password_algorithm(), password_options());
}

function verify_password_secure(string $password, ?string $stored, ?bool &$usedLegacy = null): bool {
    $usedLegacy = false;
    if ($stored === null || $stored === '') return false;

    [$hash, $tagged] = password_hash_payload($stored);
    if ($hash === '') return false;

    $primaryPepper = password_pepper();
    $derivedPepper = derived_password_pepper();
    $previousPepper = trim((string)(config()['password_pepper_previous'] ?? ''));

    if ($tagged) {
        $materials = [
            password_material_with_pepper($password, $primaryPepper),
        ];

        // Keep controlled migration paths for adding or rotating a dedicated
        // secret, but only when they differ from the primary pepper.
        if (!hash_equals($primaryPepper, $derivedPepper)) {
            $materials[] = password_material_with_pepper($password, $derivedPepper);
        }
        if (
            $previousPepper !== '' &&
            !hash_equals($primaryPepper, $previousPepper) &&
            !hash_equals($derivedPepper, $previousPepper)
        ) {
            $materials[] = password_material_with_pepper($password, $previousPepper);
        }

        foreach ($materials as $index => $material) {
            if (password_verify($material, $hash)) {
                $usedLegacy = ($index !== 0);
                return true;
            }
        }

        return false;
    }

    // v27 and older hashes were untagged password_hash(password). Try that
    // representation first, then tolerate a short-lived pre-release v28 hash.
    if (password_verify($password, $hash)) {
        $usedLegacy = true;
        return true;
    }

    $fallbackPeppers = [$primaryPepper];
    if (!hash_equals($primaryPepper, $derivedPepper)) {
        $fallbackPeppers[] = $derivedPepper;
    }
    if (
        $previousPepper !== '' &&
        !hash_equals($primaryPepper, $previousPepper) &&
        !hash_equals($derivedPepper, $previousPepper)
    ) {
        $fallbackPeppers[] = $previousPepper;
    }

    foreach ($fallbackPeppers as $pepper) {
        if (password_verify(password_material_with_pepper($password, $pepper), $hash)) {
            $usedLegacy = true;
            return true;
        }
    }

    return false;
}

function validate_new_password(string $password, string $username = ''): void {
    if (strlen($password) < 8 || strlen($password) > 256) {
        fail('Password must be between 8 and 256 characters.');
    }

    if (!preg_match('/[0-9]/', $password)) {
        fail('Password must contain at least one number.');
    }

    if (!preg_match('/[^A-Za-z0-9\s]/', $password)) {
        fail('Password must contain at least one symbol.');
    }

    $normalized = strtolower(trim($password));
    $common = [
        'password1!', 'password123!', 'password1234!', 'passw0rd!',
        'qwerty123!', 'qwertyui1!', 'welcome1!', 'welcome123!',
        'letmein1!', 'iloveyou1!', 'admin123!', 'administrator1!',
        'abc12345!', 'abcd1234!', '12345678!', '123456789!',
        '1234567890!', '11111111!', '00000000!', 'football1!',
        'baseball1!', 'dragon123!', 'monkey123!', 'sunshine1!',
        'princess1!', 'computer1!', 'internet1!', 'whatever1!',
        'trustno1!', 'freedom1!', 'shadow123!', 'master123!',
        'neochat1!', 'neochat123!', 'neochat2026!', 'changeme1!',
    ];

    if (in_array($normalized, $common, true)) {
        fail('Choose a less common password.');
    }

    $usernameNormalized = strtolower(trim($username));
    if ($usernameNormalized !== '') {
        if ($normalized === $usernameNormalized) {
            fail('Your password cannot be the same as your username.');
        }

        $collapsed = preg_replace('/[^a-z0-9]/', '', $normalized);
        $userCollapsed = preg_replace('/[^a-z0-9]/', '', $usernameNormalized);
        if (strlen($userCollapsed) >= 4 && $collapsed !== '' && str_contains($collapsed, $userCollapsed)) {
            fail('Choose a password that does not contain your username.');
        }
    }
}

function verify_password_with_timing(string $password, ?string $hash, ?bool &$usedLegacy = null): bool {
    // Match the work factor used for real accounts so a missing username does
    // not have a noticeably cheaper password-check path.
    $dummyHash = defined('PASSWORD_ARGON2ID')
        ? '$argon2id$v=19$m=32768,t=3,p=1$ZHpXUGFRM0FUbjZtQ2xFTg$xy1bnk8ZYjzP9QF3POVXth+b8UUXy07fpRqH5nHSA3Y'
        : '$2y$13$Z4EJKcEzUro8gwa2u1qm3OGkx3ZnV81ukLAf7j1TIptSyP1lQ9nuq';

    if ($hash === null || $hash === '') {
        password_verify(password_material($password), $dummyHash);
        $usedLegacy = false;
        return false;
    }

    return verify_password_secure($password, $hash, $usedLegacy);
}

function now_ms(): int {
    return (int)floor(microtime(true) * 1000);
}


function default_kid_words(): array {
    return [
        'fuck','fucking','fucked','fucker','motherfucker','motherfucking',
        'shit','shitty','bullshit','bitch','bitches','asshole','assholes',
        'bastard','bastards','dick','dicks','cock','cocks','pussy','pussies',
        'cunt','cunts','slut','sluts','whore','whores','damn','goddamn',
        'retard','retarded','jackass','dumbass','dipshit','shithead',
        'wanker','twat','bollocks','prick',
        'porn','porno','pornography','sex','sexting','nude','nudes','naked',
        'blowjob','handjob','orgasm','cum','horny','onlyfans',
        'weed','marijuana','cocaine','heroin','meth','fentanyl','ecstasy',
        'suicide','kill yourself','kys'
    ];
}

function normalized_kid_words(?string $custom): array {
    $words = default_kid_words();

    if ($custom !== null && trim($custom) !== '') {
        foreach (preg_split('/[\r\n,]+/', $custom) ?: [] as $word) {
            $word = strtolower(trim($word));
            if ($word !== '' && strlen($word) <= 40) $words[] = $word;
        }
    }

    return array_values(array_unique($words));
}

function kid_word_pattern(string $word): string {
    $map = [
        'a' => '[a@4]',
        'e' => '[e3]',
        'i' => '[i1!]',
        'o' => '[o0]',
        's' => '[s$5]',
        't' => '[t7]',
        'g' => '[g69]',
        'l' => '[l1]',
    ];

    $parts = [];
    $characters = preg_split('//u', strtolower(trim($word)), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    foreach ($characters as $character) {
        if (preg_match('/\s/u', $character)) {
            $parts[] = '[\W_]+';
            continue;
        }
        $base = $map[$character] ?? preg_quote($character, '/');
        // Catch common obfuscation such as f.u.c.k, sh1t and repeated letters
        // without broadly matching unrelated words.
        $parts[] = '(?:' . $base . '){1,3}[\W_]*';
    }

    $pattern = implode('', $parts);
    return preg_replace('/(?:\[\\\\W_\]\*)$/', '', $pattern) ?? $pattern;
}

function censor_for_kid(string $text, array $viewer): string {
    if ((int)($viewer['kid_mode'] ?? 0) !== 1 || $text === '') return $text;

    // Kid mode also hides direct external contact/link sharing in message
    // previews. E2EE message bodies are filtered on the recipient device too.
    $text = preg_replace('~\b(?:https?://|www\.)\S+~iu', '[link hidden]', $text) ?? $text;
    $text = preg_replace('/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/iu', '[email hidden]', $text) ?? $text;

    foreach (normalized_kid_words((string)($viewer['kid_blocked_words'] ?? '')) as $word) {
        $pattern = kid_word_pattern($word);
        $replacement = str_repeat('•', max(3, min(12, strlen($word))));
        $text = preg_replace(
            '/(?<![\pL\pN])' . $pattern . '(?![\pL\pN])/iu',
            $replacement,
            $text
        ) ?? $text;
    }

    return $text;
}

function b64url_encode(string $bytes): string {
    return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
}

function b64url_decode_raw(string $value): string {
    $value = strtr($value, '-_', '+/');
    $pad = strlen($value) % 4;
    if ($pad) $value .= str_repeat('=', 4 - $pad);

    $decoded = base64_decode($value, true);

    if ($decoded === false) {
        throw new RuntimeException('Invalid base64url data.');
    }

    return $decoded;
}

function b64url_decode(string $value): string {
    try {
        return b64url_decode_raw($value);
    } catch (Throwable $e) {
        fail('Invalid encoded data.', 400);
    }
}


function private_storage_candidates(): array {
    $candidates = [];

    $configured = trim((string)(getenv('SILKNEX_PRIVATE_DIR') ?: ''));
    if ($configured !== '') {
        $candidates[] = rtrim($configured, DIRECTORY_SEPARATOR);
    }

    $candidates[] = __DIR__ . '/private';

    // A sibling directory sits outside the public SilkNex folder on the common
    // shared-host layout. It is a safe fallback when an uploaded /private
    // directory is readable by PHP but not writable by the PHP worker.
    $parent = dirname(__DIR__);
    if ($parent !== '' && $parent !== __DIR__) {
        $candidates[] = $parent . '/.neochat-private';
    }

    return array_values(array_unique(array_filter($candidates)));
}

function private_storage_dir(): string {
    static $resolved = null;
    if (is_string($resolved) && $resolved !== '') return $resolved;

    $candidates = private_storage_candidates();

    // Preserve an existing message key before considering a different
    // writable location. The encryption key is more important than the push
    // key because moving away from it would make ciphertext/password peppers
    // unreadable.
    foreach ($candidates as $candidate) {
        if (
            is_dir($candidate) &&
            is_readable($candidate) &&
            is_file($candidate . '/neochat-key.php')
        ) {
            return $resolved = $candidate;
        }
    }

    // If there is no message-key file, preserve an existing VAPID identity
    // before creating a new private directory elsewhere.
    foreach ($candidates as $candidate) {
        if (
            is_dir($candidate) &&
            is_readable($candidate) &&
            is_file($candidate . '/neochat-vapid.php')
        ) {
            return $resolved = $candidate;
        }
    }

    foreach ($candidates as $candidate) {
        if (!is_dir($candidate)) {
            @mkdir($candidate, 0750, true);
        }

        if (is_dir($candidate) && is_readable($candidate) && is_writable($candidate)) {
            @chmod($candidate, 0750);

            $guard = $candidate . '/.htaccess';
            if (!is_file($guard)) {
                @file_put_contents(
                    $guard,
                    "Options -Indexes\n" .
                    "<IfModule mod_authz_core.c>\n" .
                    "  Require all denied\n" .
                    "</IfModule>\n" .
                    "<IfModule !mod_authz_core.c>\n" .
                    "  Order allow,deny\n" .
                    "  Deny from all\n" .
                    "</IfModule>\n"
                );
            }

            return $resolved = $candidate;
        }
    }

    // Reading an uploaded private directory is still useful because v37 can
    // recover/write the master key from an encrypted database backup even when
    // PHP cannot write files there.
    foreach ($candidates as $candidate) {
        if (is_dir($candidate) && is_readable($candidate)) {
            return $resolved = $candidate;
        }
    }

    throw new RuntimeException(
        'SilkNex cannot access a private storage directory. Set SILKNEX_PRIVATE_DIR to a persistent writable directory.'
    );
}

function encryption_key_path(): string {
    return private_storage_dir() . '/neochat-key.php';
}

function decode_master_key_value(string $value): ?string {
    $value = trim($value);
    if ($value === '') return null;

    if (preg_match('/^[a-f0-9]{64}$/i', $value)) {
        $decoded = hex2bin($value);
        return is_string($decoded) && strlen($decoded) === 32 ? $decoded : null;
    }

    $decoded = base64_decode($value, true);
    if (is_string($decoded) && strlen($decoded) === 32) return $decoded;

    try {
        $decoded = b64url_decode_raw($value);
        return strlen($decoded) === 32 ? $decoded : null;
    } catch (Throwable $e) {
        return null;
    }
}

function runtime_master_encryption_key(?string $set = null): ?string {
    static $key = null;

    if ($set !== null) {
        if (strlen($set) !== 32) {
            throw new RuntimeException('SilkNex master key must contain exactly 32 bytes.');
        }
        $key = $set;
    }

    return $key;
}

function configured_master_encryption_key(): ?string {
    $configured = trim((string)(
        getenv('SILKNEX_MASTER_KEY') ?: (config()['master_encryption_key'] ?? '')
    ));

    if ($configured === '') return null;

    $decoded = decode_master_key_value($configured);
    if ($decoded === null) {
        throw new RuntimeException(
            'SILKNEX_MASTER_KEY/master_encryption_key must be a 32-byte key encoded as base64, base64url, or 64 hex characters.'
        );
    }

    return $decoded;
}

function load_master_key_file(): ?string {
    try {
        $path = encryption_key_path();
    } catch (Throwable $e) {
        error_log('[SilkNex encryption storage] ' . $e->getMessage());
        return null;
    }

    if (!is_file($path) || !is_readable($path)) return null;

    try {
        $loaded = require $path;
    } catch (Throwable $e) {
        throw new RuntimeException(
            'SilkNex encryption key file exists but PHP could not read it.'
        );
    }

    if (!is_string($loaded)) {
        throw new RuntimeException(
            'SilkNex encryption key file is invalid. Restore private/neochat-key.php from backup.'
        );
    }

    $decoded = decode_master_key_value($loaded);
    if ($decoded === null) {
        throw new RuntimeException(
            'SilkNex encryption key file is invalid. Restore private/neochat-key.php from backup.'
        );
    }

    return $decoded;
}

function persist_master_key_file(string $key): bool {
    if (strlen($key) !== 32) return false;

    try {
        $path = encryption_key_path();
    } catch (Throwable $e) {
        error_log('[SilkNex encryption storage] ' . $e->getMessage());
        return false;
    }

    if (is_file($path)) {
        try {
            $existing = load_master_key_file();
            return is_string($existing) && hash_equals($existing, $key);
        } catch (Throwable $e) {
            error_log('[SilkNex encryption storage] ' . $e->getMessage());
            return false;
        }
    }

    $encoded = base64_encode($key);
    $contents =
        "<?php\n" .
        "declare(strict_types=1);\n" .
        "if (isset(\$_SERVER['SCRIPT_FILENAME']) && realpath((string)\$_SERVER['SCRIPT_FILENAME']) === __FILE__) {\n" .
        "    http_response_code(404);\n" .
        "    exit;\n" .
        "}\n" .
        "return '" . addslashes($encoded) . "';\n";

    if (publish_private_identity_file($path, $contents)) return true;
    clearstatcache(true, $path);

    if (is_file($path)) {
        try {
            $existing = load_master_key_file();
            return is_string($existing) && hash_equals($existing, $key);
        } catch (Throwable $e) {
            return false;
        }
    }

    return false;
}

function encryption_recovery_wrap_key(): string {
    $cfg = config();

    // This key protects the database-resident recovery copy. It deliberately
    // depends on a server-side secret (the DB password), so a database-only
    // backup still does not contain the plaintext message key.
    $ikm = implode("\0", [
        (string)($cfg['pass'] ?? ''),
        (string)($cfg['user'] ?? ''),
        (string)($cfg['name'] ?? ''),
        (string)($cfg['host'] ?? ''),
    ]);

    if ($ikm === "\0\0\0") {
        throw new RuntimeException('SilkNex cannot derive its encryption recovery key.');
    }

    return hash_hkdf(
        'sha256',
        $ikm,
        32,
        'SilkNex encrypted master-key recovery v1',
        (string)($cfg['name'] ?? 'SilkNex')
    );
}

function wrap_master_key_for_database(string $key): string {
    if (strlen($key) !== 32) {
        throw new RuntimeException('SilkNex cannot back up an invalid master key.');
    }

    $iv = random_bytes(12);
    $tag = '';
    $ciphertext = openssl_encrypt(
        $key,
        'aes-256-gcm',
        encryption_recovery_wrap_key(),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        'SilkNex master key backup v1',
        16
    );

    if (!is_string($ciphertext) || strlen($tag) !== 16) {
        throw new RuntimeException('SilkNex could not protect its encryption-key recovery copy.');
    }

    return 'v1.' .
        b64url_encode($iv) . '.' .
        b64url_encode($tag) . '.' .
        b64url_encode($ciphertext);
}

function unwrap_master_key_from_database(string $stored): string {
    $parts = explode('.', trim($stored), 4);
    if (count($parts) !== 4 || $parts[0] !== 'v1') {
        throw new RuntimeException('SilkNex encryption-key recovery metadata is invalid.');
    }

    $iv = b64url_decode_raw($parts[1]);
    $tag = b64url_decode_raw($parts[2]);
    $ciphertext = b64url_decode_raw($parts[3]);

    if (strlen($iv) !== 12 || strlen($tag) !== 16) {
        throw new RuntimeException('SilkNex encryption-key recovery metadata is malformed.');
    }

    $key = openssl_decrypt(
        $ciphertext,
        'aes-256-gcm',
        encryption_recovery_wrap_key(),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        'SilkNex master key backup v1'
    );

    if (!is_string($key) || strlen($key) !== 32) {
        throw new RuntimeException(
            'SilkNex could not unlock its encryption-key recovery copy. The database credentials may have changed.'
        );
    }

    return $key;
}

function master_encryption_key(): string {
    $runtime = runtime_master_encryption_key();
    if (is_string($runtime) && strlen($runtime) === 32) return $runtime;

    if (!function_exists('openssl_encrypt') || !function_exists('openssl_decrypt')) {
        throw new RuntimeException('This PHP server needs OpenSSL for encrypted SilkNex messages.');
    }

    $configured = configured_master_encryption_key();
    if ($configured !== null) {
        runtime_master_encryption_key($configured);
        return $configured;
    }

    $fileKey = load_master_key_file();
    if ($fileKey !== null) {
        runtime_master_encryption_key($fileKey);
        return $fileKey;
    }

    // Schema readiness can be cached for a few minutes, so a deployment whose
    // PHP worker cannot write private/neochat-key.php may reach an encryption
    // operation without ensure_encryption_migrations() running in this request.
    // Recover directly from app_meta in that case. db() is safe here because
    // its PDO instance is assigned before ensure_schema() is called.
    try {
        $pdo = db();
        $storedBackup = app_meta_value($pdo, 'encryption_key_backup_v1');
        if (is_string($storedBackup) && trim($storedBackup) !== '') {
            $recovered = unwrap_master_key_from_database($storedBackup);
            runtime_master_encryption_key($recovered);
            persist_master_key_file($recovered);
            return $recovered;
        }
    } catch (Throwable $e) {
        error_log('[SilkNex encryption recovery] ' . $e->getMessage());
    }

    // Never generate a replacement here. Existing ciphertext and v36+
    // password hashes are bound to the original key.
    throw new RuntimeException(
        'SilkNex encryption key has not been initialized for this request.'
    );
}

function encryption_subkey(string $purpose): string {
    return hash_hmac('sha256', 'SilkNex|' . $purpose, master_encryption_key(), true);
}

function protect_private_metadata(string $purpose, string $plain): string {
    $purpose = trim($purpose);
    if ($purpose === '' || strlen($purpose) > 80) {
        throw new RuntimeException('Invalid private metadata purpose.');
    }

    $iv = random_bytes(12);
    $tag = '';
    $ciphertext = openssl_encrypt(
        $plain,
        'aes-256-gcm',
        encryption_subkey('private-metadata-v1|' . $purpose),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        'SilkNex private metadata v1|' . $purpose,
        16
    );

    if (!is_string($ciphertext) || strlen($tag) !== 16) {
        throw new RuntimeException('SilkNex could not protect private metadata.');
    }

    return 'v1.' .
        b64url_encode($iv) . '.' .
        b64url_encode($tag) . '.' .
        b64url_encode($ciphertext);
}

function unprotect_private_metadata(string $purpose, string $stored): string {
    $purpose = trim($purpose);
    $parts = explode('.', trim($stored), 4);

    if ($purpose === '' || count($parts) !== 4 || $parts[0] !== 'v1') {
        throw new RuntimeException('SilkNex private metadata is malformed.');
    }

    $iv = b64url_decode_raw($parts[1]);
    $tag = b64url_decode_raw($parts[2]);
    $ciphertext = b64url_decode_raw($parts[3]);

    if (strlen($iv) !== 12 || strlen($tag) !== 16) {
        throw new RuntimeException('SilkNex private metadata is malformed.');
    }

    $plain = openssl_decrypt(
        $ciphertext,
        'aes-256-gcm',
        encryption_subkey('private-metadata-v1|' . $purpose),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        'SilkNex private metadata v1|' . $purpose
    );

    if (!is_string($plain)) {
        throw new RuntimeException('SilkNex could not open private metadata.');
    }

    return $plain;
}

function encrypted_message_value(string $plain): string {
    if ($plain === '') return '';

    $iv = random_bytes(12);
    $tag = '';
    $ciphertext = openssl_encrypt(
        $plain,
        'aes-256-gcm',
        encryption_subkey('message-body-v1'),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        'SilkNex message body v1',
        16
    );

    if (!is_string($ciphertext) || strlen($tag) !== 16) {
        fail('SilkNex could not encrypt the message.', 500);
    }

    return TEXT_ENCRYPTION_PREFIX .
        b64url_encode($iv) . '.' .
        b64url_encode($tag) . '.' .
        b64url_encode($ciphertext);
}

function encrypted_message_blob(string $plain): string {
    if ($plain === '') return '';

    $payload = $plain;
    $flags = 0;

    if (strlen($plain) >= 96 && function_exists('gzdeflate')) {
        $compressed = gzdeflate($plain, 6);

        if (is_string($compressed) && strlen($compressed) + 8 < strlen($plain)) {
            $payload = $compressed;
            $flags |= 1;
        }
    }

    $iv = random_bytes(12);
    $tag = '';
    $ciphertext = openssl_encrypt(
        $payload,
        'aes-256-gcm',
        encryption_subkey('message-body-compact-v1'),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        'SilkNex compact body v1',
        16
    );

    if (!is_string($ciphertext) || strlen($tag) !== 16) {
        throw new RuntimeException('SilkNex could not encrypt a compact message.');
    }

    return COMPACT_BODY_MAGIC . chr($flags) . $iv . $tag . $ciphertext;
}

function decrypted_message_blob(string $stored): string {
    if ($stored === '') return '';

    if (strlen($stored) < 33 || substr($stored, 0, 4) !== COMPACT_BODY_MAGIC) {
        throw new RuntimeException('Compact encrypted message is malformed.');
    }

    $flags = ord($stored[4]);
    $iv = substr($stored, 5, 12);
    $tag = substr($stored, 17, 16);
    $ciphertext = substr($stored, 33);

    $plain = openssl_decrypt(
        $ciphertext,
        'aes-256-gcm',
        encryption_subkey('message-body-compact-v1'),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        'SilkNex compact body v1'
    );

    if (!is_string($plain)) {
        throw new RuntimeException('SilkNex could not decrypt a compact message.');
    }

    if (($flags & 1) === 1) {
        if (!function_exists('gzinflate')) {
            throw new RuntimeException('This PHP server cannot decompress a message.');
        }

        $inflated = gzinflate($plain);

        if (!is_string($inflated)) {
            throw new RuntimeException('Compact message compression is corrupted.');
        }

        $plain = $inflated;
    }

    return $plain;
}

function message_plain_body(
    string $legacyBody,
    int $encryptedFlag,
    mixed $compactBody,
    int $bodyFormat
): string {
    if ($bodyFormat === 1 && is_string($compactBody)) {
        return decrypted_message_blob($compactBody);
    }

    return decrypted_message_value($legacyBody, $encryptedFlag);
}

function decrypted_message_value(string $stored, int $encryptedFlag = 1): string {
    if ($stored === '') return '';

    if ($encryptedFlag !== 1) {
        // Legacy plaintext is accepted only during automatic migration.
        return $stored;
    }

    if (!str_starts_with($stored, TEXT_ENCRYPTION_PREFIX)) {
        throw new RuntimeException('Encrypted message data is malformed.');
    }

    $payload = substr($stored, strlen(TEXT_ENCRYPTION_PREFIX));
    $parts = explode('.', $payload, 3);

    if (count($parts) !== 3) {
        throw new RuntimeException('Encrypted message data is malformed.');
    }

    $iv = b64url_decode_raw($parts[0]);
    $tag = b64url_decode_raw($parts[1]);
    $ciphertext = b64url_decode_raw($parts[2]);

    if (strlen($iv) !== 12 || strlen($tag) !== 16) {
        throw new RuntimeException('Encrypted message metadata is malformed.');
    }

    $plain = openssl_decrypt(
        $ciphertext,
        'aes-256-gcm',
        encryption_subkey('message-body-v1'),
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        'SilkNex message body v1'
    );

    if (!is_string($plain)) {
        throw new RuntimeException('SilkNex could not decrypt a message. The site encryption key may have changed.');
    }

    return $plain;
}

function giphy_media_url(string $url): string {
    $url = trim($url);
    if ($url === '' || strlen($url) > 1200) return '';

    $parts = parse_url($url);
    if (!is_array($parts)) return '';
    if (strtolower((string)($parts['scheme'] ?? '')) !== 'https') return '';
    if (isset($parts['user']) || isset($parts['pass']) || isset($parts['port'])) return '';

    $host = strtolower((string)($parts['host'] ?? ''));
    if (!preg_match('/^(?:media\d*|i)\.giphy\.com$/', $host)) return '';

    $path = (string)($parts['path'] ?? '');
    if ($path === '' || !preg_match('/\.(?:gif|webp)$/i', $path)) return '';

    return $url;
}

function media_reference_url(string $stored): string {
    if (str_starts_with($stored, 'media:')) {
        $token = substr($stored, 6);

        if (preg_match('/^[a-f0-9]{48}$/', $token)) {
            return 'api.php?action=media&token=' . rawurlencode($token);
        }

        return '';
    }

    return $stored;
}

function notification_media_url(string $stored, ?int $expiresAt = null): string {
    $token = media_token_from_reference($stored);
    if ($token === null) {
        // Keep safe legacy HTTPS image references working if an older install
        // stored one before private media tokens were introduced.
        $url = media_reference_url($stored);
        if ($url === '' || str_starts_with($url, 'api.php?action=media&')) return '';
        $parts = parse_url($url);
        return is_array($parts) && strtolower((string)($parts['scheme'] ?? '')) === 'https'
            ? $url
            : '';
    }

    $expiresAt ??= time() + 86400;
    $expiresAt = min(time() + 86400, max(time() + 60, $expiresAt));
    $signature = hash_hmac(
        'sha256',
        'SilkNex notification avatar v1|' . $token . '|' . $expiresAt,
        encryption_subkey('notification-avatar-url-v1')
    );

    return 'api.php?action=notification_media&token=' . rawurlencode($token) .
        '&exp=' . $expiresAt .
        '&sig=' . rawurlencode($signature);
}

function valid_notification_media_signature(string $token, int $expiresAt, string $signature): bool {
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) return false;
    if (!preg_match('/^[a-f0-9]{64}$/', $signature)) return false;

    $now = time();
    if ($expiresAt < $now - 30 || $expiresAt > $now + 86430) return false;

    $expected = hash_hmac(
        'sha256',
        'SilkNex notification avatar v1|' . $token . '|' . $expiresAt,
        encryption_subkey('notification-avatar-url-v1')
    );

    return hash_equals($expected, $signature);
}

function media_store_reference(string $token): string {
    return preg_match('/^[a-f0-9]{48}$/', $token)
        ? 'media:' . $token
        : '';
}

function media_token_from_reference(string $stored): ?string {
    if (!str_starts_with($stored, 'media:')) return null;

    $token = substr($stored, 6);
    return preg_match('/^[a-f0-9]{48}$/', $token) ? $token : null;
}

function delete_upload_if_unreferenced(
    PDO $pdo,
    string $token,
    int $ownerId
): void {
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) return;

    try {
        $reference = media_store_reference($token);

        $stmt = $pdo->prepare(
            'SELECT (
                EXISTS(
                    SELECT 1 FROM users
                    WHERE id = ?
                      AND (avatar_url = ? OR wallpaper_url = ? OR profile_banner_url = ?)
                )
                OR EXISTS(
                    SELECT 1 FROM conversation_settings
                    WHERE user_id = ? AND wallpaper_url = ?
                )
                OR EXISTS(
                    SELECT 1 FROM conversations
                    WHERE avatar_url = ?
                )
                OR EXISTS(
                    SELECT 1 FROM messages
                    WHERE attachment_token = ?
                      AND deleted_at IS NULL
                )
                OR EXISTS(
                    SELECT 1 FROM stories
                    WHERE media_token = ?
                      AND deleted_at IS NULL
                      AND expires_at > UNIX_TIMESTAMP()
                )
                OR EXISTS(
                    SELECT 1 FROM saved_stickers
                    WHERE upload_token = ?
                )
                OR EXISTS(
                    SELECT 1 FROM profile_posts
                    WHERE media_token = ?
                )
             ) AS referenced'
        );
        $stmt->execute([
            $ownerId,
            $reference,
            $reference,
            $reference,
            $ownerId,
            $reference,
            $reference,
            $token,
            $token,
            $token,
            $token
        ]);

        if ((int)$stmt->fetchColumn() === 1) return;

        $uploadStmt = $pdo->prepare(
            'SELECT id, file_url
             FROM uploads
             WHERE user_id = ? AND token = ?
             LIMIT 1'
        );
        $uploadStmt->execute([$ownerId, $token]);
        $upload = $uploadStmt->fetch();

        if (!$upload) return;

        $pdo->prepare(
            'DELETE FROM uploads WHERE id = ? AND user_id = ?'
        )->execute([(int)$upload['id'], $ownerId]);

        $relative = (string)$upload['file_url'];
        $path = resolve_upload_storage_path($relative);
        if ($path !== null && is_file($path)) @unlink($path);
    } catch (Throwable $e) {
        error_log('[SilkNex media cleanup] ' . $e->getMessage());
    }
}

function purge_expired_messages(PDO $pdo, ?int $conversationId = null): int {
    $where = 'expires_at IS NOT NULL AND expires_at <= ? AND deleted_at IS NULL';
    $params = [time()];

    if ($conversationId !== null && $conversationId > 0) {
        $where .= ' AND conversation_id = ?';
        $params[] = $conversationId;
    }

    $stmt = $pdo->prepare(
        "SELECT id, conversation_id, sender_id, attachment_token
         FROM messages
         WHERE {$where}
         ORDER BY expires_at ASC, id ASC
         LIMIT 100"
    );
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    if (!$rows) return 0;

    $now = time();
    $changedAt = now_ms();
    $conversationIds = [];
    $attachments = [];

    $pdo->beginTransaction();

    try {
        $update = $pdo->prepare(
            "UPDATE messages
             SET body = '',
                 body_compact = NULL,
                 body_format = 1,
                 body_encrypted = 1,
                 attachment_url = NULL,
                 attachment_token = NULL,
                 attachment_mime = NULL,
                 attachment_name = NULL,
                 attachment_size = 0,
                 duration_ms = 0,
                 deleted_at = ?,
                 updated_at = ?
             WHERE id = ? AND deleted_at IS NULL"
        );

        foreach ($rows as $row) {
            $update->execute([$now, $changedAt, (int)$row['id']]);
            $conversationIds[(int)$row['conversation_id']] = true;

            $token = (string)($row['attachment_token'] ?? '');
            if (preg_match('/^[a-f0-9]{48}$/', $token)) {
                $attachments[] = [$token, (int)$row['sender_id']];
            }
        }

        foreach (array_keys($conversationIds) as $cid) {
            touch_conversation_change($pdo, (int)$cid, $now);
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }

    foreach ($attachments as [$token, $ownerId]) {
        delete_upload_if_unreferenced($pdo, $token, $ownerId);
    }

    return count($rows);
}

function uint64_pack(int $value): string {
    $high = intdiv($value, 4294967296);
    $low = $value % 4294967296;
    return pack('N2', $high, $low);
}

function uint64_unpack(string $bytes): int {
    if (strlen($bytes) !== 8) {
        throw new RuntimeException('Invalid encrypted media header.');
    }

    $parts = unpack('Nhigh/Nlow', $bytes);
    return ((int)$parts['high'] * 4294967296) + (int)$parts['low'];
}

function encrypted_media_path(string $folderPath): array {
    $fileName = bin2hex(random_bytes(20)) . '.nenc';
    return [
        $folderPath . '/' . $fileName,
        $fileName
    ];
}

function encrypt_media_file(string $source, string $destination): void {
    $size = filesize($source);

    if ($size === false || $size < 0) {
        throw new RuntimeException('Could not read upload size.');
    }

    $in = fopen($source, 'rb');
    if (!is_resource($in)) throw new RuntimeException('Could not read upload.');

    $out = fopen($destination, 'xb');
    if (!is_resource($out)) {
        fclose($in);
        throw new RuntimeException('Could not create encrypted upload.');
    }

    $baseNonce = random_bytes(8);
    $header = FILE_ENCRYPTION_MAGIC . uint64_pack((int)$size) . $baseNonce;

    try {
        if (fwrite($out, $header) !== strlen($header)) {
            throw new RuntimeException('Could not write encrypted upload header.');
        }

        $index = 0;

        while (!feof($in)) {
            $plain = fread($in, FILE_ENCRYPTION_CHUNK);

            if ($plain === false) {
                throw new RuntimeException('Could not read upload while encrypting.');
            }

            if ($plain === '') {
                if (feof($in)) break;
                continue;
            }

            if ($index > 0xffffffff) {
                throw new RuntimeException('Upload has too many encryption chunks.');
            }

            $nonce = $baseNonce . pack('N', $index);
            $tag = '';
            $ciphertext = openssl_encrypt(
                $plain,
                'aes-256-gcm',
                encryption_subkey('media-file-v1'),
                OPENSSL_RAW_DATA,
                $nonce,
                $tag,
                'SilkNex media v1|' . $index,
                16
            );

            if (!is_string($ciphertext) || strlen($tag) !== 16) {
                throw new RuntimeException('Could not encrypt upload chunk.');
            }

            $record = pack('N', strlen($ciphertext)) . $tag . $ciphertext;

            if (fwrite($out, $record) !== strlen($record)) {
                throw new RuntimeException('Could not write encrypted upload.');
            }

            $index++;
        }

        fflush($out);
    } catch (Throwable $e) {
        fclose($in);
        fclose($out);
        @unlink($destination);
        throw $e;
    }

    fclose($in);
    fclose($out);
    @chmod($destination, 0600);
}

function read_exact($handle, int $length): string {
    $buffer = '';

    while (strlen($buffer) < $length && !feof($handle)) {
        $part = fread($handle, $length - strlen($buffer));

        if ($part === false) {
            throw new RuntimeException('Could not read encrypted media.');
        }

        if ($part === '') break;
        $buffer .= $part;
    }

    if (strlen($buffer) !== $length) {
        throw new RuntimeException('Encrypted media is truncated.');
    }

    return $buffer;
}

function encrypted_media_metadata(string $path): array {
    $handle = fopen($path, 'rb');
    if (!is_resource($handle)) throw new RuntimeException('Media file is unavailable.');

    try {
        $magic = read_exact($handle, 8);
        if (!hash_equals(FILE_ENCRYPTION_MAGIC, $magic)) {
            throw new RuntimeException('Media file is not encrypted correctly.');
        }

        $size = uint64_unpack(read_exact($handle, 8));
        $baseNonce = read_exact($handle, 8);

        return [
            'size' => $size,
            'base_nonce' => $baseNonce,
        ];
    } finally {
        fclose($handle);
    }
}

function validate_encrypted_media_key(string $path): void {
    $handle = fopen($path, 'rb');
    if (!is_resource($handle)) {
        throw new RuntimeException('Encrypted media file is unavailable.');
    }

    try {
        $magic = read_exact($handle, 8);
        if (!hash_equals(FILE_ENCRYPTION_MAGIC, $magic)) {
            throw new RuntimeException('Encrypted media header is invalid.');
        }

        $size = uint64_unpack(read_exact($handle, 8));
        $baseNonce = read_exact($handle, 8);

        if ($size <= 0) return;

        $cipherLength = (int)unpack('Nlen', read_exact($handle, 4))['len'];
        $tag = read_exact($handle, 16);
        $ciphertext = read_exact($handle, $cipherLength);

        $plain = openssl_decrypt(
            $ciphertext,
            'aes-256-gcm',
            encryption_subkey('media-file-v1'),
            OPENSSL_RAW_DATA,
            $baseNonce . pack('N', 0),
            $tag,
            'SilkNex media v1|0'
        );

        if (!is_string($plain)) {
            throw new RuntimeException(
                'Encryption key cannot authenticate existing media.'
            );
        }
    } finally {
        fclose($handle);
    }
}

function stream_encrypted_media(
    string $path,
    string $mime,
    string $name,
    bool $allowRange = true
): never {
    $metadata = encrypted_media_metadata($path);
    $totalSize = (int)$metadata['size'];
    $baseNonce = (string)$metadata['base_nonce'];

    $start = 0;
    $end = max(0, $totalSize - 1);
    $partial = false;

    $range = (string)($_SERVER['HTTP_RANGE'] ?? '');

    if ($allowRange && $totalSize > 0 && preg_match('/^bytes=(\d*)-(\d*)$/', trim($range), $match)) {
        $rawStart = $match[1];
        $rawEnd = $match[2];

        if ($rawStart === '' && $rawEnd !== '') {
            $suffix = min($totalSize, max(0, (int)$rawEnd));
            $start = max(0, $totalSize - $suffix);
        } else {
            $start = max(0, (int)$rawStart);
        }

        if ($rawEnd !== '') {
            $end = min($end, (int)$rawEnd);
        }

        if ($start > $end || $start >= $totalSize) {
            header('Content-Range: bytes */' . $totalSize);
            http_response_code(416);
            exit;
        }

        $partial = true;
    }

    $length = $totalSize === 0 ? 0 : ($end - $start + 1);

    header_remove('Content-Type');
    header('Content-Type: ' . $mime);
    header('Accept-Ranges: bytes');
    header('Cache-Control: private, no-store');
    header('Content-Disposition: inline; filename="' . str_replace(['"', "\r", "\n"], '', basename($name)) . '"');

    if ($partial) {
        http_response_code(206);
        header("Content-Range: bytes {$start}-{$end}/{$totalSize}");
    } else {
        http_response_code(200);
    }

    header('Content-Length: ' . $length);

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    if ($totalSize === 0 || $length === 0) exit;

    $firstChunk = intdiv($start, FILE_ENCRYPTION_CHUNK);
    $lastChunk = intdiv($end, FILE_ENCRYPTION_CHUNK);
    $recordStride = 4 + 16 + FILE_ENCRYPTION_CHUNK;
    $handle = fopen($path, 'rb');

    if (!is_resource($handle)) exit;

    try {
        $offset = FILE_ENCRYPTION_HEADER_BYTES + ($firstChunk * $recordStride);

        if (fseek($handle, $offset) !== 0) {
            throw new RuntimeException('Could not seek encrypted media.');
        }

        for ($index = $firstChunk; $index <= $lastChunk; $index++) {
            $cipherLength = unpack('Nlen', read_exact($handle, 4))['len'];
            $tag = read_exact($handle, 16);
            $ciphertext = read_exact($handle, (int)$cipherLength);
            $nonce = $baseNonce . pack('N', $index);

            $plain = openssl_decrypt(
                $ciphertext,
                'aes-256-gcm',
                encryption_subkey('media-file-v1'),
                OPENSSL_RAW_DATA,
                $nonce,
                $tag,
                'SilkNex media v1|' . $index
            );

            if (!is_string($plain)) {
                throw new RuntimeException('Encrypted media authentication failed.');
            }

            $chunkStart = $index * FILE_ENCRYPTION_CHUNK;
            $sliceStart = max(0, $start - $chunkStart);
            $sliceEnd = min(strlen($plain) - 1, $end - $chunkStart);

            if ($sliceEnd >= $sliceStart) {
                echo substr($plain, $sliceStart, $sliceEnd - $sliceStart + 1);
                flush();
            }
        }
    } catch (Throwable $e) {
        error_log('[SilkNex encrypted media] ' . $e->getMessage());
    } finally {
        fclose($handle);
    }

    exit;
}

function stream_plain_media(string $path, string $mime, string $name): never {
    $size = filesize($path);
    if ($size === false) fail('Media file is unavailable.', 404);

    header_remove('Content-Type');
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . (int)$size);
    header('Cache-Control: private, no-store');
    header('Content-Disposition: inline; filename="' . str_replace(['"', "\r", "\n"], '', basename($name)) . '"');

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    readfile($path);
    exit;
}

function request_host(): string {
    $origin = current_request_origin();
    if ($origin === '') return '';

    $parts = parse_url($origin);
    if (!is_array($parts)) return '';

    return strtolower(rtrim((string)($parts['host'] ?? ''), '.'));
}

function request_origin(): string {
    return current_request_origin();
}

function upload_mime_info(string $mime): ?array {
    return match (strtolower($mime)) {
        'image/jpeg' => ['type' => 'image', 'ext' => 'jpg', 'max' => MAX_IMAGE_UPLOAD],
        'image/png' => ['type' => 'image', 'ext' => 'png', 'max' => MAX_IMAGE_UPLOAD],
        'image/webp' => ['type' => 'image', 'ext' => 'webp', 'max' => MAX_IMAGE_UPLOAD],
        'image/gif' => ['type' => 'gif', 'ext' => 'gif', 'max' => MAX_IMAGE_UPLOAD],
        'image/heic' => ['type' => 'image', 'ext' => 'heic', 'max' => MAX_IMAGE_UPLOAD],
        'image/heif' => ['type' => 'image', 'ext' => 'heif', 'max' => MAX_IMAGE_UPLOAD],
        'image/avif' => ['type' => 'image', 'ext' => 'avif', 'max' => MAX_IMAGE_UPLOAD],
        'video/mp4' => ['type' => 'video', 'ext' => 'mp4', 'max' => MAX_VIDEO_UPLOAD],
        'video/webm' => ['type' => 'video', 'ext' => 'webm', 'max' => MAX_VIDEO_UPLOAD],
        'video/quicktime' => ['type' => 'video', 'ext' => 'mov', 'max' => MAX_VIDEO_UPLOAD],
        'audio/webm' => ['type' => 'audio', 'ext' => 'webm', 'max' => MAX_AUDIO_UPLOAD],
        'audio/ogg' => ['type' => 'audio', 'ext' => 'ogg', 'max' => MAX_AUDIO_UPLOAD],
        'audio/mp4', 'audio/x-m4a' => ['type' => 'audio', 'ext' => 'm4a', 'max' => MAX_AUDIO_UPLOAD],
        'audio/mpeg' => ['type' => 'audio', 'ext' => 'mp3', 'max' => MAX_AUDIO_UPLOAD],
        'audio/wav', 'audio/x-wav' => ['type' => 'audio', 'ext' => 'wav', 'max' => MAX_AUDIO_UPLOAD],
        default => null,
    };
}

function fallback_iso_bmff_mime(string $path): ?string {
    $handle = @fopen($path, 'rb');
    if ($handle === false) return null;

    try {
        $header = (string)@fread($handle, 96);
    } finally {
        @fclose($handle);
    }

    if (strlen($header) < 16 || substr($header, 4, 4) !== 'ftyp') {
        return null;
    }

    $sizeParts = unpack('Nsize', substr($header, 0, 4));
    $boxSize = (int)($sizeParts['size'] ?? 0);
    if ($boxSize < 16) return null;

    $brandEnd = min(strlen($header), $boxSize);
    $brands = [strtolower(substr($header, 8, 4))];
    for ($offset = 16; $offset + 4 <= $brandEnd; $offset += 4) {
        $brands[] = strtolower(substr($header, $offset, 4));
    }

    $hasBrand = static function (array $allowed) use ($brands): bool {
        return (bool)array_intersect($brands, $allowed);
    };

    if ($hasBrand(['heic','heix','hevc','hevx'])) return 'image/heic';
    if ($hasBrand(['heif','mif1','msf1'])) return 'image/heif';
    if ($hasBrand(['avif','avis'])) return 'image/avif';
    if ($hasBrand(['qt  '])) return 'video/quicktime';
    if ($hasBrand([
        'isom','iso2','iso3','iso4','iso5','iso6','mp41','mp42',
        'mmp4','m4v ','m4vh','m4vp','dash'
    ])) {
        return 'video/mp4';
    }

    return null;
}

function validate_raster_image_dimensions(string $path, string $mime, string $purpose): void {
    if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) {
        return;
    }

    $dimensions = @getimagesize($path);
    if (!is_array($dimensions)) {
        fail('That image is damaged or could not be read.');
    }

    $width = (int)($dimensions[0] ?? 0);
    $height = (int)($dimensions[1] ?? 0);
    if ($width <= 0 || $height <= 0) {
        fail('That image has invalid dimensions.');
    }

    $compactPurpose = in_array($purpose, ['avatar','sticker','ad'], true);
    $maxDimension = $compactPurpose ? 4096 : 12000;
    $maxPixels = $compactPurpose ? 16000000 : 48000000;

    if (
        $width > $maxDimension ||
        $height > $maxDimension ||
        ((float)$width * (float)$height) > $maxPixels
    ) {
        fail(
            $compactPurpose
                ? 'That image is too large in resolution. Use an image up to 4096×4096.'
                : 'That image resolution is too large to process safely.',
            413
        );
    }
}

function ensure_upload_directory(): array {
    $folder = date('Y-m');
    $base = __DIR__ . '/uploads';
    $dir = $base . '/' . $folder;

    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        fail('SilkNex could not create the uploads folder.', 500);
    }

    $guard = $base . '/.htaccess';
    $guardContents = is_file($guard)
        ? (string)@file_get_contents($guard)
        : '';

    if (!str_contains($guardContents, 'SilkNex media is API-only')) {
        @file_put_contents(
            $guard,
            "# SilkNex media is API-only\n" .
            "Options -Indexes\n" .
            "<IfModule mod_authz_core.c>\n" .
            "  Require all denied\n" .
            "</IfModule>\n" .
            "<IfModule !mod_authz_core.c>\n" .
            "  Order allow,deny\n" .
            "  Deny from all\n" .
            "</IfModule>\n" .
            "<IfModule mod_headers.c>\n" .
            "  Header always set X-Content-Type-Options \"nosniff\"\n" .
            "  Header always set Cache-Control \"private, no-store\"\n" .
            "  Header always set Referrer-Policy \"no-referrer\"\n" .
            "</IfModule>\n",
            LOCK_EX
        );
    }

    return [$dir, 'uploads/' . $folder];
}

function resolve_upload_storage_path(string $relative): ?string {
    $relative = trim($relative);
    if (
        $relative === '' ||
        !str_starts_with($relative, 'uploads/') ||
        str_contains($relative, "\0") ||
        str_contains($relative, '\\')
    ) {
        return null;
    }

    $base = realpath(__DIR__ . '/uploads');
    $path = realpath(__DIR__ . '/' . $relative);
    if (!is_string($base) || !is_string($path)) return null;

    $prefix = rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
    return str_starts_with($path, $prefix) ? $path : null;
}

function safe_original_name(string $name): string {
    $name = preg_replace('/[^\pL\pN._ -]+/u', '_', basename($name)) ?? 'file';
    $name = trim($name);
    if ($name === '') $name = 'file';
    return function_exists('mb_substr')
        ? mb_substr($name, 0, 180, 'UTF-8')
        : substr($name, 0, 180);
}

function get_owned_upload(PDO $pdo, int $userId, string $token, ?string $purpose = null): ?array {
    if (!preg_match('/^[a-f0-9]{48}$/', $token)) return null;

    $sql = 'SELECT * FROM uploads WHERE user_id = ? AND token = ?';
    $params = [$userId, $token];

    if ($purpose !== null) {
        $sql .= ' AND purpose = ?';
        $params[] = $purpose;
    }

    $sql .= ' LIMIT 1';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();
    return $row ?: null;
}


function cleanup_stale_uploads(PDO $pdo): void {
    $rows = [];

    try {
        // Claim stale uploads under a row lock before deleting database rows.
        // The old implementation unlinked files first, so a message send that
        // marked used_at between SELECT and DELETE could keep a database
        // reference to a file that had just been removed.
        $pdo->beginTransaction();

        $stmt = $pdo->prepare(
            "SELECT id, file_url
             FROM uploads
             WHERE used_at IS NULL
               AND purpose <> 'sticker'
               AND created_at < ?
             ORDER BY id ASC
             LIMIT 40
             FOR UPDATE"
        );
        $stmt->execute([time() - 86400]);
        $rows = $stmt->fetchAll();

        if (!$rows) {
            $pdo->commit();
            return;
        }

        $ids = array_map(static fn(array $row): int => (int)$row['id'], $rows);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $delete = $pdo->prepare(
            "DELETE FROM uploads
             WHERE id IN ({$placeholders})
               AND used_at IS NULL
               AND purpose <> 'sticker'"
        );
        $delete->execute($ids);
        $pdo->commit();

        // Only unlink after the locked rows have been deleted successfully.
        // A concurrent send either commits first (and is excluded) or waits
        // until this transaction finishes and then sees no usable upload.
        foreach ($rows as $row) {
            $url = (string)$row['file_url'];
            $path = resolve_upload_storage_path($url);
            if ($path !== null && is_file($path)) @unlink($path);
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[SilkNex upload cleanup] ' . $e->getMessage());
    }
}

function receipt_state(PDO $pdo, int $conversationId, int $viewerId): array {
    $members = $pdo->prepare(
        'SELECT cm.user_id,
                COALESCE(cd.last_delivered_message_id, 0) AS delivered_id,
                COALESCE(cr.last_read_message_id, 0) AS read_id
         FROM conversation_members cm
         INNER JOIN users receipt_user
           ON receipt_user.id = cm.user_id
          AND receipt_user.disabled_at IS NULL
         LEFT JOIN conversation_deliveries cd
           ON cd.conversation_id = cm.conversation_id
          AND cd.user_id = cm.user_id
         LEFT JOIN conversation_reads cr
           ON cr.conversation_id = cm.conversation_id
          AND cr.user_id = cm.user_id
         WHERE cm.conversation_id = ?
           AND cm.user_id <> ?'
    );
    $members->execute([$conversationId, $viewerId]);
    $rows = $members->fetchAll();

    if (!$rows) {
        return ['recipient_count' => 0, 'delivered_up_to' => 0, 'read_up_to' => 0];
    }

    $delivered = null;
    $read = null;

    foreach ($rows as $row) {
        $d = (int)$row['delivered_id'];
        $r = (int)$row['read_id'];
        $delivered = $delivered === null ? $d : min($delivered, $d);
        $read = $read === null ? $r : min($read, $r);
    }

    return [
        'recipient_count' => count($rows),
        'delivered_up_to' => (int)($delivered ?? 0),
        'read_up_to' => (int)($read ?? 0),
    ];
}

function touch_conversation_change(
    PDO $pdo,
    int $conversationId,
    ?int $updatedAt = null,
    bool $notifyInbox = true
): void {
    if ($updatedAt !== null) {
        $stmt = $pdo->prepare(
            'UPDATE conversations
             SET updated_at = ?, change_seq = change_seq + 1
             WHERE id = ?'
        );
        $stmt->execute([$updatedAt, $conversationId]);
        if ($stmt->rowCount() > 0 && $notifyInbox) {
            bump_conversation_inbox($pdo, $conversationId);
        }
        return;
    }

    $stmt = $pdo->prepare(
        'UPDATE conversations
         SET change_seq = change_seq + 1
         WHERE id = ?'
    );
    $stmt->execute([$conversationId]);
}

function bump_conversation_change(
    PDO $pdo,
    int $conversationId,
    ?int $updatedAt = null,
    bool $notifyInbox = true
): int {
    // LAST_INSERT_ID(expr) gives this connection the new sequence value as part
    // of the UPDATE, avoiding an extra SELECT on every send/edit/reaction.
    if ($updatedAt !== null) {
        $stmt = $pdo->prepare(
            'UPDATE conversations
             SET updated_at = ?,
                 change_seq = LAST_INSERT_ID(change_seq + 1)
             WHERE id = ?'
        );
        $stmt->execute([$updatedAt, $conversationId]);
    } else {
        $stmt = $pdo->prepare(
            'UPDATE conversations
             SET change_seq = LAST_INSERT_ID(change_seq + 1)
             WHERE id = ?'
        );
        $stmt->execute([$conversationId]);
    }

    if ($stmt->rowCount() < 1) {
        return 0;
    }

    if ($updatedAt !== null && $notifyInbox) {
        bump_conversation_inbox($pdo, $conversationId);
    }

    return max(0, (int)$pdo->lastInsertId());
}

function conversation_change_seq(PDO $pdo, int $conversationId): int {
    $stmt = $pdo->prepare(
        'SELECT change_seq FROM conversations WHERE id = ? LIMIT 1'
    );
    $stmt->execute([$conversationId]);
    return (int)$stmt->fetchColumn();
}

function mark_delivered(PDO $pdo, int $conversationId, int $userId, int $messageId, bool $touch = true): bool {
    if ($messageId <= 0) return false;

    $stmt = $pdo->prepare(
        'INSERT INTO conversation_deliveries
         (conversation_id, user_id, last_delivered_message_id, delivered_at)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           delivered_at = IF(
             VALUES(last_delivered_message_id) > last_delivered_message_id,
             VALUES(delivered_at),
             delivered_at
           ),
           last_delivered_message_id = GREATEST(
             last_delivered_message_id,
             VALUES(last_delivered_message_id)
           )'
    );
    $stmt->execute([$conversationId, $userId, $messageId, time()]);

    $changed = $stmt->rowCount() > 0;
    if ($changed && $touch) touch_conversation_change($pdo, $conversationId);

    return $changed;
}

function mark_read(PDO $pdo, int $conversationId, int $userId, int $messageId, bool $touch = true): bool {
    if ($messageId <= 0) return false;

    $stmt = $pdo->prepare(
        'INSERT INTO conversation_reads
         (conversation_id, user_id, last_read_message_id, read_at)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           read_at = IF(
               VALUES(last_read_message_id) > last_read_message_id,
               VALUES(read_at),
               read_at
           ),
           last_read_message_id = GREATEST(
               last_read_message_id,
               VALUES(last_read_message_id)
           )'
    );
    $stmt->execute([$conversationId, $userId, $messageId, time()]);

    $changed = $stmt->rowCount() > 0;
    if ($changed && $touch) touch_conversation_change($pdo, $conversationId);

    return $changed;
}

function ensure_user_realtime_state(PDO $pdo, int $userId): void {
    if ($userId <= 0) return;

    $pdo->prepare(
        'INSERT INTO user_realtime_state
         (user_id, inbox_seq, friend_seq, call_seq, updated_at)
         VALUES (?, 0, 0, 0, ?)
         ON DUPLICATE KEY UPDATE user_id = VALUES(user_id)'
    )->execute([$userId, time()]);
}

function realtime_signature(PDO $pdo, int $userId, string $field): string {
    if (!in_array($field, ['inbox_seq', 'friend_seq', 'call_seq'], true)) {
        throw new InvalidArgumentException('Invalid realtime signature field.');
    }

    // Reads must stay read-only under load. Realtime rows are created lazily
    // by bump_user_realtime()/bump_conversation_inbox when an event actually
    // happens; a missing row simply means the counter is still zero.
    $stmt = $pdo->prepare(
        "SELECT {$field}
         FROM user_realtime_state
         WHERE user_id = ?
         LIMIT 1"
    );
    $stmt->execute([$userId]);
    return (string)max(0, (int)($stmt->fetchColumn() ?: 0));
}

function bump_user_realtime(PDO $pdo, int $userId, string $field): void {
    if ($userId <= 0) return;
    if (!in_array($field, ['inbox_seq', 'friend_seq', 'call_seq'], true)) {
        throw new InvalidArgumentException('Invalid realtime counter field.');
    }

    $inbox = $field === 'inbox_seq' ? 1 : 0;
    $friend = $field === 'friend_seq' ? 1 : 0;
    $call = $field === 'call_seq' ? 1 : 0;

    $pdo->prepare(
        "INSERT INTO user_realtime_state
         (user_id, inbox_seq, friend_seq, call_seq, updated_at)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           {$field} = {$field} + 1,
           updated_at = VALUES(updated_at)"
    )->execute([$userId, $inbox, $friend, $call, time()]);
}

function bump_users_realtime(PDO $pdo, array $userIds, string $field): void {
    if (!in_array($field, ['inbox_seq', 'friend_seq', 'call_seq'], true)) {
        throw new InvalidArgumentException('Invalid realtime counter field.');
    }

    $unique = [];
    foreach ($userIds as $userId) {
        $id = (int)$userId;
        if ($id > 0) $unique[$id] = true;
    }
    $ids = array_map('intval', array_keys($unique));
    if (!$ids) return;

    $inbox = $field === 'inbox_seq' ? 1 : 0;
    $friend = $field === 'friend_seq' ? 1 : 0;
    $call = $field === 'call_seq' ? 1 : 0;
    $now = time();

    // Multi-row upsert turns N realtime wake-up writes into one round trip.
    // Chunking keeps packets/placeholder counts conservative for large groups.
    foreach (array_chunk($ids, 200) as $chunk) {
        $values = [];
        $params = [];
        foreach ($chunk as $id) {
            $values[] = '(?, ?, ?, ?, ?)';
            array_push($params, $id, $inbox, $friend, $call, $now);
        }

        $pdo->prepare(
            'INSERT INTO user_realtime_state
             (user_id, inbox_seq, friend_seq, call_seq, updated_at)
             VALUES ' . implode(',', $values) . "
             ON DUPLICATE KEY UPDATE
               {$field} = {$field} + 1,
               updated_at = VALUES(updated_at)"
        )->execute($params);
    }
}

function bump_conversation_inbox(PDO $pdo, int $conversationId): void {
    if ($conversationId <= 0) return;

    // A single INSERT..SELECT wakes every member without repeatedly aggregating
    // their entire sidebar on each heartbeat.
    $pdo->prepare(
        'INSERT INTO user_realtime_state
         (user_id, inbox_seq, friend_seq, call_seq, updated_at)
         SELECT cm.user_id, 1, 0, 0, ?
         FROM conversation_members cm
         WHERE cm.conversation_id = ?
         ON DUPLICATE KEY UPDATE
           inbox_seq = inbox_seq + 1,
           updated_at = VALUES(updated_at)'
    )->execute([time(), $conversationId]);
}

function inbox_signature(PDO $pdo, int $userId): string {
    return realtime_signature($pdo, $userId, 'inbox_seq');
}

function friendship_pair_key(int $firstUserId, int $secondUserId): string {
    $low = min($firstUserId, $secondUserId);
    $high = max($firstUserId, $secondUserId);
    return $low . ':' . $high;
}

function friendship_between(PDO $pdo, int $firstUserId, int $secondUserId): ?array {
    if ($firstUserId <= 0 || $secondUserId <= 0 || $firstUserId === $secondUserId) {
        return null;
    }

    $stmt = $pdo->prepare(
        'SELECT * FROM friendships WHERE pair_key = ? LIMIT 1'
    );
    $stmt->execute([friendship_pair_key($firstUserId, $secondUserId)]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function users_are_friends(PDO $pdo, int $firstUserId, int $secondUserId): bool {
    $friendship = friendship_between($pdo, $firstUserId, $secondUserId);
    return $friendship !== null && (string)$friendship['status'] === 'accepted';
}

function friendship_for_viewer(?array $friendship, int $viewerId): array {
    if (!$friendship) {
        return ['status' => 'none', 'request_id' => 0];
    }

    $status = (string)$friendship['status'];

    if ($status === 'accepted') {
        return [
            'status' => 'accepted',
            'request_id' => (int)$friendship['id'],
        ];
    }

    if ($status !== 'pending') {
        return ['status' => 'none', 'request_id' => 0];
    }

    return [
        'status' => (int)$friendship['requester_id'] === $viewerId
            ? 'outgoing'
            : 'incoming',
        'request_id' => (int)$friendship['id'],
    ];
}

function friendship_signature(PDO $pdo, int $userId): string {
    return realtime_signature($pdo, $userId, 'friend_seq');
}

function quiet_hours_active(array $row, ?int $now = null): bool {
    if (!(bool)($row['quiet_enabled'] ?? false)) return false;

    $start = max(0, min(1439, (int)($row['quiet_start_minute'] ?? 1320)));
    $end = max(0, min(1439, (int)($row['quiet_end_minute'] ?? 420)));
    if ($start === $end) return false;

    $timezone = trim((string)($row['quiet_timezone'] ?? $row['timezone'] ?? 'UTC'));
    if ($timezone === '') $timezone = 'UTC';

    try {
        $zone = new DateTimeZone($timezone);
    } catch (Throwable $e) {
        $zone = new DateTimeZone('UTC');
    }

    $instant = (new DateTimeImmutable('@' . (string)($now ?? time())))->setTimezone($zone);
    $minute = ((int)$instant->format('G') * 60) + (int)$instant->format('i');

    if ($start < $end) {
        return $minute >= $start && $minute < $end;
    }

    // Overnight window, for example 22:00 -> 07:00.
    return $minute >= $start || $minute < $end;
}

function direct_push_user(PDO $pdo, int $recipientId, array $payload): void {
    $userStmt = $pdo->prepare(
        'SELECT notifications_enabled FROM users
         WHERE id = ? AND disabled_at IS NULL LIMIT 1'
    );
    $userStmt->execute([$recipientId]);
    if (!(bool)$userStmt->fetchColumn()) return;

    $subsStmt = $pdo->prepare(
        'SELECT * FROM push_subscriptions
         WHERE user_id = ?
         ORDER BY id DESC
         LIMIT 8'
    );
    $subsStmt->execute([$recipientId]);

    foreach ($subsStmt->fetchAll() as $subscription) {
        try {
            $status = send_web_push($subscription, $payload);

            if (in_array($status, [200,201,202], true)) {
                $pdo->prepare(
                    'UPDATE push_subscriptions
                     SET last_success_at = ?, fail_count = 0
                     WHERE id = ?'
                )->execute([time(), (int)$subscription['id']]);
            } elseif (in_array($status, [404,410], true)) {
                $pdo->prepare('DELETE FROM push_subscriptions WHERE id = ?')
                    ->execute([(int)$subscription['id']]);
            } elseif ($status > 0) {
                $pdo->prepare(
                    'UPDATE push_subscriptions
                     SET fail_count = fail_count + 1
                     WHERE id = ?'
                )->execute([(int)$subscription['id']]);
            }
        } catch (Throwable $e) {
            error_log('[SilkNex friend push] ' . $e->getMessage());
        }
    }
}

function ensure_direct_conversation(PDO $pdo, int $firstUserId, int $secondUserId): int {
    if ($firstUserId <= 0 || $secondUserId <= 0 || $firstUserId === $secondUserId) {
        throw new RuntimeException('Invalid direct conversation participants.');
    }

    $directKey = friendship_pair_key($firstUserId, $secondUserId);
    $now = time();
    $ownsTransaction = !$pdo->inTransaction();

    if ($ownsTransaction) $pdo->beginTransaction();

    try {
        // LAST_INSERT_ID(id) makes this atomic for simultaneous accepts from
        // multiple tabs/devices: both requests resolve to the same unique DM
        // instead of one failing with a duplicate-key server error.
        $pdo->prepare(
            "INSERT INTO conversations
             (kind, direct_key, name, created_by, created_at, updated_at)
             VALUES ('dm', ?, NULL, ?, ?, ?)
             ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)"
        )->execute([$directKey, $firstUserId, $now, $now]);

        $conversationId = (int)$pdo->lastInsertId();
        if ($conversationId <= 0) {
            $stmt = $pdo->prepare(
                "SELECT id FROM conversations
                 WHERE kind = 'dm' AND direct_key = ?
                 LIMIT 1"
            );
            $stmt->execute([$directKey]);
            $conversationId = (int)($stmt->fetchColumn() ?: 0);
        }

        if ($conversationId <= 0) {
            throw new RuntimeException('Could not create direct conversation.');
        }

        $memberStmt = $pdo->prepare(
            'INSERT INTO conversation_members
             (conversation_id, user_id, joined_at, hidden_at)
             VALUES (?, ?, ?, NULL)
             ON DUPLICATE KEY UPDATE hidden_at = NULL'
        );
        $memberStmt->execute([$conversationId, $firstUserId, $now]);
        $memberStmt->execute([$conversationId, $secondUserId, $now]);

        $readStmt = $pdo->prepare(
            'INSERT INTO conversation_reads
             (conversation_id, user_id, last_read_message_id, read_at)
             VALUES (?, ?, 0, ?)
             ON DUPLICATE KEY UPDATE conversation_id = VALUES(conversation_id)'
        );
        $readStmt->execute([$conversationId, $firstUserId, $now]);
        $readStmt->execute([$conversationId, $secondUserId, $now]);

        bump_conversation_inbox($pdo, $conversationId);

        if ($ownsTransaction) $pdo->commit();
        return $conversationId;
    } catch (Throwable $e) {
        if ($ownsTransaction && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function direct_conversation_other_user(PDO $pdo, int $conversationId, int $viewerId): int {
    $stmt = $pdo->prepare(
        'SELECT user_id
         FROM conversation_members
         WHERE conversation_id = ? AND user_id <> ?
         ORDER BY user_id
         LIMIT 1'
    );
    $stmt->execute([$conversationId, $viewerId]);
    return (int)($stmt->fetchColumn() ?: 0);
}

function require_direct_friendship(PDO $pdo, array $conversation, int $viewerId): void {
    if ((string)($conversation['kind'] ?? '') !== 'dm') return;

    $otherId = direct_conversation_other_user(
        $pdo,
        (int)$conversation['id'],
        $viewerId
    );

    if ($otherId <= 0 || !users_are_friends($pdo, $viewerId, $otherId)) {
        fail('Add this person as a friend and wait for them to accept before messaging or calling.', 403);
    }
}

function conversation_preferences_stored(PDO $pdo, int $conversationId, int $userId): array {
    $stmt = $pdo->prepare(
        'SELECT
            c.disappearing_seconds,
            cs.wallpaper,
            cs.wallpaper_url,
            cs.ringtone,
            cs.bubble_style,
            cs.density,
            cs.chat_font_scale,
            cs.call_banner_text,
            cs.call_banner_style
         FROM conversations c
         LEFT JOIN conversation_settings cs
           ON cs.conversation_id = c.id
          AND cs.user_id = ?
         WHERE c.id = ?
         LIMIT 1'
    );
    $stmt->execute([$userId, $conversationId]);
    $row = $stmt->fetch() ?: [];

    return [
        'wallpaper' => (string)($row['wallpaper'] ?? 'default'),
        'wallpaper_url' => (string)($row['wallpaper_url'] ?? ''),
        'ringtone' => (string)($row['ringtone'] ?? 'classic'),
        'bubble_style' => (string)($row['bubble_style'] ?? 'default'),
        'density' => (string)($row['density'] ?? 'default'),
        'chat_font_scale' => (string)($row['chat_font_scale'] ?? 'default'),
        'call_banner_text' => (string)($row['call_banner_text'] ?? ''),
        'call_banner_style' => (string)($row['call_banner_style'] ?? 'glass'),
        'disappearing_seconds' => (int)($row['disappearing_seconds'] ?? 0),
    ];
}

function conversation_preferences(PDO $pdo, int $conversationId, int $userId): array {
    $stored = conversation_preferences_stored($pdo, $conversationId, $userId);

    return [
        'wallpaper' => (string)$stored['wallpaper'],
        'wallpaper_url' => media_reference_url((string)$stored['wallpaper_url']),
        'ringtone' => (string)$stored['ringtone'],
        'bubble_style' => (string)$stored['bubble_style'],
        'density' => (string)$stored['density'],
        'chat_font_scale' => (string)$stored['chat_font_scale'],
        'call_banner_text' => (string)$stored['call_banner_text'],
        'call_banner_style' => (string)$stored['call_banner_style'],
        'disappearing_seconds' => (int)$stored['disappearing_seconds'],
    ];
}

function normalized_call_signal_payload(string $signalType, mixed $payload): array {
    if (!is_array($payload)) {
        fail('Invalid call signal payload.', 400);
    }

    if ($signalType === 'offer' || $signalType === 'answer') {
        $type = strtolower(trim((string)($payload['type'] ?? '')));
        $sdp = (string)($payload['sdp'] ?? '');

        if ($type !== $signalType || $sdp === '' || strlen($sdp) > 19000) {
            fail('Invalid call session description.', 400);
        }

        // SDP is textual and should never contain NUL bytes. Rejecting them
        // also avoids ambiguous storage/logging behavior in downstream tools.
        if (str_contains($sdp, "\0")) {
            fail('Invalid call session description.', 400);
        }

        return ['type' => $type, 'sdp' => $sdp];
    }

    if ($signalType === 'ice') {
        $candidate = (string)($payload['candidate'] ?? '');
        $sdpMid = isset($payload['sdpMid']) ? (string)$payload['sdpMid'] : null;
        $sdpMLineIndex = isset($payload['sdpMLineIndex'])
            ? (int)$payload['sdpMLineIndex']
            : null;
        $usernameFragment = isset($payload['usernameFragment'])
            ? (string)$payload['usernameFragment']
            : null;

        if (
            strlen($candidate) > 4096 ||
            ($sdpMid !== null && strlen($sdpMid) > 128) ||
            ($sdpMLineIndex !== null && ($sdpMLineIndex < 0 || $sdpMLineIndex > 64)) ||
            ($usernameFragment !== null && strlen($usernameFragment) > 256)
        ) {
            fail('Invalid ICE candidate.', 400);
        }

        return [
            'candidate' => $candidate,
            'sdpMid' => $sdpMid,
            'sdpMLineIndex' => $sdpMLineIndex,
            'usernameFragment' => $usernameFragment,
        ];
    }

    if ($signalType === 'restart') {
        $reason = strtolower(trim((string)($payload['reason'] ?? 'peer-request')));
        $allowedReasons = [
            'network',
            'network-change',
            'online',
            'failed',
            'ice-failed',
            'disconnected',
            'peer-request',
        ];

        return [
            'reason' => in_array($reason, $allowedReasons, true)
                ? $reason
                : 'peer-request',
        ];
    }

    fail('Invalid call signal.', 400);
}

function require_call_participant(PDO $pdo, int $callId, int $userId): array {
    $stmt = $pdo->prepare(
        'SELECT *
         FROM calls
         WHERE id = ?
           AND (caller_id = ? OR callee_id = ?)
         LIMIT 1'
    );
    $stmt->execute([$callId, $userId, $userId]);
    $call = $stmt->fetch();
    if (!$call) fail('Call not found.', 404);
    return $call;
}


function cleanup_old_calls(PDO $pdo): void {
    try {
        $pdo->prepare(
            "DELETE FROM calls
             WHERE ended_at IS NOT NULL
               AND ended_at < ?
             LIMIT 100"
        )->execute([time() - (7 * 86400)]);
    } catch (Throwable $e) {
        error_log('[SilkNex call cleanup] ' . $e->getMessage());
    }
}

/* Minimal CBOR decoder for WebAuthn COSE public keys. */
function cbor_read_length(string $data, int &$offset, int $additional): int {
    if ($additional < 24) return $additional;

    $sizes = [24 => 1, 25 => 2, 26 => 4, 27 => 8];
    if (!isset($sizes[$additional])) throw new RuntimeException('Unsupported CBOR length.');
    $size = $sizes[$additional];

    if ($offset + $size > strlen($data)) throw new RuntimeException('Invalid CBOR.');

    $bytes = substr($data, $offset, $size);
    $offset += $size;
    $value = 0;

    for ($i = 0; $i < $size; $i++) {
        $value = ($value << 8) | ord($bytes[$i]);
    }

    return $value;
}

function cbor_decode_item(string $data, int &$offset): mixed {
    if ($offset >= strlen($data)) throw new RuntimeException('Invalid CBOR.');

    $initial = ord($data[$offset++]);
    $major = $initial >> 5;
    $additional = $initial & 31;

    if ($major === 0) return cbor_read_length($data, $offset, $additional);
    if ($major === 1) return -1 - cbor_read_length($data, $offset, $additional);

    if ($major === 2 || $major === 3) {
        $length = cbor_read_length($data, $offset, $additional);
        $value = substr($data, $offset, $length);
        if (strlen($value) !== $length) throw new RuntimeException('Invalid CBOR.');
        $offset += $length;
        return $value;
    }

    if ($major === 4) {
        $length = cbor_read_length($data, $offset, $additional);
        $items = [];
        for ($i = 0; $i < $length; $i++) $items[] = cbor_decode_item($data, $offset);
        return $items;
    }

    if ($major === 5) {
        $length = cbor_read_length($data, $offset, $additional);
        $map = [];
        for ($i = 0; $i < $length; $i++) {
            $key = cbor_decode_item($data, $offset);
            $value = cbor_decode_item($data, $offset);
            $map[(string)$key] = $value;
        }
        return $map;
    }

    if ($major === 7) {
        return match ($additional) {
            20 => false,
            21 => true,
            22 => null,
            default => throw new RuntimeException('Unsupported CBOR simple value.'),
        };
    }

    throw new RuntimeException('Unsupported CBOR type.');
}

function asn1_length(int $length): string {
    if ($length < 128) return chr($length);
    $bytes = '';
    while ($length > 0) {
        $bytes = chr($length & 0xff) . $bytes;
        $length >>= 8;
    }
    return chr(0x80 | strlen($bytes)) . $bytes;
}

function cose_es256_to_pem(string $cose): string {
    $offset = 0;
    $key = cbor_decode_item($cose, $offset);

    if (!is_array($key)) throw new RuntimeException('Invalid passkey public key.');

    $kty = (int)($key['1'] ?? 0);
    $alg = (int)($key['3'] ?? 0);
    $crv = (int)($key['-1'] ?? 0);
    $x = $key['-2'] ?? null;
    $y = $key['-3'] ?? null;

    if ($kty !== 2 || $alg !== -7 || $crv !== 1 || !is_string($x) || !is_string($y)) {
        throw new RuntimeException('Unsupported passkey algorithm.');
    }

    if (strlen($x) !== 32 || strlen($y) !== 32) {
        throw new RuntimeException('Invalid passkey key size.');
    }

    $spkiPrefix = hex2bin('3059301306072A8648CE3D020106082A8648CE3D03010703420004');
    $der = $spkiPrefix . $x . $y;

    return "-----BEGIN PUBLIC KEY-----\n" .
        chunk_split(base64_encode($der), 64, "\n") .
        "-----END PUBLIC KEY-----\n";
}

function parse_authenticator_data(string $authData): array {
    if (strlen($authData) < 37) throw new RuntimeException('Invalid authenticator data.');

    $rpIdHash = substr($authData, 0, 32);
    $flags = ord($authData[32]);
    $counterBytes = substr($authData, 33, 4);
    $counter = unpack('N', $counterBytes)[1];

    return [
        'rp_id_hash' => $rpIdHash,
        'flags' => $flags,
        'counter' => (int)$counter,
    ];
}

function verify_webauthn_client_data(string $clientJson, string $expectedType, string $expectedChallenge): array {
    $client = json_decode($clientJson, true);
    if (!is_array($client)) fail('Invalid passkey response.', 400);

    if ((string)($client['type'] ?? '') !== $expectedType) {
        fail('Invalid passkey ceremony.', 400);
    }

    if (!hash_equals($expectedChallenge, (string)($client['challenge'] ?? ''))) {
        fail('Passkey challenge expired. Try again.', 400);
    }

    $origin = normalized_origin((string)($client['origin'] ?? ''));
    $expectedOrigin = request_origin();
    if ($origin === '' || $expectedOrigin === '' || !hash_equals($expectedOrigin, $origin)) {
        fail('Passkey origin check failed.', 403);
    }

    return $client;
}


function extract_attested_credential(string $authData): array {
    $parsed = parse_authenticator_data($authData);
    $flags = (int)$parsed['flags'];

    if (($flags & 0x01) !== 0x01 || ($flags & 0x04) !== 0x04 || ($flags & 0x40) !== 0x40) {
        throw new RuntimeException('Passkey user verification is required.');
    }

    $offset = 37;
    if (strlen($authData) < $offset + 18) {
        throw new RuntimeException('Invalid passkey registration data.');
    }

    $offset += 16; // AAGUID.
    $lengthBytes = substr($authData, $offset, 2);
    $offset += 2;
    $credentialLength = unpack('n', $lengthBytes)[1];

    if ($credentialLength <= 0 || strlen($authData) < $offset + $credentialLength) {
        throw new RuntimeException('Invalid passkey credential ID.');
    }

    $credentialId = substr($authData, $offset, $credentialLength);
    $offset += $credentialLength;

    $coseStart = $offset;
    cbor_decode_item($authData, $offset);
    $cose = substr($authData, $coseStart, $offset - $coseStart);

    // Ensure the stored key is an ES256 P-256 key we know how to verify.
    cose_es256_to_pem($cose);

    return [
        'credential_id' => $credentialId,
        'public_key_cose' => $cose,
        'counter' => (int)$parsed['counter'],
        'flags' => $flags,
        'rp_id_hash' => (string)$parsed['rp_id_hash'],
    ];
}


function normalize_avatar_style(mixed $raw): array {
    if (is_string($raw) && $raw !== '') {
        try {
            $decoded = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
            $raw = is_array($decoded) ? $decoded : [];
        } catch (Throwable $e) {
            $raw = [];
        }
    }

    if (!is_array($raw)) return [];

    $allowed = [
        'skin' => ['porcelain','fair','warm','olive','tan','brown','deep','ebony'],
        'face_shape' => ['oval','round','soft_square','heart','long','diamond','square','triangle','pear'],
        'hair' => ['crop','textured_crop','french_crop','taper_fade','low_fade','mid_fade','high_fade','curly_fade','quiff','pompadour','comb_over','two_block','waves','curls','curtain','slick_back','undercut','bob','french_bob','long','layers','wolf_cut','bun','space_buns','messy_bun','low_bun','ponytail','high_ponytail','side_part','afro','taper_afro','locs','loc_bun','twists','box_braids','dutch_braids','cornrows','mohawk','buzz','bald','hijab','pixie','braids','shag','spiky'],
        'hair_color' => ['black','espresso','brown','auburn','blonde','platinum','blue','pink','teal','silver','red','purple','copper','green'],
        'eyes' => ['round','soft','bright','sleepy','wink','almond','wide','hooded','monolid','cat'],
        'lashes' => ['none','soft','full','cat'],
        'eye_color' => ['brown','dark_brown','hazel','green','blue','gray','amber'],
        'brows' => ['soft','straight','arched','bold','tapered','rounded','high_arch','feathered'],
        'nose' => ['soft','button','straight','wide','petite','aquiline','upturned'],
        'mouth' => ['smile','grin','soft','open','cool','neutral','smirk','kiss','laugh'],
        'face_detail' => ['none','blush','freckles','beauty_mark','sun_kiss','cheek_mark','freckles_dense','under_eye','scar_brow','dimples'],
        'outfit' => ['tee','hoodie','jacket','sweater','shirt','tank','turtleneck','blazer','vest','jersey','bomber','denim','varsity','dress','overalls'],
        'outfit_color' => ['charcoal','silver','blue','green','purple','orange','pink','red','teal','yellow','white'],
        'outfit_pattern' => ['solid','stripe','badge','split','checker','gradient'],
        'background' => ['neo','blue','mint','violet','sunset','mono','rose','ocean','forest','gold','coral','lavender'],
        'background_pattern' => ['clean','dots','rings','grid','halo','diagonal','stars','checker','aurora','sparkles'],
        'accessory' => ['none','glasses','round_glasses','square_glasses','aviator','heart_glasses','sunglasses','earrings','hoop_earrings','studs','nose_ring','septum','lip_ring','chain','pearl_chain','choker','monocle','brow_ring','hearing_aid','face_bandage','earbuds'],
        'accessory_color' => ['charcoal','silver','gold','blue','pink','red','white'],
        'headwear' => ['none','beanie','bandana','durag','cap','snapback','sports_cap','headphones','crown','bucket','flower','beret','fedora','visor','cowboy','tiara','cat_ears','hood','headband','bow'],
        'facial_hair' => ['none','stubble','mustache','beard','goatee','boxed_beard','full_beard','soul_patch'],
        'hair_highlight' => ['none','soft','streaks','tips'],
        'makeup' => ['none','rosy','liner','bold'],
        'face_decal' => ['none','star','heart','bolt'],
    ];

    $normalized = [];
    foreach ($allowed as $key => $values) {
        $value = strtolower(trim((string)($raw[$key] ?? '')));
        if (in_array($value, $values, true)) {
            $normalized[$key] = $value;
        }
    }

    foreach (['skin_hex','hair_hex','outfit_hex','background_hex','accessory_hex','hair_highlight_hex','eye_hex','lip_hex'] as $key) {
        $value = strtolower(trim((string)($raw[$key] ?? '')));
        if (preg_match('/^#[0-9a-f]{6}$/', $value) === 1) {
            $normalized[$key] = $value;
        }
    }

    foreach ([
        'face_width' => [82, 120],
        'face_length' => [86, 116],
        'jaw_width' => [82, 122],
        'eye_scale' => [75, 135],
        'iris_size' => [65, 145],
        'eye_spacing' => [75, 130],
        'eye_height' => [88, 112],
        'nose_scale' => [78, 125],
        'mouth_width' => [78, 128],
        'brow_height' => [86, 116],
        'ear_size' => [80, 124],
        'neck_width' => [80, 125],
        'eye_tilt' => [82, 118],
        'brow_thickness' => [70, 145],
        'nose_width' => [76, 132],
        'lip_fullness' => [72, 140],
        'facial_hair_opacity' => [20, 100],
        'hair_volume' => [82, 125],
    ] as $key => [$min, $max]) {
        if (!array_key_exists($key, $raw)) continue;
        $value = max($min, min($max, (int)$raw[$key]));
        $normalized[$key] = (string)$value;
    }

    return $normalized;
}

function avatar_style_json(mixed $raw): ?string {
    $style = normalize_avatar_style($raw);
    if (!$style) return null;
    return json_encode($style, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

function call_ice_servers_for_user(array $user): array {
    $cfg = config();
    $servers = [
        ['urls' => [
            'stun:stun.l.google.com:19302',
            'stun:stun1.l.google.com:19302',
            'stun:stun2.l.google.com:19302',
            'stun:stun.cloudflare.com:3478',
        ]],
    ];

    $rawUrls = $cfg['turn_urls'] ?? [];
    if (is_string($rawUrls)) {
        $rawUrls = array_values(array_filter(array_map('trim', explode(',', $rawUrls))));
    }
    if (!is_array($rawUrls)) $rawUrls = [];

    $turnUrls = [];
    foreach ($rawUrls as $url) {
        $url = trim((string)$url);
        if ($url === '' || strlen($url) > 512) continue;
        $lowerUrl = strtolower($url);
        if (
            str_starts_with($lowerUrl, 'turn:') ||
            str_starts_with($lowerUrl, 'turns:')
        ) {
            $turnUrls[] = $url;
        }
        if (count($turnUrls) >= 8) break;
    }
    $turnUrls = array_values(array_unique($turnUrls));

    if (!$turnUrls) return $servers;

    $username = substr(trim((string)($cfg['turn_username'] ?? '')), 0, 256);
    $credential = substr((string)($cfg['turn_credential'] ?? ''), 0, 1024);
    $secret = substr((string)($cfg['turn_secret'] ?? ''), 0, 1024);

    // coturn TURN REST credentials: timestamp:user-id + HMAC-SHA1 secret.
    // This keeps a long-lived shared TURN password out of the browser.
    if ($secret !== '') {
        $expiry = time() + 3600;
        $username = $expiry . ':neochat-' . (int)($user['id'] ?? 0);
        $credential = base64_encode(hash_hmac('sha1', $username, $secret, true));
    }

    if ($username !== '' && $credential !== '') {
        $servers[] = [
            'urls' => $turnUrls,
            'username' => $username,
            'credential' => $credential,
        ];
    }

    return $servers;
}

function public_user(array $row): array {
    $seen = (int)($row['last_seen_at'] ?? 0);
    $onlineUntil = (int)($row['online_until'] ?? 0);

    return [
        'id' => (int)$row['id'],
        'username' => (string)$row['username'],
        'display_name' => (string)$row['display_name'],
        'about' => (string)($row['about'] ?? ''),
        'accent' => (static function (string $accent): string {
            $allowed = ['silver', 'steel', 'graphite', 'frost', 'smoke'];
            return in_array($accent, $allowed, true) ? $accent : 'silver';
        })((string)($row['accent'] ?? 'silver')),
        'avatar_url' => media_reference_url((string)($row['avatar_url'] ?? '')),
        'avatar_style' => normalize_avatar_style($row['avatar_style'] ?? []),
        'profile_banner_url' => media_reference_url((string)($row['profile_banner_url'] ?? '')),
        'public_profile' => (bool)($row['public_profile'] ?? true),
        'online' => $onlineUntil >= time(),
        'last_seen_at' => $seen,
        'role' => public_staff_role($row),
    ];
}

function self_user(array $row): array {
    return public_user($row) + [
        'username_changed_at' => (int)($row['username_changed_at'] ?? 0),
        'theme' => in_array((string)($row['theme'] ?? 'dark'), ['system','dark','light','amoled'], true)
            ? (string)$row['theme']
            : 'dark',
        'app_icon_style' => in_array((string)($row['app_icon_style'] ?? 'auto'), ['auto','dark','light'], true)
            ? (string)$row['app_icon_style']
            : 'auto',
        'wallpaper' => (string)($row['wallpaper'] ?? 'neo'),
        'wallpaper_url' => media_reference_url((string)($row['wallpaper_url'] ?? '')),
        'font_scale' => in_array((string)($row['font_scale'] ?? 'normal'), ['small','normal','large'], true)
            ? (string)$row['font_scale']
            : 'normal',
        'font_family' => in_array((string)($row['font_family'] ?? 'system'), ['system','rounded','serif','mono','humanist','condensed','book'], true)
            ? (string)$row['font_family']
            : 'system',
        'ui_accent' => in_array((string)($row['ui_accent'] ?? 'silver'), ['silver','blue','green','purple','orange'], true)
            ? (string)$row['ui_accent']
            : 'silver',
        'bubble_style' => in_array((string)($row['bubble_style'] ?? 'rounded'), ['rounded','soft','square'], true)
            ? (string)$row['bubble_style']
            : 'rounded',
        'message_density' => in_array((string)($row['message_density'] ?? 'normal'), ['compact','normal','spacious'], true)
            ? (string)$row['message_density']
            : 'normal',
        'chat_width' => in_array((string)($row['chat_width'] ?? 'normal'), ['narrow','normal','wide'], true)
            ? (string)$row['chat_width']
            : 'normal',
        'reduce_motion' => (bool)($row['reduce_motion'] ?? false),
        'easy_mode' => (bool)($row['easy_mode'] ?? false),
        'notifications_enabled' => (bool)($row['notifications_enabled'] ?? false),
        'kid_mode' => (bool)($row['kid_mode'] ?? false),
        // Only the signed-in user receives their filtering vocabulary. It is
        // intentionally omitted from public_user() and therefore never leaks
        // through profiles, friend search, conversation members, or stories.
        'kid_blocked_words' => normalized_kid_words(
            (string)($row['kid_blocked_words'] ?? '')
        ),
    ];
}


function public_staff_role(array $user): string {
    if (strcasecmp((string)($user['username'] ?? ''), FOUNDER_USERNAME) === 0
        && ($user['account_role'] ?? '') === 'founder_ceo') return 'founder_ceo';
    if (strcasecmp((string)($user['username'] ?? ''), COFOUNDER_USERNAME) === 0
        && ($user['account_role'] ?? '') === 'cofounder_ceo') return 'cofounder_ceo';
    return 'member';
}

function is_founder_user(array $user): bool {
    return public_staff_role($user) !== 'member';
}

function is_primary_founder_user(array $user): bool {
    return (string)($user['account_role'] ?? '') === 'founder_ceo'
        && strcasecmp((string)($user['username'] ?? ''), FOUNDER_USERNAME) === 0;
}

function require_founder(): array {
    $user = current_user();
    if (!is_founder_user($user)) {
        fail('Founder access required.', 403);
    }
    return $user;
}

function active_access_block(PDO $pdo, ?int $now = null): ?array {
    $now ??= time();
    $stmt = $pdo->prepare(
        'SELECT id, starts_at, ends_at, note FROM owner_access_blocks
         WHERE starts_at <= ? AND ends_at > ? ORDER BY ends_at DESC LIMIT 1'
    );
    $stmt->execute([$now, $now]);
    $block = $stmt->fetch();
    return $block ?: null;
}

function access_block_guard(string $action): void {
    // Preserve payments, health, and an emergency release path during a block.
    if (in_array($action, [
        'health', 'ads_txt', 'stripe_webhook', 'access_block_status',
        'owner_access_blocks', 'owner_access_block_create',
        'owner_access_block_delete', 'login', 'logout'
    ], true)) return;
    $block = active_access_block(db());
    if (!$block) return;
    http_response_code(423);
    header('Retry-After: ' . min(86400, max(1, (int)$block['ends_at'] - time())));
    echo json_encode([
        'ok' => false,
        'error' => 'SilkNex is unavailable during a scheduled access block.',
        'access_block' => [
            'id' => (int)$block['id'],
            'ends_at' => (int)$block['ends_at'],
            'note' => (string)$block['note'],
        ],
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function owner_audit(PDO $pdo, int $ownerUserId, string $action, string $target = '', array $details = []): void {
    $action = substr(preg_replace('/[^a-z0-9_.:-]/i', '', $action) ?? '', 0, 64);
    if ($action === '') return;

    $target = mb_substr(trim($target), 0, 120);
    $detailsJson = null;
    if ($details !== []) {
        $detailsJson = json_encode(
            $details,
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE
        );
        if (!is_string($detailsJson) || strlen($detailsJson) > 8000) {
            $detailsJson = json_encode(['note' => 'Details omitted because they were too large.']);
        }
    }

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO owner_audit_log
                (owner_user_id, action, target, details_json, created_at)
             VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([$ownerUserId, $action, $target, $detailsJson, time()]);
    } catch (Throwable $e) {
        // Operational logging must never make the control action itself fail.
        error_log('[SilkNex owner audit] ' . $e->getMessage());
    }
}

function owner_feature_flags(PDO $pdo): array {
    return [
        'posting_paused' => app_meta_value($pdo, 'owner_posting_paused_v1') === '1',
        'ads_paused' => app_meta_value($pdo, 'owner_ads_paused_v1') === '1',
        'ad_sales_paused' => app_meta_value($pdo, 'owner_ad_sales_paused_v1') === '1',
        'protection_mode' => app_meta_value($pdo, 'owner_protection_mode_v1') === '1',
        'uploads_paused' => app_meta_value($pdo, 'owner_uploads_paused_v1') === '1',
        'calls_paused' => app_meta_value($pdo, 'owner_calls_paused_v1') === '1',
    ];
}

function active_system_announcement(PDO $pdo): ?array {
    $raw = app_meta_value($pdo, 'system_announcement_v1');
    if (!is_string($raw) || trim($raw) === '') return null;

    $data = json_decode($raw, true);
    if (!is_array($data)) return null;

    $text = trim((string)($data['text'] ?? ''));
    $expiresAt = max(0, (int)($data['expires_at'] ?? 0));
    $updatedAt = max(0, (int)($data['updated_at'] ?? 0));
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($data['id'] ?? ''));

    if ($text === '' || $expiresAt <= time() || $updatedAt <= 0 || $id === '') {
        return null;
    }

    return [
        'id' => $id,
        'text' => $text,
        'expires_at' => $expiresAt,
        'updated_at' => $updatedAt,
    ];
}

function current_user(): array {
    $id = (int)($_SESSION['user_id'] ?? 0);

    if ($id <= 0 && restore_login_from_token()) {
        $id = (int)($_SESSION['user_id'] ?? 0);
    }

    if ($id <= 0) {
        fail('Authentication required.', 401);
    }

    $currentFingerprint = client_fingerprint();
    $sessionFingerprint = (string)($_SESSION['client_fingerprint'] ?? '');
    if ($sessionFingerprint === '') {
        // Adopt upgraded pre-v28 sessions once. New sessions are fingerprinted
        // at authentication time.
        $_SESSION['client_fingerprint'] = $currentFingerprint;
    } elseif (!hash_equals($sessionFingerprint, $currentFingerprint)) {
        revoke_current_remember_token();
        destroy_login_session();
        fail('This login changed browsers. Sign in again for security.', 401);
    }

    $lastActivity = (int)($_SESSION['last_activity'] ?? time());

    if ($lastActivity < time() - (60 * 60 * 12)) {
        $_SESSION = [];
        session_regenerate_id(true);

        if (!restore_login_from_token()) {
            fail('Session expired. Log in again.', 401);
        }

        $id = (int)($_SESSION['user_id'] ?? 0);
    }

    $now = time();
    // Do not dirty/write the PHP session file on every heartbeat. Refresh the
    // inactivity marker at most once per minute; the 12-hour timeout semantics
    // remain unchanged while concurrent tabs spend less time on session I/O.
    if ($lastActivity < $now - 60) {
        $_SESSION['last_activity'] = $now;
    }

    // High-frequency read endpoints (inbox/sync/call polling) do not need to
    // re-read the same user profile row on every request. Keep a very short
    // server-side session snapshot. POST/PUT/DELETE requests always bypass it,
    // and the small TTL bounds device-revocation/profile-change propagation.
    $readOnlyRequest = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'GET';
    $cachedUser = $_SESSION['user_snapshot'] ?? null;
    $cachedAt = (int)($_SESSION['user_snapshot_at'] ?? 0);
    if (
        $readOnlyRequest &&
        is_array($cachedUser) &&
        $cachedAt >= time() - 20 &&
        (int)($cachedUser['id'] ?? 0) === $id &&
        max(1, (int)($cachedUser['session_version'] ?? 1)) ===
            max(1, (int)($_SESSION['session_version'] ?? 1))
    ) {
        // Open/validate the request's PDO connection while the session schema
        // marker is still available, then reuse that connection after the
        // endpoint releases the PHP session lock.
        db();
        return $cachedUser;
    }

    $pdo = db();
    $stmt = $pdo->prepare(
        'SELECT id, username, display_name, about, accent, avatar_url, avatar_style,
                theme, app_icon_style, wallpaper, wallpaper_url, font_scale, font_family, ui_accent,
                bubble_style, message_density, chat_width, reduce_motion, easy_mode,
                notifications_enabled,
                kid_mode, kid_pin_hash, kid_blocked_words,
                passkey_user_handle, last_seen_at, online_until, session_version, account_role
         FROM users
         WHERE id = ? AND disabled_at IS NULL
         LIMIT 1'
    );
    $stmt->execute([$id]);
    $user = $stmt->fetch();

    if (!$user) {
        revoke_current_remember_token();
        $_SESSION = [];
        session_destroy();
        fail('Session expired.', 401);
    }

    $databaseSessionVersion = max(1, (int)($user['session_version'] ?? 1));
    $sessionVersion = max(0, (int)($_SESSION['session_version'] ?? 0));

    // Older SilkNex sessions did not carry a database generation number.
    // Re-authenticate those through their persistent token instead of blindly
    // trusting them. This also makes device revocation work across upgrades.
    if ($sessionVersion === 0) {
        $_SESSION = [];
        session_regenerate_id(true);

        if (!restore_login_from_token()) {
            fail('Security upgrade requires you to log in again.', 401);
        }

        return current_user();
    }

    if ($sessionVersion !== $databaseSessionVersion) {
        revoke_current_remember_token();
        $_SESSION = [];
        session_destroy();
        fail('This login was revoked. Log in again.', 401);
    }

    // Periodic ID rotation limits the lifetime of a captured session ID.
    $rotatedAt = (int)($_SESSION['rotated_at'] ?? 0);
    if ($rotatedAt < time() - 900) {
        rotate_session_id_safely();
    }

    // Online presence is intentionally not refreshed by ordinary authenticated
    // requests. Only the explicit foreground presence lease may mark a user
    // online, so background tabs and notification polling do not fake activity.

    if ($readOnlyRequest) {
        $_SESSION['user_snapshot'] = $user;
        $_SESSION['user_snapshot_at'] = time();
    } else {
        unset($_SESSION['user_snapshot'], $_SESSION['user_snapshot_at']);
    }

    return $user;
}

function destroy_login_session(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => $p['path'],
            'domain' => $p['domain'],
            'secure' => $p['secure'],
            'httponly' => $p['httponly'],
            'samesite' => $p['samesite'] ?? 'Strict',
        ]);
    }
    session_destroy();
}

function session_rate_limit(
    string $action,
    int $max,
    int $seconds,
    string $message = 'Too many requests. Try again shortly.'
): void {
    $now = time();
    $key = 'rl:' . preg_replace('/[^a-z0-9_.-]/i', '', $action);
    $bucket = $_SESSION[$key] ?? null;

    if (
        !is_array($bucket) ||
        (int)($bucket['started_at'] ?? 0) <= $now - $seconds
    ) {
        $_SESSION[$key] = ['started_at' => $now, 'attempts' => 1];
        return;
    }

    $attempts = max(0, (int)($bucket['attempts'] ?? 0));
    $startedAt = max(0, (int)($bucket['started_at'] ?? $now));

    if ($attempts >= $max) {
        header('Retry-After: ' . max(1, ($startedAt + $seconds) - $now));
        fail($message, 429);
    }

    $_SESSION[$key]['attempts'] = $attempts + 1;
}

function rate_limit(
    string $action,
    int $max,
    int $seconds,
    string $subject = '',
    string $scope = 'ip',
    string $message = 'Too many attempts. Try again shortly.'
): void {
    $pdo = db();

    if ($scope === 'device') {
        $base = 'device:' . (string)($_SESSION['rate_key'] ?? session_id());
    } elseif ($scope === 'subject') {
        $base = 'subject:' . strtolower(trim($subject));
        $subject = '';
    } else {
        $base = 'ip:' . (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    }

    $material = $base . '|' . strtolower(trim($subject));
    $key = hash('sha256', $material);
    $now = time();
    $cutoff = $now - $seconds;

    try {
        $pdo->beginTransaction();

        $select = $pdo->prepare(
            'SELECT attempts, window_started_at
             FROM rate_limits
             WHERE ip_hash = ? AND action_name = ?
             FOR UPDATE'
        );
        $select->execute([$key, $action]);
        $row = $select->fetch();

        if (!$row || (int)$row['window_started_at'] < $cutoff) {
            $pdo->prepare(
                'INSERT INTO rate_limits
                 (ip_hash, action_name, attempts, window_started_at)
                 VALUES (?, ?, 1, ?)
                 ON DUPLICATE KEY UPDATE
                   attempts = 1,
                   window_started_at = VALUES(window_started_at)'
            )->execute([$key, $action, $now]);
        } else {
            if ((int)$row['attempts'] >= $max) {
                $retryAfter = max(1, ((int)$row['window_started_at'] + $seconds) - $now);
                $pdo->rollBack();
                header('Retry-After: ' . $retryAfter);
                fail($message, 429);
            }

            $pdo->prepare(
                'UPDATE rate_limits
                 SET attempts = attempts + 1
                 WHERE ip_hash = ? AND action_name = ?'
            )->execute([$key, $action]);
        }

        $pdo->commit();

        if (claim_maintenance_slot($pdo, 'rate_limits', 120)) {
            $pdo->prepare(
                'DELETE FROM rate_limits
                 WHERE window_started_at < ?
                 ORDER BY window_started_at ASC
                 LIMIT 500'
            )->execute([$now - 86400]);
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log('[SilkNex rate limit] ' . $e->getMessage());
        fail('Security check unavailable. Try again shortly.', 503);
    }
}

function clear_rate_limit(
    string $action,
    string $subject = '',
    string $scope = 'ip'
): void {
    try {
        if ($scope === 'device') {
            $base = 'device:' . (string)($_SESSION['rate_key'] ?? session_id());
        } elseif ($scope === 'subject') {
            $base = 'subject:' . strtolower(trim($subject));
            $subject = '';
        } else {
            $base = 'ip:' . (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        }

        $material = $base . '|' . strtolower(trim($subject));
        $key = hash('sha256', $material);
        db()->prepare(
            'DELETE FROM rate_limits WHERE ip_hash = ? AND action_name = ?'
        )->execute([$key, $action]);
    } catch (Throwable $e) {
        // A successful authentication must not fail because optional throttle
        // cleanup had a transient database error.
        error_log('[SilkNex rate-limit cleanup] ' . $e->getMessage());
    }
}

function revalidate_user_generation(PDO $pdo, array $user): void {
    $stmt = $pdo->prepare(
        'SELECT session_version
         FROM users
         WHERE id = ? AND disabled_at IS NULL
         LIMIT 1'
    );
    $stmt->execute([(int)$user['id']]);
    $version = $stmt->fetchColumn();

    if (
        $version === false ||
        max(1, (int)$version) !== max(1, (int)($user['session_version'] ?? 1))
    ) {
        fail('This login was revoked. Log in again.', 401);
    }
}

function require_member(int $conversationId, int $userId): array {
    $pdo = db();
    $stmt = $pdo->prepare(
        'SELECT c.*,
                cm.hidden_at AS member_hidden_at,
                cm.cleared_before_message_id AS cleared_before_message_id,
                cm.pinned_at AS pinned_at
         FROM conversations c
         INNER JOIN conversation_members cm ON cm.conversation_id = c.id
         WHERE c.id = ? AND cm.user_id = ?
         LIMIT 1'
    );
    $stmt->execute([$conversationId, $userId]);
    $row = $stmt->fetch();
    if (!$row) fail('Conversation not found.', 404);
    v77_channel_access($conversationId, $userId);
    return $row;
}

function group_proposals_for_viewer(PDO $pdo, int $conversationId, int $viewerId): array {
    $pdo->prepare(
        "UPDATE group_change_proposals
         SET status = 'expired', resolved_at = ?
         WHERE conversation_id = ? AND status = 'open' AND expires_at <= ?"
    )->execute([time(), $conversationId, time()]);

    $stmt = $pdo->prepare(
        "SELECT
            p.id, p.proposed_by, p.change_type, p.proposed_name,
            p.proposed_avatar_token, p.status, p.created_at, p.expires_at,
            proposer.display_name AS proposer_name,
            SUM(CASE WHEN voting_member.user_id IS NOT NULL
                           AND voting_user.id IS NOT NULL
                           AND v.vote = 'yes' THEN 1 ELSE 0 END) AS yes_count,
            SUM(CASE WHEN voting_member.user_id IS NOT NULL
                           AND voting_user.id IS NOT NULL
                           AND v.vote = 'no' THEN 1 ELSE 0 END) AS no_count,
            MAX(CASE WHEN voting_member.user_id IS NOT NULL
                          AND voting_user.id IS NOT NULL
                          AND v.user_id = ? THEN v.vote ELSE NULL END) AS viewer_vote,
            (
              SELECT COUNT(*)
              FROM conversation_members cm2
              INNER JOIN users u2 ON u2.id = cm2.user_id AND u2.disabled_at IS NULL
              WHERE cm2.conversation_id = p.conversation_id
            ) AS member_count
         FROM group_change_proposals p
         INNER JOIN users proposer ON proposer.id = p.proposed_by
         LEFT JOIN group_change_votes v ON v.proposal_id = p.id
         LEFT JOIN conversation_members voting_member
           ON voting_member.conversation_id = p.conversation_id
          AND voting_member.user_id = v.user_id
         LEFT JOIN users voting_user
           ON voting_user.id = v.user_id
          AND voting_user.disabled_at IS NULL
         WHERE p.conversation_id = ? AND p.status = 'open'
         GROUP BY p.id, p.proposed_by, p.change_type, p.proposed_name,
                  p.proposed_avatar_token, p.status, p.created_at, p.expires_at,
                  proposer.display_name
         ORDER BY p.created_at DESC
         LIMIT 10"
    );
    $stmt->execute([$viewerId, $conversationId]);

    $items = [];
    foreach ($stmt->fetchAll() as $row) {
        $avatarToken = (string)($row['proposed_avatar_token'] ?? '');
        $items[] = [
            'id' => (int)$row['id'],
            'proposed_by' => (int)$row['proposed_by'],
            'proposer_name' => (string)$row['proposer_name'],
            'change_type' => (string)$row['change_type'],
            'proposed_name' => (string)($row['proposed_name'] ?? ''),
            'proposed_avatar_url' => preg_match('/^[a-f0-9]{48}$/', $avatarToken)
                ? media_reference_url(media_store_reference($avatarToken))
                : '',
            'yes_count' => (int)($row['yes_count'] ?? 0),
            'no_count' => (int)($row['no_count'] ?? 0),
            'member_count' => (int)($row['member_count'] ?? 0),
            'viewer_vote' => (string)($row['viewer_vote'] ?? ''),
            'created_at' => (int)$row['created_at'],
            'expires_at' => (int)$row['expires_at'],
        ];
    }
    return $items;
}

function conversation_info(array $conversation, int $viewerId): array {
    $pdo = db();
    $id = (int)$conversation['id'];

    $stmt = $pdo->prepare(
        'SELECT u.id, u.username, u.display_name, u.about, u.accent,
                u.avatar_url, u.avatar_style, u.last_seen_at, u.account_role,
                COALESCE(fn.nickname, \'\') AS nickname
         FROM conversation_members cm
         INNER JOIN users u ON u.id = cm.user_id
         LEFT JOIN friend_nicknames fn
           ON fn.viewer_id = ? AND fn.friend_id = u.id
         WHERE cm.conversation_id = ? AND u.disabled_at IS NULL
         ORDER BY u.display_name, u.username'
    );
    $stmt->execute([$viewerId, $id]);
    $members = $stmt->fetchAll();

    if ($conversation['kind'] === 'group') {
        $title = (string)($conversation['name'] ?: 'Group');
        $subtitle = count($members) . ' members';
    } else {
        $other = null;
        foreach ($members as $member) {
            if ((int)$member['id'] !== $viewerId) {
                $other = $member;
                break;
            }
        }
        $nickname = $other ? trim((string)($other['nickname'] ?? '')) : '';
        $title = $other
            ? ($nickname !== '' ? $nickname : (string)$other['display_name'])
            : 'Direct message';
        $subtitle = $other ? '@' . (string)$other['username'] : 'Direct message';
    }

    $memberItems = array_map(
        static function (array $member): array {
            $item = public_user($member);
            $item['nickname'] = (string)($member['nickname'] ?? '');
            return $item;
        },
        $members
    );

    return [
        'id' => $id,
        'kind' => (string)$conversation['kind'],
        'change_seq' => (int)($conversation['change_seq'] ?? 0),
        'title' => $title,
        'subtitle' => $subtitle,
        'members' => $memberItems,
        'avatar_url' => (string)$conversation['kind'] === 'group'
            ? media_reference_url((string)($conversation['avatar_url'] ?? ''))
            : '',
        'group_proposals' => (string)$conversation['kind'] === 'group'
            ? group_proposals_for_viewer($pdo, $id, $viewerId)
            : [],
    ];
}

function map_message(array $row, ?array $viewer = null): array {
    $expired =
        ($row['expires_at'] ?? null) !== null &&
        (int)$row['expires_at'] <= time();
    $deleted = $row['deleted_at'] !== null || $expired;

    $body = '';
    if (!$deleted) {
        $body = message_plain_body(
            (string)($row['body'] ?? ''),
            (int)($row['body_encrypted'] ?? 0),
            $row['body_compact'] ?? null,
            (int)($row['body_format'] ?? 0)
        );

        if ($viewer !== null) {
            $body = censor_for_kid($body, $viewer);
        }
    }

    $replyBody = 'Message deleted';

    if (
        $row['reply_to_id'] !== null &&
        $row['reply_deleted_at'] === null
    ) {
        $replyExpired =
            isset($row['reply_expires_at']) &&
            $row['reply_expires_at'] !== null &&
            (int)$row['reply_expires_at'] <= time();

        if ($replyExpired) {
            $replyBody = 'Message expired';
        } else {
            $replyBody = message_plain_body(
                (string)($row['reply_body'] ?? ''),
                (int)($row['reply_body_encrypted'] ?? 0),
                $row['reply_body_compact'] ?? null,
                (int)($row['reply_body_format'] ?? 0)
            );
        }

        if ($replyBody === '') {
            $replyBody = match ((string)($row['reply_message_type'] ?? 'text')) {
                'image' => 'Photo',
                'gif' => 'GIF',
                'sticker' => 'Sticker',
                'video' => 'Video',
                'audio' => 'Voice message',
                'video_note' => 'Video message',
                default => 'Attachment',
            };
        }

        if ($viewer !== null) {
            $replyBody = censor_for_kid($replyBody, $viewer);
        }
    }

    $attachmentUrl = '';

    if (!$deleted) {
        $attachmentToken = (string)($row['attachment_token'] ?? '');

        if (preg_match('/^[a-f0-9]{48}$/', $attachmentToken)) {
            $attachmentUrl = media_reference_url(
                media_store_reference($attachmentToken)
            );
        } else {
            $attachmentUrl = media_reference_url(
                (string)($row['attachment_url'] ?? '')
            );
        }
    }

    return [
        'id' => (int)$row['id'],
        'conversation_id' => (int)$row['conversation_id'],
        'sender_id' => (int)$row['sender_id'],
        'sender_username' => (string)$row['sender_username'],
        'sender_display_name' => (string)$row['sender_display_name'],
        'sender_accent' => (string)$row['sender_accent'],
        'sender_avatar_url' => media_reference_url(
            (string)($row['sender_avatar_url'] ?? '')
        ),
        'sender_avatar_style' => normalize_avatar_style($row['sender_avatar_style'] ?? []),
        'sender_role' => public_staff_role(['account_role'=>$row['sender_role']??'member','username'=>$row['sender_username']??'']),
        'body' => $body,
        'repeat_count' => max(1,(int)($row['repeat_count'] ?? 1)),
        'e2ee_payload' => !$deleted ? (string)($row['e2ee_payload'] ?? '') : '',
        'message_type' => (string)($row['message_type'] ?? 'text'),
        'attachment_url' => $attachmentUrl,
        'attachment_mime' => $deleted ? '' : (string)($row['attachment_mime'] ?? ''),
        'attachment_name' => $deleted ? '' : (string)($row['attachment_name'] ?? ''),
        'attachment_size' => $deleted ? 0 : (int)($row['attachment_size'] ?? 0),
        'duration_ms' => $deleted ? 0 : (int)($row['duration_ms'] ?? 0),
        'expires_at' => !$deleted && ($row['expires_at'] ?? null) !== null
            ? (int)$row['expires_at']
            : null,
        'created_at' => (int)$row['created_at'],
        'updated_at' => (int)($row['updated_at'] ?? ((int)$row['created_at'] * 1000)),
        'edited_at' => $row['edited_at'] !== null ? (int)$row['edited_at'] : null,
        'deleted_at' => $row['deleted_at'] !== null ? (int)$row['deleted_at'] : null,
        'expired' => $expired,
        'reply' => $row['reply_to_id'] !== null ? [
            'id' => (int)$row['reply_to_id'],
            'sender_display_name' => (string)($row['reply_sender_display_name'] ?? 'Unknown'),
            'body' => $replyBody,
            'e2ee_payload' => (string)($row['reply_e2ee_payload'] ?? ''),
        ] : null,
    ];
}


function touch_reply_dependents(
    PDO $pdo,
    int $conversationId,
    int $messageId,
    int $changedAt
): void {
    if ($conversationId <= 0 || $messageId <= 0 || $changedAt <= 0) return;

    // Keep reply previews index-friendly. When a replied-to message changes,
    // stamp the dependent rows themselves instead of making every live sync
    // compute GREATEST(parent.updated_at, reply.updated_at), which prevents
    // MySQL from using idx_messages_updated efficiently on large conversations.
    $stmt = $pdo->prepare(
        'UPDATE messages
         SET updated_at = GREATEST(updated_at, ?)
         WHERE conversation_id = ?
           AND reply_to_id = ?'
    );
    $stmt->execute([$changedAt, $conversationId, $messageId]);
}


function map_messages(PDO $pdo, array $rows, ?array $viewer = null): array {
    if (!$rows) return [];

    $items = [];
    $ids = [];

    foreach ($rows as $row) {
        $message = map_message($row, $viewer);
        $message['reactions'] = [];
        $items[(int)$message['id']] = $message;
        $ids[] = (int)$message['id'];
    }

    $ids = array_values(array_filter(array_unique($ids), static fn(int $id): bool => $id > 0));
    if (!$ids) return array_values($items);

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare(
        "SELECT r.message_id, r.user_id, r.reaction, r.updated_at,
                u.display_name, u.accent, u.avatar_url, u.avatar_style
         FROM message_reactions r
         INNER JOIN users u ON u.id = r.user_id AND u.disabled_at IS NULL
         WHERE r.message_id IN ({$placeholders})
         ORDER BY r.updated_at ASC, r.user_id ASC"
    );
    $stmt->execute($ids);

    foreach ($stmt->fetchAll() as $reaction) {
        $messageId = (int)$reaction['message_id'];
        if (!isset($items[$messageId])) continue;

        $items[$messageId]['reactions'][] = [
            'user_id' => (int)$reaction['user_id'],
            'reaction' => (string)$reaction['reaction'],
            'display_name' => (string)$reaction['display_name'],
            'accent' => (string)($reaction['accent'] ?? 'silver'),
            'avatar_url' => media_reference_url((string)($reaction['avatar_url'] ?? '')),
            'avatar_style' => normalize_avatar_style($reaction['avatar_style'] ?? []),
            'updated_at' => (int)$reaction['updated_at'],
        ];
    }

    return array_values($items);
}



function release_due_scheduled_messages(PDO $pdo): void {
    $now = time();
    $stmt = $pdo->prepare(
        "SELECT id
         FROM scheduled_messages
         WHERE status = 'pending' AND scheduled_at <= ?
         ORDER BY scheduled_at ASC, id ASC
         LIMIT 25"
    );
    $stmt->execute([$now]);
    $ids = array_map('intval', array_column($stmt->fetchAll(), 'id'));

    foreach ($ids as $scheduledId) {
        try {
            $pdo->beginTransaction();

            $locked = $pdo->prepare(
                "SELECT s.*, c.kind, c.disappearing_seconds
                 FROM scheduled_messages s
                 INNER JOIN conversations c ON c.id = s.conversation_id
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = s.conversation_id
                  AND cm.user_id = s.sender_id
                 INNER JOIN users sender
                   ON sender.id = s.sender_id
                  AND sender.disabled_at IS NULL
                 WHERE s.id = ? AND s.status = 'pending' AND s.scheduled_at <= ?
                 FOR UPDATE"
            );
            $locked->execute([$scheduledId, $now]);
            $row = $locked->fetch();

            if (!$row) {
                $pdo->commit();
                continue;
            }

            $cid = (int)$row['conversation_id'];
            $senderId = (int)$row['sender_id'];

            if ((string)$row['kind'] === 'dm') {
                $otherId = direct_conversation_other_user($pdo, $cid, $senderId);
                if ($otherId <= 0 || !users_are_friends($pdo, $senderId, $otherId)) {
                    $pdo->prepare(
                        "UPDATE scheduled_messages SET status = 'cancelled' WHERE id = ?"
                    )->execute([$scheduledId]);
                    $pdo->commit();
                    continue;
                }
            }

            $replyTo = $row['reply_to_id'] !== null ? (int)$row['reply_to_id'] : null;
            if ($replyTo !== null) {
                $replyCheck = $pdo->prepare(
                    "SELECT id FROM messages
                     WHERE id = ? AND conversation_id = ? AND deleted_at IS NULL
                     LIMIT 1"
                );
                $replyCheck->execute([$replyTo, $cid]);
                if (!$replyCheck->fetchColumn()) $replyTo = null;
            }

            $expiresAt = (int)$row['disappearing_seconds'] > 0
                ? $now + (int)$row['disappearing_seconds']
                : null;
            $clientNonce = bin2hex(random_bytes(16));

            $pdo->prepare(
                "INSERT INTO messages
                 (conversation_id, sender_id, body, body_encrypted,
                  body_compact, body_format, e2ee_payload, reply_to_id, created_at, updated_at,
                  client_nonce, message_type, attachment_size, duration_ms, expires_at)
                 VALUES (?, ?, '', 1, ?, 1, NULLIF(?, ''), ?, ?, ?, ?, 'text', 0, 0, ?)"
            )->execute([
                $cid,
                $senderId,
                $row['body'],
                (string)($row['e2ee_payload'] ?? ''),
                $replyTo,
                $now,
                now_ms(),
                $clientNonce,
                $expiresAt
            ]);

            $messageId = (int)$pdo->lastInsertId();

            $pdo->prepare(
                'UPDATE conversation_members SET hidden_at = NULL WHERE conversation_id = ?'
            )->execute([$cid]);

            bump_conversation_change($pdo, $cid, $now);
            mark_read($pdo, $cid, $senderId, $messageId);
            queue_push_job($pdo, $senderId, $cid, 'message', $messageId, null);

            $pdo->prepare(
                "UPDATE scheduled_messages
                 SET status = 'sent', sent_message_id = ?
                 WHERE id = ?"
            )->execute([$messageId, $scheduledId]);

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log('[SilkNex scheduled message] ' . $e->getMessage());
        }
    }
}



function claim_maintenance_slot(PDO $pdo, string $name, int $intervalSeconds): bool {
    $intervalSeconds = max(1, $intervalSeconds);
    $key = 'maintenance:' . preg_replace('/[^a-z0-9_.-]/i', '', $name);
    $now = time();
    $next = (string)($now + $intervalSeconds);

    // One atomic upsert replaces the old INSERT+UPDATE pair. A newly inserted
    // lease reports rowCount 1; a claimed existing lease reports 2; an
    // unexpired lease is unchanged and reports 0 with normal PDO MySQL flags.
    $stmt = $pdo->prepare(
        'INSERT INTO app_meta (meta_key, meta_value)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE
           meta_value = IF(
             CAST(meta_value AS UNSIGNED) <= ?,
             VALUES(meta_value),
             meta_value
           )'
    );
    $stmt->execute([$key, $next, $now]);

    return $stmt->rowCount() > 0;
}

function cleanup_stale_calls(PDO $pdo): void {
    $now = time();

    // Split ringing and active cleanup so the ringing path can use the
    // status/created_at index instead of scanning the whole call history.
    $pdo->prepare(
        "UPDATE calls
         SET status = 'ended', ended_at = ?
         WHERE status = 'ringing'
           AND created_at < ?
         LIMIT 200"
    )->execute([$now, $now - CALL_RING_TTL_SECONDS]);

    $pdo->prepare(
        "UPDATE calls
         SET status = 'ended', ended_at = ?
         WHERE status = 'active'
           AND (
             (caller_heartbeat > 0 AND caller_heartbeat < ?)
             OR (callee_heartbeat > 0 AND callee_heartbeat < ?)
           )
         LIMIT 200"
    )->execute([
        $now,
        $now - CALL_HEARTBEAT_GRACE_SECONDS,
        $now - CALL_HEARTBEAT_GRACE_SECONDS
    ]);
}

function run_shared_maintenance(PDO $pdo): void {
    try {
        // When APCu is available, coalesce maintenance attempts in PHP shared
        // memory before touching MySQL. Under high concurrency this turns
        // hundreds of identical heartbeat lease upserts into one DB attempt
        // every two seconds per host. The database lease remains the source of
        // truth across multiple web hosts and when APCu is unavailable.
        $apcuEnabled =
            function_exists('apcu_add') &&
            filter_var((string)ini_get('apc.enabled'), FILTER_VALIDATE_BOOL);
        if ($apcuEnabled) {
            $localGate = 'silknex-maintenance-gate:' . hash(
                'sha256',
                __DIR__ . '|' . (string)(config()['name'] ?? '')
            );
            if (!@apcu_add($localGate, 1, 2)) {
                return;
            }
        }

        // One indexed DB lease serializes maintenance across hosts. Only the
        // winner performs the per-task cadence checks.
        if (!claim_maintenance_slot($pdo, 'shared_gate', 2)) {
            return;
        }

        if (claim_maintenance_slot($pdo, 'scheduled', 2)) {
            release_due_scheduled_messages($pdo);
        }

        if (claim_maintenance_slot($pdo, 'expired_messages', 4)) {
            purge_expired_messages($pdo);
        }

        if (claim_maintenance_slot($pdo, 'stale_calls', 20)) {
            cleanup_stale_calls($pdo);
        }

        if (claim_maintenance_slot($pdo, 'expired_stories', 30)) {
            purge_expired_stories($pdo);
        }
    } catch (Throwable $e) {
        // Maintenance is best-effort and must never make chat heartbeat fail.
        error_log('[SilkNex maintenance] ' . $e->getMessage());
    }
}

function story_row_visible_to(array $story, int $viewerId, bool $isFriend = false): bool {
    if ((int)($story['user_id'] ?? 0) === $viewerId) return true;

    $visibility = (string)($story['visibility'] ?? 'friends');
    if ($visibility === 'public') return true;
    if ($visibility === 'friends') return $isFriend;
    if ($visibility !== 'custom' || !$isFriend) return false;

    $decoded = json_decode((string)($story['audience_json'] ?? '[]'), true);
    if (!is_array($decoded)) return false;
    foreach ($decoded as $candidate) {
        if ((int)$candidate === $viewerId) return true;
    }
    return false;
}

function story_is_visible_to(PDO $pdo, int $storyId, int $viewerId): bool {
    $stmt = $pdo->prepare(
        'SELECT s.user_id, s.visibility, s.audience_json,
                EXISTS (
                  SELECT 1
                  FROM friendships f
                  WHERE f.status = \'accepted\'
                    AND (
                      (f.requester_id = ? AND f.addressee_id = s.user_id)
                      OR
                      (f.addressee_id = ? AND f.requester_id = s.user_id)
                    )
                  LIMIT 1
                ) AS is_friend
         FROM stories s
         INNER JOIN users owner
           ON owner.id = s.user_id
          AND owner.disabled_at IS NULL
         WHERE s.id = ?
           AND s.deleted_at IS NULL
           AND s.expires_at > ?
         LIMIT 1'
    );
    $stmt->execute([$viewerId, $viewerId, $storyId, time()]);
    $row = $stmt->fetch();
    return $row ? story_row_visible_to($row, $viewerId, !empty($row['is_friend'])) : false;
}

function story_item(array $row): array {
    return [
        'id' => (int)$row['id'],
        'user_id' => (int)$row['user_id'],
        'username' => (string)$row['username'],
        'display_name' => (string)$row['display_name'],
        'accent' => (string)($row['accent'] ?? 'silver'),
        'avatar_url' => media_reference_url((string)($row['avatar_url'] ?? '')),
        'avatar_style' => normalize_avatar_style($row['avatar_style'] ?? []),
        'role' => public_staff_role($row),
        'media_type' => (string)$row['media_type'],
        'media_url' => media_reference_url(media_store_reference((string)$row['media_token'])),
        'caption' => (string)($row['caption'] ?? ''),
        'created_at' => (int)$row['created_at'],
        'expires_at' => (int)$row['expires_at'],
        'viewed' => !empty($row['viewed_at']),
        'view_count' => (int)($row['view_count'] ?? 0),
        'visibility' => in_array((string)($row['visibility'] ?? 'friends'), ['public','friends','custom'], true) ? (string)$row['visibility'] : 'friends',
        'mine' => !empty($row['mine']),
    ];
}


function purge_expired_stories(PDO $pdo): void {
    try {
        $stmt = $pdo->prepare(
            'SELECT id, user_id, media_token
             FROM stories
             WHERE expires_at <= ? OR deleted_at IS NOT NULL
             ORDER BY id ASC
             LIMIT 40'
        );
        $stmt->execute([time()]);
        $rows = $stmt->fetchAll();
        if (!$rows) return;

        $ids = array_map(static fn(array $row): int => (int)$row['id'], $rows);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $pdo->prepare("DELETE FROM stories WHERE id IN ({$placeholders})")
            ->execute($ids);

        foreach ($rows as $row) {
            delete_upload_if_unreferenced(
                $pdo,
                (string)$row['media_token'],
                (int)$row['user_id']
            );
        }
    } catch (Throwable $e) {
        error_log('[SilkNex story cleanup] ' . $e->getMessage());
    }
}


function e2ee_public_key_json(mixed $value): string {
    if (is_string($value)) {
        $decoded = json_decode($value, true);
    } elseif (is_array($value)) {
        $decoded = $value;
    } else {
        $decoded = null;
    }

    if (
        !is_array($decoded) ||
        (string)($decoded['kty'] ?? '') !== 'EC' ||
        (string)($decoded['crv'] ?? '') !== 'P-256' ||
        !preg_match('/^[A-Za-z0-9_-]{40,60}$/', (string)($decoded['x'] ?? '')) ||
        !preg_match('/^[A-Za-z0-9_-]{40,60}$/', (string)($decoded['y'] ?? ''))
    ) {
        fail('Invalid end-to-end encryption public key.');
    }

    return json_encode([
        'kty' => 'EC',
        'crv' => 'P-256',
        'x' => (string)$decoded['x'],
        'y' => (string)$decoded['y'],
        'ext' => true,
    ], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
}

function strict_b64url_bytes(
    mixed $value,
    int $minBytes,
    int $maxBytes,
    ?int $exactBytes = null
): ?string {
    if (!is_string($value)) return null;

    // WebCrypto emitters normally use unpadded base64url, but older browsers,
    // migration tools and some WebViews can preserve one or two '=' padding
    // characters. Accept canonical padding instead of rejecting otherwise
    // valid AES-GCM ciphertext with a brittle character-count regex.
    $raw = trim($value);
    if ($raw === '' || strlen($raw) > (($maxBytes * 4) + 16)) return null;
    if (!preg_match('/^[A-Za-z0-9_-]+={0,2}$/D', $raw)) return null;

    $unpadded = rtrim($raw, '=');
    if ($unpadded === '' || (strlen($unpadded) % 4) === 1) return null;

    try {
        $decoded = b64url_decode_raw($unpadded);
    } catch (Throwable $e) {
        return null;
    }

    $length = strlen($decoded);
    if ($exactBytes !== null && $length !== $exactBytes) return null;
    if ($length < $minBytes || $length > $maxBytes) return null;

    // Require a canonical round-trip so alternate/non-base64 encodings cannot
    // sneak through merely because PHP's decoder happened to accept them.
    if (!hash_equals(b64url_encode($decoded), $unpadded)) return null;

    return $decoded;
}

function normalize_e2ee_payload(mixed $value): string {
    $raw = is_string($value) ? trim($value) : '';
    if ($raw === '') return '';
    if (strlen($raw) > 524288) fail('Encrypted message is too large.');

    $payload = json_decode($raw, true, 32);
    $version = (int)($payload['v'] ?? 0);
    if (
        !is_array($payload) ||
        !in_array($version, [1, 2], true) ||
        (string)($payload['alg'] ?? '') !== 'P-256+HKDF-SHA256+A256GCM' ||
        !is_array($payload['sender_public_jwk'] ?? null) ||
        !is_array($payload['wraps'] ?? null) ||
        count($payload['wraps']) < 1 ||
        count($payload['wraps']) > 250
    ) {
        fail('Invalid encrypted message envelope.');
    }

    if (!preg_match('/^[a-f0-9]{32}$/D', (string)($payload['sender_device_id'] ?? ''))) {
        fail('Invalid encrypted message device.');
    }

    // Validate the sender key using the same strict JWK contract used during
    // device registration. This prevents malformed EC keys from being stored
    // inside an otherwise well-shaped envelope.
    e2ee_public_key_json($payload['sender_public_jwk']);

    $nonce = (string)($payload['nonce'] ?? '');
    if (
        $nonce === '' ||
        strlen($nonce) > 128 ||
        preg_match('/[\x00-\x1F\x7F]/', $nonce)
    ) {
        fail('Invalid encrypted message nonce.');
    }

    if ($version >= 2 && strict_b64url_bytes($payload['salt'] ?? null, 16, 16, 16) === null) {
        fail('Invalid encrypted message salt.');
    }

    // AES-GCM uses a 96-bit IV. The ciphertext returned by WebCrypto contains
    // the authentication tag, so even an empty plaintext is at least 16 bytes.
    if (
        strict_b64url_bytes($payload['iv'] ?? null, 12, 12, 12) === null ||
        strict_b64url_bytes($payload['ciphertext'] ?? null, 16, 393216) === null
    ) {
        fail('Invalid encrypted message ciphertext.');
    }

    $seenWraps = [];
    foreach ($payload['wraps'] as $wrap) {
        $deviceId = is_array($wrap) ? (string)($wrap['device_id'] ?? '') : '';
        $recipientUserId = is_array($wrap) ? (int)($wrap['user_id'] ?? 0) : 0;
        if (
            !is_array($wrap) ||
            !preg_match('/^[a-f0-9]{32}$/D', $deviceId) ||
            ($version >= 2 && $recipientUserId <= 0) ||
            strict_b64url_bytes($wrap['iv'] ?? null, 12, 12, 12) === null ||
            // A 32-byte content key encrypted with AES-GCM is 48 bytes.
            strict_b64url_bytes($wrap['ciphertext'] ?? null, 48, 48, 48) === null ||
            isset($seenWraps[$deviceId])
        ) {
            fail('Invalid encrypted message key wrap.');
        }
        $seenWraps[$deviceId] = true;
    }

    return $raw;
}


function validate_e2ee_envelope_for_conversation(
    PDO $pdo,
    string $payload,
    int $conversationId,
    int $senderId
): void {
    if ($payload === '') fail('Encrypted message required. Reload the latest Silknex and try again.', 400);
    $decoded = json_decode($payload, true, 32);
    if (!is_array($decoded)) fail('Invalid encrypted message.');
    $version = (int)($decoded['v'] ?? 0);

    $senderDevice = (string)($decoded['sender_device_id'] ?? '');
    $senderKey = json_encode(
        $decoded['sender_public_jwk'] ?? [],
        JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
    );

    $registered = $pdo->prepare(
        'SELECT public_key_jwk
         FROM e2ee_devices
         WHERE user_id = ? AND device_id = ? AND revoked_at IS NULL
         LIMIT 1'
    );
    $registered->execute([$senderId, $senderDevice]);
    $storedKey = (string)($registered->fetchColumn() ?: '');
    if ($storedKey === '') fail('Register this device for secure messaging first.', 409);

    $normalizeJwk = static function (string $json): string {
        $item = json_decode($json, true);
        if (!is_array($item)) return '';
        return json_encode([
            'kty' => (string)($item['kty'] ?? ''),
            'crv' => (string)($item['crv'] ?? ''),
            'x' => (string)($item['x'] ?? ''),
            'y' => (string)($item['y'] ?? ''),
        ], JSON_UNESCAPED_SLASHES);
    };
    if ($normalizeJwk($storedKey) !== $normalizeJwk($senderKey)) {
        fail('This device encryption key changed. Re-register the device.', 409);
    }

    $deviceStmt = $pdo->prepare(
        'SELECT d.user_id, d.device_id
         FROM conversation_members cm
         INNER JOIN users u ON u.id = cm.user_id AND u.disabled_at IS NULL
         LEFT JOIN e2ee_devices d
           ON d.user_id = cm.user_id AND d.revoked_at IS NULL
         WHERE cm.conversation_id = ?'
    );
    $deviceStmt->execute([$conversationId]);
    $requiredDevices = [];
    $deviceOwners = [];
    $membersWithDevice = [];
    $memberIds = [];
    foreach ($deviceStmt->fetchAll() as $row) {
        $uid = (int)$row['user_id'];
        $memberIds[$uid] = true;
        $deviceId = (string)($row['device_id'] ?? '');
        if ($deviceId !== '') {
            $requiredDevices[$deviceId] = true;
            $deviceOwners[$deviceId] = $uid;
            $membersWithDevice[$uid] = true;
        }
    }
    if (count($membersWithDevice) !== count($memberIds)) {
        fail('Secure messaging is waiting for every participant to open the latest SilkNex once.', 409);
    }

    $wrapped = [];
    foreach (($decoded['wraps'] ?? []) as $wrap) {
        if (!is_array($wrap)) continue;
        $deviceId = (string)($wrap['device_id'] ?? '');
        $wrapped[$deviceId] = true;
        if (
            $version >= 2 &&
            (!isset($deviceOwners[$deviceId]) ||
             (int)($wrap['user_id'] ?? 0) !== (int)$deviceOwners[$deviceId])
        ) {
            fail('Encrypted message recipient binding is invalid.', 409);
        }
    }
    foreach ($requiredDevices as $deviceId => $_) {
        if (empty($wrapped[$deviceId])) {
            fail('Encrypted message is missing a participant device.', 409);
        }
    }
    foreach ($wrapped as $deviceId => $_) {
        if (empty($requiredDevices[$deviceId])) {
            fail('Encrypted message contains a non-participant device.', 409);
        }
    }
}

function conversation_typing_users(PDO $pdo, int $conversationId, int $viewerId): array {
    $stmt = $pdo->prepare(
        'SELECT u.id, u.username, u.display_name, u.accent, u.avatar_url, u.avatar_style, u.account_role
         FROM typing_state ts
         INNER JOIN users u ON u.id = ts.user_id AND u.disabled_at IS NULL
         WHERE ts.conversation_id = ?
           AND ts.user_id <> ?
           AND ts.expires_at > ?
         ORDER BY ts.updated_at DESC
         LIMIT 6'
    );
    $stmt->execute([$conversationId, $viewerId, time()]);

    return array_map(static fn(array $row): array => public_user($row), $stmt->fetchAll());
}

function subscription_plan_catalog(): array {
    return [
        'basic' => ['id'=>'basic','name'=>'Basic','price_cents'=>199,'features'=>['ad_free'=>true,'custom_emojis'=>false,'feature_requests'=>false,'beta_access'=>false,'dev_access'=>false]],
        'simple' => ['id'=>'simple','name'=>'Simple','price_cents'=>349,'features'=>['ad_free'=>true,'custom_emojis'=>true,'feature_requests'=>false,'beta_access'=>false,'dev_access'=>false]],
        'premium' => ['id'=>'premium','name'=>'Premium','price_cents'=>499,'features'=>['ad_free'=>true,'custom_emojis'=>true,'feature_requests'=>true,'beta_access'=>false,'dev_access'=>false]],
        'super-premium' => ['id'=>'super-premium','name'=>'Super-Premium','price_cents'=>649,'features'=>['ad_free'=>true,'custom_emojis'=>true,'feature_requests'=>true,'beta_access'=>true,'dev_access'=>false]],
        'super-develop' => ['id'=>'super-develop','name'=>'Super-Develop','price_cents'=>999,'features'=>['ad_free'=>true,'custom_emojis'=>true,'feature_requests'=>true,'beta_access'=>true,'dev_access'=>true]],
    ];
}
function normalize_subscription_plan(string $plan): string {
    $plan = strtolower(trim($plan));
    $aliases=['super_premium'=>'super-premium','superpremium'=>'super-premium','super_develop'=>'super-develop','superdevelop'=>'super-develop'];
    $plan=$aliases[$plan]??$plan;
    return array_key_exists($plan,subscription_plan_catalog())?$plan:'';
}
function subscription_features_for(string $plan,bool $active): array {
    $none=['ad_free'=>false,'custom_emojis'=>false,'feature_requests'=>false,'beta_access'=>false,'dev_access'=>false];
    if(!$active)return $none;
    $catalog=subscription_plan_catalog();
    $plan=normalize_subscription_plan($plan);
    if($plan===''||!isset($catalog[$plan]))$plan='basic';
    return $catalog[$plan]['features'];
}
function require_subscription_feature(PDO $pdo,int $userId,string $feature): array {
    $status=ad_status($pdo,$userId);
    if(empty($status['subscription_features'][$feature])) fail('Your current SilkNex plan does not include this feature.',403);
    return $status;
}

function ensure_ad_state(PDO $pdo, int $userId): void {
    $now = time();
    $pdo->prepare(
        'INSERT INTO user_ad_state (user_id, last_interstitial_at, updated_at)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE
           last_interstitial_at = IF(last_interstitial_at = 0, VALUES(last_interstitial_at), last_interstitial_at),
           user_id = VALUES(user_id)'
    )->execute([$userId, $now, $now]);
}

function ad_status(PDO $pdo, int $userId): array {
    ensure_ad_state($pdo,$userId);
    $stmt=$pdo->prepare('SELECT rewarded_count,ad_pass_until,subscription_status,subscription_plan,subscription_started_at,subscription_current_period_end,story_view_counter,last_interstitial_at FROM user_ad_state WHERE user_id=? LIMIT 1');
    $stmt->execute([$userId]); $row=$stmt->fetch()?:[];
    $now=time();
    $globalAdsPaused=app_meta_value($pdo,'owner_ads_paused_v1')==='1';
    $subStatus=(string)($row['subscription_status']??'inactive');
    $periodEnd=(int)($row['subscription_current_period_end']??0);
    $active=in_array($subStatus,['active','trialing'],true)&&($periodEnd===0||$periodEnd>$now);
    $plan=normalize_subscription_plan((string)($row['subscription_plan']??''));
    if($active&&$plan==='')$plan='basic'; // legacy ad-free subscribers
    $catalog=subscription_plan_catalog(); $entry=$catalog[$plan]??null;
    $features=subscription_features_for($plan,$active);
    $passUntil=(int)($row['ad_pass_until']??0);
    $adsDisabled=$globalAdsPaused||!empty($features['ad_free'])||$passUntil>$now;
    $last=max(0,(int)($row['last_interstitial_at']??0));
    $min=max(900,(int)(config()['ad_interstitial_min_seconds']??1200));
    $next=$last>0?$last+$min:$now;
    return [
      'rewarded_count'=>max(0,min(4,(int)($row['rewarded_count']??0))),
      'ad_pass_until'=>$passUntil,'pass_active'=>$passUntil>$now,
      'subscription_status'=>$subStatus,'subscription_plan'=>$plan,
      'subscription_plan_name'=>(string)($entry['name']??''),
      'subscription_started_at'=>max(0,(int)($row['subscription_started_at']??0)),
      'subscription_current_period_end'=>$periodEnd,'subscription_active'=>$active,
      'subscription_features'=>$features,'ads_disabled'=>$adsDisabled,'global_ads_paused'=>$globalAdsPaused,
      'story_view_counter'=>max(0,(int)($row['story_view_counter']??0)),
      'last_interstitial_at'=>$last,'interstitial_min_seconds'=>$min,'interstitial_next_at'=>$next,
      'interstitial_due'=>!$adsDisabled&&$now>=$next,'server_now'=>$now
    ];
}

function silknex_public_origin(): string {
    $cfg = config();
    $configured = rtrim((string)($cfg['app_origin'] ?? ''), '/');
    if ($configured !== '') return $configured;

    $host = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') fail('App origin is not configured.', 503);
    return 'https://' . $host;
}

function stripe_request(string $path, array $fields): array {
    $secret = (string)(config()['stripe_secret_key'] ?? '');
    if ($secret === '' || !str_starts_with($secret, 'sk_')) {
        fail('Secure checkout is not configured yet.', 503);
    }
    if (!function_exists('curl_init')) {
        fail('Secure checkout needs PHP cURL on this server.', 503);
    }

    $ch = curl_init('https://api.stripe.com/v1/' . ltrim($path, '/'));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_USERPWD => $secret . ':',
        CURLOPT_POSTFIELDS => http_build_query($fields),
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
    ]);
    $body = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if (!is_string($body) || $body === '' || $curlError !== '') {
        error_log('[SilkNex Stripe] ' . $curlError);
        fail('Could not reach secure checkout.', 502);
    }
    $decoded = json_decode($body, true);
    if ($status < 200 || $status >= 300 || !is_array($decoded)) {
        error_log('[SilkNex Stripe] HTTP ' . $status . ' ' . substr($body, 0, 500));
        fail('Secure checkout could not be created.', 502);
    }
    return $decoded;
}

function verify_stripe_signature(string $payload, string $header, string $secret): bool {
    if ($secret === '' || $header === '') return false;
    $timestamp = 0;
    $signatures = [];
    foreach (explode(',', $header) as $part) {
        [$key, $value] = array_pad(explode('=', trim($part), 2), 2, '');
        if ($key === 't') $timestamp = (int)$value;
        if ($key === 'v1' && $value !== '') $signatures[] = $value;
    }
    if ($timestamp < time() - 300 || $timestamp > time() + 300) return false;
    $expected = hash_hmac('sha256', $timestamp . '.' . $payload, $secret);
    foreach ($signatures as $signature) {
        if (hash_equals($expected, $signature)) return true;
    }
    return false;
}

function update_subscription_from_stripe(PDO $pdo,array $object,string $eventType): void {
    $metadata=is_array($object['metadata']??null)?$object['metadata']:[];
    $userId=(int)($metadata['user_id']??$object['client_reference_id']??0);
    $plan=normalize_subscription_plan((string)($metadata['plan']??''));
    if($userId<1&&!empty($object['id'])){
        $q=$pdo->prepare('SELECT user_id FROM user_ad_state WHERE stripe_subscription_id=? OR stripe_customer_id=? LIMIT 1');
        $q->execute([(string)($object['id']??''),(string)($object['customer']??'')]); $userId=(int)($q->fetchColumn()?:0);
    }
    if($userId<1)return;
    ensure_ad_state($pdo,$userId);
    $customer=(string)($object['customer']??'');
    $subId=(string)($object['subscription']??(str_starts_with((string)($object['id']??''),'sub_')?$object['id']:''));
    $now=time();
    if($eventType==='checkout.session.completed'){
      // Checkout completion is not proof of an active subscription. Delayed
      // payment methods may still be unpaid. Only subscription lifecycle
      // webhooks below set entitlements; checkout just records billing links.
      if (($object['mode'] ?? '') !== 'subscription' || $subId === '') return;
      $pdo->prepare("UPDATE user_ad_state SET stripe_customer_id=COALESCE(NULLIF(stripe_customer_id,''),NULLIF(?,'')),stripe_subscription_id=COALESCE(NULLIF(stripe_subscription_id,''),NULLIF(?,'')),updated_at=? WHERE user_id=?")
          ->execute([$customer,$subId,$now,$userId]); return;
    }
    $status=strtolower((string)($object['status']??'inactive')); if($eventType==='customer.subscription.deleted')$status='canceled';
    $period=max(0,(int)($object['current_period_end']??0));
    $pdo->prepare("UPDATE user_ad_state SET subscription_status=?,subscription_plan=COALESCE(NULLIF(?,''),subscription_plan),subscription_started_at=IF(subscription_started_at=0 AND ? IN ('active','trialing'),?,subscription_started_at),subscription_current_period_end=?,stripe_customer_id=COALESCE(NULLIF(?,''),stripe_customer_id),stripe_subscription_id=COALESCE(NULLIF(?,''),stripe_subscription_id),updated_at=? WHERE user_id=?")
        ->execute([$status,$plan,$status,$now,$period,$customer,$subId,$now,$userId]);
}


function normalize_ad_destination_url(string $url): string {
    $url = trim($url);
    if ($url === '' || strlen($url) > 1000) {
        fail('Enter a valid destination URL.');
    }

    $parts = parse_url($url);
    if (
        !is_array($parts) ||
        strtolower((string)($parts['scheme'] ?? '')) !== 'https' ||
        empty($parts['host']) ||
        isset($parts['user']) ||
        isset($parts['pass'])
    ) {
        fail('Ad links must use a public HTTPS URL.');
    }

    $host = strtolower((string)$parts['host']);
    if (
        $host === 'localhost' ||
        str_ends_with($host, '.local') ||
        filter_var($host, FILTER_VALIDATE_IP)
    ) {
        fail('Ad links must use a public HTTPS hostname.');
    }

    return $url;
}

function ad_campaign_payload(array $row): array {
    $token = strtolower(trim((string)($row['upload_token'] ?? '')));
    return [
        'id' => (int)($row['id'] ?? 0),
        'headline' => (string)($row['headline'] ?? ''),
        'destination_url' => (string)($row['destination_url'] ?? ''),
        'image_url' => preg_match('/^[a-f0-9]{48}$/', $token)
            ? media_reference_url(media_store_reference($token))
            : '',
        'days' => max(1, (int)($row['days'] ?? 1)),
        'price_cents' => max(0, (int)($row['price_cents'] ?? 0)),
        'status' => (string)($row['status'] ?? 'pending'),
        'starts_at' => max(0, (int)($row['starts_at'] ?? 0)),
        'ends_at' => max(0, (int)($row['ends_at'] ?? 0)),
        'created_at' => max(0, (int)($row['created_at'] ?? 0)),
    ];
}

function activate_ad_campaign_from_stripe(PDO $pdo, array $object, string $eventType): void {
    $metadata = is_array($object['metadata'] ?? null) ? $object['metadata'] : [];
    if ((string)($metadata['purchase_type'] ?? '') !== 'ad_campaign') return;

    $campaignId = (int)($metadata['campaign_id'] ?? 0);
    if ($campaignId < 1) return;

    $checkoutId = (string)($object['id'] ?? '');
    $paymentIntentId = (string)($object['payment_intent'] ?? '');
    $paymentStatus = strtolower((string)($object['payment_status'] ?? ''));

    if (in_array($eventType, ['checkout.session.expired', 'checkout.session.async_payment_failed'], true)) {
        $pdo->prepare(
            "UPDATE ad_campaigns
             SET status = 'cancelled'
             WHERE id = ? AND status = 'pending'"
        )->execute([$campaignId]);
        return;
    }

    if (
        !in_array($eventType, ['checkout.session.completed', 'checkout.session.async_payment_succeeded'], true) ||
        !in_array($paymentStatus, ['paid', 'no_payment_required'], true)
    ) {
        return;
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare(
            'SELECT id, user_id, upload_token, days, price_cents, status,
                    stripe_checkout_session_id
             FROM ad_campaigns
             WHERE id = ?
             FOR UPDATE'
        );
        $stmt->execute([$campaignId]);
        $campaign = $stmt->fetch();
        if (!$campaign || (string)$campaign['status'] === 'active') {
            $pdo->commit();
            return;
        }

        $days = max(1, min(30, (int)$campaign['days']));
        $expected = $days * 500;
        $storedCheckout = (string)($campaign['stripe_checkout_session_id'] ?? '');
        $amountTotal = (int)($object['amount_total'] ?? 0);
        if (
            (int)$campaign['price_cents'] !== $expected ||
            ($storedCheckout !== '' && $checkoutId !== '' && !hash_equals($storedCheckout, $checkoutId)) ||
            ($amountTotal > 0 && $amountTotal !== $expected)
        ) {
            $pdo->rollBack();
            error_log('[SilkNex ads] Campaign checkout verification failed for campaign ' . $campaignId);
            return;
        }

        $now = time();
        $endsAt = $now + ($days * 86400);
        $pdo->prepare(
            "UPDATE ad_campaigns
             SET status = 'active',
                 stripe_checkout_session_id = COALESCE(NULLIF(?, ''), stripe_checkout_session_id),
                 stripe_payment_intent_id = NULLIF(?, ''),
                 paid_at = ?,
                 starts_at = ?,
                 ends_at = ?
             WHERE id = ?"
        )->execute([$checkoutId, $paymentIntentId, $now, $now, $endsAt, $campaignId]);

        $pdo->prepare(
            'UPDATE uploads SET used_at = COALESCE(used_at, ?) WHERE token = ? AND user_id = ?'
        )->execute([$now, (string)$campaign['upload_token'], (int)$campaign['user_id']]);

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function active_ad_campaigns(PDO $pdo, int $viewerUserId, int $limit = 5): array {
    if (app_meta_value($pdo, 'owner_ads_paused_v1') === '1') {
        return [];
    }

    $now = time();
    $limit = max(1, min(8, $limit));

    // Expiration is maintained lazily. The indexed status/end-time lookup keeps
    // this bounded even when many campaigns have existed historically.
    if (random_int(1, 60) === 1) {
        $pdo->prepare(
            "UPDATE ad_campaigns
             SET status = 'expired'
             WHERE status = 'active'
               AND ends_at IS NOT NULL
               AND ends_at <= ?
             LIMIT 200"
        )->execute([$now]);
    }

    $maxStmt = $pdo->prepare(
        "SELECT MAX(id)
         FROM ad_campaigns
         WHERE status = 'active'
           AND starts_at <= ?
           AND ends_at > ?
           AND user_id <> ?"
    );
    $maxStmt->execute([$now, $now, $viewerUserId]);
    $maxId = (int)($maxStmt->fetchColumn() ?: 0);
    if ($maxId < 1) return [];

    // Rotate the starting point every ten minutes per viewer so a larger
    // desktop can fill multiple placements without always favoring low IDs.
    $bucket = (int)floor($now / 600);
    $seed = (int)sprintf('%u', crc32($viewerUserId . ':' . $bucket));
    $startId = 1 + ($seed % $maxId);
    $selectColumns =
        'id, user_id, upload_token, headline, destination_url, days,
         price_cents, status, starts_at, ends_at, created_at';

    $select = $pdo->prepare(
        "SELECT {$selectColumns}
         FROM ad_campaigns
         WHERE status = 'active'
           AND starts_at <= ?
           AND ends_at > ?
           AND user_id <> ?
           AND id >= ?
         ORDER BY id
         LIMIT {$limit}"
    );
    $select->execute([$now, $now, $viewerUserId, $startId]);
    $rows = $select->fetchAll();

    $remaining = $limit - count($rows);
    if ($remaining > 0 && $startId > 1) {
        $wrap = $pdo->prepare(
            "SELECT {$selectColumns}
             FROM ad_campaigns
             WHERE status = 'active'
               AND starts_at <= ?
               AND ends_at > ?
               AND user_id <> ?
               AND id < ?
             ORDER BY id
             LIMIT {$remaining}"
        );
        $wrap->execute([$now, $now, $viewerUserId, $startId]);
        $rows = array_merge($rows, $wrap->fetchAll());
    }

    return array_values(array_map('ad_campaign_payload', $rows));
}

function active_ad_campaign(PDO $pdo, int $viewerUserId): ?array {
    $campaigns = active_ad_campaigns($pdo, $viewerUserId, 1);
    return $campaigns[0] ?? null;
}

if (defined('SILKNEX_LIBRARY_ONLY') && SILKNEX_LIBRARY_ONLY === true) {
    return;
}

$action = (string)($_GET['action'] ?? '');
if ($action !== 'health') {
    require_secure_transport();
}

$sessionlessActions = ['health', 'notification_media', 'stripe_webhook', 'ads_txt'];
if (!in_array($action, $sessionlessActions, true)) {
    start_session_securely();
}

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));

if (!in_array($action, $sessionlessActions, true)) {
    enforce_fetch_metadata();
}

try {
    access_block_guard($action);
    v77_guard($action, $method);
    v77_route($action, $method);
    switch ($action) {
        case 'access_block_status':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $block = active_access_block(db());
            ok(['active' => $block ? [
                'id' => (int)$block['id'],
                'ends_at' => (int)$block['ends_at'],
                'note' => (string)$block['note'],
            ] : null, 'server_time' => time()]);

        case 'owner_access_blocks':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            $now = time();
            $stmt = db()->prepare('SELECT id, starts_at, ends_at, note FROM owner_access_blocks WHERE ends_at > ? ORDER BY starts_at ASC LIMIT 100');
            $stmt->execute([$now]);
            ok(['blocks' => $stmt->fetchAll(), 'server_time' => $now]);

        case 'owner_database_diagnostics':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            release_session_lock();
            $pdo = db();
            $cfg = config();
            $now = time();
            $counts = $pdo->query(
                'SELECT COUNT(*) AS accounts,
                        COALESCE(SUM(disabled_at IS NULL),0) AS active_accounts,
                        COALESCE(SUM(created_at >= UNIX_TIMESTAMP() - 86400),0) AS new_24h,
                        COALESCE(MAX(id),0) AS last_user_id
                 FROM users'
            )->fetch() ?: [];
            ok(['database' => [
                'configured_host' => (string)$cfg['host'],
                'configured_database' => (string)$cfg['name'],
                'connected_database' => (string)$pdo->query('SELECT DATABASE()')->fetchColumn(),
                'configured_user' => (string)$cfg['user'],
                'schema_version' => (string)(app_meta_value($pdo, 'schema_version') ?? ''),
                'accounts' => (int)($counts['accounts'] ?? 0),
                'active_accounts' => (int)($counts['active_accounts'] ?? 0),
                'new_24h' => (int)($counts['new_24h'] ?? 0),
                'last_user_id' => (int)($counts['last_user_id'] ?? 0),
                'messages' => (int)$pdo->query('SELECT COUNT(*) FROM messages')->fetchColumn(),
                'posts' => (int)$pdo->query('SELECT COUNT(*) FROM profile_posts')->fetchColumn(),
                'checked_at' => $now,
            ]]);

        case 'owner_posting_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $owner = require_founder();
            require_csrf();
            $input = body_json();
            $paused = filter_var($input['paused'] ?? null, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($paused === null) fail('Invalid posting setting.');
            set_app_meta_value(db(), 'owner_posting_paused_v1', $paused ? '1' : '0');
            owner_audit(db(), (int)$owner['id'], $paused ? 'posts.pause' : 'posts.resume', 'global');
            ok(['posting_paused' => $paused]);

        case 'owner_access_block_create':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $owner = require_founder();
            require_csrf();
            session_rate_limit('owner_block_create', 12, 60);
            $input = body_json();
            $start = filter_var($input['starts_at'] ?? null, FILTER_VALIDATE_INT);
            $end = filter_var($input['ends_at'] ?? null, FILTER_VALIDATE_INT);
            $now = time();
            if ($start === false || $end === false || $start < $now - 30 ||
                $start > $now + 366 * 86400 || $end <= $start ||
                $end - $start > 7 * 86400) {
                fail('Choose a future start and end, up to seven days apart and within one year.');
            }
            $note = clean($input['note'] ?? '', 120);
            $pdo = db();
            $stmt = $pdo->prepare('INSERT INTO owner_access_blocks(starts_at,ends_at,note,created_by,created_at) VALUES(?,?,?,?,?)');
            $stmt->execute([$start,$end,$note,(int)$owner['id'],$now]);
            $id = (int)$pdo->lastInsertId();
            owner_audit($pdo,(int)$owner['id'],'access_block.create',(string)$id,['starts_at'=>$start,'ends_at'=>$end]);
            ok(['id'=>$id],201);

        case 'owner_access_block_delete':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $owner = require_founder();
            require_csrf();
            session_rate_limit('owner_block_delete', 12, 60);
            $id = (int)(body_json()['id'] ?? 0);
            if ($id <= 0) fail('Choose an access block.');
            $pdo = db();
            $stmt = $pdo->prepare('DELETE FROM owner_access_blocks WHERE id=?');
            $stmt->execute([$id]);
            owner_audit($pdo,(int)$owner['id'],'access_block.delete',(string)$id);
            ok(['deleted'=>$stmt->rowCount() > 0]);
        case 'health':
            db();
            ok(['app' => 'SilkNex', 'status' => 'ready']);

        case 'system_announcement':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            current_user();
            release_session_lock();
            ok(['announcement' => active_system_announcement(db())]);

        case 'owner_dashboard':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            release_session_lock();
            $pdo = db();
            $now = time();

            $userTotal = (int)$pdo->query(
                'SELECT COUNT(*) FROM users WHERE disabled_at IS NULL'
            )->fetchColumn();

            $onlineStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM users
                 WHERE disabled_at IS NULL AND online_until >= ?'
            );
            $onlineStmt->execute([$now]);
            $onlineNow = (int)$onlineStmt->fetchColumn();

            $newUsersStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM users
                 WHERE disabled_at IS NULL AND created_at >= ?'
            );
            $newUsersStmt->execute([$now - 86400]);
            $newUsers24h = (int)$newUsersStmt->fetchColumn();

            $messageVelocityStmt = $pdo->prepare(
                'SELECT
                    COALESCE(SUM(created_at >= ?), 0) AS last_hour,
                    COALESCE(SUM(created_at >= ?), 0) AS last_day,
                    COUNT(*) AS last_week
                 FROM messages
                 WHERE created_at >= ?'
            );
            $messageVelocityStmt->execute([
                $now - 3600,
                $now - 86400,
                $now - 604800,
            ]);
            $messageVelocity = $messageVelocityStmt->fetch() ?: [];

            $activeCallsStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM calls
                 WHERE status IN ('ringing','active')
                   AND created_at >= ?"
            );
            $activeCallsStmt->execute([$now - 86400]);
            $activeCalls = (int)$activeCallsStmt->fetchColumn();

            $messageHighWater = (int)$pdo->query(
                'SELECT COUNT(*) FROM messages'
            )->fetchColumn();
            $conversationHighWater = (int)$pdo->query(
                'SELECT COUNT(*) FROM conversations'
            )->fetchColumn();
            $uploadHighWater = (int)$pdo->query(
                'SELECT COUNT(*) FROM uploads'
            )->fetchColumn();

            $adStmt = $pdo->prepare(
                "SELECT
                    SUM(status = 'active' AND starts_at <= ? AND ends_at > ?) AS active_count,
                    SUM(status = 'pending') AS pending_count,
                    COALESCE(SUM(CASE WHEN paid_at IS NOT NULL THEN price_cents ELSE 0 END), 0) AS paid_revenue_cents
                 FROM ad_campaigns"
            );
            $adStmt->execute([$now, $now]);
            $adCounts = $adStmt->fetch() ?: [];

            $scheduledStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM scheduled_messages
                 WHERE status = 'pending' AND scheduled_at > ?"
            );
            $scheduledStmt->execute([$now]);
            $scheduledPending = (int)$scheduledStmt->fetchColumn();

            ok([
                'dashboard' => [
                    'users_total' => $userTotal,
                    'online_now' => $onlineNow,
                    'new_users_24h' => $newUsers24h,
                    'messages_1h' => (int)($messageVelocity['last_hour'] ?? 0),
                    'messages_24h' => (int)($messageVelocity['last_day'] ?? 0),
                    'messages_7d' => (int)($messageVelocity['last_week'] ?? 0),
                    'active_calls' => $activeCalls,
                    'messages_total' => $messageHighWater,
                    'conversations_total' => $conversationHighWater,
                    'uploads_total' => $uploadHighWater,
                    'scheduled_pending' => $scheduledPending,
                    'active_ad_campaigns' => (int)($adCounts['active_count'] ?? 0),
                    'pending_ad_campaigns' => (int)($adCounts['pending_count'] ?? 0),
                    'paid_ad_revenue_cents' => (int)($adCounts['paid_revenue_cents'] ?? 0),
                    'feature_flags' => owner_feature_flags($pdo),
                    'registration_open' => app_meta_value($pdo, 'registration_closed_v1') !== '1',
                    'announcement' => active_system_announcement($pdo),
                    'schema_version' => SCHEMA_VERSION,
                    'server_time' => $now,
                    'php_memory_limit' => (string)ini_get('memory_limit'),
                ],
            ]);

        case 'owner_timeseries':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            release_session_lock();
            $pdo = db();
            $now = time();
            $start = $now - 24 * 3600;

            $messageStmt = $pdo->prepare(
                'SELECT FLOOR(created_at / 3600) * 3600 AS bucket,
                        COUNT(*) AS message_count,
                        COUNT(DISTINCT sender_id) AS sender_count
                 FROM messages
                 WHERE created_at >= ?
                 GROUP BY FLOOR(created_at / 3600)
                 ORDER BY bucket ASC'
            );
            $messageStmt->execute([$start]);

            $signupStmt = $pdo->prepare(
                'SELECT FLOOR(created_at / 3600) * 3600 AS bucket,
                        COUNT(*) AS signup_count
                 FROM users
                 WHERE created_at >= ?
                 GROUP BY FLOOR(created_at / 3600)
                 ORDER BY bucket ASC'
            );
            $signupStmt->execute([$start]);

            $buckets = [];
            $firstBucket = intdiv($start, 3600) * 3600;
            $lastBucket = intdiv($now, 3600) * 3600;
            for ($bucket = $firstBucket; $bucket <= $lastBucket; $bucket += 3600) {
                $buckets[$bucket] = [
                    'bucket' => $bucket,
                    'messages' => 0,
                    'active_senders' => 0,
                    'signups' => 0,
                ];
            }

            foreach ($messageStmt->fetchAll() as $row) {
                $bucket = (int)$row['bucket'];
                if (!isset($buckets[$bucket])) continue;
                $buckets[$bucket]['messages'] = (int)$row['message_count'];
                $buckets[$bucket]['active_senders'] = (int)$row['sender_count'];
            }

            foreach ($signupStmt->fetchAll() as $row) {
                $bucket = (int)$row['bucket'];
                if (!isset($buckets[$bucket])) continue;
                $buckets[$bucket]['signups'] = (int)$row['signup_count'];
            }

            ok([
                'hours' => array_values($buckets),
                'server_time' => $now,
            ]);

        case 'owner_audit':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            release_session_lock();
            $pdo = db();
            $auditStmt = $pdo->query(
                'SELECT id, action, target, details_json, created_at
                 FROM owner_audit_log
                 ORDER BY id DESC
                 LIMIT 80'
            );
            $audit = [];
            foreach ($auditStmt->fetchAll() as $row) {
                $details = [];
                if (is_string($row['details_json'] ?? null) && $row['details_json'] !== '') {
                    $decoded = json_decode((string)$row['details_json'], true);
                    if (is_array($decoded)) $details = $decoded;
                }
                $audit[] = [
                    'id' => (int)$row['id'],
                    'action' => (string)$row['action'],
                    'target' => (string)$row['target'],
                    'details' => $details,
                    'created_at' => (int)$row['created_at'],
                ];
            }
            ok(['audit' => $audit]);

        case 'owner_ads_pause_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_ads_pause', 30, 60);
            $data = body_json();
            $paused = filter_var($data['paused'] ?? false, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($paused === null) fail('Invalid ad serving setting.');
            release_session_lock();
            $pdo = db();
            set_app_meta_value($pdo, 'owner_ads_paused_v1', $paused ? '1' : '0');
            owner_audit(
                $pdo,
                (int)$founder['id'],
                $paused ? 'ads.pause' : 'ads.resume',
                'global'
            );
            ok([
                'ads_paused' => $paused,
                'feature_flags' => owner_feature_flags($pdo),
            ]);

        case 'owner_ad_sales_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_ad_sales', 20, 60);
            $data = body_json();
            $paused = filter_var($data['paused'] ?? false, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($paused === null) fail('Invalid ad sales setting.');
            release_session_lock();
            $pdo = db();
            set_app_meta_value($pdo, 'owner_ad_sales_paused_v1', $paused ? '1' : '0');
            owner_audit(
                $pdo,
                (int)$founder['id'],
                $paused ? 'ads.sales_pause' : 'ads.sales_resume',
                'global'
            );
            ok([
                'ad_sales_paused' => $paused,
                'feature_flags' => owner_feature_flags($pdo),
            ]);

        case 'owner_protection_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_protection', 20, 60);
            $data = body_json();
            $enabled = filter_var($data['enabled'] ?? false, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($enabled === null) fail('Invalid protection-mode setting.');
            release_session_lock();
            $pdo = db();
            set_app_meta_value($pdo, 'owner_protection_mode_v1', $enabled ? '1' : '0');
            owner_audit(
                $pdo,
                (int)$founder['id'],
                $enabled ? 'security.protection_enable' : 'security.protection_disable',
                'global'
            );
            ok([
                'protection_mode' => $enabled,
                'feature_flags' => owner_feature_flags($pdo),
            ]);

        case 'owner_uploads_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_uploads_set', 20, 60);
            $data = body_json();
            $paused = filter_var($data['paused'] ?? false, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($paused === null) fail('Invalid upload setting.');
            release_session_lock();
            $pdo = db();
            set_app_meta_value($pdo, 'owner_uploads_paused_v1', $paused ? '1' : '0');
            owner_audit(
                $pdo,
                (int)$founder['id'],
                $paused ? 'operations.uploads_pause' : 'operations.uploads_resume',
                'global'
            );
            ok([
                'uploads_paused' => $paused,
                'feature_flags' => owner_feature_flags($pdo),
            ]);

        case 'owner_calls_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_calls_set', 20, 60);
            $data = body_json();
            $paused = filter_var($data['paused'] ?? false, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($paused === null) fail('Invalid call setting.');
            release_session_lock();
            $pdo = db();
            set_app_meta_value($pdo, 'owner_calls_paused_v1', $paused ? '1' : '0');
            owner_audit(
                $pdo,
                (int)$founder['id'],
                $paused ? 'operations.calls_pause' : 'operations.calls_resume',
                'global'
            );
            ok([
                'calls_paused' => $paused,
                'feature_flags' => owner_feature_flags($pdo),
            ]);

        case 'owner_privacy_health':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            release_session_lock();
            $pdo = db();
            $now = time();

            // Counts only. Founder diagnostics never decrypt or return message
            // bodies, E2EE keys, attachment contents, or private story media.
            $accounts = (int)$pdo->query(
                'SELECT COUNT(*) FROM users WHERE disabled_at IS NULL'
            )->fetchColumn();

            $profiles = (int)$pdo->query(
                'SELECT COUNT(*) FROM users
                 WHERE disabled_at IS NULL AND public_profile = 1'
            )->fetchColumn();

            $deviceRows = $pdo->query(
                'SELECT COUNT(*) AS device_count,
                        COUNT(DISTINCT user_id) AS user_count
                 FROM e2ee_devices
                 WHERE revoked_at IS NULL'
            )->fetch() ?: [];

            $publicStoryStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM stories
                 WHERE deleted_at IS NULL
                   AND expires_at > ?
                   AND visibility = 'public'"
            );
            $publicStoryStmt->execute([$now]);

            $encryptedStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM messages
                 WHERE created_at >= ?
                   AND e2ee_payload IS NOT NULL
                   AND e2ee_payload <> ''"
            );
            $encryptedStmt->execute([$now - 86400]);

            ok([
                'health' => [
                    'accounts' => $accounts,
                    'accounts_with_e2ee_device' => (int)($deviceRows['user_count'] ?? 0),
                    'active_e2ee_devices' => (int)($deviceRows['device_count'] ?? 0),
                    'public_profiles' => $profiles,
                    'active_public_stories' => (int)$publicStoryStmt->fetchColumn(),
                    'encrypted_messages_24h' => (int)$encryptedStmt->fetchColumn(),
                    'server_time' => $now,
                ],
            ]);

        case 'owner_maintenance_run':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_maintenance_run', 3, 60);
            release_session_lock();
            $pdo = db();
            $now = time();

            $expiredStoriesStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM stories
                 WHERE expires_at <= ? OR deleted_at IS NOT NULL'
            );
            $expiredStoriesStmt->execute([$now]);
            $expiredStories = (int)$expiredStoriesStmt->fetchColumn();

            $expiredMessagesStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM messages
                 WHERE (expires_at IS NOT NULL AND expires_at <= ?)
                    OR (deleted_at IS NOT NULL AND deleted_at <= ?)'
            );
            $expiredMessagesStmt->execute([$now, $now - 86400]);
            $expiredMessages = (int)$expiredMessagesStmt->fetchColumn();

            purge_expired_stories($pdo);
            purge_expired_messages($pdo);
            cleanup_stale_calls($pdo);

            owner_audit($pdo, (int)$founder['id'], 'maintenance.run', 'platform', [
                'expired_story_candidates' => $expiredStories,
                'expired_message_candidates' => $expiredMessages,
            ]);

            ok([
                'ran' => true,
                'expired_stories' => $expiredStories,
                'expired_messages' => $expiredMessages,
                'server_time' => time(),
            ]);

        case 'owner_system_health':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            release_session_lock();
            $pdo = db();
            $now = time();

            $activeStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM users
                 WHERE disabled_at IS NULL AND last_seen_at >= ?'
            );
            $activeStmt->execute([$now - 300]);

            $callStmt = $pdo->prepare(
                "SELECT
                    SUM(status = 'ringing' AND created_at >= ?) AS ringing_count,
                    SUM(status = 'active') AS active_count
                 FROM calls
                 WHERE status IN ('ringing','active')"
            );
            $callStmt->execute([$now - CALL_RING_TTL_SECONDS]);
            $callHealth = $callStmt->fetch() ?: [];

            $pushQueue = 0;
            try {
                $pushQueue = (int)$pdo->query(
                    'SELECT COUNT(*) FROM push_jobs'
                )->fetchColumn();
            } catch (Throwable $e) {
                $pushQueue = 0;
            }

            $userEstimate = 0;
            try {
                $statusStmt = $pdo->query("SHOW TABLE STATUS LIKE 'users'");
                $statusRow = $statusStmt->fetch() ?: [];
                $userEstimate = max(0, (int)($statusRow['Rows'] ?? 0));
            } catch (Throwable $e) {
                $userEstimate = 0;
            }

            $memoryLimit = (string)ini_get('memory_limit');
            $serverVersion = '';
            try {
                $serverVersion = (string)$pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
            } catch (Throwable $e) {
                $serverVersion = '';
            }

            ok([
                'health' => [
                    'server_time' => $now,
                    'schema_version' => SCHEMA_VERSION,
                    'php_version' => PHP_VERSION,
                    'database_version' => $serverVersion,
                    'memory_limit' => $memoryLimit,
                    'request_memory_bytes' => memory_get_usage(true),
                    'request_peak_memory_bytes' => memory_get_peak_usage(true),
                    'active_users_5m' => (int)$activeStmt->fetchColumn(),
                    'accounts_estimate' => $userEstimate,
                    'active_calls' => (int)($callHealth['active_count'] ?? 0),
                    'ringing_calls' => (int)($callHealth['ringing_count'] ?? 0),
                    'pending_push_jobs' => $pushQueue,
                    'feature_flags' => owner_feature_flags($pdo),
                ],
            ]);

        case 'owner_user_lookup':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            $username = clean($_GET['username'] ?? '', MAX_USERNAME);
            if (!valid_username($username)) fail('Enter a valid username.');
            release_session_lock();
            $pdo = db();

            $userStmt = $pdo->prepare(
                'SELECT id, username, display_name, account_role, created_at, updated_at,
                        last_seen_at, session_version, disabled_at
                 FROM users
                 WHERE username = ?
                 LIMIT 1'
            );
            $userStmt->execute([$username]);
            $target = $userStmt->fetch();
            if (!$target) fail('User not found.', 404);
            $targetId = (int)$target['id'];

            $friendStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM friendships
                 WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)"
            );
            $friendStmt->execute([$targetId, $targetId]);

            $conversationStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM conversation_members WHERE user_id = ?'
            );
            $conversationStmt->execute([$targetId]);

            $messageStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM messages
                 WHERE sender_id = ? AND created_at >= ?'
            );
            $messageStmt->execute([$targetId, time() - 86400]);

            $adStateStmt = $pdo->prepare(
                'SELECT ad_pass_until, subscription_status, subscription_current_period_end
                 FROM user_ad_state WHERE user_id = ? LIMIT 1'
            );
            $adStateStmt->execute([$targetId]);
            $adState = $adStateStmt->fetch() ?: [];

            ok([
                'user' => [
                    'username' => (string)$target['username'],
                    'display_name' => (string)$target['display_name'],
                    'account_role' => (string)$target['account_role'],
                    'created_at' => (int)$target['created_at'],
                    'updated_at' => (int)$target['updated_at'],
                    'last_seen_at' => (int)$target['last_seen_at'],
                    'session_version' => (int)$target['session_version'],
                    'disabled' => $target['disabled_at'] !== null,
                    'friends' => (int)$friendStmt->fetchColumn(),
                    'conversations' => (int)$conversationStmt->fetchColumn(),
                    'messages_24h' => (int)$messageStmt->fetchColumn(),
                    'ad_pass_until' => (int)($adState['ad_pass_until'] ?? 0),
                    'subscription_status' => (string)($adState['subscription_status'] ?? 'inactive'),
                    'subscription_current_period_end' => (int)($adState['subscription_current_period_end'] ?? 0),
                ],
            ]);

        case 'owner_account_status_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_account_status', 20, 60);
            $data = body_json();
            $username = clean($data['username'] ?? '', MAX_USERNAME);
            $disabled = filter_var($data['disabled'] ?? null, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            $reason = clean($data['reason'] ?? '', 200);
            if (!valid_username($username) || !array_key_exists('disabled', $data) || $disabled === null) fail('Choose an account and a valid status.');
            if (mb_strlen($reason) < 4) fail('Add a short reason for the audit log.');
            release_session_lock();
            $pdo = db();
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare('SELECT id, username, account_role FROM users WHERE username = ? LIMIT 1 FOR UPDATE');
                $stmt->execute([$username]);
                $target = $stmt->fetch();
                if (!$target) { $pdo->rollBack(); fail('User not found.', 404); }
                if ((int)$target['id'] === (int)$founder['id'] || in_array((string)$target['account_role'], ['founder_ceo','cofounder_ceo'], true)) {
                    $pdo->rollBack(); fail('Founder accounts cannot be suspended with this tool.', 409);
                }
                $now = time();
                $pdo->prepare('UPDATE users SET disabled_at = ?, online_until = 0, session_version = session_version + 1, updated_at = ? WHERE id = ?')
                    ->execute([$disabled ? $now : null, $now, (int)$target['id']]);
                $pdo->prepare('DELETE FROM auth_tokens WHERE user_id = ?')->execute([(int)$target['id']]);
                owner_audit($pdo, (int)$founder['id'], $disabled ? 'account.suspend' : 'account.restore', (string)$target['username'], ['reason' => $reason]);
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            ok(['username' => (string)$target['username'], 'disabled' => $disabled]);

        case 'owner_feature_requests':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_founder();
            $status = (string)($_GET['status'] ?? 'submitted');
            if (!in_array($status, ['submitted','reviewing','planned','closed'], true)) fail('Invalid request status.');
            $before = max(0, (int)($_GET['before'] ?? 0));
            release_session_lock();
            $pdo = db();
            $stmt = $pdo->prepare('SELECT f.id, f.title, f.details, f.status, f.created_at, f.updated_at, u.username FROM feature_requests f JOIN users u ON u.id = f.user_id WHERE f.status = ? AND (? = 0 OR f.id < ?) ORDER BY f.id DESC LIMIT 31');
            $stmt->execute([$status, $before, $before]);
            $items = $stmt->fetchAll();
            $hasMore = count($items) > 30;
            $items = array_slice($items, 0, 30);
            ok(['requests' => $items, 'next_before' => $hasMore ? (int)$items[count($items)-1]['id'] : null]);

        case 'owner_feature_request_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_feature_request', 40, 60);
            $data = body_json();
            $id = max(0, (int)($data['id'] ?? 0));
            $status = (string)($data['status'] ?? '');
            if (!$id || !in_array($status, ['submitted','reviewing','planned','closed'], true)) fail('Choose a request and a valid status.');
            release_session_lock();
            $pdo = db();
            $stmt = $pdo->prepare('SELECT id FROM feature_requests WHERE id = ? LIMIT 1');
            $stmt->execute([$id]);
            if (!$stmt->fetchColumn()) fail('Feature request not found.', 404);
            $pdo->prepare('UPDATE feature_requests SET status = ?, updated_at = ? WHERE id = ?')->execute([$status, time(), $id]);
            owner_audit($pdo, (int)$founder['id'], 'feature.status', (string)$id, ['status' => $status]);
            ok(['id' => $id, 'status' => $status]);

        case 'owner_ad_free_grant':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_ad_free_grant', 30, 60);
            $data = body_json();
            $username = clean($data['username'] ?? '', MAX_USERNAME);
            $hours = min(720, max(1, (int)($data['hours'] ?? 24)));
            if (!valid_username($username)) fail('Enter a valid username.');
            release_session_lock();
            $pdo = db();

            $targetStmt = $pdo->prepare(
                'SELECT id, username FROM users
                 WHERE username = ? AND disabled_at IS NULL
                 LIMIT 1'
            );
            $targetStmt->execute([$username]);
            $target = $targetStmt->fetch();
            if (!$target) fail('User not found.', 404);

            $targetId = (int)$target['id'];
            ensure_ad_state($pdo, $targetId);
            $until = time() + ($hours * 3600);
            $pdo->prepare(
                'UPDATE user_ad_state
                 SET ad_pass_until = GREATEST(ad_pass_until, ?),
                     updated_at = ?
                 WHERE user_id = ?'
            )->execute([$until, time(), $targetId]);

            owner_audit($pdo, (int)$founder['id'], 'ads.grant_pass', (string)$target['username'], [
                'hours' => $hours,
                'until' => $until,
            ]);

            ok([
                'username' => (string)$target['username'],
                'ad_pass_until' => $until,
            ]);

        case 'owner_announcement_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_announcement', 20, 60);
            $data = body_json();
            $text = clean($data['text'] ?? '', 280);
            $hours = min(168, max(1, (int)($data['hours'] ?? 24)));
            release_session_lock();
            $pdo = db();

            if ($text === '') {
                set_app_meta_value($pdo, 'system_announcement_v1', '');
                owner_audit($pdo, (int)$founder['id'], 'announcement.clear', 'global');
                ok(['announcement' => null]);
            }

            $updatedAt = time();
            $announcement = [
                'id' => substr(hash('sha256', $updatedAt . '|' . $text . '|' . random_bytes(12)), 0, 24),
                'text' => $text,
                'expires_at' => $updatedAt + ($hours * 3600),
                'updated_at' => $updatedAt,
            ];
            set_app_meta_value(
                $pdo,
                'system_announcement_v1',
                json_encode($announcement, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            );
            owner_audit($pdo, (int)$founder['id'], 'announcement.publish', 'global', [
                'hours' => $hours,
                'expires_at' => $announcement['expires_at'],
            ]);
            ok(['announcement' => $announcement]);

        case 'owner_registration_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_registration', 20, 60);
            $data = body_json();
            $open = filter_var($data['open'] ?? true, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($open === null) fail('Invalid registration setting.');
            release_session_lock();
            $pdo = db();
            set_app_meta_value($pdo, 'registration_closed_v1', $open ? '0' : '1');
            owner_audit(
                $pdo,
                (int)$founder['id'],
                $open ? 'registration.open' : 'registration.pause',
                'global'
            );
            ok(['registration_open' => $open]);

        case 'owner_revoke_sessions':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $founder = require_founder();
            require_csrf();
            session_rate_limit('owner_revoke_sessions', 20, 60);
            $data = body_json();
            $username = clean($data['username'] ?? '', MAX_USERNAME);
            if (!valid_username($username)) fail('Enter a valid username.');
            release_session_lock();
            $pdo = db();

            $targetStmt = $pdo->prepare(
                'SELECT id, username, account_role
                 FROM users
                 WHERE username = ? AND disabled_at IS NULL
                 LIMIT 1'
            );
            $targetStmt->execute([$username]);
            $target = $targetStmt->fetch();
            if (!$target) fail('User not found.', 404);
            if (
                (int)$target['id'] === (int)$founder['id'] ||
                in_array((string)($target['account_role'] ?? ''), ['founder_ceo','cofounder_ceo'], true)
            ) {
                fail('Founder sessions cannot be revoked from this tool.', 409);
            }

            $pdo->beginTransaction();
            try {
                $pdo->prepare(
                    'UPDATE users
                     SET session_version = session_version + 1, updated_at = ?
                     WHERE id = ?'
                )->execute([time(), (int)$target['id']]);
                $pdo->prepare(
                    'DELETE FROM auth_tokens WHERE user_id = ?'
                )->execute([(int)$target['id']]);
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            owner_audit($pdo, (int)$founder['id'], 'security.revoke_sessions', (string)$target['username']);
            ok([
                'revoked' => true,
                'username' => (string)$target['username'],
            ]);

        case 'ads_txt':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $client = trim((string)(config()['adsense_client'] ?? ''));
            if (preg_match('/^ca-pub-(\d{8,32})$/i', $client, $match) !== 1) {
                http_response_code(404);
                header('Content-Type: text/plain; charset=utf-8');
                header('Cache-Control: public, max-age=300');
                echo "# SilkNex AdSense is not configured yet.\n";
                exit;
            }
            header('Content-Type: text/plain; charset=utf-8');
            header('Cache-Control: public, max-age=3600, stale-while-revalidate=86400');
            header_remove('Pragma');
            header_remove('Expires');
            echo 'google.com, pub-' . $match[1] . ", DIRECT, f08c47fec0942fa0\n";
            exit;

        case 'stripe_webhook':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $payload = file_get_contents('php://input');
            $payload = is_string($payload) ? $payload : '';
            $signature = (string)($_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '');
            $webhookSecret = (string)(config()['stripe_webhook_secret'] ?? '');
            if (!verify_stripe_signature($payload, $signature, $webhookSecret)) {
                fail('Invalid webhook signature.', 400);
            }
            $event = json_decode($payload, true);
            if (!is_array($event)) fail('Invalid webhook payload.', 400);
            $eventType = (string)($event['type'] ?? '');
            $object = $event['data']['object'] ?? null;
            if (is_array($object)) {
                $metadata = is_array($object['metadata'] ?? null) ? $object['metadata'] : [];
                $purchaseType = (string)($metadata['purchase_type'] ?? '');

                if (
                    $purchaseType === 'ad_campaign' &&
                    in_array($eventType, [
                        'checkout.session.completed',
                        'checkout.session.async_payment_succeeded',
                        'checkout.session.async_payment_failed',
                        'checkout.session.expired',
                    ], true)
                ) {
                    activate_ad_campaign_from_stripe(db(), $object, $eventType);
                } elseif (
                    in_array($eventType, [
                        'checkout.session.completed',
                        'customer.subscription.created',
                        'customer.subscription.updated',
                        'customer.subscription.deleted',
                    ], true)
                ) {
                    update_subscription_from_stripe(db(), $object, $eventType);
                }
            }
            ok(['received' => true]);

        case 'e2ee_device_register':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $deviceId = strtolower(trim((string)($data['device_id'] ?? '')));
            if (!preg_match('/^[a-f0-9]{32}$/', $deviceId)) {
                fail('Invalid encryption device id.');
            }
            $publicKey = e2ee_public_key_json($data['public_key_jwk'] ?? null);
            $label = clean($data['label'] ?? '', 80);
            $pdo = db();
            $now = time();
            $pdo->prepare(
                'INSERT INTO e2ee_devices
                    (user_id, device_id, public_key_jwk, label, created_at, last_seen_at, revoked_at)
                 VALUES (?, ?, ?, ?, ?, ?, NULL)
                 ON DUPLICATE KEY UPDATE
                    public_key_jwk = VALUES(public_key_jwk),
                    label = VALUES(label),
                    last_seen_at = VALUES(last_seen_at),
                    revoked_at = NULL'
            )->execute([(int)$user['id'], $deviceId, $publicKey, $label, $now, $now]);
            ok(['registered' => true, 'device_id' => $deviceId]);

        case 'e2ee_devices':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $conversationId = max(0, (int)($_GET['conversation_id'] ?? 0));
            require_member($conversationId, (int)$user['id']);
            release_session_lock();
            $pdo = db();

            $memberStmt = $pdo->prepare(
                'SELECT cm.user_id
                 FROM conversation_members cm
                 INNER JOIN users u ON u.id = cm.user_id AND u.disabled_at IS NULL
                 WHERE cm.conversation_id = ?
                 ORDER BY cm.user_id ASC'
            );
            $memberStmt->execute([$conversationId]);
            $memberIds = array_map('intval', array_column($memberStmt->fetchAll(), 'user_id'));

            $deviceStmt = $pdo->prepare(
                'SELECT d.user_id, d.device_id, d.public_key_jwk, d.label, d.last_seen_at
                 FROM e2ee_devices d
                 INNER JOIN conversation_members cm
                   ON cm.user_id = d.user_id AND cm.conversation_id = ?
                 INNER JOIN users u ON u.id = d.user_id AND u.disabled_at IS NULL
                 WHERE d.revoked_at IS NULL
                 ORDER BY d.user_id ASC, d.id ASC'
            );
            $deviceStmt->execute([$conversationId]);
            $devices = [];
            $covered = [];
            foreach ($deviceStmt->fetchAll() as $row) {
                $jwk = json_decode((string)$row['public_key_jwk'], true);
                if (!is_array($jwk)) continue;
                $uid = (int)$row['user_id'];
                $covered[$uid] = true;
                $devices[] = [
                    'user_id' => $uid,
                    'device_id' => (string)$row['device_id'],
                    'public_key_jwk' => $jwk,
                    'label' => (string)$row['label'],
                    'last_seen_at' => (int)$row['last_seen_at'],
                ];
            }
            $missing = array_values(array_filter(
                $memberIds,
                static fn(int $id): bool => empty($covered[$id])
            ));
            ok([
                'devices' => $devices,
                'missing_user_ids' => $missing,
                'member_count' => count($memberIds),
            ]);

        case 'presence':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $active = !empty($data['active']);
            $now = time();
            release_session_lock();
            $pdo = db();

            if ($active) {
                // A short renewable lease makes "online" mean the app is
                // actually foregrounded and focused. If a tab is backgrounded,
                // suspended, killed, or loses connectivity, the lease expires
                // without any cleanup job.
                $onlineUntil = $now + 18;
                $pdo->prepare(
                    'UPDATE users
                     SET last_seen_at = ?, online_until = ?
                     WHERE id = ? AND disabled_at IS NULL'
                )->execute([$now, $onlineUntil, (int)$user['id']]);
            } else {
                $onlineUntil = 0;
                $pdo->prepare(
                    'UPDATE users SET online_until = 0 WHERE id = ?'
                )->execute([(int)$user['id']]);
            }

            ok([
                'online' => $active,
                'online_until' => $onlineUntil,
                'last_seen_at' => $active ? $now : (int)($user['last_seen_at'] ?? 0),
            ]);

        case 'typing':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $conversationId = max(0, (int)($data['conversation_id'] ?? 0));
            require_member($conversationId, (int)$user['id']);
            release_session_lock();
            $pdo = db();
            if (!empty($data['typing'])) {
                $now = time();
                $pdo->prepare(
                    'INSERT INTO typing_state (conversation_id, user_id, expires_at, updated_at)
                     VALUES (?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE expires_at = VALUES(expires_at), updated_at = VALUES(updated_at)'
                )->execute([$conversationId, (int)$user['id'], $now + 6, $now]);
            } else {
                $pdo->prepare(
                    'DELETE FROM typing_state WHERE conversation_id = ? AND user_id = ?'
                )->execute([$conversationId, (int)$user['id']]);
            }
            ok(['typing' => !empty($data['typing'])]);

        case 'ad_config':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            $cfg = config();
            $client = trim((string)($cfg['adsense_client'] ?? ''));
            $homeSlot = trim((string)($cfg['adsense_home_slot'] ?? ''));
            $adsenseConnected =
                !empty($cfg['adsense_enabled']) &&
                preg_match('/^ca-pub-\d{8,32}$/i', $client) === 1;
            $manualHomeReady =
                $adsenseConnected &&
                preg_match('/^\d{5,32}$/', $homeSlot) === 1;
            $rewardedUnit = trim((string)($cfg['gam_rewarded_ad_unit'] ?? ''));
            $pdo = db();
            $adSalesPaused = app_meta_value($pdo, 'owner_ad_sales_paused_v1') === '1';
            ok([
                'provider' => 'google',
                'adsense' => [
                    // A publisher client is enough for site verification and
                    // Auto Ads. A manual responsive home banner additionally
                    // needs SILKNEX_ADSENSE_HOME_SLOT.
                    'enabled' => $adsenseConnected,
                    'manual_home_enabled' => $manualHomeReady,
                    'client' => $adsenseConnected ? $client : '',
                    'home_slot' => $manualHomeReady ? $homeSlot : '',
                    'auto_ads' => $adsenseConnected && !empty($cfg['adsense_auto_ads']),
                    'auto_ads_recommended' => false,
                    'channel' => (
                        $adsenseConnected &&
                        preg_match('/^\d{1,20}$/', trim((string)($cfg['adsense_channel'] ?? ''))) === 1
                    ) ? trim((string)$cfg['adsense_channel']) : '',
                    'test_mode' => !empty($cfg['adsense_test_mode']),
                    // Google Publisher Policy does not allow AdSense display ads
                    // on screens where private communication is the primary focus.
                    'active_chat_allowed' => false,
                ],
                'ad_manager' => [
                    'rewarded_enabled' => preg_match('#^/\d{3,20}/[A-Za-z0-9_./-]{1,180}$#', $rewardedUnit) === 1,
                    'rewarded_ad_unit' => preg_match('#^/\d{3,20}/[A-Za-z0-9_./-]{1,180}$#', $rewardedUnit) === 1 ? $rewardedUnit : '',
                    'interstitial_enabled' => preg_match(
                        '#^/\d{3,20}/[A-Za-z0-9_./-]{1,180}$#',
                        trim((string)($cfg['gam_interstitial_ad_unit'] ?? ''))
                    ) === 1,
                    'interstitial_ad_unit' => preg_match(
                        '#^/\d{3,20}/[A-Za-z0-9_./-]{1,180}$#',
                        trim((string)($cfg['gam_interstitial_ad_unit'] ?? ''))
                    ) === 1
                        ? trim((string)$cfg['gam_interstitial_ad_unit'])
                        : '',
                    'interstitial_min_seconds' => max(
                        900,
                        (int)($cfg['ad_interstitial_min_seconds'] ?? 1200)
                    ),
                ],
                'policy' => [
                    'active_chat_google_ads' => false,
                    'calls_google_ads' => false,
                    'reward_requires_provider_grant' => true,
                ],
                'status' => ad_status($pdo, (int)$user['id']),
                'subscription' => [
                    'currency' => 'usd',
                    'interval' => 'month',
                    'checkout_ready' => (
                        str_starts_with((string)($cfg['stripe_secret_key'] ?? ''), 'sk_') &&
                        str_starts_with((string)($cfg['stripe_webhook_secret'] ?? ''), 'whsec_')
                    ),
                    'plans' => array_values(subscription_plan_catalog()),
                ],
                'self_serve_ads' => [
                    'enabled' => true,
                    'sales_paused' => $adSalesPaused,
                    'checkout_ready' => (
                        !$adSalesPaused &&
                        str_starts_with((string)($cfg['stripe_secret_key'] ?? ''), 'sk_') &&
                        str_starts_with((string)($cfg['stripe_webhook_secret'] ?? ''), 'whsec_')
                    ),
                    'price_per_day_cents' => 500,
                    'currency' => 'usd',
                    'max_days' => 30,
                    'active_chat_allowed' => false,
                    'calls_allowed' => false,
                ],
            ]);

        case 'ad_inventory':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            $limit = min(5, max(1, (int)($_GET['limit'] ?? 1)));
            $campaigns = active_ad_campaigns(db(), (int)$user['id'], $limit);
            ok([
                'campaign' => $campaigns[0] ?? null,
                'campaigns' => $campaigns,
            ]);

        case 'ad_campaigns':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            $pdo = db();
            $now = time();
            $pdo->prepare(
                "UPDATE ad_campaigns
                 SET status = 'expired'
                 WHERE user_id = ?
                   AND status = 'active'
                   AND ends_at IS NOT NULL
                   AND ends_at <= ?"
            )->execute([(int)$user['id'], $now]);
            $pdo->prepare(
                "UPDATE ad_campaigns
                 SET status = 'cancelled'
                 WHERE user_id = ?
                   AND status = 'pending'
                   AND created_at <= ?"
            )->execute([(int)$user['id'], $now - 86400]);

            $stmt = $pdo->prepare(
                'SELECT id, user_id, upload_token, headline, destination_url, days,
                        price_cents, status, starts_at, ends_at, created_at
                 FROM ad_campaigns
                 WHERE user_id = ?
                 ORDER BY id DESC
                 LIMIT 20'
            );
            $stmt->execute([(int)$user['id']]);
            $items = array_map('ad_campaign_payload', $stmt->fetchAll());
            ok(['campaigns' => $items]);

        case 'ad_campaign_checkout':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit(
                'ad_campaign_checkout',
                8,
                3600,
                (string)$user['id'],
                'subject',
                'Too many ad checkout attempts. Try again later.'
            );
            $data = body_json();
            $headline = clean($data['headline'] ?? '', 60);
            if (mb_strlen($headline) < 3) fail('Ad headline must be at least 3 characters.');

            $destinationUrl = normalize_ad_destination_url((string)($data['destination_url'] ?? ''));
            $days = max(0, (int)($data['days'] ?? 0));
            if ($days < 1 || $days > 30) fail('Choose between 1 and 30 advertising days.');

            $uploadToken = strtolower(trim((string)($data['upload_token'] ?? '')));
            if (!preg_match('/^[a-f0-9]{48}$/', $uploadToken)) {
                fail('Upload an ad image first.');
            }

            release_session_lock();
            $cfg = config();
            if (
                !str_starts_with((string)($cfg['stripe_secret_key'] ?? ''), 'sk_') ||
                !str_starts_with((string)($cfg['stripe_webhook_secret'] ?? ''), 'whsec_')
            ) {
                fail('Ad checkout is not configured yet.', 503);
            }

            $pdo = db();
            if (
                !is_founder_user($user) &&
                app_meta_value($pdo, 'owner_ad_sales_paused_v1') === '1'
            ) {
                fail('New ad campaign purchases are temporarily paused. Try again later.', 503);
            }

            $upload = $pdo->prepare(
                "SELECT user_id, purpose, media_type, mime_type, file_size, used_at
                 FROM uploads
                 WHERE token = ?
                 LIMIT 1"
            );
            $upload->execute([$uploadToken]);
            $uploadRow = $upload->fetch();
            if (
                !$uploadRow ||
                (int)$uploadRow['user_id'] !== (int)$user['id'] ||
                (string)$uploadRow['purpose'] !== 'ad' ||
                (string)$uploadRow['media_type'] !== 'image'
            ) {
                fail('That ad image is unavailable.');
            }

            if (!in_array((string)$uploadRow['mime_type'], ['image/png','image/jpeg','image/webp'], true)) {
                fail('Ad creative must be PNG, JPEG, or WebP.');
            }

            $priceCents = $days * 500;
            $now = time();
            $pdo->prepare(
                "INSERT INTO ad_campaigns
                    (user_id, upload_token, headline, destination_url, days,
                     price_cents, status, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)"
            )->execute([
                (int)$user['id'],
                $uploadToken,
                $headline,
                $destinationUrl,
                $days,
                $priceCents,
                $now,
            ]);
            $campaignId = (int)$pdo->lastInsertId();
            if ($campaignId < 1) fail('Could not create the ad campaign.', 500);
            $pdo->prepare(
                'UPDATE uploads SET used_at = COALESCE(used_at, ?) WHERE token = ? AND user_id = ?'
            )->execute([$now, $uploadToken, (int)$user['id']]);

            $origin = silknex_public_origin();
            $fields = [
                'mode' => 'payment',
                'client_reference_id' => (string)$user['id'],
                'success_url' => $origin . '/?advertise=success',
                'cancel_url' => $origin . '/?advertise=cancelled',
                'line_items[0][quantity]' => '1',
                'line_items[0][price_data][currency]' => 'usd',
                'line_items[0][price_data][unit_amount]' => (string)$priceCents,
                'line_items[0][price_data][product_data][name]' =>
                    'SilkNex advertising · ' . $days . ($days === 1 ? ' day' : ' days'),
                'line_items[0][price_data][product_data][description]' =>
                    'Self-serve SilkNex home advertising at $5 per day.',
                'metadata[purchase_type]' => 'ad_campaign',
                'metadata[campaign_id]' => (string)$campaignId,
                'metadata[user_id]' => (string)$user['id'],
                'payment_intent_data[metadata][purchase_type]' => 'ad_campaign',
                'payment_intent_data[metadata][campaign_id]' => (string)$campaignId,
                'payment_intent_data[metadata][user_id]' => (string)$user['id'],
            ];
            $checkout = stripe_request('checkout/sessions', $fields);
            $url = (string)($checkout['url'] ?? '');
            $checkoutId = (string)($checkout['id'] ?? '');
            if (
                !str_starts_with($url, 'https://checkout.stripe.com/') ||
                !str_starts_with($checkoutId, 'cs_')
            ) {
                fail('Ad checkout returned an invalid response.', 502);
            }

            $pdo->prepare(
                'UPDATE ad_campaigns
                 SET stripe_checkout_session_id = ?
                 WHERE id = ? AND user_id = ?'
            )->execute([$checkoutId, $campaignId, (int)$user['id']]);

            ok([
                'url' => $url,
                'campaign_id' => $campaignId,
                'price_cents' => $priceCents,
                'days' => $days,
            ]);

        case 'ad_events_batch':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $events = $data['events'] ?? null;
            if (!is_array($events) || count($events) < 1 || count($events) > 12) {
                fail('Invalid ad event batch.');
            }
            release_session_lock();
            $pdo = db();
            $now = time();

            // One bounded write per batch is much cheaper than one HTTP request
            // per ad lifecycle event, especially on mobile networks. Telemetry is
            // diagnostic only and never decides whether a reward is granted.
            $recent = $pdo->prepare(
                'SELECT COUNT(*) FROM ad_events WHERE user_id = ? AND created_at >= ?'
            );
            $recent->execute([(int)$user['id'], $now - 60]);
            $remaining = max(0, 24 - (int)$recent->fetchColumn());
            $accepted = 0;

            if ($remaining > 0) {
                $insert = $pdo->prepare(
                    'INSERT INTO ad_events
                        (user_id, provider, placement, event_type, client_key, created_at)
                     VALUES (?, ?, ?, ?, ?, ?)'
                );
                $allowedEvents = [
                    'requested', 'rendered', 'unfilled', 'blocked',
                    'reward_ready', 'reward_granted', 'reward_closed',
                    'interstitial_registered', 'interstitial_rendered', 'interstitial_viewed'
                ];

                $pdo->beginTransaction();
                try {
                    foreach (array_slice($events, 0, $remaining) as $event) {
                        if (!is_array($event)) continue;
                        $provider = strtolower(trim((string)($event['provider'] ?? 'adsense')));
                        $placement = strtolower(trim((string)($event['placement'] ?? '')));
                        $eventType = strtolower(trim((string)($event['event_type'] ?? '')));
                        $clientKey = strtolower(trim((string)($event['client_key'] ?? '')));

                        if (!in_array($provider, ['adsense', 'admanager', 'house'], true)) continue;
                        if (!preg_match('/^[a-z0-9_-]{2,40}$/', $placement)) continue;
                        if (!in_array($eventType, $allowedEvents, true)) continue;
                        if (!preg_match('/^[a-f0-9]{32}$/', $clientKey)) continue;

                        $insert->execute([
                            (int)$user['id'], $provider, $placement, $eventType, $clientKey, $now
                        ]);
                        $accepted++;
                    }
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    throw $e;
                }
            }

            if (random_int(1, 100) === 1) {
                $pdo->prepare('DELETE FROM ad_events WHERE created_at < ?')
                    ->execute([$now - 30 * 86400]);
            }
            ok(['recorded' => $accepted]);

        case 'ad_event':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $provider = strtolower(trim((string)($data['provider'] ?? 'adsense')));
            $placement = strtolower(trim((string)($data['placement'] ?? '')));
            $eventType = strtolower(trim((string)($data['event_type'] ?? '')));
            $clientKey = strtolower(trim((string)($data['client_key'] ?? '')));
            if (!in_array($provider, ['adsense', 'admanager', 'house'], true)) {
                fail('Invalid ad provider.');
            }
            if (!preg_match('/^[a-z0-9_-]{2,40}$/', $placement)) {
                fail('Invalid ad placement.');
            }
            if (!in_array($eventType, [
                'requested', 'rendered', 'unfilled', 'blocked',
                'reward_ready', 'reward_granted', 'reward_closed',
                'interstitial_registered', 'interstitial_rendered', 'interstitial_viewed'
            ], true)) {
                fail('Invalid ad event.');
            }
            if (!preg_match('/^[a-f0-9]{32}$/', $clientKey)) {
                fail('Invalid ad client key.');
            }
            release_session_lock();
            $pdo = db();
            $now = time();

            // Client telemetry is diagnostics only. Cap duplicate rows so a
            // broken browser cannot turn this endpoint into an unbounded write path.
            $recent = $pdo->prepare(
                'SELECT COUNT(*) FROM ad_events
                 WHERE user_id = ? AND client_key = ? AND created_at >= ?'
            );
            $recent->execute([(int)$user['id'], $clientKey, $now - 60]);
            if ((int)$recent->fetchColumn() < 12) {
                $pdo->prepare(
                    'INSERT INTO ad_events
                        (user_id, provider, placement, event_type, client_key, created_at)
                     VALUES (?, ?, ?, ?, ?, ?)'
                )->execute([
                    (int)$user['id'], $provider, $placement, $eventType, $clientKey, $now
                ]);
            }

            // Opportunistic retention keeps the diagnostics table small without
            // requiring a cron job on shared hosting.
            if (random_int(1, 100) === 1) {
                $pdo->prepare('DELETE FROM ad_events WHERE created_at < ?')
                    ->execute([$now - 30 * 86400]);
            }
            ok(['recorded' => true]);

        case 'ad_status':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            ok(['status' => ad_status(db(), (int)$user['id'])]);

        case 'rewarded_ad_start':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            release_session_lock();
            $pdo = db();
            $status = ad_status($pdo, (int)$user['id']);
            if (!empty($status['ads_disabled'])) {
                ok(['status' => $status, 'already_ad_free' => true]);
            }
            $id = bin2hex(random_bytes(24));
            $now = time();
            $pdo->prepare(
                'INSERT INTO ad_reward_sessions
                    (id, user_id, started_at, complete_after, expires_at, completed_at)
                 VALUES (?, ?, ?, ?, ?, NULL)'
            )->execute([$id, (int)$user['id'], $now, $now + 30, $now + 600]);
            ok([
                'reward_token' => $id,
                'complete_after' => $now + 30,
                'duration_seconds' => 30,
                'status' => $status,
            ]);

        case 'rewarded_ad_complete':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $token = strtolower(trim((string)($data['reward_token'] ?? '')));
            if (!preg_match('/^[a-f0-9]{48}$/', $token)) fail('Invalid ad reward token.');
            release_session_lock();
            $pdo = db();
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare(
                    'SELECT user_id, complete_after, expires_at, completed_at
                     FROM ad_reward_sessions
                     WHERE id = ?
                     FOR UPDATE'
                );
                $stmt->execute([$token]);
                $session = $stmt->fetch();
                if (!$session || (int)$session['user_id'] !== (int)$user['id']) {
                    fail('Ad reward session not found.', 404);
                }
                if ($session['completed_at'] !== null) fail('This ad reward was already claimed.', 409);
                $now = time();
                if ((int)$session['expires_at'] < $now) fail('This ad reward expired.', 410);
                if ((int)$session['complete_after'] > $now) {
                    fail('Finish watching the ad before claiming this reward.', 409);
                }

                ensure_ad_state($pdo, (int)$user['id']);
                $stateStmt = $pdo->prepare(
                    'SELECT rewarded_count FROM user_ad_state WHERE user_id = ? FOR UPDATE'
                );
                $stateStmt->execute([(int)$user['id']]);
                $count = min(5, (int)($stateStmt->fetchColumn() ?: 0) + 1);
                $passUntil = 0;
                if ($count >= 5) {
                    $count = 0;
                    $passUntil = $now + 1800;
                    $pdo->prepare(
                        'UPDATE user_ad_state
                         SET rewarded_count = 0, ad_pass_until = ?, updated_at = ?
                         WHERE user_id = ?'
                    )->execute([$passUntil, $now, (int)$user['id']]);
                } else {
                    $pdo->prepare(
                        'UPDATE user_ad_state
                         SET rewarded_count = ?, updated_at = ?
                         WHERE user_id = ?'
                    )->execute([$count, $now, (int)$user['id']]);
                }
                $pdo->prepare(
                    'UPDATE ad_reward_sessions SET completed_at = ? WHERE id = ?'
                )->execute([$now, $token]);
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            ok(['status' => ad_status($pdo, (int)$user['id'])]);

        case 'interstitial_impression':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            release_session_lock();
            $pdo = db();
            $userId = (int)$user['id'];
            ensure_ad_state($pdo, $userId);

            // Treat this endpoint as a frequency-cap marker, not proof of ad
            // revenue. Google controls the actual reactive-ad impression.
            $before = ad_status($pdo, $userId);
            if (!empty($before['ads_disabled'])) {
                ok(['accepted' => false, 'status' => $before]);
            }

            if (empty($before['interstitial_due'])) {
                ok(['accepted' => false, 'status' => $before]);
            }

            $now = time();
            $pdo->prepare(
                'UPDATE user_ad_state
                 SET last_interstitial_at = ?, updated_at = ?
                 WHERE user_id = ?'
            )->execute([$now, $now, $userId]);
            ok(['accepted' => true, 'status' => ad_status($pdo, $userId)]);

        case 'subscription_checkout':
            if($method!=='POST')fail('Method not allowed.',405);
            $user=current_user(); require_csrf(); $data=body_json();
            $plan=normalize_subscription_plan((string)($data['plan']??'basic')); $catalog=subscription_plan_catalog();
            if($plan===''||!isset($catalog[$plan]))fail('Choose a valid SilkNex subscription.');
            rate_limit('subscription_checkout',10,3600,(string)$user['id'],'subject','Too many checkout attempts. Try again later.');
            release_session_lock(); $cfg=config();
            if(!str_starts_with((string)($cfg['stripe_secret_key']??''),'sk_')||!str_starts_with((string)($cfg['stripe_webhook_secret']??''),'whsec_'))fail('Secure subscription checkout is not configured yet.',503);
            $entry=$catalog[$plan]; $origin=silknex_public_origin();
            $fields=['mode'=>'subscription','client_reference_id'=>(string)$user['id'],
              'success_url'=>$origin.'/?subscription=success&plan='.rawurlencode($plan),'cancel_url'=>$origin.'/?subscription=cancelled',
              'line_items[0][quantity]'=>'1','line_items[0][price_data][currency]'=>'usd',
              'line_items[0][price_data][unit_amount]'=>(string)(int)$entry['price_cents'],
              'line_items[0][price_data][recurring][interval]'=>'month',
              'line_items[0][price_data][product_data][name]'=>'SilkNex '.(string)$entry['name'],
              'metadata[purchase_type]'=>'subscription','metadata[user_id]'=>(string)$user['id'],'metadata[plan]'=>$plan,
              'subscription_data[metadata][purchase_type]'=>'subscription','subscription_data[metadata][user_id]'=>(string)$user['id'],'subscription_data[metadata][plan]'=>$plan];
            $co=stripe_request('checkout/sessions',$fields); $url=(string)($co['url']??'');
            if(!str_starts_with($url,'https://checkout.stripe.com/'))fail('Subscription checkout returned an invalid URL.',502);
            ok(['url'=>$url,'plan'=>$plan]);

        case 'custom_emojis':
            if($method!=='GET')fail('Method not allowed.',405);
            $user=current_user(); release_session_lock(); $pdo=db();
            require_subscription_feature($pdo,(int)$user['id'],'custom_emojis');
            $q=$pdo->prepare("SELECT ce.id,ce.shortcode,ce.upload_token,ce.created_at,u.original_name,u.file_size,ss.id AS sticker_id FROM custom_emojis ce INNER JOIN uploads u ON u.token=ce.upload_token AND u.user_id=ce.user_id LEFT JOIN saved_stickers ss ON ss.user_id=ce.user_id AND ss.upload_token=ce.upload_token WHERE ce.user_id=? ORDER BY ce.id DESC LIMIT 64");
            $q->execute([(int)$user['id']]);
            $items=array_map(static fn(array $r):array=>['id'=>(int)$r['id'],'shortcode'=>(string)$r['shortcode'],'sticker_id'=>(int)($r['sticker_id']??0),'token'=>(string)$r['upload_token'],'url'=>media_reference_url(media_store_reference((string)$r['upload_token'])),'name'=>(string)$r['original_name'],'size'=>(int)$r['file_size'],'created_at'=>(int)$r['created_at']],$q->fetchAll());
            ok(['emojis'=>$items]);

        case 'custom_emoji_create':
            if($method!=='POST')fail('Method not allowed.',405);
            $user=current_user(); require_csrf(); $data=body_json(); release_session_lock(); $pdo=db();
            require_subscription_feature($pdo,(int)$user['id'],'custom_emojis');
            $stickerId=max(0,(int)($data['sticker_id']??0));
            $shortcode=strtolower(trim((string)($data['shortcode']??'')));
            $shortcode=trim($shortcode,':');
            if(!preg_match('/^[a-z0-9_]{2,22}$/',$shortcode))fail('Emoji names use 2–22 letters, numbers, or underscores.');
            $q=$pdo->prepare("SELECT ss.upload_token FROM saved_stickers ss INNER JOIN uploads u ON u.token=ss.upload_token AND u.user_id=ss.user_id AND u.purpose='sticker' WHERE ss.id=? AND ss.user_id=? LIMIT 1");
            $q->execute([$stickerId,(int)$user['id']]); $token=(string)($q->fetchColumn()?:'');
            if($token==='')fail('Create or choose a sticker first.',404);
            $pdo->prepare('INSERT INTO custom_emojis(user_id,upload_token,shortcode,created_at) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE upload_token=VALUES(upload_token),created_at=VALUES(created_at)')->execute([(int)$user['id'],$token,$shortcode,time()]);
            ok(['created'=>true,'shortcode'=>$shortcode],201);

        case 'custom_emoji_delete':
            if($method!=='POST')fail('Method not allowed.',405);
            $user=current_user(); require_csrf(); $data=body_json(); release_session_lock(); $pdo=db();
            require_subscription_feature($pdo,(int)$user['id'],'custom_emojis');
            $id=max(0,(int)($data['id']??0)); $pdo->prepare('DELETE FROM custom_emojis WHERE id=? AND user_id=?')->execute([$id,(int)$user['id']]);
            ok(['deleted'=>true]);

        case 'subscription_manage':
            if($method!=='POST')fail('Method not allowed.',405);
            $user=current_user(); require_csrf(); release_session_lock(); $pdo=db();
            ensure_ad_state($pdo,(int)$user['id']);
            $q=$pdo->prepare('SELECT stripe_customer_id FROM user_ad_state WHERE user_id=? LIMIT 1');
            $q->execute([(int)$user['id']]); $customer=trim((string)($q->fetchColumn()?:''));
            if($customer===''||!str_starts_with($customer,'cus_'))fail('No billing account is available yet.',404);
            $portal=stripe_request('billing_portal/sessions',[
              'customer'=>$customer,
              'return_url'=>silknex_public_origin().'/?subscription=manage'
            ]);
            $url=(string)($portal['url']??'');
            if(!str_starts_with($url,'https://billing.stripe.com/'))fail('Subscription management is unavailable.',502);
            ok(['url'=>$url]);

        case 'feature_requests':
            if($method!=='GET')fail('Method not allowed.',405);
            $user=current_user(); release_session_lock(); $pdo=db();
            require_subscription_feature($pdo,(int)$user['id'],'feature_requests');
            $q=$pdo->prepare('SELECT id,title,details,status,created_at,updated_at FROM feature_requests WHERE user_id=? ORDER BY id DESC LIMIT 50');
            $q->execute([(int)$user['id']]); ok(['requests'=>$q->fetchAll()]);

        case 'feature_request_submit':
            if($method!=='POST')fail('Method not allowed.',405);
            $user=current_user(); require_csrf(); $data=body_json(); release_session_lock(); $pdo=db();
            require_subscription_feature($pdo,(int)$user['id'],'feature_requests');
            $title=clean($data['title']??'',100); $details=clean($data['details']??'',2000);
            if(mb_strlen($title)<3||mb_strlen($details)<8)fail('Add a short title and a little more detail.');
            $now=time(); $pdo->prepare('INSERT INTO feature_requests(user_id,title,details,status,created_at,updated_at) VALUES(?,?,?,\'submitted\',?,?)')->execute([(int)$user['id'],$title,$details,$now,$now]);
            ok(['id'=>(int)$pdo->lastInsertId()],201);


        case 'signup':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            require_same_origin();

            $data = body_json();
            $username = clean($data['username'] ?? '', MAX_USERNAME);
            $password = (string)($data['password'] ?? '');
            $passwordConfirm = (string)($data['password_confirm'] ?? '');

            if (!valid_username($username)) {
                fail('Username must be 3–24 characters using letters, numbers, ., _ or -.');
            }

            if (!hash_equals($password, $passwordConfirm)) {
                fail('The passwords do not match.');
            }

            if (strcasecmp($username, COFOUNDER_USERNAME) === 0 || strcasecmp($username, FOUNDER_USERNAME) === 0) fail('That username is reserved.', 409);
            validate_new_password($password, $username);

            $pdo = db();

            if (app_meta_value($pdo, 'registration_closed_v1') === '1') {
                fail('New account creation is temporarily paused.', 503);
            }

            // Checking availability before the creation throttle means simple
            // form mistakes and "username taken" responses do not consume the
            // browser's account-creation allowance.
            $exists = $pdo->prepare(
                'SELECT id FROM users WHERE username = ? LIMIT 1'
            );
            $exists->execute([$username]);

            if ($exists->fetchColumn()) {
                fail('That username is already taken.', 409);
            }

            // Signup throttling is browser-session scoped instead of IP-wide.
            // This avoids one device/network/proxy locking out every other
            // device while still stopping one browser from rapid account spam.
            rate_limit(
                'signup_device',
                10,
                600,
                '',
                'device',
                'Too many account creation attempts in this browser. Wait a few minutes and try again.'
            );
            rate_limit(
                'signup_network',
                30,
                3600,
                '',
                'ip',
                'This network created too many accounts recently. Try again later.'
            );

            $now = time();

            try {
                $stmt = $pdo->prepare(
                    'INSERT INTO users
                     (username, display_name, password_hash, about, accent, created_at, updated_at, last_seen_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute([
                    $username,
                    $username,
                    hash_password_secure($password),
                    '',
                    'silver',
                    $now,
                    $now,
                    $now,
                ]);
            } catch (PDOException $e) {
                // A race can still occur if two valid signup requests choose
                // the same username at nearly the same moment.
                if ((string)$e->getCode() === '23000') {
                    fail('That username is already taken.', 409);
                }
                throw $e;
            }

            $userId = (int)$pdo->lastInsertId();

            session_regenerate_id(true);
            $_SESSION['user_id'] = $userId;
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            $_SESSION['last_seen_touch'] = $now;
            $_SESSION['last_activity'] = $now;
            $_SESSION['rotated_at'] = $now;
            $_SESSION['session_version'] = 1;
            $_SESSION['client_fingerprint'] = client_fingerprint();

            $createdUser = [
                'id' => $userId,
                'username' => $username,
                'display_name' => $username,
                'about' => '',
                'accent' => 'silver',
                'last_seen_at' => $now,
                'session_version' => 1
            ];

            $persistentLogin = true;

            try {
                issue_remember_token($userId);
            } catch (Throwable $e) {
                // The permanent MySQL account and live PHP session are already
                // valid. Never report account creation as failed just because
                // an optional long-lived login token could not be created.
                $persistentLogin = false;
                error_log('[SilkNex remember token] ' . $e->getMessage());
            }

            ok([
                'user' => self_user($createdUser),
                'csrf' => csrf_token(),
                'account_saved' => true,
                'created' => true,
                'persistent_login' => $persistentLogin
            ], 201);

        case 'login':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            require_same_origin();

            $data = body_json();
            $username = clean($data['username'] ?? '', MAX_USERNAME);
            $password = (string)($data['password'] ?? '');

            if (strlen($password) > 256) {
                fail('Incorrect username or password.', 401);
            }

            rate_limit(
                'login_device',
                12,
                300,
                $username,
                'device',
                'Too many login attempts for this account in this browser. Wait a few minutes and try again.'
            );
            rate_limit(
                'login_account_network',
                24,
                900,
                $username,
                'ip',
                'Too many login attempts for this account from this network. Try again later.'
            );
            rate_limit(
                'login_network',
                240,
                600,
                '',
                'ip',
                'This network is sending too many login attempts. Wait a few minutes and try again.'
            );

            $pdo = db();
            $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? AND disabled_at IS NULL LIMIT 1');
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            $passwordHash = $user ? (string)$user['password_hash'] : null;
            $legacyPasswordHash = false;
            $passwordValid = verify_password_with_timing($password, $passwordHash, $legacyPasswordHash);

            if (!$user || !$passwordValid) {
                usleep(random_int(90000, 180000));
                fail('Incorrect username or password.', 401);
            }

            if ($legacyPasswordHash || password_needs_rehash_secure((string)$user['password_hash'])) {
                $pdo->prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?')
                    ->execute([hash_password_secure($password), time(), (int)$user['id']]);
            }

            // Successful authentication resets only this account/browser's
            // buckets. The global network throttle remains intact against abuse.
            clear_rate_limit('login_device', $username, 'device');
            clear_rate_limit('login_account_network', $username, 'ip');

            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            $_SESSION['last_seen_touch'] = time();
            $_SESSION['last_activity'] = time();
            $_SESSION['rotated_at'] = time();
            $_SESSION['session_version'] = max(1, (int)($user['session_version'] ?? 1));
            $_SESSION['client_fingerprint'] = client_fingerprint();

            $pdo->prepare('UPDATE users SET last_seen_at = ? WHERE id = ?')
                ->execute([time(), (int)$user['id']]);
            $user['last_seen_at'] = time();

            $persistentLogin = true;

            try {
                issue_remember_token((int)$user['id']);
            } catch (Throwable $e) {
                $persistentLogin = false;
                error_log('[SilkNex remember token] ' . $e->getMessage());
            }

            ok([
                'user' => self_user($user),
                'csrf' => csrf_token(),
                'account_saved' => true,
                'persistent_login' => $persistentLogin
            ]);

        case 'passkey_login_options':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            require_same_origin();
            if (!function_exists('openssl_verify')) {
                fail('Passkeys are not available on this PHP server.', 503);
            }
            rate_limit(
                'passkey_options',
                40,
                300,
                '',
                'device',
                'Too many passkey attempts. Wait a few minutes and try again.'
            );

            $challenge = b64url_encode(random_bytes(32));
            $_SESSION['webauthn_login_challenge'] = $challenge;
            $_SESSION['webauthn_login_challenge_at'] = time();

            ok([
                'publicKey' => [
                    'challenge' => $challenge,
                    'rpId' => request_host(),
                    'timeout' => 60000,
                    'userVerification' => 'required',
                ]
            ]);

        case 'passkey_login_finish':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            require_same_origin();
            rate_limit(
                'passkey_login',
                12,
                300,
                '',
                'device',
                'Too many passkey attempts. Wait a few minutes and try again.'
            );

            $data = body_json();
            $challenge = (string)($_SESSION['webauthn_login_challenge'] ?? '');
            $challengeAt = (int)($_SESSION['webauthn_login_challenge_at'] ?? 0);

            unset($_SESSION['webauthn_login_challenge'], $_SESSION['webauthn_login_challenge_at']);

            if ($challenge === '' || $challengeAt < time() - 300) {
                fail('Passkey challenge expired. Try again.', 400);
            }

            $credentialId = (string)($data['id'] ?? '');
            $clientJson = b64url_decode((string)($data['clientDataJSON'] ?? ''));
            $authenticatorData = b64url_decode((string)($data['authenticatorData'] ?? ''));
            $signature = b64url_decode((string)($data['signature'] ?? ''));

            verify_webauthn_client_data(
                $clientJson,
                'webauthn.get',
                $challenge
            );

            $parsed = parse_authenticator_data($authenticatorData);
            if (!hash_equals(hash('sha256', request_host(), true), (string)$parsed['rp_id_hash'])) {
                fail('Passkey website check failed.', 403);
            }

            $flags = (int)$parsed['flags'];
            if (($flags & 0x01) !== 0x01 || ($flags & 0x04) !== 0x04) {
                fail('Passkey user verification is required.', 403);
            }

            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT p.id AS passkey_id, p.public_key_cose, p.sign_count,
                        u.*
                 FROM passkeys p
                 INNER JOIN users u ON u.id = p.user_id
                 WHERE p.credential_id = ?
                   AND u.disabled_at IS NULL
                 LIMIT 1'
            );
            $stmt->execute([$credentialId]);
            $row = $stmt->fetch();

            if (!$row) {
                fail('That passkey is not registered with SilkNex.', 401);
            }

            try {
                $pem = cose_es256_to_pem(
                    b64url_decode((string)$row['public_key_cose'])
                );
            } catch (Throwable $e) {
                fail('That passkey is not supported.', 401);
            }

            $signedData = $authenticatorData . hash('sha256', $clientJson, true);
            $verified = openssl_verify(
                $signedData,
                $signature,
                $pem,
                OPENSSL_ALGO_SHA256
            );

            if ($verified !== 1) {
                fail('Passkey verification failed.', 401);
            }

            $newCounter = (int)$parsed['counter'];
            $oldCounter = (int)$row['sign_count'];

            if ($newCounter > 0 && $oldCounter > 0 && $newCounter <= $oldCounter) {
                fail('This passkey may have been copied. Use your password and replace it.', 401);
            }

            $now = time();
            $pdo->prepare(
                'UPDATE passkeys
                 SET sign_count = GREATEST(sign_count, ?),
                     last_used_at = ?
                 WHERE id = ?'
            )->execute([$newCounter, $now, (int)$row['passkey_id']]);

            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$row['id'];
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            $_SESSION['last_seen_touch'] = $now;
            $_SESSION['last_activity'] = $now;
            $_SESSION['rotated_at'] = $now;
            $_SESSION['session_version'] = max(1, (int)($row['session_version'] ?? 1));
            $_SESSION['client_fingerprint'] = client_fingerprint();

            $pdo->prepare(
                'UPDATE users SET last_seen_at = ? WHERE id = ?'
            )->execute([$now, (int)$row['id']]);
            $row['last_seen_at'] = $now;

            $persistentLogin = true;
            try {
                issue_remember_token((int)$row['id']);
            } catch (Throwable $e) {
                $persistentLogin = false;
                error_log('[SilkNex remember token] ' . $e->getMessage());
            }

            ok([
                'user' => self_user($row),
                'csrf' => csrf_token(),
                'account_saved' => true,
                'persistent_login' => $persistentLogin,
                'passkey_login' => true
            ]);

        case 'passkey_register_options':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            if (!function_exists('openssl_verify')) {
                fail('Passkeys are not available on this PHP server.', 503);
            }
            $user = current_user();
            $pdo = db();

            $handle = (string)($user['passkey_user_handle'] ?? '');
            if (!preg_match('/^[a-f0-9]{64}$/', $handle)) {
                $handle = bin2hex(random_bytes(32));
                $pdo->prepare(
                    'UPDATE users SET passkey_user_handle = ?, updated_at = ? WHERE id = ?'
                )->execute([$handle, time(), (int)$user['id']]);
            }

            $challenge = b64url_encode(random_bytes(32));
            $_SESSION['webauthn_register_challenge'] = $challenge;
            $_SESSION['webauthn_register_challenge_at'] = time();

            $existing = $pdo->prepare(
                'SELECT credential_id FROM passkeys WHERE user_id = ?'
            );
            $existing->execute([(int)$user['id']]);

            $exclude = [];
            foreach ($existing->fetchAll() as $credential) {
                $exclude[] = [
                    'type' => 'public-key',
                    'id' => (string)$credential['credential_id'],
                ];
            }

            ok([
                'publicKey' => [
                    'challenge' => $challenge,
                    'rp' => [
                        'name' => 'SilkNex',
                        'id' => request_host(),
                    ],
                    'user' => [
                        'id' => b64url_encode(hex2bin($handle)),
                        'name' => (string)$user['username'],
                        'displayName' => (string)$user['display_name'],
                    ],
                    'pubKeyCredParams' => [
                        ['type' => 'public-key', 'alg' => -7],
                    ],
                    'timeout' => 60000,
                    'attestation' => 'none',
                    'authenticatorSelection' => [
                        'residentKey' => 'required',
                        'requireResidentKey' => true,
                        'userVerification' => 'required',
                    ],
                    'excludeCredentials' => $exclude,
                ]
            ]);

        case 'passkey_register_finish':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('passkey_register', 8, 600, (string)$user['id'], 'device');

            $data = body_json();
            $challenge = (string)($_SESSION['webauthn_register_challenge'] ?? '');
            $challengeAt = (int)($_SESSION['webauthn_register_challenge_at'] ?? 0);

            unset($_SESSION['webauthn_register_challenge'], $_SESSION['webauthn_register_challenge_at']);

            if ($challenge === '' || $challengeAt < time() - 300) {
                fail('Passkey challenge expired. Try again.', 400);
            }

            $rawId = b64url_decode((string)($data['rawId'] ?? ''));
            $clientJson = b64url_decode((string)($data['clientDataJSON'] ?? ''));
            $attestationObject = b64url_decode((string)($data['attestationObject'] ?? ''));

            verify_webauthn_client_data(
                $clientJson,
                'webauthn.create',
                $challenge
            );

            try {
                $offset = 0;
                $attestation = cbor_decode_item($attestationObject, $offset);

                if (!is_array($attestation) || !isset($attestation['authData'])) {
                    throw new RuntimeException('Invalid attestation object.');
                }

                $authData = (string)$attestation['authData'];
                $credential = extract_attested_credential($authData);
            } catch (Throwable $e) {
                fail('SilkNex could not read that passkey. Try another passkey.', 400);
            }

            if (!hash_equals(hash('sha256', request_host(), true), (string)$credential['rp_id_hash'])) {
                fail('Passkey website check failed.', 403);
            }

            if (!hash_equals($rawId, (string)$credential['credential_id'])) {
                fail('Passkey credential ID mismatch.', 400);
            }

            $credentialId = b64url_encode($rawId);
            $transports = $data['transports'] ?? [];
            if (!is_array($transports)) $transports = [];
            $transports = array_values(array_filter(
                array_map(
                    static fn($value): string => substr((string)$value, 0, 30),
                    $transports
                )
            ));

            $pdo = db();

            try {
                $pdo->prepare(
                    'INSERT INTO passkeys
                     (user_id, credential_id, public_key_cose, sign_count,
                      transports, created_at, last_used_at)
                     VALUES (?, ?, ?, ?, ?, ?, 0)'
                )->execute([
                    (int)$user['id'],
                    $credentialId,
                    b64url_encode((string)$credential['public_key_cose']),
                    (int)$credential['counter'],
                    implode(',', $transports),
                    time()
                ]);
            } catch (PDOException $e) {
                if ((string)$e->getCode() === '23000') {
                    fail('That passkey is already registered.', 409);
                }
                throw $e;
            }

            ok(['registered' => true], 201);

        case 'passkeys':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT id, created_at, last_used_at, transports
                 FROM passkeys
                 WHERE user_id = ?
                 ORDER BY created_at DESC'
            );
            $stmt->execute([(int)$user['id']]);

            $items = [];
            foreach ($stmt->fetchAll() as $row) {
                $items[] = [
                    'id' => (int)$row['id'],
                    'created_at' => (int)$row['created_at'],
                    'last_used_at' => (int)$row['last_used_at'],
                    'transports' => array_values(array_filter(
                        explode(',', (string)$row['transports'])
                    )),
                ];
            }

            ok(['passkeys' => $items]);

        case 'passkey_remove':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $passkeyId = (int)($data['passkey_id'] ?? 0);

            $pdo = db();
            $pdo->prepare(
                'DELETE FROM passkeys WHERE id = ? AND user_id = ?'
            )->execute([$passkeyId, (int)$user['id']]);

            ok();

        case 'logout':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            try {
                db()->prepare('UPDATE users SET online_until = 0 WHERE id = ?')
                    ->execute([(int)$user['id']]);
            } catch (Throwable $e) {
                error_log('[SilkNex presence logout] ' . $e->getMessage());
            }
            revoke_current_remember_token();
            destroy_login_session();
            ok();

        case 'me':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $csrf = csrf_token();
            release_session_lock();
            ok([
                'user' => self_user($user),
                'csrf' => $csrf,
                'account_saved' => true,
                'account_storage' => 'mysql'
            ]);

        case 'giphy_config':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            current_user();
            release_session_lock();
            $cfg = config();
            $key = trim((string)($cfg['giphy_sdk_key'] ?? ''));
            $enabled = $key !== '' && !str_starts_with($key, 'YOUR_');
            ok([
                'enabled' => $enabled,
                'sdk_key' => $enabled ? $key : '',
                'sdk' => '@giphy/js-fetch-api',
                'sdk_version' => '5.8.0'
            ]);


        case 'push_public_key':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            current_user();
            release_session_lock();

            if (
                !function_exists('curl_init') ||
                !function_exists('openssl_pkey_derive')
            ) {
                fail('Web Push is not available on this PHP server.', 503);
            }

            try {
                $vapid = vapid_key_material();
                ok(['public_key' => (string)$vapid['public']]);
            } catch (Throwable $e) {
                error_log('[SilkNex push setup] ' . $e->getMessage());
                fail('Web Push is not available on this PHP server.', 503);
            }

        case 'push_subscribe':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit(
                'push_subscribe',
                20,
                600,
                (string)$user['id'],
                'device',
                'Too many notification-device changes. Try again shortly.'
            );
            $data = body_json();

            $endpoint = trim((string)($data['endpoint'] ?? ''));
            $p256dh = trim((string)($data['p256dh'] ?? ''));
            $auth = trim((string)($data['auth'] ?? ''));
            $iconStyle = strtolower(trim((string)($data['icon_style'] ?? 'dark')));
            if (!in_array($iconStyle, ['dark','light'], true)) {
                $iconStyle = 'dark';
            }

            if (
                $endpoint === '' ||
                strlen($endpoint) > 4096 ||
                filter_var($endpoint, FILTER_VALIDATE_URL) === false ||
                !str_starts_with(strtolower($endpoint), 'https://')
            ) {
                fail('Invalid Push subscription.');
            }

            try {
                safe_push_target($endpoint);
            } catch (Throwable $e) {
                fail('That browser Push endpoint is not safe or reachable.', 400);
            }

            try {
                $publicBytes = b64url_decode_raw($p256dh);
                $authBytes = b64url_decode_raw($auth);
            } catch (Throwable $e) {
                fail('Invalid Push subscription.');
            }

            if (
                strlen($publicBytes) !== 65 ||
                strlen($authBytes) < 16 ||
                strlen($authBytes) > 64 ||
                strlen($p256dh) > 255 ||
                strlen($auth) > 255
            ) {
                fail('Invalid Push subscription.');
            }

            $pdo = db();
            $now = time();
            $endpointHash = hash('sha256', $endpoint);
            $userAgent = substr(
                (string)($_SERVER['HTTP_USER_AGENT'] ?? ''),
                0,
                255
            );

            $pdo->prepare(
                'INSERT INTO push_subscriptions
                 (user_id, endpoint_hash, endpoint, p256dh, auth,
                  user_agent, icon_style, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                   user_id = VALUES(user_id),
                   endpoint = VALUES(endpoint),
                   p256dh = VALUES(p256dh),
                   auth = VALUES(auth),
                   user_agent = VALUES(user_agent),
                   icon_style = VALUES(icon_style),
                   updated_at = VALUES(updated_at),
                   fail_count = 0'
            )->execute([
                (int)$user['id'],
                $endpointHash,
                $endpoint,
                $p256dh,
                $auth,
                $userAgent,
                $iconStyle,
                $now,
                $now
            ]);

            ok(['subscribed' => true]);

        case 'push_unsubscribe':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();

            $endpoint = trim((string)($data['endpoint'] ?? ''));
            $pdo = db();

            if ($endpoint !== '') {
                $pdo->prepare(
                    'DELETE FROM push_subscriptions
                     WHERE user_id = ? AND endpoint_hash = ?'
                )->execute([
                    (int)$user['id'],
                    hash('sha256', $endpoint)
                ]);
            } else {
                $pdo->prepare(
                    'DELETE FROM push_subscriptions WHERE user_id = ?'
                )->execute([(int)$user['id']]);
            }

            ok(['subscribed' => false]);

        case 'push_flush':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            release_session_lock();
            $pdo = db();

            $processed = process_push_jobs(
                $pdo,
                (int)$user['id'],
                8
            );

            ok(['processed' => $processed]);

        case 'notification_icon':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            current_user();
            release_session_lock();

            $token = strtolower(trim((string)($_GET['token'] ?? '')));
            if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
                fail('Media not found.', 404);
            }

            $pdo = db();
            $stmt = $pdo->prepare(
                "SELECT token
                 FROM uploads
                 WHERE token = ? AND purpose = 'avatar'
                 LIMIT 1"
            );
            $stmt->execute([$token]);
            if (!$stmt->fetchColumn()) {
                fail('Media not found.', 404);
            }

            $expiresAt = time() + 21600;
            ok([
                'url' => notification_media_url(media_store_reference($token), $expiresAt),
                'expires_at' => $expiresAt,
            ]);

        case 'notification_media':
            if ($method !== 'GET' && $method !== 'HEAD') {
                fail('Method not allowed.', 405);
            }

            $token = strtolower(trim((string)($_GET['token'] ?? '')));
            $expiresAt = (int)($_GET['exp'] ?? 0);
            $signature = strtolower(trim((string)($_GET['sig'] ?? '')));

            if (!valid_notification_media_signature($token, $expiresAt, $signature)) {
                fail('Media not found.', 404);
            }

            $pdo = db();
            $stmt = $pdo->prepare(
                "SELECT file_url, mime_type, original_name, file_size
                 FROM uploads
                 WHERE token = ? AND purpose = 'avatar'
                 LIMIT 1"
            );
            $stmt->execute([$token]);
            $upload = $stmt->fetch();

            if (!$upload || !str_starts_with((string)$upload['mime_type'], 'image/')) {
                fail('Media not found.', 404);
            }

            $relativePath = (string)$upload['file_url'];
            if (!str_starts_with($relativePath, 'uploads/')) {
                fail('Media not found.', 404);
            }

            $path = resolve_upload_storage_path($relativePath);
            if ($path === null || !is_file($path)) {
                fail('Media not found.', 404);
            }

            $mime = (string)$upload['mime_type'];
            $name = (string)$upload['original_name'];

            if ($method === 'HEAD') {
                header_remove('Content-Type');
                header('Content-Type: ' . $mime);
                header('Content-Length: ' . (int)$upload['file_size']);
                header('Cache-Control: private, no-store');
                http_response_code(200);
                exit;
            }

            if (str_ends_with($relativePath, '.nenc')) {
                stream_encrypted_media($path, $mime, $name, false);
            }

            stream_plain_media($path, $mime, $name);

        case 'media':
            if ($method !== 'GET' && $method !== 'HEAD') {
                fail('Method not allowed.', 405);
            }

            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $token = strtolower(trim((string)($_GET['token'] ?? '')));

            if (!preg_match('/^[a-f0-9]{48}$/', $token)) {
                fail('Media not found.', 404);
            }

            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT id, user_id, purpose, file_url, mime_type,
                        original_name, file_size, used_at
                 FROM uploads
                 WHERE token = ?
                 LIMIT 1'
            );
            $stmt->execute([$token]);
            $upload = $stmt->fetch();

            if (!$upload) {
                fail('Media not found.', 404);
            }

            $allowed = (int)$upload['user_id'] === $userId;

            if (!$allowed && in_array((string)$upload['purpose'], ['avatar', 'wallpaper', 'banner'], true)) {
                // Opaque 192-bit media tokens are exposed only to authenticated
                // clients that already received them through SilkNex data.
                $allowed = true;
            }

            if (!$allowed && (string)$upload['purpose'] === 'ad') {
                $campaignAccess = $pdo->prepare(
                    "SELECT 1
                     FROM ad_campaigns
                     WHERE upload_token = ?
                       AND status = 'active'
                       AND starts_at IS NOT NULL
                       AND ends_at IS NOT NULL
                       AND starts_at <= ?
                       AND ends_at > ?
                     LIMIT 1"
                );
                $campaignAccess->execute([$token, time(), time()]);
                $allowed = (bool)$campaignAccess->fetchColumn();
            }

            if (!$allowed && (string)$upload['purpose'] === 'story') {
                $storyAccess = $pdo->prepare(
                    'SELECT s.id
                     FROM stories s
                     WHERE s.media_token = ?
                       AND s.deleted_at IS NULL
                       AND s.expires_at > ?
                     ORDER BY s.id DESC
                     LIMIT 1'
                );
                $storyAccess->execute([$token, time()]);
                $storyId = (int)($storyAccess->fetchColumn() ?: 0);
                $allowed = $storyId > 0 && story_is_visible_to($pdo, $storyId, $userId);
            }

            if (!$allowed && (string)$upload['purpose'] === 'sticker') {
                $savedAccess = $pdo->prepare(
                    'SELECT 1 FROM saved_stickers
                     WHERE user_id = ? AND upload_token = ?
                     LIMIT 1'
                );
                $savedAccess->execute([$userId, $token]);
                $allowed = (bool)$savedAccess->fetchColumn();
            }

            if (!$allowed && in_array((string)$upload['purpose'], ['message', 'message_e2ee', 'sticker'], true)) {
                $access = $pdo->prepare(
                    'SELECT 1
                     FROM messages m
                     INNER JOIN conversation_members cm
                       ON cm.conversation_id = m.conversation_id
                      AND cm.user_id = ?
                     WHERE m.attachment_token = ?
                       AND m.id > cm.cleared_before_message_id
                       AND m.deleted_at IS NULL
                       AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                     LIMIT 1'
                );
                $access->execute([$userId, $token]);
                $allowed = (bool)$access->fetchColumn();
            }

            if (!$allowed) {
                fail('Media not found.', 404);
            }

            $relativePath = (string)$upload['file_url'];

            if (!str_starts_with($relativePath, 'uploads/')) {
                fail('Media not found.', 404);
            }

            $path = resolve_upload_storage_path($relativePath);

            if ($path === null || !is_file($path)) {
                fail('Media file is unavailable.', 404);
            }

            $mime = (string)$upload['mime_type'];
            $name = (string)$upload['original_name'];

            if ($method === 'HEAD') {
                $size = (int)$upload['file_size'];
                header_remove('Content-Type');
                header('Content-Type: ' . $mime);
                header('Content-Length: ' . $size);
                header('Accept-Ranges: bytes');
                header('Cache-Control: private, no-store');
                http_response_code(200);
                exit;
            }

            if (str_ends_with($relativePath, '.nenc')) {
                stream_encrypted_media($path, $mime, $name);
            }

            // Compatibility for a partially upgraded installation.
            stream_plain_media($path, $mime, $name);

        case 'upload':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            if (
                !is_founder_user($user) &&
                app_meta_value(db(), 'owner_uploads_paused_v1') === '1'
            ) {
                fail('Media uploads are temporarily paused for maintenance. Text messaging still works.', 503);
            }
            rate_limit(
                'upload_device',
                40,
                600,
                (string)$user['id'],
                'device',
                'Too many uploads from this browser. Wait a few minutes and try again.'
            );
            rate_limit(
                'upload_network',
                300,
                600,
                '',
                'ip',
                'This network is sending too many uploads. Wait a few minutes and try again.'
            );
            // File validation/encryption can be comparatively expensive. Persist the
            // already-updated rate-limit/session state and let this user's message,
            // call and sync requests run concurrently while the upload is processed.
            release_session_lock();

            $purpose = strtolower(trim((string)($_POST['purpose'] ?? 'message')));
            if (!in_array($purpose, ['message','message_e2ee','avatar','wallpaper','banner','story','sticker','ad'], true)) {
                fail('Invalid upload purpose.');
            }

            if (!isset($_FILES['file']) || !is_array($_FILES['file'])) {
                fail('Choose a file to upload.');
            }

            $file = $_FILES['file'];
            $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);

            if ($error !== UPLOAD_ERR_OK) {
                $message = match ($error) {
                    UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'That file is larger than this server allows.',
                    UPLOAD_ERR_PARTIAL => 'The upload was interrupted. Try again.',
                    UPLOAD_ERR_NO_FILE => 'Choose a file to upload.',
                    default => 'The upload failed. Try again.',
                };
                fail($message, 400);
            }

            $tmp = (string)($file['tmp_name'] ?? '');
            $size = (int)($file['size'] ?? 0);

            if ($tmp === '' || !is_uploaded_file($tmp) || $size <= 0) {
                fail('Invalid upload.');
            }

            $mediaHint = strtolower(trim((string)($_POST['media_hint'] ?? '')));
            if ($purpose === 'message_e2ee') {
                $allowedEncryptedTypes = ['image','gif','video','audio','video_note'];
                if (!in_array($mediaHint, $allowedEncryptedTypes, true)) {
                    fail('Invalid encrypted attachment type.');
                }
                $mime = 'application/octet-stream';
                // Client E2EE v2 encrypts large media in 256-512 KiB AES-GCM
                // chunks. Every chunk carries a 16-byte authentication tag, so a
                // fixed +64 byte allowance rejects otherwise-valid files near the
                // normal media limit. Bound the allowance to the worst supported
                // 256 KiB chunk size plus a small format/header margin.
                $encryptedLimit = static function (int $plaintextMax): int {
                    $tagBytes = (int)ceil($plaintextMax / (256 * 1024)) * 16;
                    return $plaintextMax + max(8192, $tagBytes + 1024);
                };
                $maxByType = [
                    'image' => $encryptedLimit(MAX_IMAGE_UPLOAD),
                    'gif' => $encryptedLimit(MAX_IMAGE_UPLOAD),
                    'video' => $encryptedLimit(MAX_VIDEO_UPLOAD),
                    'audio' => $encryptedLimit(MAX_AUDIO_UPLOAD),
                    'video_note' => $encryptedLimit(min(MAX_VIDEO_UPLOAD, 24 * 1024 * 1024)),
                ];
                $info = ['type' => $mediaHint, 'max' => $maxByType[$mediaHint]];
            } else {
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = strtolower((string)$finfo->file($tmp));
                $info = upload_mime_info($mime);

                // Some shared-host libmagic builds identify iPhone HEIC/MOV media
                // only as application/octet-stream. Verify the ISO-BMFF container
                // signature before applying a narrow fallback so mobile Stories do
                // not depend on the host's MIME database version.
                if ($info === null) {
                    $containerMime = fallback_iso_bmff_mime($tmp);
                    if ($containerMime !== null) {
                        $mime = $containerMime;
                        $info = upload_mime_info($mime);
                    }
                }

                if ($info === null) {
                    fail('That file type is not supported.');
                }
            }

            if (
                $purpose === 'message' &&
                $mediaHint === 'audio' &&
                in_array($mime, ['video/webm', 'video/mp4', 'audio/webm', 'audio/mp4'], true)
            ) {
                $info['type'] = 'audio';
                $info['max'] = MAX_AUDIO_UPLOAD;
            }

            if (
                $purpose === 'message' &&
                $mediaHint === 'video_note' &&
                in_array($mime, ['video/webm', 'video/mp4', 'video/quicktime'], true)
            ) {
                $info['type'] = 'video_note';
                $info['max'] = min(MAX_VIDEO_UPLOAD, 24 * 1024 * 1024);
            }

            if (
                $purpose === 'sticker' &&
                in_array($mime, ['image/png','image/jpeg','image/webp'], true)
            ) {
                $info['type'] = 'sticker';
                $info['max'] = min(MAX_IMAGE_UPLOAD, 6 * 1024 * 1024);
            }

            if (in_array($purpose, ['avatar','wallpaper','banner'], true) &&
                !in_array($info['type'], ['image','gif'], true)) {
                fail('Profile photos, banners, and wallpapers must be images or GIFs.');
            }

            if ($purpose === 'story' &&
                !in_array($info['type'], ['image','gif','video'], true)) {
                fail('Stories must be a photo, GIF, or video.');
            }

            if ($purpose === 'sticker' && $info['type'] !== 'sticker') {
                fail('Stickers must be PNG, JPEG, or WebP images.');
            }

            if (
                $purpose === 'ad' &&
                (!in_array($mime, ['image/png','image/jpeg','image/webp'], true) || $info['type'] !== 'image')
            ) {
                fail('Ad creative must be a PNG, JPEG, or WebP image.');
            }

            $max = (int)$info['max'];
            if (in_array($purpose, ['avatar', 'wallpaper', 'banner'], true)) {
                $max = min($max, 8 * 1024 * 1024);
            } elseif ($purpose === 'sticker') {
                $max = min($max, 6 * 1024 * 1024);
            } elseif ($purpose === 'story') {
                $max = min($max, 24 * 1024 * 1024);
            } elseif ($purpose === 'ad') {
                $max = min($max, 5 * 1024 * 1024);
            }

            if ($size > $max) {
                fail('That file is too large.');
            }

            if ($purpose !== 'message_e2ee') {
                validate_raster_image_dimensions($tmp, $mime, $purpose);
            }

            // Prove database availability before writing encrypted bytes so a
            // transient DB/schema failure cannot strand an untracked file.
            $pdo = db();
            [$dir, $webFolder] = ensure_upload_directory();
            [$target, $fileName] = encrypted_media_path($dir);

            try {
                encrypt_media_file($tmp, $target);
            } catch (Throwable $e) {
                error_log('[SilkNex upload encryption] ' . $e->getMessage());
                fail('SilkNex could not encrypt the upload.', 500);
            }

            $url = $webFolder . '/' . $fileName;
            $token = bin2hex(random_bytes(24));
            $originalName = safe_original_name((string)($purpose === 'message_e2ee' ? ($_POST['original_name'] ?? 'encrypted-attachment') : ($file['name'] ?? 'file')));

            $stickerId = null;
            $pdo->beginTransaction();

            try {
                $pdo->prepare(
                    'INSERT INTO uploads
                     (user_id, token, purpose, media_type, file_url, mime_type,
                      original_name, file_size, created_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
                )->execute([
                    (int)$user['id'],
                    $token,
                    $purpose,
                    (string)$info['type'],
                    $url,
                    $mime,
                    $originalName,
                    $size,
                    time()
                ]);

                if ($purpose === 'sticker') {
                    $pdo->prepare(
                        'INSERT INTO saved_stickers (user_id, upload_token, created_at)
                         VALUES (?, ?, ?)
                         ON DUPLICATE KEY UPDATE created_at = VALUES(created_at)'
                    )->execute([(int)$user['id'], $token, time()]);

                    $stickerId = (int)$pdo->lastInsertId();
                    if ($stickerId <= 0) {
                        $stickerStmt = $pdo->prepare(
                            'SELECT id FROM saved_stickers WHERE user_id = ? AND upload_token = ? LIMIT 1'
                        );
                        $stickerStmt->execute([(int)$user['id'], $token]);
                        $stickerId = (int)$stickerStmt->fetchColumn();
                    }
                }

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                @unlink($target);
                throw $e;
            }

            if (random_int(1, 40) === 1) {
                cleanup_stale_uploads($pdo);
            }

            ok([
                'token' => $token,
                'url' => media_reference_url(media_store_reference($token)),
                'media_type' => (string)$info['type'],
                'mime' => $mime,
                'name' => $originalName,
                'size' => $size,
                'sticker_id' => $stickerId,
                'encrypted' => true
            ], 201);

        case 'stickers':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT ss.id, ss.upload_token, ss.created_at,
                        u.user_id AS source_user_id,
                        u.mime_type, u.original_name, u.file_size
                 FROM saved_stickers ss
                 INNER JOIN uploads u
                   ON u.token = ss.upload_token
                  AND u.purpose = \'sticker\'
                 WHERE ss.user_id = ?
                 ORDER BY ss.created_at DESC, ss.id DESC
                 LIMIT 120'
            );
            $stmt->execute([(int)$user['id']]);
            $items = array_map(
                static fn(array $row): array => [
                    'id' => (int)$row['id'],
                    'token' => (string)$row['upload_token'],
                    'url' => media_reference_url(
                        media_store_reference((string)$row['upload_token'])
                    ),
                    'mime' => (string)$row['mime_type'],
                    'name' => (string)$row['original_name'],
                    'size' => (int)$row['file_size'],
                    'source_user_id' => (int)$row['source_user_id'],
                    'created_at' => (int)$row['created_at'],
                ],
                $stmt->fetchAll()
            );
            ok(['stickers' => $items]);

        case 'sticker_save_message':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $messageId = max(0, (int)($data['message_id'] ?? 0));
            if ($messageId <= 0) fail('Invalid sticker message.');
            $userId = (int)$user['id'];
            release_session_lock();
            $pdo = db();

            $stmt = $pdo->prepare(
                "SELECT m.attachment_token
                 FROM messages m
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = m.conversation_id
                  AND cm.user_id = ?
                 INNER JOIN uploads u
                   ON u.token = m.attachment_token
                  AND u.purpose = 'sticker'
                 WHERE m.id = ?
                   AND m.message_type = 'sticker'
                   AND m.attachment_token IS NOT NULL
                   AND m.id > cm.cleared_before_message_id
                   AND m.deleted_at IS NULL
                   AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                 LIMIT 1"
            );
            $stmt->execute([$userId, $messageId]);
            $token = (string)($stmt->fetchColumn() ?: '');
            if ($token === '') fail('That sticker is no longer available.', 404);

            $pdo->prepare(
                'INSERT IGNORE INTO saved_stickers (user_id, upload_token, created_at)
                 VALUES (?, ?, ?)'
            )->execute([$userId, $token, time()]);

            $idStmt = $pdo->prepare(
                'SELECT id FROM saved_stickers
                 WHERE user_id = ? AND upload_token = ?
                 LIMIT 1'
            );
            $idStmt->execute([$userId, $token]);
            $savedId = (int)($idStmt->fetchColumn() ?: 0);

            ok(['saved' => true, 'sticker_id' => $savedId]);

        case 'sticker_delete':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $stickerId = max(0, (int)($data['sticker_id'] ?? 0));
            if ($stickerId <= 0) fail('Invalid sticker.');

            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT upload_token
                 FROM saved_stickers
                 WHERE id = ? AND user_id = ?
                 LIMIT 1'
            );
            $stmt->execute([$stickerId, (int)$user['id']]);
            $token = (string)($stmt->fetchColumn() ?: '');
            if ($token === '') fail('Sticker not found.', 404);

            $pdo->prepare(
                'DELETE FROM saved_stickers WHERE id = ? AND user_id = ?'
            )->execute([$stickerId, (int)$user['id']]);

            delete_upload_if_unreferenced($pdo, $token, (int)$user['id']);
            ok();


        case 'public_profile':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $viewer = current_user();
            $viewerId = (int)$viewer['id'];
            $username = strtolower(trim((string)($_GET['username'] ?? '')));
            if (!preg_match('/^[a-z0-9_.]{3,24}$/', $username)) {
                fail('Profile not found.', 404);
            }
            release_session_lock();
            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT id, username, display_name, about, accent, avatar_url, avatar_style,
                        profile_banner_url, public_profile, kid_mode, last_seen_at, account_role
                 FROM users
                 WHERE username = ? AND disabled_at IS NULL
                 LIMIT 1'
            );
            $stmt->execute([$username]);
            $profile = $stmt->fetch();
            if (!$profile) fail('Profile not found.', 404);

            $profileId = (int)$profile['id'];
            if (!empty($viewer['kid_mode']) && empty($profile['kid_mode'])) {
                fail('Kid accounts can open only other kid profiles.', 403);
            }
            $friendship = $profileId === $viewerId
                ? null
                : friendship_between($pdo, $viewerId, $profileId);
            $friendState = $profileId === $viewerId
                ? ['status' => 'self', 'request_id' => 0]
                : friendship_for_viewer($friendship, $viewerId);

            if (
                $profileId !== $viewerId &&
                !(bool)$profile['public_profile'] &&
                (string)$friendState['status'] !== 'accepted'
            ) {
                fail('Profile not found.', 404);
            }

            $storiesStmt = $pdo->prepare(
                'SELECT s.id, s.user_id, s.media_token, s.media_type, s.caption,
                        s.visibility, s.audience_json, s.created_at, s.expires_at,
                        u.username, u.display_name, u.accent, u.avatar_url, u.avatar_style, u.account_role,
                        NULL AS viewed_at, 0 AS view_count,
                        CASE WHEN s.user_id = ? THEN 1 ELSE 0 END AS mine
                 FROM stories s
                 INNER JOIN users u ON u.id = s.user_id
                 WHERE s.user_id = ?
                   AND s.deleted_at IS NULL
                   AND s.expires_at > ?
                 ORDER BY s.created_at DESC, s.id DESC
                 LIMIT 40'
            );
            $storiesStmt->execute([$viewerId, $profileId, time()]);
            $isFriend = $profileId === $viewerId || (string)$friendState['status'] === 'accepted';
            $visibleStories = [];
            foreach ($storiesStmt->fetchAll() as $storyRow) {
                if (!story_row_visible_to($storyRow, $viewerId, $isFriend)) continue;
                $storyRow['caption'] = censor_for_kid((string)($storyRow['caption'] ?? ''), $viewer);
                $visibleStories[] = story_item($storyRow);
            }

            $mutualFriends = [];
            if ($profileId !== $viewerId) {
                $mutualStmt = $pdo->prepare(
                    'SELECT DISTINCT u.id, u.username, u.display_name, u.about, u.accent, u.avatar_url,
                            u.avatar_style, u.last_seen_at, u.account_role
                     FROM users u
                     INNER JOIN friendships vf
                       ON vf.status = \'accepted\'
                      AND ((vf.requester_id = ? AND vf.addressee_id = u.id)
                        OR (vf.addressee_id = ? AND vf.requester_id = u.id))
                     INNER JOIN friendships pf
                       ON pf.status = \'accepted\'
                      AND ((pf.requester_id = ? AND pf.addressee_id = u.id)
                        OR (pf.addressee_id = ? AND pf.requester_id = u.id))
                     WHERE u.disabled_at IS NULL
                       AND u.id NOT IN (?, ?)
                     ORDER BY u.display_name ASC, u.username ASC
                     LIMIT 24'
                );
                $mutualStmt->execute([
                    $viewerId, $viewerId,
                    $profileId, $profileId,
                    $viewerId, $profileId,
                ]);
                $mutualFriends = array_map(
                    static fn(array $row): array => public_user($row),
                    $mutualStmt->fetchAll()
                );
            }

            $friendCountStmt = $pdo->prepare(
                'SELECT COUNT(*)
                 FROM friendships
                 WHERE status = \'accepted\'
                   AND (requester_id = ? OR addressee_id = ?)'
            );
            $friendCountStmt->execute([$profileId, $profileId]);
            $friendCount = (int)$friendCountStmt->fetchColumn();

            $postsStmt = $pdo->prepare(
                'SELECT id, media_token, media_type, body, created_at
                 FROM profile_posts WHERE user_id=? ORDER BY id DESC LIMIT 60'
            );
            $postsStmt->execute([$profileId]);
            $posts = [];
            foreach ($postsStmt->fetchAll() as $post) {
                $posts[] = [
                    'id' => (int)$post['id'],
                    'media_type' => (string)$post['media_type'],
                    'media_url' => $post['media_token'] ? media_reference_url(media_store_reference((string)$post['media_token'])) : '',
                    'body' => censor_for_kid(decrypted_message_value((string)$post['body']), $viewer),
                    'created_at' => (int)$post['created_at'],
                ];
            }

            ok([
                'profile' => public_user($profile),
                'friendship' => $friendState,
                'mutual_friends' => $mutualFriends,
                'stories' => $visibleStories,
                'posts' => $posts,
                'friend_count' => $friendCount,
            ]);

        case 'profile_post_create':
            if ($method !== 'POST') fail('Method not allowed.',405);
            $user = current_user();
            require_csrf();
            if (app_meta_value(db(),'owner_posting_paused_v1') === '1') fail('Profile posting is temporarily paused.',503);
            rate_limit('profile_post_create',20,3600,(string)$user['id'],'subject');
            $data = body_json();
            $body = clean($data['body'] ?? '', 2000);
            $token = strtolower(trim((string)($data['upload_token'] ?? '')));
            if ($body === '' && $token === '') fail('Add text, an image, or a video.');
            $pdo = db();
            $mediaType = 'text';
            if ($token !== '') {
                $upload = get_owned_upload($pdo,(int)$user['id'],$token,'story');
                if (!$upload || $upload['used_at'] !== null ||
                    !in_array((string)$upload['media_type'],['image','gif','video'],true)) {
                    fail('Upload an image or video for this post.');
                }
                $mediaType = (string)$upload['media_type'];
            }
            $now = time();
            $pdo->beginTransaction();
            try {
                $pdo->prepare('INSERT INTO profile_posts(user_id,media_token,media_type,body,created_at) VALUES(?,?,?,?,?)')
                    ->execute([(int)$user['id'],$token ?: null,$mediaType,encrypted_message_value($body),$now]);
                $id = (int)$pdo->lastInsertId();
                if ($token !== '') $pdo->prepare('UPDATE uploads SET used_at=? WHERE token=? AND user_id=?')
                    ->execute([$now,$token,(int)$user['id']]);
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            ok(['id'=>$id],201);

        case 'profile_post_delete':
            if ($method !== 'POST') fail('Method not allowed.',405);
            $user = current_user();
            require_csrf();
            $id = (int)(body_json()['id'] ?? 0);
            $pdo = db();
            $stmt = $pdo->prepare('SELECT media_token FROM profile_posts WHERE id=? AND user_id=?');
            $stmt->execute([$id,(int)$user['id']]);
            $token = $stmt->fetchColumn();
            if ($token === false) fail('Post not found.',404);
            $pdo->prepare('DELETE FROM profile_posts WHERE id=? AND user_id=?')->execute([$id,(int)$user['id']]);
            if ($token) delete_upload_if_unreferenced($pdo,(string)$token,(int)$user['id']);
            ok(['deleted'=>true]);

        case 'public_profile_settings':
            $user = current_user();
            $pdo = db();

            if ($method === 'GET') {
                ok([
                    'public_profile' => (bool)($user['public_profile'] ?? true),
                    'profile_banner_url' => media_reference_url((string)($user['profile_banner_url'] ?? '')),
                ]);
            }

            if ($method !== 'POST') fail('Method not allowed.', 405);
            require_csrf();
            $data = body_json();
            $public = array_key_exists('public_profile', $data)
                ? (bool)$data['public_profile']
                : (bool)($user['public_profile'] ?? true);
            $previousBanner = (string)($user['profile_banner_url'] ?? '');
            $bannerUrl = $previousBanner;

            if (!empty($data['remove_banner'])) {
                $bannerUrl = '';
            }

            $bannerToken = strtolower(trim((string)($data['banner_token'] ?? '')));
            if ($bannerToken !== '') {
                $upload = get_owned_upload($pdo, (int)$user['id'], $bannerToken, 'banner');
                if (!$upload || !in_array((string)$upload['media_type'], ['image','gif'], true)) {
                    fail('That profile banner is no longer available.');
                }
                $bannerUrl = media_store_reference($bannerToken);
                $pdo->prepare('UPDATE uploads SET used_at = ? WHERE id = ?')
                    ->execute([time(), (int)$upload['id']]);
            }

            $pdo->prepare(
                'UPDATE users
                 SET public_profile = ?, profile_banner_url = ?, updated_at = ?
                 WHERE id = ?'
            )->execute([$public ? 1 : 0, $bannerUrl, time(), (int)$user['id']]);

            if ($previousBanner !== $bannerUrl) {
                $oldToken = media_token_from_reference($previousBanner);
                if ($oldToken !== null) {
                    delete_upload_if_unreferenced($pdo, $oldToken, (int)$user['id']);
                }
            }

            ok([
                'public_profile' => $public,
                'profile_banner_url' => media_reference_url($bannerUrl),
            ]);

        case 'username_change':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            session_rate_limit('username_change', 6, 3600);
            if (is_founder_user($user)) fail('Staff handles cannot be changed here.', 403);
            $input = body_json();
            $newUsername = strtolower(clean($input['username'] ?? '', MAX_USERNAME));
            if (!valid_username($newUsername) ||
                strcasecmp($newUsername, FOUNDER_USERNAME) === 0 ||
                strcasecmp($newUsername, COFOUNDER_USERNAME) === 0) {
                fail('Choose a valid available username.');
            }
            $pdo = db();
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare('SELECT username, username_changed_at FROM users WHERE id=? FOR UPDATE');
                $stmt->execute([(int)$user['id']]);
                $previous = $stmt->fetch();
                if (!$previous) { $pdo->rollBack(); fail('Account not found.',404); }
                $now = time();
                $last = (int)($previous['username_changed_at'] ?? 0);
                if ($last > $now - 7 * 86400) {
                    $pdo->rollBack();
                    fail('You can change your username again after ' . gmdate('M j, Y', $last + 7 * 86400) . '.', 429);
                }
                if (strcasecmp((string)$previous['username'], $newUsername) === 0) {
                    $pdo->rollBack(); fail('Choose a different username.');
                }
                $pdo->prepare('UPDATE users SET username=?,username_changed_at=?,updated_at=? WHERE id=?')
                    ->execute([$newUsername,$now,$now,(int)$user['id']]);
                $pdo->commit();
                ok(['username'=>$newUsername,'username_changed_at'=>$now]);
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                if ((string)$e->getCode() === '23000') fail('That username is already taken.',409);
                throw $e;
            }

        case 'profile':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();

            $name = clean($data['display_name'] ?? '', MAX_DISPLAY_NAME);
            $about = clean($data['about'] ?? '', MAX_ABOUT);
            $accent = clean($data['accent'] ?? 'silver', 16);
            $allowed = ['silver', 'steel', 'graphite', 'frost', 'smoke'];

            if ($name === '') fail('Display name cannot be empty.');
            if (!in_array($accent, $allowed, true)) fail('Invalid accent.');

            $pdo = db();
            $avatarUrl = (string)($user['avatar_url'] ?? '');
            $avatarStyleJson = avatar_style_json($user['avatar_style'] ?? null);
            $previousAvatarUrl = $avatarUrl;

            if (!empty($data['remove_avatar'])) {
                $avatarUrl = '';
            }

            if (array_key_exists('avatar_style', $data)) {
                $avatarStyleJson = avatar_style_json($data['avatar_style']);
                if ($avatarStyleJson !== null) {
                    $avatarUrl = '';
                }
            }

            $avatarToken = strtolower(trim((string)($data['avatar_token'] ?? '')));
            if ($avatarToken !== '') {
                $upload = get_owned_upload($pdo, (int)$user['id'], $avatarToken, 'avatar');
                if (!$upload || !in_array((string)$upload['media_type'], ['image','gif'], true)) {
                    fail('That profile photo is no longer available.');
                }
                $avatarUrl = media_store_reference($avatarToken);
                $avatarStyleJson = null;
                $pdo->prepare('UPDATE uploads SET used_at = ? WHERE id = ?')
                    ->execute([time(), (int)$upload['id']]);
            }

            $pdo->prepare(
                'UPDATE users
                 SET display_name = ?, about = ?, accent = ?, avatar_url = ?,
                     avatar_style = ?, updated_at = ?
                 WHERE id = ?'
            )->execute([
                $name, $about, $accent, $avatarUrl, $avatarStyleJson,
                time(), (int)$user['id']
            ]);

            if ($previousAvatarUrl !== $avatarUrl) {
                $oldToken = media_token_from_reference($previousAvatarUrl);
                if ($oldToken !== null) {
                    delete_upload_if_unreferenced(
                        $pdo,
                        $oldToken,
                        (int)$user['id']
                    );
                }
            }

            $stmt = $pdo->prepare(
                'SELECT id, username, display_name, about, accent, avatar_url, avatar_style,
                        profile_banner_url, public_profile,
                        theme, app_icon_style, wallpaper, wallpaper_url, font_scale, font_family, ui_accent,
                bubble_style, message_density, chat_width, reduce_motion, easy_mode,
                notifications_enabled,
                        kid_mode, last_seen_at
                 FROM users WHERE id = ?'
            );
            $stmt->execute([(int)$user['id']]);
            ok(['user' => self_user($stmt->fetch())]);

        case 'preferences':
            $user = current_user();
            $pdo = db();

            if ($method === 'GET') {
                ok(['preferences' => [
                    'theme' => (string)($user['theme'] ?? 'dark'),
                    'app_icon_style' => (string)($user['app_icon_style'] ?? 'auto'),
                    'wallpaper' => (string)($user['wallpaper'] ?? 'neo'),
                    'wallpaper_url' => media_reference_url(
                        (string)($user['wallpaper_url'] ?? '')
                    ),
                    'font_scale' => (string)($user['font_scale'] ?? 'normal'),
                    'font_family' => (string)($user['font_family'] ?? 'system'),
                    'ui_accent' => (string)($user['ui_accent'] ?? 'silver'),
                    'bubble_style' => (string)($user['bubble_style'] ?? 'rounded'),
                    'message_density' => (string)($user['message_density'] ?? 'normal'),
                    'chat_width' => (string)($user['chat_width'] ?? 'normal'),
                    'reduce_motion' => (bool)($user['reduce_motion'] ?? false),
                    'easy_mode' => (bool)($user['easy_mode'] ?? false),
                    'notifications_enabled' => (bool)($user['notifications_enabled'] ?? false),
                ]]);
            }

            if ($method !== 'POST') fail('Method not allowed.', 405);
            require_csrf();
            $data = body_json();

            $theme = (string)($data['theme'] ?? $user['theme'] ?? 'dark');
            $appIconStyle = (string)($data['app_icon_style'] ?? $user['app_icon_style'] ?? 'auto');
            $wallpaper = clean(
                $data['wallpaper'] ?? ($user['wallpaper'] ?? 'neo'),
                24
            );
            $fontScale = (string)($data['font_scale'] ?? $user['font_scale'] ?? 'normal');
            $fontFamily = (string)($data['font_family'] ?? $user['font_family'] ?? 'system');
            $uiAccent = (string)($data['ui_accent'] ?? $user['ui_accent'] ?? 'silver');
            $bubbleStyle = (string)($data['bubble_style'] ?? $user['bubble_style'] ?? 'rounded');
            $messageDensity = (string)($data['message_density'] ?? $user['message_density'] ?? 'normal');
            $chatWidth = (string)($data['chat_width'] ?? $user['chat_width'] ?? 'normal');
            $reduceMotion = !empty($data['reduce_motion']) ? 1 : 0;
            $easyMode = !empty($data['easy_mode']) ? 1 : 0;
            $notifications = !empty($data['notifications_enabled']) ? 1 : 0;

            if (!in_array($theme, ['system','dark','light','amoled'], true)) fail('Invalid theme.');
            if (!in_array($appIconStyle, ['auto','dark','light'], true)) fail('Invalid app icon style.');
            if (!in_array($fontScale, ['small','normal','large'], true)) fail('Invalid text size.');
            if (!in_array($fontFamily, ['system','rounded','serif','mono','humanist','condensed','book'], true)) fail('Invalid font family.');
            if (!in_array($uiAccent, ['silver','blue','green','purple','orange'], true)) fail('Invalid interface accent.');
            if (!in_array($bubbleStyle, ['rounded','soft','square'], true)) fail('Invalid bubble style.');
            if (!in_array($messageDensity, ['compact','normal','spacious'], true)) fail('Invalid message spacing.');
            if (!in_array($chatWidth, ['narrow','normal','wide'], true)) fail('Invalid chat width.');

            $allowedWallpapers = [
                'neo','dots','waves','grid','solid','midnight','paper','mist','aurora','graphite','ocean','sunset','forest','lavender','sand','ice','rose','stars','neon','sakura','matrix','cosmos','custom'
            ];
            if (!in_array($wallpaper, $allowedWallpapers, true)) fail('Invalid wallpaper.');

            $wallpaperUrl = (string)($user['wallpaper_url'] ?? '');
            $previousWallpaperUrl = $wallpaperUrl;
            $wallpaperToken = strtolower(trim((string)($data['wallpaper_token'] ?? '')));

            if ($wallpaper !== 'custom') {
                $wallpaperUrl = '';
            } elseif ($wallpaperToken !== '') {
                $upload = get_owned_upload(
                    $pdo,
                    (int)$user['id'],
                    $wallpaperToken,
                    'wallpaper'
                );

                if (
                    !$upload ||
                    !in_array((string)$upload['media_type'], ['image','gif'], true)
                ) {
                    fail('That wallpaper is no longer available.');
                }

                $wallpaperUrl = media_store_reference($wallpaperToken);
                $pdo->prepare(
                    'UPDATE uploads SET used_at = ? WHERE id = ?'
                )->execute([time(), (int)$upload['id']]);
            } elseif ($wallpaperUrl === '') {
                fail('Choose a custom wallpaper image.');
            }

            $pdo->prepare(
                'UPDATE users
                 SET theme = ?,
                     app_icon_style = ?,
                     wallpaper = ?,
                     wallpaper_url = ?,
                     font_scale = ?,
                     font_family = ?,
                     ui_accent = ?,
                     bubble_style = ?,
                     message_density = ?,
                     chat_width = ?,
                     reduce_motion = ?,
                     easy_mode = ?,
                     notifications_enabled = ?,
                     updated_at = ?
                 WHERE id = ?'
            )->execute([
                $theme,
                $appIconStyle,
                $wallpaper,
                $wallpaperUrl,
                $fontScale,
                $fontFamily,
                $uiAccent,
                $bubbleStyle,
                $messageDensity,
                $chatWidth,
                $reduceMotion,
                $easyMode,
                $notifications,
                time(),
                (int)$user['id']
            ]);

            if ($previousWallpaperUrl !== $wallpaperUrl) {
                $oldToken = media_token_from_reference($previousWallpaperUrl);
                if ($oldToken !== null) {
                    delete_upload_if_unreferenced(
                        $pdo,
                        $oldToken,
                        (int)$user['id']
                    );
                }
            }

            $stmt = $pdo->prepare(
                'SELECT id, username, display_name, about, accent, avatar_url, avatar_style,
                        theme, app_icon_style, wallpaper, wallpaper_url, font_scale, font_family, ui_accent,
                        bubble_style, message_density, chat_width, reduce_motion, easy_mode,
                        notifications_enabled, kid_mode, last_seen_at
                 FROM users WHERE id = ?'
            );
            $stmt->execute([(int)$user['id']]);
            ok(['user' => self_user($stmt->fetch())]);

        case 'conversation_preferences':
            $user = current_user();
            $userId = (int)$user['id'];
            $data = [];

            if ($method === 'GET') {
                $cid = (int)($_GET['conversation_id'] ?? 0);
            } elseif ($method === 'POST') {
                require_csrf();
                $data = body_json();
                $cid = (int)($data['conversation_id'] ?? 0);
            } else {
                fail('Method not allowed.', 405);
            }

            $conversation = require_member($cid, $userId);
            $pdo = db();

            if ($method === 'GET') {
                ok(['preferences' => conversation_preferences($pdo, $cid, $userId)]);
            }

            $current = conversation_preferences_stored($pdo, $cid, $userId);

            $wallpaper = clean(
                $data['wallpaper'] ?? $current['wallpaper'] ?? 'default',
                24
            );
            $allowedWallpapers = [
                'default','neo','dots','waves','grid','solid','midnight','paper','mist','aurora','graphite','ocean','sunset','forest','lavender','sand','ice','rose','stars','neon','sakura','matrix','cosmos','custom'
            ];
            if (!in_array($wallpaper, $allowedWallpapers, true)) {
                fail('Invalid wallpaper.');
            }

            $ringtone = clean(
                $data['ringtone'] ?? $current['ringtone'] ?? 'classic',
                24
            );
            $allowedRingtones = ['classic','chime','pulse','digital','soft','bell','orbit','arcade','glass','bass','alert','custom','none'];
            if (!in_array($ringtone, $allowedRingtones, true)) {
                fail('Invalid ringtone.');
            }

            $bubbleStyle = (string)(
                $data['bubble_style'] ?? $current['bubble_style'] ?? 'default'
            );
            if (!in_array($bubbleStyle, ['default','rounded','soft','square'], true)) {
                fail('Invalid bubble style.');
            }

            $density = (string)(
                $data['density'] ?? $current['density'] ?? 'default'
            );
            if (!in_array($density, ['default','compact','normal','spacious'], true)) {
                fail('Invalid chat density.');
            }

            $chatFontScale = (string)(
                $data['chat_font_scale'] ?? $current['chat_font_scale'] ?? 'default'
            );
            if (!in_array($chatFontScale, ['default','small','normal','large'], true)) {
                fail('Invalid chat text size.');
            }

            $callBannerText = clean(
                $data['call_banner_text'] ?? $current['call_banner_text'] ?? '',
                80
            );
            $callBannerStyle = (string)(
                $data['call_banner_style'] ?? $current['call_banner_style'] ?? 'glass'
            );
            if (!in_array($callBannerStyle, ['glass','dark','light','accent'], true)) {
                fail('Invalid call banner style.');
            }

            $disappearingSeconds = isset($data['disappearing_seconds'])
                ? (int)$data['disappearing_seconds']
                : (int)($current['disappearing_seconds'] ?? 0);

            $allowedExpirations = [0, 86400, 604800, 2592000, 31536000];
            if (!in_array($disappearingSeconds, $allowedExpirations, true)) {
                fail('Invalid disappearing-message timer.');
            }

            $wallpaperUrl = (string)($current['wallpaper_url'] ?? '');
            $previousWallpaperUrl = $wallpaperUrl;
            $token = strtolower(trim((string)($data['wallpaper_token'] ?? '')));

            if ($wallpaper !== 'custom') {
                $wallpaperUrl = '';
            } elseif ($token !== '') {
                $upload = get_owned_upload($pdo, $userId, $token, 'wallpaper');

                if (
                    !$upload ||
                    !in_array((string)$upload['media_type'], ['image','gif'], true)
                ) {
                    fail('That wallpaper is no longer available.');
                }

                $wallpaperUrl = media_store_reference($token);

                $pdo->prepare(
                    'UPDATE uploads SET used_at = ? WHERE id = ?'
                )->execute([time(), (int)$upload['id']]);
            } elseif ($wallpaperUrl === '') {
                fail('Choose a custom wallpaper image.');
            }

            $pdo->beginTransaction();

            try {
                $pdo->prepare(
                    'INSERT INTO conversation_settings
                     (conversation_id, user_id, wallpaper, wallpaper_url,
                      ringtone, bubble_style, density, chat_font_scale,
                      call_banner_text, call_banner_style)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE
                       wallpaper = VALUES(wallpaper),
                       wallpaper_url = VALUES(wallpaper_url),
                       ringtone = VALUES(ringtone),
                       bubble_style = VALUES(bubble_style),
                       density = VALUES(density),
                       chat_font_scale = VALUES(chat_font_scale),
                       call_banner_text = VALUES(call_banner_text),
                       call_banner_style = VALUES(call_banner_style)'
                )->execute([
                    $cid,
                    $userId,
                    $wallpaper,
                    $wallpaperUrl,
                    $ringtone,
                    $bubbleStyle,
                    $density,
                    $chatFontScale,
                    $callBannerText,
                    $callBannerStyle
                ]);

                if (
                    (int)($conversation['disappearing_seconds'] ?? 0)
                    !== $disappearingSeconds
                ) {
                    $pdo->prepare(
                        'UPDATE conversations
                         SET disappearing_seconds = ?
                         WHERE id = ?'
                    )->execute([$disappearingSeconds, $cid]);
                    touch_conversation_change($pdo, $cid, time());
                }

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            if ($previousWallpaperUrl !== $wallpaperUrl) {
                $oldToken = media_token_from_reference($previousWallpaperUrl);
                if ($oldToken !== null) {
                    delete_upload_if_unreferenced($pdo, $oldToken, $userId);
                }
            }

            ok([
                'preferences' => conversation_preferences($pdo, $cid, $userId)
            ]);

        case 'kid_settings':
            $user = current_user();
            $pdo = db();

            if ($method === 'GET') {
                ok(['kid' => [
                    'enabled' => (bool)($user['kid_mode'] ?? false),
                    'custom_words' => (string)($user['kid_blocked_words'] ?? ''),
                ]]);
            }

            if ($method !== 'POST') fail('Method not allowed.', 405);
            require_csrf();
            rate_limit(
                'kid_settings',
                8,
                300,
                (string)$user['id'],
                'subject',
                'Too many kid-filter password attempts. Try again shortly.'
            );
            $data = body_json();

            $enabled = !empty($data['enabled']);
            $password = (string)($data['kid_password'] ?? '');
            $customWords = clean($data['custom_words'] ?? ($user['kid_blocked_words'] ?? ''), 2000);
            $currentlyEnabled = (int)($user['kid_mode'] ?? 0) === 1;
            $existingHash = (string)($user['kid_pin_hash'] ?? '');

            if ($enabled && !$currentlyEnabled) {
                if (strlen($password) < 4 || strlen($password) > 128) {
                    fail('Kid filter password must be at least 4 characters.');
                }

                $hash = hash_password_secure($password);
                $pdo->prepare(
                    'UPDATE users
                     SET kid_mode = 1, kid_pin_hash = ?, kid_blocked_words = ?, updated_at = ?
                     WHERE id = ?'
                )->execute([$hash, $customWords, time(), (int)$user['id']]);
            } elseif (!$enabled && $currentlyEnabled) {
                if ($existingHash === '' || !verify_password_secure($password, $existingHash)) {
                    fail('Kid filter password is incorrect.', 401);
                }

                $pdo->prepare(
                    'UPDATE users
                     SET kid_mode = 0, kid_pin_hash = NULL, updated_at = ?
                     WHERE id = ?'
                )->execute([time(), (int)$user['id']]);
            } elseif ($enabled && $currentlyEnabled) {
                if ($existingHash === '' || !verify_password_secure($password, $existingHash)) {
                    fail('Kid filter password is incorrect.', 401);
                }

                $pdo->prepare(
                    'UPDATE users
                     SET kid_blocked_words = ?, updated_at = ?
                     WHERE id = ?'
                )->execute([$customWords, time(), (int)$user['id']]);
            }

            $stmt = $pdo->prepare(
                'SELECT id, username, display_name, about, accent, avatar_url, avatar_style,
                        theme, app_icon_style, wallpaper, wallpaper_url, font_scale, font_family, ui_accent,
                bubble_style, message_density, chat_width, reduce_motion, easy_mode,
                notifications_enabled,
                        kid_mode, last_seen_at
                 FROM users WHERE id = ?'
            );
            $stmt->execute([(int)$user['id']]);
            ok(['user' => self_user($stmt->fetch())]);

        case 'security_status':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            $pdo = db();

            $stmt = $pdo->prepare(
                'SELECT password_hash, created_at
                 FROM users
                 WHERE id = ? AND disabled_at IS NULL
                 LIMIT 1'
            );
            $stmt->execute([(int)$user['id']]);
            $securityUser = $stmt->fetch();

            if (!$securityUser) {
                fail('Account not found.', 404);
            }

            $tokenStmt = $pdo->prepare(
                'SELECT COUNT(*)
                 FROM auth_tokens
                 WHERE user_id = ? AND expires_at > ?'
            );
            $tokenStmt->execute([(int)$user['id'], time()]);
            $savedLogins = (int)$tokenStmt->fetchColumn();

            $passkeyStmt = $pdo->prepare(
                'SELECT COUNT(*) FROM passkeys WHERE user_id = ?'
            );
            $passkeyStmt->execute([(int)$user['id']]);
            $passkeyCount = (int)$passkeyStmt->fetchColumn();

            [$passwordHashPayload] = password_hash_payload((string)$securityUser['password_hash']);
            $passwordInfo = password_get_info($passwordHashPayload);
            $algorithmName = (string)($passwordInfo['algoName'] ?? 'secure hash');

            ok([
                'password_algorithm' => $algorithmName,
                'password_server_keyed' => true,
                'saved_logins' => $savedLogins,
                'passkeys' => $passkeyCount,
                'login_binding' => 'browser-bound',
                'account_created_at' => (int)$securityUser['created_at'],
                'session_rotation_minutes' => 15,
                'session_idle_hours' => 12,
                'message_encryption' => 'AES-256-GCM',
                'media_encryption' => 'AES-256-GCM'
            ]);

        case 'change_password':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('password_change', 5, 600, (string)$user['id']);

            $data = body_json();
            $currentPassword = (string)($data['current_password'] ?? '');
            $newPassword = (string)($data['new_password'] ?? '');
            $newPasswordConfirm = (string)($data['new_password_confirm'] ?? '');

            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT password_hash FROM users WHERE id = ? AND disabled_at IS NULL LIMIT 1'
            );
            $stmt->execute([(int)$user['id']]);
            $storedHash = (string)($stmt->fetchColumn() ?: '');

            if ($storedHash === '' || !verify_password_secure($currentPassword, $storedHash)) {
                usleep(random_int(90000, 180000));
                fail('Current password is incorrect.', 401);
            }

            if (!hash_equals($newPassword, $newPasswordConfirm)) {
                fail('The new passwords do not match.');
            }

            validate_new_password($newPassword, (string)$user['username']);

            if (verify_password_secure($newPassword, $storedHash)) {
                fail('Choose a new password that is different from your current password.');
            }

            $now = time();
            $pdo->beginTransaction();

            try {
                $pdo->prepare(
                    'UPDATE users
                     SET password_hash = ?,
                         updated_at = ?,
                         session_version = session_version + 1
                     WHERE id = ?'
                )->execute([
                    hash_password_secure($newPassword),
                    $now,
                    (int)$user['id']
                ]);

                $pdo->prepare('DELETE FROM auth_tokens WHERE user_id = ?')
                    ->execute([(int)$user['id']]);

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            clear_remember_cookie();
            issue_remember_token((int)$user['id']);

            $versionStmt = $pdo->prepare(
                'SELECT session_version FROM users WHERE id = ?'
            );
            $versionStmt->execute([(int)$user['id']]);
            $newSessionVersion = max(1, (int)$versionStmt->fetchColumn());

            rotate_session_id_safely();
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            $_SESSION['last_activity'] = $now;
            $_SESSION['rotated_at'] = $now;
            $_SESSION['session_version'] = $newSessionVersion;

            ok([
                'csrf' => csrf_token(),
                'other_logins_revoked' => true
            ]);

        case 'logout_other_devices':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('logout_devices', 8, 300, (string)$user['id']);

            $pdo = db();
            $now = time();
            $parts = remember_cookie_parts();

            $pdo->beginTransaction();

            try {
                // This invalidates every currently active PHP session for the
                // account. The current browser adopts the new generation below.
                $pdo->prepare(
                    'UPDATE users
                     SET session_version = session_version + 1,
                         updated_at = ?
                     WHERE id = ?'
                )->execute([$now, (int)$user['id']]);

                if ($parts !== null) {
                    [$selector] = $parts;

                    $pdo->prepare(
                        'DELETE FROM auth_tokens
                         WHERE user_id = ? AND selector <> ?'
                    )->execute([(int)$user['id'], $selector]);
                } else {
                    $pdo->prepare(
                        'DELETE FROM auth_tokens WHERE user_id = ?'
                    )->execute([(int)$user['id']]);
                }

                $versionStmt = $pdo->prepare(
                    'SELECT session_version FROM users WHERE id = ?'
                );
                $versionStmt->execute([(int)$user['id']]);
                $newSessionVersion = max(1, (int)$versionStmt->fetchColumn());

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }

            // Make sure the current browser still has a valid persistent
            // token after the cleanup. A stale cookie must never be left behind.
            $needsFreshToken = ($parts === null);

            if ($parts !== null) {
                [$selector] = $parts;
                $tokenCheck = $pdo->prepare(
                    'SELECT id
                     FROM auth_tokens
                     WHERE user_id = ?
                       AND selector = ?
                       AND expires_at > ?
                     LIMIT 1'
                );
                $tokenCheck->execute([(int)$user['id'], $selector, $now]);
                $needsFreshToken = !$tokenCheck->fetchColumn();
            }

            if ($needsFreshToken) {
                clear_remember_cookie();
                issue_remember_token((int)$user['id']);
            }

            rotate_session_id_safely();
            $_SESSION['csrf'] = bin2hex(random_bytes(32));
            $_SESSION['last_activity'] = $now;
            $_SESSION['rotated_at'] = $now;
            $_SESSION['session_version'] = $newSessionVersion;

            ok([
                'csrf' => csrf_token(),
                'other_logins_revoked' => true
            ]);

        case 'search_users':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            $q = clean($_GET['q'] ?? '', 50);
            if ($q === '') ok(['users' => []]);

            // Use a custom LIKE escape character so searches behave
            // consistently even under unusual MySQL backslash SQL modes.
            $escaped = str_replace(
                ['!', '%', '_'],
                ['!!', '!%', '!_'],
                $q
            );
            $like = '%' . $escaped . '%';
            $prefix = $escaped . '%';

            $pdo = db();
            $stmt = $pdo->prepare(
                "SELECT id, username, display_name, about, accent, avatar_url, avatar_style, last_seen_at, online_until, account_role
                 FROM users
                 WHERE id <> ? AND disabled_at IS NULL
                   AND (
                     username LIKE ? ESCAPE '!'
                     OR display_name LIKE ? ESCAPE '!'
                   )
                 ORDER BY
                   CASE WHEN username LIKE ? ESCAPE '!' THEN 0 ELSE 1 END,
                   username
                 LIMIT 12"
            );
            $viewerId = (int)$user['id'];
            $stmt->execute([$viewerId, $like, $like, $prefix]);

            $searchUsers = [];
            foreach ($stmt->fetchAll() as $row) {
                $item = public_user($row);
                $item['friendship'] = friendship_for_viewer(
                    friendship_between($pdo, $viewerId, (int)$row['id']),
                    $viewerId
                );
                $searchUsers[] = $item;
            }

            ok(['users' => $searchUsers]);

        case 'friends':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $pdo = db();

            $stmt = $pdo->prepare(
                'SELECT f.*,
                        u.id AS other_id,
                        u.username AS other_username,
                        u.display_name AS other_display_name,
                        u.about AS other_about,
                        u.accent AS other_accent,
                        u.avatar_url AS other_avatar_url,
                        u.avatar_style AS other_avatar_style,
                        u.last_seen_at AS other_last_seen_at,
                        u.online_until AS other_online_until,
                        u.account_role AS other_account_role,
                        (
                          SELECT nickname FROM friend_nicknames fn
                          WHERE fn.viewer_id = ? AND fn.friend_id = u.id
                          LIMIT 1
                        ) AS other_nickname
                 FROM friendships f
                 INNER JOIN users u
                   ON u.id = IF(f.requester_id = ?, f.addressee_id, f.requester_id)
                  AND u.disabled_at IS NULL
                 WHERE f.requester_id = ? OR f.addressee_id = ?
                 ORDER BY f.updated_at DESC, f.id DESC'
            );
            $stmt->execute([$userId, $userId, $userId, $userId]);

            $friends = [];
            $incoming = [];
            $outgoing = [];

            foreach ($stmt->fetchAll() as $row) {
                $person = public_user([
                    'id' => (int)$row['other_id'],
                    'username' => (string)$row['other_username'],
                    'display_name' => (string)$row['other_display_name'],
                    'about' => (string)$row['other_about'],
                    'accent' => (string)$row['other_accent'],
                    'avatar_url' => (string)$row['other_avatar_url'],
                    'avatar_style' => (string)($row['other_avatar_style'] ?? ''),
                    'last_seen_at' => (int)$row['other_last_seen_at'],
                    'online_until' => (int)($row['other_online_until'] ?? 0),
                    'account_role' => (string)($row['other_account_role'] ?? 'member'),
                ]);

                $person['nickname'] = (string)($row['other_nickname'] ?? '');

                $item = [
                    'id' => (int)$row['id'],
                    'person' => $person,
                    'created_at' => (int)$row['created_at'],
                    'updated_at' => (int)$row['updated_at'],
                ];

                if ((string)$row['status'] === 'accepted') {
                    $friends[] = $item;
                } elseif ((string)$row['status'] === 'pending') {
                    if ((int)$row['addressee_id'] === $userId) {
                        $incoming[] = $item;
                    } else {
                        $outgoing[] = $item;
                    }
                }
            }

            ok([
                'friends' => $friends,
                'incoming' => $incoming,
                'outgoing' => $outgoing,
                'signature' => friendship_signature($pdo, $userId),
            ]);

        case 'friend_suggestions':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $pdo = db();

            // Friend-of-friend discovery. Only public, enabled accounts are
            // returned, and existing/pending friendships are excluded.
            $stmt = $pdo->prepare(
                'SELECT candidate.id, candidate.username, candidate.display_name,
                        candidate.about, candidate.accent, candidate.avatar_url,
                        candidate.avatar_style, candidate.profile_banner_url,
                        candidate.public_profile, candidate.last_seen_at,
                        candidate.online_until, candidate.account_role,
                        COUNT(DISTINCT mutual.id) AS mutual_count
                 FROM friendships mine
                 INNER JOIN users mutual
                   ON mutual.id = IF(mine.requester_id = ?, mine.addressee_id, mine.requester_id)
                  AND mutual.disabled_at IS NULL
                 INNER JOIN friendships edge
                   ON edge.status = \'accepted\'
                  AND (edge.requester_id = mutual.id OR edge.addressee_id = mutual.id)
                 INNER JOIN users candidate
                   ON candidate.id = IF(edge.requester_id = mutual.id, edge.addressee_id, edge.requester_id)
                  AND candidate.disabled_at IS NULL
                 LEFT JOIN friendships existing
                   ON existing.pair_key = CONCAT(LEAST(?, candidate.id), \':\', GREATEST(?, candidate.id))
                 WHERE mine.status = \'accepted\'
                   AND (mine.requester_id = ? OR mine.addressee_id = ?)
                   AND candidate.id <> ?
                   AND candidate.public_profile = 1
                   AND existing.id IS NULL
                 GROUP BY candidate.id, candidate.username, candidate.display_name,
                          candidate.about, candidate.accent, candidate.avatar_url,
                          candidate.avatar_style, candidate.profile_banner_url,
                          candidate.public_profile, candidate.last_seen_at,
                          candidate.online_until, candidate.account_role
                 ORDER BY mutual_count DESC, candidate.last_seen_at DESC, candidate.id DESC
                 LIMIT 24'
            );
            $stmt->execute([
                $userId,
                $userId,
                $userId,
                $userId,
                $userId,
                $userId,
            ]);

            $suggestions = [];
            foreach ($stmt->fetchAll() as $row) {
                $person = public_user($row);
                $person['mutual_count'] = max(1, (int)($row['mutual_count'] ?? 1));
                $suggestions[] = $person;
            }

            ok(['suggestions' => $suggestions]);

        case 'friend_request':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit(
                'friend_request',
                40,
                3600,
                (string)$user['id'],
                'device',
                'Too many friend requests were sent recently.'
            );
            $data = body_json();
            $userId = (int)$user['id'];
            $targetId = max(0, (int)($data['user_id'] ?? 0));
            $targetUsername = clean($data['username'] ?? '', MAX_USERNAME);
            $pdo = db();

            if ($targetId > 0) {
                $targetStmt = $pdo->prepare(
                    'SELECT id, username, display_name, about, accent, avatar_url, avatar_style, last_seen_at
                     FROM users WHERE id = ? AND disabled_at IS NULL LIMIT 1'
                );
                $targetStmt->execute([$targetId]);
            } else {
                if (!valid_username($targetUsername)) fail('Choose a valid user.');
                $targetStmt = $pdo->prepare(
                    'SELECT id, username, display_name, about, accent, avatar_url, avatar_style, last_seen_at
                     FROM users WHERE username = ? AND disabled_at IS NULL LIMIT 1'
                );
                $targetStmt->execute([$targetUsername]);
            }

            $target = $targetStmt->fetch();
            if (!$target) fail('User not found.', 404);
            $targetId = (int)$target['id'];
            if ($targetId === $userId) fail('You cannot add yourself.');

            $pairKey = friendship_pair_key($userId, $targetId);
            $existing = friendship_between($pdo, $userId, $targetId);
            $now = time();

            if ($existing && (string)$existing['status'] === 'accepted') {
                ok([
                    'status' => 'accepted',
                    'request_id' => (int)$existing['id'],
                ]);
            }

            if ($existing && (string)$existing['status'] === 'pending') {
                if ((int)$existing['requester_id'] === $userId) {
                    ok([
                        'status' => 'outgoing',
                        'request_id' => (int)$existing['id'],
                    ]);
                }

                fail('This person already sent you a friend request. Accept it from Friend requests.', 409);
            }

            if ($existing) {
                $pdo->prepare(
                    "UPDATE friendships
                     SET requester_id = ?, addressee_id = ?, status = 'pending',
                         created_at = ?, updated_at = ?, responded_at = NULL
                     WHERE id = ?"
                )->execute([
                    $userId,
                    $targetId,
                    $now,
                    $now,
                    (int)$existing['id'],
                ]);
                $requestId = (int)$existing['id'];
            } else {
                $pdo->prepare(
                    "INSERT INTO friendships
                     (pair_key, requester_id, addressee_id, status, created_at, updated_at)
                     VALUES (?, ?, ?, 'pending', ?, ?)"
                )->execute([$pairKey, $userId, $targetId, $now, $now]);
                $requestId = (int)$pdo->lastInsertId();
            }

            bump_users_realtime($pdo, [$userId, $targetId], 'friend_seq');

            // Push delivery performs external HTTPS requests. The session no
            // longer needs mutation here, so don't block this device's other
            // tabs/calls while notification providers respond.
            release_session_lock();
            direct_push_user($pdo, $targetId, [
                'title' => (string)$user['display_name'],
                'body' => 'wants to be friends on SilkNex',
                'tag' => 'friend-request-' . $requestId,
                'icon' => notification_media_url((string)($user['avatar_url'] ?? '')),
                'data' => [
                    'type' => 'friend_request',
                    'request_id' => $requestId,
                    'user_id' => $userId,
                    'avatar_url' => notification_media_url((string)($user['avatar_url'] ?? '')),
                ],
            ]);

            ok([
                'status' => 'outgoing',
                'request_id' => $requestId,
                'friend_signature' => friendship_signature($pdo, $userId),
            ], 201);

        case 'friend_respond':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $userId = (int)$user['id'];
            $requestId = max(0, (int)($data['request_id'] ?? 0));
            $accept = !empty($data['accept']);
            $pdo = db();

            $now = time();
            $status = $accept ? 'accepted' : 'declined';
            $conversationId = 0;
            $requesterId = 0;

            // Transition the friendship and create/repair its DM atomically.
            // Previously an error during DM creation could leave an accepted
            // friendship with no usable conversation.
            $pdo->beginTransaction();
            try {
                $stmt = $pdo->prepare(
                    "SELECT * FROM friendships
                     WHERE id = ? AND addressee_id = ? AND status = 'pending'
                     LIMIT 1
                     FOR UPDATE"
                );
                $stmt->execute([$requestId, $userId]);
                $friendship = $stmt->fetch();

                if (!$friendship) {
                    $pdo->rollBack();
                    fail('Friend request not found or already answered.', 404);
                }

                $requesterId = (int)$friendship['requester_id'];

                $update = $pdo->prepare(
                    "UPDATE friendships
                     SET status = ?, updated_at = ?, responded_at = ?
                     WHERE id = ? AND status = 'pending'"
                );
                $update->execute([$status, $now, $now, $requestId]);

                if ($update->rowCount() !== 1) {
                    $pdo->rollBack();
                    fail('Friend request was already answered.', 409);
                }

                if ($accept) {
                    $conversationId = ensure_direct_conversation(
                        $pdo,
                        $userId,
                        $requesterId
                    );
                }

                bump_users_realtime($pdo, [$userId, $requesterId], 'friend_seq');
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            if ($accept) {
                release_session_lock();
                direct_push_user($pdo, $requesterId, [
                    'title' => (string)$user['display_name'],
                    'body' => 'accepted your friend request',
                    'tag' => 'friend-accepted-' . $requestId,
                    'icon' => notification_media_url((string)($user['avatar_url'] ?? '')),
                    'data' => [
                        'type' => 'friend_accepted',
                        'conversation_id' => $conversationId,
                        'request_id' => $requestId,
                        'avatar_url' => notification_media_url((string)($user['avatar_url'] ?? '')),
                    ],
                ]);
            }

            ok([
                'status' => $status,
                'conversation_id' => $conversationId,
                'friend_signature' => friendship_signature($pdo, $userId),
            ]);

        case 'friend_remove':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $userId = (int)$user['id'];
            $otherId = max(0, (int)($data['user_id'] ?? 0));
            if ($otherId <= 0 || $otherId === $userId) fail('Invalid friend.');

            $pdo = db();
            $pdo->prepare(
                'DELETE FROM friendships WHERE pair_key = ?'
            )->execute([friendship_pair_key($userId, $otherId)]);
            bump_users_realtime($pdo, [$userId, $otherId], 'friend_seq');

            ok([
                'removed' => true,
                'friend_signature' => friendship_signature($pdo, $userId),
            ]);

        case 'stories':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $pdo = db();
            $now = time();

            // Public stories are discoverable to signed-in users, while friend
            // and custom stories stay scoped to the owner's friend graph.
            // Custom audiences are filtered in PHP after the indexed candidate
            // query so this remains compatible with older shared-host MySQL/
            // MariaDB builds that do not have identical JSON operators.
            $stmt = $pdo->prepare(
                'SELECT
                   s.id, s.user_id, s.media_token, s.media_type, s.caption,
                   s.created_at, s.expires_at, s.visibility, s.audience_json,
                   u.username, u.display_name, u.accent, u.avatar_url, u.avatar_style, u.account_role,
                   viewed.viewed_at,
                   (
                     SELECT COUNT(*)
                     FROM story_views view_count
                     WHERE view_count.story_id = s.id
                       AND view_count.user_id <> s.user_id
                   ) AS view_count,
                   CASE WHEN s.user_id = ? THEN 1 ELSE 0 END AS mine,
                   EXISTS (
                     SELECT 1
                     FROM friendships f
                     WHERE f.status = \'accepted\'
                       AND (
                         (f.requester_id = ? AND f.addressee_id = s.user_id)
                         OR
                         (f.addressee_id = ? AND f.requester_id = s.user_id)
                       )
                     LIMIT 1
                   ) AS is_friend
                 FROM stories s
                 INNER JOIN users u
                   ON u.id = s.user_id
                  AND u.disabled_at IS NULL
                 LEFT JOIN story_views viewed
                   ON viewed.story_id = s.id
                  AND viewed.user_id = ?
                 WHERE s.deleted_at IS NULL
                   AND s.expires_at > ?
                   AND s.created_at > ?
                   AND (
                     s.user_id = ?
                     OR s.visibility = \'public\'
                     OR EXISTS (
                       SELECT 1
                       FROM friendships f2
                       WHERE f2.status = \'accepted\'
                         AND (
                           (f2.requester_id = ? AND f2.addressee_id = s.user_id)
                           OR
                           (f2.addressee_id = ? AND f2.requester_id = s.user_id)
                         )
                       LIMIT 1
                     )
                   )
                 ORDER BY
                   CASE WHEN s.user_id = ? THEN 0 ELSE 1 END,
                   s.user_id ASC,
                   s.created_at ASC,
                   s.id ASC
                 LIMIT 320'
            );
            $stmt->execute([
                $userId,
                $userId,
                $userId,
                $userId,
                $now,
                $now - 86400,
                $userId,
                $userId,
                $userId,
                $userId
            ]);

            $storyRows = [];
            foreach ($stmt->fetchAll() as $storyRow) {
                if (!story_row_visible_to($storyRow, $userId, !empty($storyRow['is_friend']))) {
                    continue;
                }
                $storyRow['caption'] = censor_for_kid(
                    (string)($storyRow['caption'] ?? ''),
                    $user
                );
                $storyRows[] = $storyRow;
                if (count($storyRows) >= 250) break;
            }

            ok([
                'stories' => array_map('story_item', $storyRows),
                'server_time' => $now,
            ]);

        case 'story_create':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit(
                'story_create',
                40,
                3600,
                (string)$user['id'],
                'device',
                'Too many stories were posted recently. Try again later.'
            );

            $data = body_json();
            $token = strtolower(trim((string)($data['upload_token'] ?? '')));
            $caption = clean($data['caption'] ?? '', 500);
            $retentionDays = (int)($data['retention_days'] ?? 30);
            if (!in_array($retentionDays, [1,7,30], true)) fail('Choose 1, 7, or 30 days for profile story retention.');
            $visibility = strtolower(clean($data['visibility'] ?? 'friends', 16));
            if (!in_array($visibility, ['public','friends','custom'], true)) {
                $visibility = 'friends';
            }
            $audience = [];
            if ($visibility === 'custom' && is_array($data['audience'] ?? null)) {
                foreach ($data['audience'] as $candidate) {
                    $id = (int)$candidate;
                    if ($id > 0 && $id !== (int)$user['id']) $audience[$id] = $id;
                    if (count($audience) >= 100) break;
                }
            }
            $audienceJson = json_encode(array_values($audience), JSON_UNESCAPED_SLASHES);
            $pdo = db();
            $upload = get_owned_upload($pdo, (int)$user['id'], $token, 'story');

            if (!$upload || !in_array((string)$upload['media_type'], ['image','gif','video'], true)) {
                fail('That story media is no longer available.');
            }

            $now = time();
            // New stories appear in the main rail for 24 hours; their owner's
            // profile keeps them until the chosen retention period ends.
            $expires = $now + $retentionDays * 86400;

            $pdo->beginTransaction();
            try {
                $pdo->prepare(
                    'INSERT INTO stories
                     (user_id, media_token, media_type, caption, visibility, audience_json, created_at, expires_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
                )->execute([
                    (int)$user['id'],
                    $token,
                    (string)$upload['media_type'],
                    $caption,
                    $visibility,
                    $audienceJson,
                    $now,
                    $expires,
                ]);
                $storyId = (int)$pdo->lastInsertId();

                $pdo->prepare('UPDATE uploads SET used_at = ? WHERE id = ?')
                    ->execute([$now, (int)$upload['id']]);

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            ok(['story_id' => $storyId, 'expires_at' => $expires], 201);

        case 'story_views':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            session_rate_limit(
                'story_views',
                240,
                60,
                'Story updates are being acknowledged too quickly.'
            );
            $userId = (int)$user['id'];
            $data = body_json();
            $rawIds = is_array($data['story_ids'] ?? null) ? $data['story_ids'] : [];

            $storyIds = [];
            foreach ($rawIds as $candidate) {
                $id = (int)$candidate;
                if ($id > 0) $storyIds[$id] = $id;
                if (count($storyIds) >= 25) break;
            }
            $storyIds = array_values($storyIds);
            if (!$storyIds) ok(['viewed' => true, 'viewed_ids' => [], 'show_ad' => false]);

            // Persist CSRF/session state, then get out of the session lock.
            // Fast story swiping can otherwise serialize view acknowledgements
            // behind unrelated chat/call requests from the same device.
            release_session_lock();
            $pdo = db();
            $now = time();

            $placeholders = implode(',', array_fill(0, count($storyIds), '?'));
            $visibleStmt = $pdo->prepare(
                "SELECT
                    s.id, s.user_id, s.visibility, s.audience_json,
                    EXISTS (
                      SELECT 1
                      FROM friendships f
                      WHERE f.status = 'accepted'
                        AND (
                          (f.requester_id = ? AND f.addressee_id = s.user_id)
                          OR
                          (f.addressee_id = ? AND f.requester_id = s.user_id)
                        )
                      LIMIT 1
                    ) AS is_friend
                 FROM stories s
                 INNER JOIN users u
                    ON u.id = s.user_id
                   AND u.disabled_at IS NULL
                 WHERE s.id IN ({$placeholders})
                   AND s.deleted_at IS NULL
                   AND s.expires_at > ?"
            );
            $visibleStmt->execute(array_merge(
                [$userId, $userId],
                $storyIds,
                [$now]
            ));

            $visibleIds = [];
            foreach ($visibleStmt->fetchAll() as $storyRow) {
                if ((int)$storyRow['user_id'] === $userId) continue;
                if (!story_row_visible_to($storyRow, $userId, !empty($storyRow['is_friend']))) {
                    continue;
                }
                $visibleIds[] = (int)$storyRow['id'];
            }

            if (!$visibleIds) {
                ok(['viewed' => true, 'viewed_ids' => [], 'show_ad' => false]);
            }

            $statusBefore = ad_status($pdo, $userId);
            $counterBefore = max(0, (int)($statusBefore['story_view_counter'] ?? 0));
            $newUniqueViews = 0;
            $insertView = $pdo->prepare(
                'INSERT IGNORE INTO story_views (story_id, user_id, viewed_at)
                 VALUES (?, ?, ?)'
            );

            $pdo->beginTransaction();
            try {
                foreach ($visibleIds as $storyId) {
                    $insertView->execute([$storyId, $userId, $now]);
                    if ($insertView->rowCount() === 1) $newUniqueViews++;
                }

                if ($newUniqueViews > 0 && empty($statusBefore['ads_disabled'])) {
                    $pdo->prepare(
                        'UPDATE user_ad_state
                         SET story_view_counter = story_view_counter + ?, updated_at = ?
                         WHERE user_id = ?'
                    )->execute([$newUniqueViews, $now, $userId]);
                }
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            $status = $newUniqueViews > 0 ? ad_status($pdo, $userId) : $statusBefore;
            $counterAfter = max(0, (int)($status['story_view_counter'] ?? $counterBefore));
            $showAd =
                empty($status['ads_disabled']) &&
                intdiv($counterAfter, 4) > intdiv($counterBefore, 4);

            ok([
                'viewed' => true,
                'viewed_ids' => $visibleIds,
                'new_views' => $newUniqueViews,
                'show_ad' => $showAd,
                'ad_status' => $status,
            ]);

        case 'story_view':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $storyId = (int)($data['story_id'] ?? 0);
            release_session_lock();
            $pdo = db();

            if ($storyId < 1 || !story_is_visible_to($pdo, $storyId, (int)$user['id'])) {
                fail('Story not found.', 404);
            }

            $viewStmt = $pdo->prepare(
                'INSERT INTO story_views (story_id, user_id, viewed_at)
                 VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE viewed_at = VALUES(viewed_at)'
            );
            $viewStmt->execute([$storyId, (int)$user['id'], time()]);
            $firstUniqueView = $viewStmt->rowCount() === 1;

            $showAd = false;
            $status = ad_status($pdo, (int)$user['id']);
            if ($firstUniqueView && empty($status['ads_disabled'])) {
                $pdo->prepare(
                    'UPDATE user_ad_state
                     SET story_view_counter = story_view_counter + 1, updated_at = ?
                     WHERE user_id = ?'
                )->execute([time(), (int)$user['id']]);
                $status = ad_status($pdo, (int)$user['id']);
                // Stories create occasional ad opportunities, not an ad every
                // couple of taps. The server interstitial cap still applies.
                $showAd = ((int)$status['story_view_counter'] % 4) === 0;
            }

            ok([
                'viewed' => true,
                'show_ad' => $showAd,
                'ad_status' => $status,
            ]);

        case 'story_delete':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $storyId = (int)($data['story_id'] ?? 0);
            $pdo = db();

            $stmt = $pdo->prepare(
                'SELECT media_token
                 FROM stories
                 WHERE id = ? AND user_id = ? AND deleted_at IS NULL
                 LIMIT 1'
            );
            $stmt->execute([$storyId, (int)$user['id']]);
            $storyToken = (string)($stmt->fetchColumn() ?: '');

            if ($storyToken === '') fail('Story not found.', 404);

            $pdo->prepare(
                'UPDATE stories SET deleted_at = ? WHERE id = ? AND user_id = ?'
            )->execute([time(), $storyId, (int)$user['id']]);

            delete_upload_if_unreferenced(
                $pdo,
                $storyToken,
                (int)$user['id']
            );

            ok(['deleted' => true]);

        case 'inbox_state':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            $activeConversationId = max(0, (int)($_GET['conversation_id'] ?? 0));
            release_session_lock();
            $pdo = db();

            // One global lease performs due/expiry cleanup for the entire
            // deployment instead of making every online user scan the same
            // maintenance tables.
            run_shared_maintenance($pdo);

            // Keep the global heartbeat to a single MySQL round trip. At scale
            // the parse/network/statement overhead of three tiny queries per
            // browser costs more than the indexed lookups themselves. The
            // scalar subqueries below all hit primary/covering indexes, while
            // the seed row guarantees a response even before realtime state
            // has ever been created for this user.
            $heartbeatStmt = $pdo->prepare(
                "SELECT
                    COALESCE(rs.inbox_seq, 0) AS inbox_seq,
                    COALESCE(rs.friend_seq, 0) AS friend_seq,
                    COALESCE(rs.call_seq, 0) AS call_seq,
                    COALESCE(
                        (
                            SELECT c.change_seq
                            FROM conversations c
                            INNER JOIN conversation_members cm
                              ON cm.conversation_id = c.id
                             AND cm.user_id = ?
                            WHERE c.id = ?
                            LIMIT 1
                        ),
                        0
                    ) AS active_change_seq,
                    COALESCE(
                        (
                            SELECT incoming.id
                            FROM calls incoming
                            WHERE incoming.callee_id = ?
                              AND incoming.status = 'ringing'
                              AND incoming.created_at >= ?
                            ORDER BY incoming.id DESC
                            LIMIT 1
                        ),
                        0
                    ) AS incoming_call_id
                 FROM (SELECT 1 AS seed) heartbeat
                 LEFT JOIN user_realtime_state rs
                   ON rs.user_id = ?
                 LIMIT 1"
            );
            $heartbeatStmt->execute([
                $userId,
                $activeConversationId,
                $userId,
                time() - CALL_RING_TTL_SECONDS,
                $userId
            ]);
            $heartbeat = $heartbeatStmt->fetch() ?: [];

            ok([
                'signature' => (string)max(0, (int)($heartbeat['inbox_seq'] ?? 0)),
                'friend_signature' => (string)max(0, (int)($heartbeat['friend_seq'] ?? 0)),
                'call_signature' => (string)max(0, (int)($heartbeat['call_seq'] ?? 0)),
                'active_change_seq' => max(0, (int)($heartbeat['active_change_seq'] ?? 0)),
                'incoming_call_id' => max(0, (int)($heartbeat['incoming_call_id'] ?? 0))
            ]);

        case 'conversations':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $pdo = db();
            run_shared_maintenance($pdo);

            // Capture before reading rows so a concurrent write is detected on
            // the following refresh rather than hidden by a newer signature.
            $snapshotSignature = inbox_signature($pdo, $userId);
            $knownSignature = (string)($_GET['known_signature'] ?? '');
            if ($knownSignature !== '' && hash_equals($snapshotSignature, $knownSignature)) {
                ok(['unchanged' => true, 'signature' => $snapshotSignature]);
            }

            $stmt = $pdo->prepare(
                'SELECT
                    c.id,
                    c.kind,
                    c.name,
                    c.avatar_url,
                    c.updated_at,
                    own_membership.pinned_at,
                    own_membership.favorite_at,
                    own_membership.archived_at,
                    own_membership.muted_until,
                    own_membership.manual_unread,
                    (
                        SELECT COUNT(*)
                        FROM conversation_members member_count
                        INNER JOIN users count_user
                           ON count_user.id = member_count.user_id
                          AND count_user.disabled_at IS NULL
                        WHERE member_count.conversation_id = c.id
                    ) AS member_count,
                    other_user.username AS other_username,
                    other_user.display_name AS other_display_name,
                    other_user.accent AS other_accent,
                    other_user.avatar_url AS other_avatar_url,
                    other_user.avatar_style AS other_avatar_style,
                    other_user.last_seen_at AS other_last_seen_at,
                    other_user.online_until AS other_online_until,
                    other_user.account_role AS other_account_role,
                    (
                        SELECT fn.nickname
                        FROM friend_nicknames fn
                        WHERE fn.viewer_id = ? AND fn.friend_id = other_user.id
                        LIMIT 1
                    ) AS other_nickname,
                    last_message.id AS last_message_id,
                    last_message.sender_id AS last_message_sender_id,
                    last_sender.avatar_url AS last_message_sender_avatar_url,
                    last_sender.avatar_style AS last_message_sender_avatar_style,
                    last_message.body AS last_message_body,
                    last_message.body_encrypted AS last_message_body_encrypted,
                    last_message.body_compact AS last_message_body_compact,
                    last_message.body_format AS last_message_body_format,
                    last_message.e2ee_payload AS last_message_e2ee_payload,
                    last_message.message_type AS last_message_type,
                    last_message.created_at AS last_message_created_at,
                    last_message.deleted_at AS last_message_deleted_at,
                    COALESCE(
                        (
                            SELECT COUNT(*)
                            FROM messages unread_message
                            WHERE unread_message.conversation_id = c.id
                              AND unread_message.id > GREATEST(
                                  COALESCE(read_state.last_read_message_id, 0),
                                  own_membership.cleared_before_message_id
                              )
                              AND unread_message.sender_id <> ?
                              AND unread_message.deleted_at IS NULL
                              AND (
                                  unread_message.expires_at IS NULL
                                  OR unread_message.expires_at > UNIX_TIMESTAMP()
                              )
                        ),
                        0
                    ) AS unread_count
                 FROM conversations c
                 INNER JOIN conversation_members own_membership
                    ON own_membership.conversation_id = c.id
                   AND own_membership.user_id = ?
                 LEFT JOIN conversation_reads read_state
                    ON read_state.conversation_id = c.id
                   AND read_state.user_id = ?
                 LEFT JOIN users other_user
                    ON other_user.id = (
                        SELECT other_member.user_id
                        FROM conversation_members other_member
                        WHERE other_member.conversation_id = c.id
                          AND other_member.user_id <> ?
                        ORDER BY other_member.user_id
                        LIMIT 1
                    )
                   AND other_user.disabled_at IS NULL
                 LEFT JOIN messages last_message
                    ON last_message.id = (
                        SELECT newest_message.id
                        FROM messages newest_message
                        WHERE newest_message.conversation_id = c.id
                          AND newest_message.id > own_membership.cleared_before_message_id
                          AND newest_message.deleted_at IS NULL
                          AND (
                              newest_message.expires_at IS NULL
                              OR newest_message.expires_at > UNIX_TIMESTAMP()
                          )
                        ORDER BY newest_message.id DESC
                        LIMIT 1
                    )
                 LEFT JOIN users last_sender
                    ON last_sender.id = last_message.sender_id
                   AND last_sender.disabled_at IS NULL
                 WHERE
                   own_membership.hidden_at IS NULL
                   OR EXISTS (
                       SELECT 1
                       FROM messages visible_message
                       WHERE visible_message.conversation_id = c.id
                         AND visible_message.id > own_membership.cleared_before_message_id
                         AND visible_message.deleted_at IS NULL
                         AND (
                             visible_message.expires_at IS NULL
                             OR visible_message.expires_at > UNIX_TIMESTAMP()
                         )
                   )
                 ORDER BY
                    (own_membership.archived_at IS NOT NULL) ASC,
                    (own_membership.pinned_at IS NULL) ASC,
                    own_membership.pinned_at DESC,
                    (own_membership.favorite_at IS NULL) ASC,
                    own_membership.favorite_at DESC,
                    c.updated_at DESC,
                    c.id DESC
                 LIMIT 100'
            );
            $stmt->execute([$userId, $userId, $userId, $userId, $userId]);

            $rows = $stmt->fetchAll();
            $items = [];

            foreach ($rows as $row) {
                $kind = (string)$row['kind'];

                if ($kind === 'group') {
                    $title = trim((string)($row['name'] ?? ''));
                    if ($title === '') $title = 'Group';
                    $memberCount = max(1, (int)$row['member_count']);
                    $subtitle = $memberCount . ($memberCount === 1 ? ' member' : ' members');
                    $avatarAccent = 'silver';
                    $online = false;
                } else {
                    $nickname = trim((string)($row['other_nickname'] ?? ''));
                    $title = $nickname !== ''
                        ? $nickname
                        : trim((string)($row['other_display_name'] ?? ''));
                    if ($title === '') $title = 'Direct message';

                    $otherUsername = trim((string)($row['other_username'] ?? ''));
                    $subtitle = $otherUsername !== '' ? '@' . $otherUsername : 'Direct message';

                    $avatarAccent = (string)($row['other_accent'] ?? 'silver');
                    $online = (int)($row['other_online_until'] ?? 0) >= time();
                }

                $lastMessage = null;
                if ($row['last_message_id'] !== null) {
                    $lastMessageType = (string)($row['last_message_type'] ?? 'text');

                    if ($row['last_message_deleted_at'] !== null) {
                        $previewBody = 'Message deleted';
                    } elseif ((string)($row['last_message_e2ee_payload'] ?? '') !== '') {
                        // The server intentionally cannot decrypt E2EE message text.
                        // The browser replaces this generic preview after local decryption.
                        $previewBody = 'Older message';
                    } else {
                        $previewBody = message_plain_body(
                            (string)($row['last_message_body'] ?? ''),
                            (int)($row['last_message_body_encrypted'] ?? 0),
                            $row['last_message_body_compact'] ?? null,
                            (int)($row['last_message_body_format'] ?? 0)
                        );
                        $previewBody = censor_for_kid($previewBody, $user);
                    }

                    if ($row['last_message_deleted_at'] === null && $previewBody === '') {
                        $previewBody = match ($lastMessageType) {
                            'image' => 'Photo',
                            'gif' => 'GIF',
                            'video' => 'Video',
                            'audio' => 'Voice message',
                            'video_note' => 'Video message',
                            'sticker' => 'Sticker',
                            default => '',
                        };
                    }

                    $lastMessage = [
                        'id' => (int)$row['last_message_id'],
                        'sender_id' => (int)($row['last_message_sender_id'] ?? 0),
                        'sender_avatar_url' => media_reference_url(
                            (string)($row['last_message_sender_avatar_url'] ?? '')
                        ),
                        'sender_avatar_style' => normalize_avatar_style($row['last_message_sender_avatar_style'] ?? []),
                        'body' => $previewBody,
                        'e2ee_payload' => (string)($row['last_message_e2ee_payload'] ?? ''),
                        'conversation_id' => (int)$row['id'],
                        'message_type' => $lastMessageType,
                        'created_at' => (int)$row['last_message_created_at'],
                    ];
                }

                $items[] = [
                    'id' => (int)$row['id'],
                    'kind' => $kind,
                    'title' => $title,
                    'subtitle' => $subtitle,
                    'avatar_accent' => $avatarAccent,
                    'avatar_url' => $kind === 'dm'
                        ? media_reference_url((string)($row['other_avatar_url'] ?? ''))
                        : media_reference_url((string)($row['avatar_url'] ?? '')),
                    'avatar_style' => $kind === 'dm'
                        ? normalize_avatar_style($row['other_avatar_style'] ?? [])
                        : [],
                    'online' => $online,
                    'role' => $kind === 'dm' ? public_staff_role(['account_role'=>$row['other_account_role']??'member','username'=>$row['other_username']??'']) : 'member',
                    'pinned' => $row['pinned_at'] !== null,
                    'pinned_at' => $row['pinned_at'] !== null ? (int)$row['pinned_at'] : null,
                    'favorite' => $row['favorite_at'] !== null,
                    'favorite_at' => $row['favorite_at'] !== null ? (int)$row['favorite_at'] : null,
                    'archived' => $row['archived_at'] !== null,
                    'archived_at' => $row['archived_at'] !== null ? (int)$row['archived_at'] : null,
                    'muted_until' => $row['muted_until'] !== null ? (int)$row['muted_until'] : null,
                    'muted' => $row['muted_until'] !== null && (int)$row['muted_until'] > time(),
                    'manual_unread' => (bool)($row['manual_unread'] ?? false),
                    'updated_at' => (int)$row['updated_at'],
                    'unread_count' => (int)$row['unread_count'],
                    'last_message' => $lastMessage,
                ];
            }



            ok([
                'conversations' => $items,
                'signature' => $snapshotSignature
            ]);

        case 'create_conversation':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit(
                'create_chat',
                30,
                600,
                (string)$user['id'],
                'device',
                'Too many new chats were created recently. Wait a few minutes and try again.'
            );
            $data = body_json();

            $raw = $data['usernames'] ?? [];
            if (!is_array($raw)) fail('Invalid members.');

            $requested = [];
            foreach ($raw as $value) {
                $username = clean($value, MAX_USERNAME);
                if (!valid_username($username)) fail('One of the usernames is invalid.');
                if (strcasecmp($username, (string)$user['username']) === 0) continue;
                $requested[strtolower($username)] = $username;
            }
            $requested = array_values($requested);

            if (count($requested) < 1) fail('Choose at least one other person.');
            if (count($requested) >= MAX_GROUP_MEMBERS) fail('Group is too large.');

            $pdo = db();
            $placeholders = implode(',', array_fill(0, count($requested), '?'));
            $stmt = $pdo->prepare(
                "SELECT id, username FROM users
                 WHERE disabled_at IS NULL AND username IN ({$placeholders})"
            );
            $stmt->execute($requested);
            $people = $stmt->fetchAll();

            if (count($people) !== count($requested)) fail('One or more selected users no longer exist.', 404);

            $userId = (int)$user['id'];

            foreach ($people as $person) {
                if (!empty(v77_account((int)$person['id'])['school_id'])) fail('School accounts participate through approved class channels.', 403);
                if (!users_are_friends($pdo, $userId, (int)$person['id'])) {
                    fail(
                        'You can only start chats with friends. Send a friend request and wait for it to be accepted.',
                        403
                    );
                }
            }

            $kind = count($people) === 1 ? 'dm' : 'group';
            $directKey = null;

            if ($kind === 'dm') {
                $otherId = (int)$people[0]['id'];
                $directKey = min($userId, $otherId) . ':' . max($userId, $otherId);

                $stmt = $pdo->prepare("SELECT id FROM conversations WHERE kind = 'dm' AND direct_key = ? LIMIT 1");
                $stmt->execute([$directKey]);
                $existing = $stmt->fetchColumn();
                if ($existing) {
                    $pdo->prepare(
                        'UPDATE conversation_members
                         SET hidden_at = NULL
                         WHERE conversation_id = ? AND user_id = ?'
                    )->execute([(int)$existing, $userId]);
                    bump_user_realtime($pdo, $userId, 'inbox_seq');

                    ok(['conversation_id' => (int)$existing]);
                }
            }

            $name = $kind === 'group'
                ? clean($data['name'] ?? 'New group', MAX_GROUP_NAME)
                : null;
            if ($kind === 'group' && $name === '') $name = 'New group';

            $now = time();
            $pdo->beginTransaction();
            try {
                $pdo->prepare(
                    'INSERT INTO conversations (kind, direct_key, name, created_by, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?)'
                )->execute([$kind, $directKey, $name, $userId, $now, $now]);

                $cid = (int)$pdo->lastInsertId();

                $memberStmt = $pdo->prepare(
                    'INSERT INTO conversation_members (conversation_id, user_id, joined_at) VALUES (?, ?, ?)'
                );
                $memberStmt->execute([$cid, $userId, $now]);
                foreach ($people as $person) {
                    $memberStmt->execute([$cid, (int)$person['id'], $now]);
                }

                $readStmt = $pdo->prepare(
                    'INSERT INTO conversation_reads
                     (conversation_id, user_id, last_read_message_id, read_at)
                     VALUES (?, ?, 0, ?)'
                );
                $readStmt->execute([$cid, $userId, $now]);
                foreach ($people as $person) {
                    $readStmt->execute([$cid, (int)$person['id'], $now]);
                }

                bump_conversation_inbox($pdo, $cid);
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();

                if ($kind === 'dm' && $directKey !== null) {
                    $stmt = $pdo->prepare("SELECT id FROM conversations WHERE kind = 'dm' AND direct_key = ? LIMIT 1");
                    $stmt->execute([$directKey]);
                    $existing = $stmt->fetchColumn();
                    if ($existing) {
                    $pdo->prepare(
                        'UPDATE conversation_members
                         SET hidden_at = NULL
                         WHERE conversation_id = ? AND user_id = ?'
                    )->execute([(int)$existing, $userId]);
                    bump_user_realtime($pdo, $userId, 'inbox_seq');

                    ok(['conversation_id' => (int)$existing]);
                }
                }

                throw $e;
            }

            ok(['conversation_id' => $cid], 201);

        case 'set_nickname':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $friendId = (int)($data['friend_id'] ?? 0);
            $nickname = clean($data['nickname'] ?? '', MAX_DISPLAY_NAME);
            $userId = (int)$user['id'];

            if ($friendId <= 0 || $friendId === $userId) {
                fail('Invalid friend.');
            }

            $pdo = db();
            if (!users_are_friends($pdo, $userId, $friendId)) {
                fail('You can only add nicknames to friends.', 403);
            }

            if ($nickname === '') {
                $pdo->prepare(
                    'DELETE FROM friend_nicknames WHERE viewer_id = ? AND friend_id = ?'
                )->execute([$userId, $friendId]);
            } else {
                $pdo->prepare(
                    'INSERT INTO friend_nicknames (viewer_id, friend_id, nickname, updated_at)
                     VALUES (?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE nickname = VALUES(nickname), updated_at = VALUES(updated_at)'
                )->execute([$userId, $friendId, $nickname, time()]);
            }

            bump_user_realtime($pdo, $userId, 'inbox_seq');
            bump_user_realtime($pdo, $userId, 'friend_seq');
            ok(['nickname' => $nickname]);

        case 'schedule_message':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit(
                'schedule_message',
                60,
                600,
                (string)$user['id'],
                'device',
                'Too many messages were scheduled recently.'
            );
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $text = clean($data['body'] ?? '', MAX_MESSAGE);
            $e2eePayload = normalize_e2ee_payload($data['e2ee_payload'] ?? '');
            $scheduledAt = (int)($data['scheduled_at'] ?? 0);
            $replyTo = isset($data['reply_to_id']) && (int)$data['reply_to_id'] > 0
                ? (int)$data['reply_to_id']
                : null;

            if ($text === '' && $e2eePayload === '') fail('Scheduled message cannot be empty.');
            if ($scheduledAt < time() + 30) {
                fail('Choose a time at least 30 seconds from now.');
            }
            if ($scheduledAt > time() + 31536000) {
                fail('Messages can be scheduled up to one year ahead.');
            }

            $conversation = require_member($cid, $userId);
            $pdo = db();
            require_direct_friendship($pdo, $conversation, $userId);
            if ($e2eePayload !== '') {
                validate_e2ee_envelope_for_conversation($pdo, $e2eePayload, $cid, $userId);
            }

            if ($replyTo !== null) {
                $check = $pdo->prepare(
                    'SELECT id FROM messages
                     WHERE id = ? AND conversation_id = ? AND deleted_at IS NULL
                     LIMIT 1'
                );
                $check->execute([$replyTo, $cid]);
                if (!$check->fetchColumn()) $replyTo = null;
            }

            $pendingCount = $pdo->prepare(
                "SELECT COUNT(*) FROM scheduled_messages
                 WHERE sender_id = ? AND status = 'pending'"
            );
            $pendingCount->execute([$userId]);
            if ((int)$pendingCount->fetchColumn() >= 100) {
                fail('You already have 100 scheduled messages. Send or cancel some first.', 409);
            }

            $pdo->prepare(
                "INSERT INTO scheduled_messages
                 (conversation_id, sender_id, body, e2ee_payload, reply_to_id, scheduled_at, created_at, status)
                 VALUES (?, ?, ?, NULLIF(?, ''), ?, ?, ?, 'pending')"
            )->execute([
                $cid,
                $userId,
                encrypted_message_blob($e2eePayload !== '' ? '' : $text),
                $e2eePayload,
                $replyTo,
                $scheduledAt,
                time()
            ]);

            ok([
                'scheduled' => [
                    'id' => (int)$pdo->lastInsertId(),
                    'conversation_id' => $cid,
                    'body' => $e2eePayload !== '' ? '' : censor_for_kid($text, $user),
                    'e2ee_payload' => $e2eePayload,
                    'scheduled_at' => $scheduledAt,
                ]
            ], 201);

        case 'scheduled_messages':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $cid = max(0, (int)($_GET['conversation_id'] ?? 0));
            $pdo = db();
            release_due_scheduled_messages($pdo);

            $sql =
                "SELECT s.id, s.conversation_id, s.body, s.e2ee_payload, s.scheduled_at, s.created_at
                 FROM scheduled_messages s
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = s.conversation_id
                  AND cm.user_id = ?
                 WHERE s.sender_id = ? AND s.status = 'pending'";
            $params = [$userId, $userId];
            if ($cid > 0) {
                $sql .= ' AND s.conversation_id = ?';
                $params[] = $cid;
            }
            $sql .= ' ORDER BY s.scheduled_at ASC LIMIT 100';

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $items = [];
            foreach ($stmt->fetchAll() as $row) {
                $body = (string)($row['e2ee_payload'] ?? '') !== ''
                    ? ''
                    : message_plain_body('', 1, $row['body'], 1);
                $items[] = [
                    'id' => (int)$row['id'],
                    'conversation_id' => (int)$row['conversation_id'],
                    'body' => censor_for_kid($body, $user),
                    'e2ee_payload' => (string)($row['e2ee_payload'] ?? ''),
                    'scheduled_at' => (int)$row['scheduled_at'],
                    'created_at' => (int)$row['created_at'],
                ];
            }
            ok(['scheduled' => $items]);

        case 'cancel_scheduled_message':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $scheduledId = (int)($data['scheduled_id'] ?? 0);
            $pdo = db();
            $stmt = $pdo->prepare(
                "UPDATE scheduled_messages
                 SET status = 'cancelled'
                 WHERE id = ? AND sender_id = ? AND status = 'pending'"
            );
            $stmt->execute([$scheduledId, (int)$user['id']]);
            if ($stmt->rowCount() < 1) fail('Scheduled message not found.', 404);
            ok(['cancelled' => true]);

        case 'group_change_propose':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $changeType = (string)($data['change_type'] ?? '');
            $conversation = require_member($cid, $userId);

            if ((string)$conversation['kind'] !== 'group') {
                fail('Voting is only available in group chats.');
            }
            if (!in_array($changeType, ['name','avatar'], true)) {
                fail('Invalid group change.');
            }

            $pdo = db();
            $proposedName = null;
            $avatarToken = null;

            if ($changeType === 'name') {
                $proposedName = clean($data['name'] ?? '', MAX_GROUP_NAME);
                if ($proposedName === '') fail('Enter a group name.');
                if ($proposedName === (string)($conversation['name'] ?? '')) {
                    fail('That is already the group name.');
                }
            } else {
                $avatarToken = strtolower(trim((string)($data['upload_token'] ?? '')));
                if (!preg_match('/^[a-f0-9]{48}$/', $avatarToken)) {
                    fail('Choose a new group photo.');
                }
            }

            $now = time();
            $pdo->beginTransaction();
            try {
                // Serialize proposal creation per conversation. Without this
                // lock, two tabs can both observe "no open proposal" and then
                // create competing votes for the same group setting.
                $conversationLock = $pdo->prepare(
                    "SELECT id
                     FROM conversations
                     WHERE id = ? AND kind = 'group'
                     LIMIT 1
                     FOR UPDATE"
                );
                $conversationLock->execute([$cid]);
                if (!$conversationLock->fetchColumn()) {
                    $pdo->rollBack();
                    fail('Group chat not found.', 404);
                }

                $pdo->prepare(
                    "UPDATE group_change_proposals
                     SET status = 'expired', resolved_at = ?
                     WHERE conversation_id = ? AND status = 'open' AND expires_at <= ?"
                )->execute([$now, $cid, $now]);

                $open = $pdo->prepare(
                    "SELECT id
                     FROM group_change_proposals
                     WHERE conversation_id = ? AND change_type = ? AND status = 'open'
                     LIMIT 1"
                );
                $open->execute([$cid, $changeType]);
                if ($open->fetchColumn()) {
                    $pdo->rollBack();
                    fail('There is already an active vote for that group setting.', 409);
                }

                if ($changeType === 'avatar') {
                    // Lock the upload too so a second concurrent proposal
                    // cannot race on the same still-unused avatar token.
                    $uploadStmt = $pdo->prepare(
                        "SELECT id, media_type, used_at
                         FROM uploads
                         WHERE user_id = ? AND token = ? AND purpose = 'avatar'
                         LIMIT 1
                         FOR UPDATE"
                    );
                    $uploadStmt->execute([$userId, $avatarToken]);
                    $upload = $uploadStmt->fetch();
                    if (
                        !$upload ||
                        $upload['used_at'] !== null ||
                        (string)$upload['media_type'] !== 'image'
                    ) {
                        $pdo->rollBack();
                        fail('Choose a new group photo.');
                    }
                }

                $pdo->prepare(
                    "INSERT INTO group_change_proposals
                     (conversation_id, proposed_by, change_type, proposed_name,
                      proposed_avatar_token, status, created_at, expires_at)
                     VALUES (?, ?, ?, ?, ?, 'open', ?, ?)"
                )->execute([
                    $cid,
                    $userId,
                    $changeType,
                    $proposedName,
                    $avatarToken,
                    $now,
                    $now + 86400
                ]);
                $proposalId = (int)$pdo->lastInsertId();

                $pdo->prepare(
                    "INSERT INTO group_change_votes (proposal_id, user_id, vote, voted_at)
                     VALUES (?, ?, 'yes', ?)"
                )->execute([$proposalId, $userId, $now]);

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            ok(['proposal_id' => $proposalId], 201);

        case 'group_change_vote':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $proposalId = (int)($data['proposal_id'] ?? 0);
            $vote = (string)($data['vote'] ?? '');
            if (!in_array($vote, ['yes','no'], true)) fail('Invalid vote.');

            $pdo = db();
            $now = time();
            $pdo->beginTransaction();

            try {
                // Lock the proposal before recording/counting votes. This
                // prevents a stale concurrent request from changing the result
                // after another request has already approved/rejected it.
                $stmt = $pdo->prepare(
                    "SELECT p.*, c.kind
                     FROM group_change_proposals p
                     INNER JOIN conversations c ON c.id = p.conversation_id
                     INNER JOIN conversation_members cm
                       ON cm.conversation_id = p.conversation_id
                      AND cm.user_id = ?
                     WHERE p.id = ?
                     LIMIT 1
                     FOR UPDATE"
                );
                $stmt->execute([(int)$user['id'], $proposalId]);
                $proposal = $stmt->fetch();

                if (!$proposal) {
                    $pdo->rollBack();
                    fail('Vote not found.', 404);
                }

                if (
                    (string)$proposal['status'] !== 'open' ||
                    (int)$proposal['expires_at'] <= $now
                ) {
                    if (
                        (string)$proposal['status'] === 'open' &&
                        (int)$proposal['expires_at'] <= $now
                    ) {
                        $pdo->prepare(
                            "UPDATE group_change_proposals
                             SET status = 'expired', resolved_at = ?
                             WHERE id = ? AND status = 'open'"
                        )->execute([$now, $proposalId]);
                        $pdo->commit();
                    } else {
                        $pdo->rollBack();
                    }
                    fail('This vote has ended.', 409);
                }

                $pdo->prepare(
                    "INSERT INTO group_change_votes (proposal_id, user_id, vote, voted_at)
                     VALUES (?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE vote = VALUES(vote), voted_at = VALUES(voted_at)"
                )->execute([$proposalId, (int)$user['id'], $vote, $now]);

                $countStmt = $pdo->prepare(
                    "SELECT
                       COUNT(*) AS member_count,
                       SUM(CASE WHEN gv.vote = 'yes' THEN 1 ELSE 0 END) AS yes_count,
                       SUM(CASE WHEN gv.vote = 'no' THEN 1 ELSE 0 END) AS no_count
                     FROM conversation_members cm
                     INNER JOIN users u
                       ON u.id = cm.user_id
                      AND u.disabled_at IS NULL
                     LEFT JOIN group_change_votes gv
                       ON gv.proposal_id = ?
                      AND gv.user_id = cm.user_id
                     WHERE cm.conversation_id = ?"
                );
                $countStmt->execute([$proposalId, (int)$proposal['conversation_id']]);
                $counts = $countStmt->fetch() ?: [];
                $memberCount = max(1, (int)($counts['member_count'] ?? 1));
                $yesCount = (int)($counts['yes_count'] ?? 0);
                $noCount = (int)($counts['no_count'] ?? 0);
                $status = 'open';

                if ($yesCount > ($memberCount / 2)) {
                    if ((string)$proposal['change_type'] === 'name') {
                        $pdo->prepare(
                            'UPDATE conversations SET name = ?, updated_at = ? WHERE id = ?'
                        )->execute([
                            (string)$proposal['proposed_name'],
                            $now,
                            (int)$proposal['conversation_id']
                        ]);
                    } else {
                        $avatarToken = (string)$proposal['proposed_avatar_token'];
                        $upload = get_owned_upload(
                            $pdo,
                            (int)$proposal['proposed_by'],
                            $avatarToken,
                            'avatar'
                        );
                        if (!$upload || (string)$upload['media_type'] !== 'image') {
                            throw new RuntimeException('Proposed group photo is unavailable.');
                        }
                        $pdo->prepare(
                            'UPDATE conversations SET avatar_url = ?, updated_at = ? WHERE id = ?'
                        )->execute([
                            media_store_reference($avatarToken),
                            $now,
                            (int)$proposal['conversation_id']
                        ]);
                        $pdo->prepare(
                            'UPDATE uploads SET used_at = COALESCE(used_at, ?) WHERE id = ?'
                        )->execute([$now, (int)$upload['id']]);
                    }

                    bump_conversation_change($pdo, (int)$proposal['conversation_id'], $now);
                    $status = 'approved';
                } elseif ($noCount >= (int)ceil($memberCount / 2)) {
                    $status = 'rejected';
                }

                if ($status !== 'open') {
                    $pdo->prepare(
                        "UPDATE group_change_proposals
                         SET status = ?, resolved_at = ?
                         WHERE id = ? AND status = 'open'"
                    )->execute([$status, $now, $proposalId]);
                }

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            ok([
                'status' => $status,
                'yes_count' => $yesCount,
                'no_count' => $noCount,
                'member_count' => $memberCount
            ]);

        case 'pin_conversation':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $pinned = !empty($data['pinned']);
            require_member($cid, $userId);
            $pdo = db();

            $pdo->prepare(
                'UPDATE conversation_members
                 SET pinned_at = ?
                 WHERE conversation_id = ? AND user_id = ?'
            )->execute([$pinned ? time() : null, $cid, $userId]);
            bump_user_realtime($pdo, $userId, 'inbox_seq');

            ok([
                'conversation_id' => $cid,
                'pinned' => $pinned,
                'signature' => inbox_signature($pdo, $userId),
            ]);

        case 'conversation_list_state':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('conversation_list_state', 240, 600, (string)$user['id'], 'device');
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = max(0, (int)($data['conversation_id'] ?? 0));
            if ($cid <= 0) fail('Invalid conversation.');
            require_member($cid, $userId);
            release_session_lock();
            $pdo = db();

            $favorite = filter_var($data['favorite'] ?? false, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            $archived = filter_var($data['archived'] ?? false, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);
            if ($favorite === null || $archived === null) fail('Invalid conversation state.');

            $now = time();
            $pdo->prepare(
                'UPDATE conversation_members
                 SET favorite_at = ?,
                     archived_at = ?,
                     pinned_at = CASE WHEN ? IS NOT NULL THEN NULL ELSE pinned_at END
                 WHERE conversation_id = ? AND user_id = ?'
            )->execute([
                $favorite ? $now : null,
                $archived ? $now : null,
                $archived ? $now : null,
                $cid,
                $userId,
            ]);
            bump_user_realtime($pdo, $userId, 'inbox_seq');

            ok([
                'conversation_id' => $cid,
                'favorite' => $favorite,
                'archived' => $archived,
                'signature' => inbox_signature($pdo, $userId),
            ]);

        case 'notification_preferences':
            $user = current_user();
            $userId = (int)$user['id'];

            if ($method === 'GET') {
                release_session_lock();
                $pdo = db();
                $stmt = $pdo->prepare(
                    'SELECT quiet_enabled, quiet_start_minute, quiet_end_minute, timezone
                     FROM user_notification_preferences
                     WHERE user_id = ?
                     LIMIT 1'
                );
                $stmt->execute([$userId]);
                $prefs = $stmt->fetch() ?: [];

                ok([
                    'preferences' => [
                        'quiet_enabled' => (bool)($prefs['quiet_enabled'] ?? false),
                        'quiet_start_minute' => (int)($prefs['quiet_start_minute'] ?? 1320),
                        'quiet_end_minute' => (int)($prefs['quiet_end_minute'] ?? 420),
                        'timezone' => (string)($prefs['timezone'] ?? 'UTC'),
                    ],
                ]);
            }

            if ($method !== 'POST') fail('Method not allowed.', 405);
            require_csrf();
            rate_limit('notification_preferences', 60, 600, (string)$userId, 'device');
            $data = body_json();

            $enabled = filter_var(
                $data['quiet_enabled'] ?? false,
                FILTER_VALIDATE_BOOL,
                FILTER_NULL_ON_FAILURE
            );
            if ($enabled === null) fail('Invalid quiet-hours setting.');

            $start = (int)($data['quiet_start_minute'] ?? 1320);
            $end = (int)($data['quiet_end_minute'] ?? 420);
            if ($start < 0 || $start > 1439 || $end < 0 || $end > 1439) {
                fail('Invalid quiet-hours time.');
            }

            $timezone = trim((string)($data['timezone'] ?? 'UTC'));
            if ($timezone === '' || strlen($timezone) > 64) {
                fail('Invalid timezone.');
            }
            try {
                new DateTimeZone($timezone);
            } catch (Throwable $e) {
                fail('Invalid timezone.');
            }

            release_session_lock();
            $pdo = db();
            $now = time();
            $pdo->prepare(
                'INSERT INTO user_notification_preferences
                 (user_id, quiet_enabled, quiet_start_minute, quiet_end_minute, timezone, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                   quiet_enabled = VALUES(quiet_enabled),
                   quiet_start_minute = VALUES(quiet_start_minute),
                   quiet_end_minute = VALUES(quiet_end_minute),
                   timezone = VALUES(timezone),
                   updated_at = VALUES(updated_at)'
            )->execute([
                $userId,
                $enabled ? 1 : 0,
                $start,
                $end,
                $timezone,
                $now,
            ]);

            ok([
                'preferences' => [
                    'quiet_enabled' => $enabled,
                    'quiet_start_minute' => $start,
                    'quiet_end_minute' => $end,
                    'timezone' => $timezone,
                ],
            ]);

        case 'conversation_unread_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('conversation_unread', 180, 600, (string)$user['id'], 'device');
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = max(0, (int)($data['conversation_id'] ?? 0));
            $unread = filter_var(
                $data['unread'] ?? true,
                FILTER_VALIDATE_BOOL,
                FILTER_NULL_ON_FAILURE
            );
            if ($cid <= 0) fail('Invalid conversation.');
            if ($unread === null) fail('Invalid unread setting.');

            require_member($cid, $userId);
            release_session_lock();
            $pdo = db();
            $pdo->prepare(
                'UPDATE conversation_members
                 SET manual_unread = ?
                 WHERE conversation_id = ? AND user_id = ?'
            )->execute([$unread ? 1 : 0, $cid, $userId]);
            bump_user_realtime($pdo, $userId, 'inbox_seq');

            ok([
                'conversation_id' => $cid,
                'manual_unread' => $unread,
                'signature' => inbox_signature($pdo, $userId),
            ]);

        case 'conversation_mute':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('conversation_mute', 180, 600, (string)$user['id'], 'device');
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = max(0, (int)($data['conversation_id'] ?? 0));
            $durationSeconds = (int)($data['duration_seconds'] ?? 0);
            $allowedDurations = [0, 3600, 28800, 86400, 604800, 2592000, -1];

            if ($cid <= 0) fail('Invalid conversation.');
            if (!in_array($durationSeconds, $allowedDurations, true)) {
                fail('Invalid mute duration.');
            }

            require_member($cid, $userId);
            release_session_lock();
            $pdo = db();
            $now = time();
            $mutedUntil = null;

            if ($durationSeconds === -1) {
                $mutedUntil = $now + 315360000; // ten years; effectively "until I turn it off"
            } elseif ($durationSeconds > 0) {
                $mutedUntil = $now + $durationSeconds;
            }

            $pdo->prepare(
                'UPDATE conversation_members
                 SET muted_until = ?
                 WHERE conversation_id = ? AND user_id = ?'
            )->execute([$mutedUntil, $cid, $userId]);
            bump_user_realtime($pdo, $userId, 'inbox_seq');

            ok([
                'conversation_id' => $cid,
                'muted' => $mutedUntil !== null,
                'muted_until' => $mutedUntil,
                'signature' => inbox_signature($pdo, $userId),
            ]);

        case 'delete_conversation':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();

            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            require_member($cid, $userId);
            $pdo = db();

            $latestStmt = $pdo->prepare(
                'SELECT COALESCE(MAX(id), 0)
                 FROM messages
                 WHERE conversation_id = ?'
            );
            $latestStmt->execute([$cid]);
            $latestId = (int)$latestStmt->fetchColumn();
            $now = time();

            $pdo->beginTransaction();

            try {
                $pdo->prepare(
                    'UPDATE conversation_members
                     SET hidden_at = ?,
                         cleared_before_message_id = GREATEST(
                             cleared_before_message_id,
                             ?
                         )
                     WHERE conversation_id = ? AND user_id = ?'
                )->execute([$now, $latestId, $cid, $userId]);

                // Clearing/hiding a chat is private membership state. Do not
                // bump the shared conversation sequence or wake other members.
                bump_user_realtime($pdo, $userId, 'inbox_seq');
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            ok([
                'conversation_id' => $cid,
                'cleared_before_message_id' => $latestId
            ]);

        case 'conversation':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $cid = (int)($_GET['id'] ?? 0);
            if ($cid <= 0) fail('Invalid conversation.');

            $conversation = require_member($cid, $userId);
            $pdo = db();
            $info = conversation_info($conversation, $userId);
            $info['preferences'] = conversation_preferences($pdo, $cid, $userId);

            if ((string)$conversation['kind'] === 'dm') {
                $otherId = direct_conversation_other_user($pdo, $cid, $userId);
                $friendship = friendship_between($pdo, $userId, $otherId);
                $info['friendship'] = friendship_for_viewer($friendship, $userId);
                $info['other_user_id'] = $otherId;
                $info['can_message'] = users_are_friends($pdo, $userId, $otherId);
                $info['can_call'] = $info['can_message'];
            } else {
                $info['friendship'] = ['status' => 'accepted', 'request_id' => 0];
                $info['other_user_id'] = 0;
                $info['can_message'] = true;
                $info['can_call'] = false;
            }

            ok(['conversation' => $info]);


        case 'board_items':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            $cid = (int)($_GET['conversation_id'] ?? 0);
            $includeArchived = ((string)($_GET['include_archived'] ?? '0')) === '1';
            release_session_lock();
            if ($cid <= 0) fail('Invalid conversation.');

            require_member($cid, $userId);
            $pdo = db();

            $sql = "SELECT
                        b.id, b.conversation_id, b.created_by, b.kind,
                        b.payload_e2ee, b.payload_nonce, b.status, b.priority,
                        b.due_at, b.assigned_user_id, b.created_at, b.updated_at,
                        creator.display_name AS creator_name,
                        assignee.display_name AS assignee_name
                    FROM conversation_board_items b
                    INNER JOIN users creator
                      ON creator.id = b.created_by AND creator.disabled_at IS NULL
                    LEFT JOIN users assignee
                      ON assignee.id = b.assigned_user_id AND assignee.disabled_at IS NULL
                    WHERE b.conversation_id = ?";
            if (!$includeArchived) $sql .= " AND b.status <> 'archived'";
            $sql .= " ORDER BY
                        CASE b.status WHEN 'open' THEN 0 WHEN 'done' THEN 1 ELSE 2 END,
                        CASE b.priority WHEN 'high' THEN 0 WHEN 'normal' THEN 1 ELSE 2 END,
                        CASE WHEN b.due_at IS NULL THEN 1 ELSE 0 END,
                        b.due_at ASC, b.updated_at DESC, b.id DESC
                      LIMIT 300";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([$cid]);
            $items = $stmt->fetchAll();

            $memberStmt = $pdo->prepare(
                'SELECT u.id, u.username, u.display_name, u.accent, u.avatar_url, u.avatar_style
                 FROM conversation_members cm
                 INNER JOIN users u ON u.id = cm.user_id AND u.disabled_at IS NULL
                 WHERE cm.conversation_id = ?
                 ORDER BY u.display_name ASC, u.id ASC
                 LIMIT 100'
            );
            $memberStmt->execute([$cid]);
            $members = array_map(static fn(array $row): array => public_user($row), $memberStmt->fetchAll());

            ok([
                'conversation_id' => $cid,
                'items' => array_map(static function (array $row): array {
                    return [
                        'id' => (int)$row['id'],
                        'conversation_id' => (int)$row['conversation_id'],
                        'created_by' => (int)$row['created_by'],
                        'creator_name' => (string)$row['creator_name'],
                        'kind' => (string)$row['kind'],
                        'payload_e2ee' => (string)$row['payload_e2ee'],
                        'payload_nonce' => (string)$row['payload_nonce'],
                        'status' => (string)$row['status'],
                        'priority' => (string)$row['priority'],
                        'due_at' => $row['due_at'] !== null ? (int)$row['due_at'] : null,
                        'assigned_user_id' => $row['assigned_user_id'] !== null
                            ? (int)$row['assigned_user_id']
                            : null,
                        'assignee_name' => (string)($row['assignee_name'] ?? ''),
                        'created_at' => (int)$row['created_at'],
                        'updated_at' => (int)$row['updated_at'],
                    ];
                }, $items),
                'members' => $members,
            ]);

        case 'board_create':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('board_write', 120, 600, (string)$user['id'], 'device');
            $data = body_json();
            release_session_lock();

            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $kind = strtolower(trim((string)($data['kind'] ?? 'note')));
            $priority = strtolower(trim((string)($data['priority'] ?? 'normal')));
            $dueAt = isset($data['due_at']) && (int)$data['due_at'] > 0 ? (int)$data['due_at'] : null;
            $assignedUserId = isset($data['assigned_user_id']) && (int)$data['assigned_user_id'] > 0
                ? (int)$data['assigned_user_id']
                : null;
            $payload = normalize_e2ee_payload($data['payload_e2ee'] ?? '');

            if ($cid <= 0) fail('Invalid conversation.');
            if (!in_array($kind, ['note','task','decision'], true)) fail('Invalid board item type.');
            if (!in_array($priority, ['low','normal','high'], true)) fail('Invalid board priority.');
            if ($payload === '') fail('Secure board content is required.');
            if ($dueAt !== null && ($dueAt < time() - 86400 || $dueAt > time() + 315360000)) {
                fail('Board due date is outside the supported range.');
            }

            $conversation = require_member($cid, $userId);
            $pdo = db();
            require_direct_friendship($pdo, $conversation, $userId);
            validate_e2ee_envelope_for_conversation($pdo, $payload, $cid, $userId);

            if ($assignedUserId !== null) {
                $member = $pdo->prepare(
                    'SELECT 1 FROM conversation_members cm
                     INNER JOIN users u ON u.id = cm.user_id AND u.disabled_at IS NULL
                     WHERE cm.conversation_id = ? AND cm.user_id = ?
                     LIMIT 1'
                );
                $member->execute([$cid, $assignedUserId]);
                if (!$member->fetchColumn()) fail('Assignee is not in this conversation.');
            }

            $countStmt = $pdo->prepare(
                "SELECT COUNT(*) FROM conversation_board_items
                 WHERE conversation_id = ? AND status <> 'archived'"
            );
            $countStmt->execute([$cid]);
            if ((int)$countStmt->fetchColumn() >= 300) {
                fail('This SilkBoard has reached 300 active items. Archive older items first.', 409);
            }

            $decoded = json_decode($payload, true);
            $payloadNonce = substr((string)($decoded['nonce'] ?? ''), 0, 96);
            $now = time();

            $stmt = $pdo->prepare(
                "INSERT INTO conversation_board_items
                 (conversation_id, created_by, kind, payload_e2ee, payload_nonce,
                  status, priority, due_at, assigned_user_id, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, 'open', ?, ?, ?, ?, ?)"
            );
            $stmt->execute([
                $cid, $userId, $kind, $payload, $payloadNonce,
                $priority, $dueAt, $assignedUserId, $now, $now
            ]);

            ok([
                'item' => [
                    'id' => (int)$pdo->lastInsertId(),
                    'conversation_id' => $cid,
                    'created_by' => $userId,
                    'creator_name' => (string)$user['display_name'],
                    'kind' => $kind,
                    'payload_e2ee' => $payload,
                    'payload_nonce' => $payloadNonce,
                    'status' => 'open',
                    'priority' => $priority,
                    'due_at' => $dueAt,
                    'assigned_user_id' => $assignedUserId,
                    'assignee_name' => '',
                    'created_at' => $now,
                    'updated_at' => $now,
                ],
            ], 201);

        case 'board_update':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('board_write', 160, 600, (string)$user['id'], 'device');
            $data = body_json();
            release_session_lock();

            $userId = (int)$user['id'];
            $itemId = (int)($data['id'] ?? 0);
            if ($itemId <= 0) fail('Invalid board item.');

            $pdo = db();
            $lookup = $pdo->prepare(
                'SELECT b.*, c.kind AS conversation_kind
                 FROM conversation_board_items b
                 INNER JOIN conversations c ON c.id = b.conversation_id
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = b.conversation_id AND cm.user_id = ?
                 WHERE b.id = ?
                 LIMIT 1'
            );
            $lookup->execute([$userId, $itemId]);
            $item = $lookup->fetch();
            if (!$item) fail('Board item not found.', 404);

            $cid = (int)$item['conversation_id'];
            $conversation = require_member($cid, $userId);
            require_direct_friendship($pdo, $conversation, $userId);

            $kind = array_key_exists('kind', $data)
                ? strtolower(trim((string)$data['kind']))
                : (string)$item['kind'];
            $status = array_key_exists('status', $data)
                ? strtolower(trim((string)$data['status']))
                : (string)$item['status'];
            $priority = array_key_exists('priority', $data)
                ? strtolower(trim((string)$data['priority']))
                : (string)$item['priority'];
            $dueAt = array_key_exists('due_at', $data)
                ? (((int)$data['due_at'] > 0) ? (int)$data['due_at'] : null)
                : ($item['due_at'] !== null ? (int)$item['due_at'] : null);
            $assignedUserId = array_key_exists('assigned_user_id', $data)
                ? (((int)$data['assigned_user_id'] > 0) ? (int)$data['assigned_user_id'] : null)
                : ($item['assigned_user_id'] !== null ? (int)$item['assigned_user_id'] : null);
            $payload = array_key_exists('payload_e2ee', $data)
                ? normalize_e2ee_payload($data['payload_e2ee'])
                : (string)$item['payload_e2ee'];

            if (!in_array($kind, ['note','task','decision'], true)) fail('Invalid board item type.');
            if (!in_array($status, ['open','done','archived'], true)) fail('Invalid board status.');
            if (!in_array($priority, ['low','normal','high'], true)) fail('Invalid board priority.');
            if ($payload === '') fail('Secure board content is required.');
            if ($dueAt !== null && ($dueAt < time() - 86400 || $dueAt > time() + 315360000)) {
                fail('Board due date is outside the supported range.');
            }

            if (array_key_exists('payload_e2ee', $data)) {
                validate_e2ee_envelope_for_conversation($pdo, $payload, $cid, $userId);
            }

            if ($assignedUserId !== null) {
                $member = $pdo->prepare(
                    'SELECT 1 FROM conversation_members cm
                     INNER JOIN users u ON u.id = cm.user_id AND u.disabled_at IS NULL
                     WHERE cm.conversation_id = ? AND cm.user_id = ?
                     LIMIT 1'
                );
                $member->execute([$cid, $assignedUserId]);
                if (!$member->fetchColumn()) fail('Assignee is not in this conversation.');
            }

            $decoded = json_decode($payload, true);
            $payloadNonce = substr((string)($decoded['nonce'] ?? $item['payload_nonce']), 0, 96);
            $now = time();
            $pdo->prepare(
                'UPDATE conversation_board_items
                 SET kind = ?, payload_e2ee = ?, payload_nonce = ?, status = ?,
                     priority = ?, due_at = ?, assigned_user_id = ?, updated_at = ?
                 WHERE id = ?'
            )->execute([
                $kind, $payload, $payloadNonce, $status, $priority,
                $dueAt, $assignedUserId, $now, $itemId
            ]);

            ok([
                'item_id' => $itemId,
                'conversation_id' => $cid,
                'status' => $status,
                'updated_at' => $now,
            ]);

        case 'board_delete':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('board_write', 120, 600, (string)$user['id'], 'device');
            $data = body_json();
            release_session_lock();

            $userId = (int)$user['id'];
            $itemId = (int)($data['id'] ?? 0);
            if ($itemId <= 0) fail('Invalid board item.');

            $pdo = db();
            $lookup = $pdo->prepare(
                'SELECT b.conversation_id
                 FROM conversation_board_items b
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = b.conversation_id AND cm.user_id = ?
                 WHERE b.id = ?
                 LIMIT 1'
            );
            $lookup->execute([$userId, $itemId]);
            $cid = (int)($lookup->fetchColumn() ?: 0);
            if ($cid <= 0) fail('Board item not found.', 404);

            $conversation = require_member($cid, $userId);
            require_direct_friendship($pdo, $conversation, $userId);
            $pdo->prepare('DELETE FROM conversation_board_items WHERE id = ?')->execute([$itemId]);

            ok(['item_id' => $itemId, 'deleted' => true]);

        case 'canvas_get':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            $cid = (int)($_GET['conversation_id'] ?? 0);
            release_session_lock();
            if ($cid <= 0) fail('Invalid conversation.');

            require_member($cid, $userId);
            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT cc.conversation_id, cc.revision, cc.payload_e2ee,
                        cc.payload_nonce, cc.updated_by, cc.updated_at,
                        u.display_name AS updated_by_name
                 FROM conversation_canvas cc
                 INNER JOIN users u ON u.id = cc.updated_by
                 WHERE cc.conversation_id = ?
                 LIMIT 1'
            );
            $stmt->execute([$cid]);
            $canvas = $stmt->fetch();

            if (!$canvas) {
                ok([
                    'canvas' => [
                        'conversation_id' => $cid,
                        'revision' => 0,
                        'payload_e2ee' => '',
                        'payload_nonce' => '',
                        'updated_by' => 0,
                        'updated_by_name' => '',
                        'updated_at' => 0,
                    ],
                ]);
            }

            ok([
                'canvas' => [
                    'conversation_id' => (int)$canvas['conversation_id'],
                    'revision' => (int)$canvas['revision'],
                    'payload_e2ee' => (string)$canvas['payload_e2ee'],
                    'payload_nonce' => (string)$canvas['payload_nonce'],
                    'updated_by' => (int)$canvas['updated_by'],
                    'updated_by_name' => (string)$canvas['updated_by_name'],
                    'updated_at' => (int)$canvas['updated_at'],
                ],
            ]);

        case 'canvas_save':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('canvas_save', 80, 600, (string)$user['id'], 'device');
            $data = body_json();
            release_session_lock();

            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $expectedRevision = max(0, (int)($data['expected_revision'] ?? 0));
            $payload = normalize_e2ee_payload($data['payload_e2ee'] ?? '');
            if ($cid <= 0) fail('Invalid conversation.');
            if ($payload === '') fail('Secure canvas data is required.');

            $conversation = require_member($cid, $userId);
            $pdo = db();
            require_direct_friendship($pdo, $conversation, $userId);
            validate_e2ee_envelope_for_conversation($pdo, $payload, $cid, $userId);

            $decoded = json_decode($payload, true);
            $payloadNonce = substr((string)($decoded['nonce'] ?? ''), 0, 96);
            $now = time();

            $pdo->beginTransaction();
            try {
                $lock = $pdo->prepare(
                    'SELECT revision FROM conversation_canvas
                     WHERE conversation_id = ?
                     FOR UPDATE'
                );
                $lock->execute([$cid]);
                $current = $lock->fetchColumn();

                if ($current === false) {
                    if ($expectedRevision !== 0) {
                        $pdo->rollBack();
                        fail('The shared canvas changed. Refresh it before saving.', 409);
                    }
                    $nextRevision = 1;
                    $pdo->prepare(
                        'INSERT INTO conversation_canvas
                         (conversation_id, revision, payload_e2ee, payload_nonce, updated_by, updated_at)
                         VALUES (?, ?, ?, ?, ?, ?)'
                    )->execute([$cid, $nextRevision, $payload, $payloadNonce, $userId, $now]);
                } else {
                    $currentRevision = (int)$current;
                    if ($currentRevision !== $expectedRevision) {
                        $pdo->rollBack();
                        fail('The shared canvas changed. Refresh it before saving.', 409);
                    }
                    $nextRevision = $currentRevision + 1;
                    $pdo->prepare(
                        'UPDATE conversation_canvas
                         SET revision = ?, payload_e2ee = ?, payload_nonce = ?,
                             updated_by = ?, updated_at = ?
                         WHERE conversation_id = ?'
                    )->execute([
                        $nextRevision, $payload, $payloadNonce, $userId, $now, $cid
                    ]);
                }

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            ok([
                'canvas' => [
                    'conversation_id' => $cid,
                    'revision' => $nextRevision,
                    'updated_by' => $userId,
                    'updated_by_name' => (string)$user['display_name'],
                    'updated_at' => $now,
                ],
            ]);

        case 'pulse_list':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            $cid = (int)($_GET['conversation_id'] ?? 0);
            release_session_lock();
            if ($cid <= 0) fail('Invalid conversation.');

            require_member($cid, $userId);
            $pdo = db();
            $now = time();
            $pdo->prepare(
                'DELETE FROM conversation_pulses
                 WHERE conversation_id = ? AND expires_at <= ?'
            )->execute([$cid, $now]);

            $stmt = $pdo->prepare(
                'SELECT cp.user_id, cp.payload_e2ee, cp.payload_nonce,
                        cp.expires_at, cp.updated_at,
                        u.username, u.display_name, u.accent, u.avatar_url, u.avatar_style
                 FROM conversation_pulses cp
                 INNER JOIN users u ON u.id = cp.user_id AND u.disabled_at IS NULL
                 WHERE cp.conversation_id = ? AND cp.expires_at > ?
                 ORDER BY cp.updated_at DESC
                 LIMIT 100'
            );
            $stmt->execute([$cid, $now]);
            $rows = $stmt->fetchAll();

            ok([
                'pulses' => array_map(static function (array $row): array {
                    return [
                        'user' => public_user($row),
                        'payload_e2ee' => (string)$row['payload_e2ee'],
                        'payload_nonce' => (string)$row['payload_nonce'],
                        'expires_at' => (int)$row['expires_at'],
                        'updated_at' => (int)$row['updated_at'],
                    ];
                }, $rows),
            ]);

        case 'pulse_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('pulse_set', 60, 600, (string)$user['id'], 'device');
            $data = body_json();
            release_session_lock();

            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $ttlMinutes = max(15, min(1440, (int)($data['ttl_minutes'] ?? 120)));
            $payload = normalize_e2ee_payload($data['payload_e2ee'] ?? '');
            if ($cid <= 0) fail('Invalid conversation.');
            if ($payload === '') fail('Secure pulse content is required.');

            $conversation = require_member($cid, $userId);
            $pdo = db();
            require_direct_friendship($pdo, $conversation, $userId);
            validate_e2ee_envelope_for_conversation($pdo, $payload, $cid, $userId);

            $decoded = json_decode($payload, true);
            $payloadNonce = substr((string)($decoded['nonce'] ?? ''), 0, 96);
            $now = time();
            $expiresAt = $now + ($ttlMinutes * 60);

            $pdo->prepare(
                'INSERT INTO conversation_pulses
                 (conversation_id, user_id, payload_e2ee, payload_nonce, expires_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                   payload_e2ee = VALUES(payload_e2ee),
                   payload_nonce = VALUES(payload_nonce),
                   expires_at = VALUES(expires_at),
                   updated_at = VALUES(updated_at)'
            )->execute([$cid, $userId, $payload, $payloadNonce, $expiresAt, $now]);

            ok([
                'expires_at' => $expiresAt,
                'updated_at' => $now,
            ]);

        case 'pulse_clear':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            release_session_lock();

            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            if ($cid <= 0) fail('Invalid conversation.');
            require_member($cid, $userId);

            $pdo = db();
            $pdo->prepare(
                'DELETE FROM conversation_pulses
                 WHERE conversation_id = ? AND user_id = ?'
            )->execute([$cid, $userId]);

            ok(['cleared' => true]);

        case 'call_config':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();

            ok([
                'ice_servers' => call_ice_servers_for_user($user),
                'ttl_seconds' => 3300,
            ]);

        case 'call_start':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            if (
                !is_founder_user($user) &&
                app_meta_value(db(), 'owner_calls_paused_v1') === '1'
            ) {
                fail('New calls are temporarily paused for maintenance. Messaging still works.', 503);
            }
            rate_limit(
                'call_start',
                20,
                600,
                (string)$user['id'],
                'device',
                'Too many calls were started recently. Wait a few minutes and try again.'
            );
            $data = body_json();

            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $callType = (string)($data['call_type'] ?? 'audio');

            if (!in_array($callType, ['audio','video'], true)) {
                fail('Invalid call type.');
            }

            $conversation = require_member($cid, $userId);
            if ((string)$conversation['kind'] !== 'dm') {
                fail('Audio and video calls are currently available in direct messages.');
            }

            $pdo = db();
            require_direct_friendship($pdo, $conversation, $userId);
            if (random_int(1, 50) === 1) cleanup_old_calls($pdo);

            $calleeStmt = $pdo->prepare(
                'SELECT u.id, u.username, u.display_name, u.about, u.avatar_url, u.avatar_style,
                        u.accent, u.last_seen_at
                 FROM conversation_members cm
                 INNER JOIN users u ON u.id = cm.user_id
                 WHERE cm.conversation_id = ?
                   AND cm.user_id <> ?
                   AND u.disabled_at IS NULL
                 LIMIT 1'
            );
            $calleeStmt->execute([$cid, $userId]);
            $callee = $calleeStmt->fetch();

            if (!$callee) fail('The other person is unavailable.', 404);
            if (!empty(v77_account((int)$callee['id'])['school_id'])) fail('School accounts receive calls through approved class channels.', 403);

            // Do not run a table-wide cleanup UPDATE on every 1-second call
            // poll. Stale ringing calls are filtered below, and active calls
            // have their own heartbeat check. An occasional opportunistic
            // sweep keeps old rows tidy without adding a write to every idle
            // user's polling path.
            if (random_int(1, 30) === 1) {
                $cleanupNow = time();
                $pdo->prepare(
                    "UPDATE calls
                     SET status = 'ended', ended_at = ?
                     WHERE
                       (status = 'ringing' AND created_at < ?)
                       OR (
                         status = 'active'
                         AND (
                           (caller_heartbeat > 0 AND caller_heartbeat < ?)
                           OR (callee_heartbeat > 0 AND callee_heartbeat < ?)
                         )
                       )"
                )->execute([
                    $cleanupNow,
                    $cleanupNow - CALL_RING_TTL_SECONDS,
                    $cleanupNow - CALL_HEARTBEAT_GRACE_SECONDS,
                    $cleanupNow - CALL_HEARTBEAT_GRACE_SECONDS
                ]);
            }

            $calleeId = (int)$callee['id'];
            $busyNow = time();
            $newCallId = 0;
            $now = $busyNow;

            // Serialize call creation for both participants. Without this lock,
            // two nearly-simultaneous taps/devices could both pass the busy
            // check and create overlapping calls.
            $pdo->beginTransaction();
            try {
                $lockUsers = $pdo->prepare(
                    'SELECT id FROM users
                     WHERE id IN (?, ?)
                     ORDER BY id
                     FOR UPDATE'
                );
                $lockUsers->execute([$userId, $calleeId]);
                if (count($lockUsers->fetchAll()) !== 2) {
                    $pdo->rollBack();
                    fail('The other person is unavailable.', 404);
                }

                $busy = $pdo->prepare(
                    "SELECT id FROM calls
                     WHERE
                       (
                         (status = 'ringing' AND created_at >= ?)
                         OR (
                           status = 'active'
                           AND caller_heartbeat >= ?
                           AND callee_heartbeat >= ?
                         )
                       )
                       AND (
                         caller_id IN (?, ?)
                         OR callee_id IN (?, ?)
                       )
                     ORDER BY id DESC
                     LIMIT 1"
                );
                $busy->execute([
                    $busyNow - CALL_RING_TTL_SECONDS,
                    $busyNow - CALL_HEARTBEAT_GRACE_SECONDS,
                    $busyNow - CALL_HEARTBEAT_GRACE_SECONDS,
                    $userId,
                    $calleeId,
                    $userId,
                    $calleeId
                ]);

                if ($busy->fetchColumn()) {
                    $pdo->rollBack();
                    fail('You or the other person is already in a call.', 409);
                }

                $insertCall = $pdo->prepare(
                    'INSERT INTO calls
                     (conversation_id, caller_id, callee_id, call_type, status, created_at, caller_heartbeat)
                     VALUES (?, ?, ?, ?, ?, ?, ?)'
                );
                $insertCall->execute([
                    $cid,
                    $userId,
                    $calleeId,
                    $callType,
                    'ringing',
                    $now,
                    $now
                ]);

                $newCallId = (int)$pdo->lastInsertId();
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
            queue_push_job(
                $pdo,
                $userId,
                $cid,
                'call',
                null,
                $newCallId
            );

            ok([
                'call' => [
                    'id' => $newCallId,
                    'conversation_id' => $cid,
                    'call_type' => $callType,
                    'status' => 'ringing',
                    'caller_id' => $userId,
                    'callee_id' => (int)$callee['id'],
                    'other' => public_user($callee),
                    'created_at' => $now
                ]
            ], 201);

        case 'call_answer':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            release_session_lock();
            $callId = (int)($data['call_id'] ?? 0);
            $accept = !empty($data['accept']);

            $pdo = db();
            $call = require_call_participant($pdo, $callId, (int)$user['id']);

            if ((int)$call['callee_id'] !== (int)$user['id']) {
                fail('Only the person receiving the call can answer it.', 403);
            }

            if ((string)$call['status'] !== 'ringing') {
                fail('This call is no longer ringing.', 409);
            }

            $now = time();
            if ((int)$call['created_at'] < $now - CALL_RING_TTL_SECONDS) {
                $pdo->prepare(
                    "UPDATE calls SET status = 'ended', ended_at = ?
                     WHERE id = ? AND status = 'ringing'"
                )->execute([$now, $callId]);
                fail('This call is no longer ringing.', 409);
            }

            if ($accept) {
                $answerStmt = $pdo->prepare(
                    "UPDATE calls
                     SET status = 'active', answered_at = ?, callee_heartbeat = ?
                     WHERE id = ? AND status = 'ringing'"
                );
                $answerStmt->execute([$now, $now, $callId]);
            } else {
                $answerStmt = $pdo->prepare(
                    "UPDATE calls
                     SET status = 'declined', ended_at = ?
                     WHERE id = ? AND status = 'ringing'"
                );
                $answerStmt->execute([$now, $callId]);
            }

            if ($answerStmt->rowCount() !== 1) {
                fail('This call is no longer ringing.', 409);
            }

            if (!$accept) {
                $pdo->prepare('DELETE FROM call_signals WHERE call_id = ?')
                    ->execute([$callId]);
            }

            ok(['status' => $accept ? 'active' : 'declined']);

        case 'call_end':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            release_session_lock();
            $callId = (int)($data['call_id'] ?? 0);

            $pdo = db();
            require_call_participant($pdo, $callId, (int)$user['id']);

            $pdo->prepare(
                "UPDATE calls
                 SET status = 'ended', ended_at = COALESCE(ended_at, ?)
                 WHERE id = ? AND status IN ('ringing','active')"
            )->execute([time(), $callId]);

            $pdo->prepare('DELETE FROM call_signals WHERE call_id = ?')
                ->execute([$callId]);

            ok(['status' => 'ended']);

        case 'call_signal':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            // ICE trickle can generate many small signaling requests. Keep
            // the hot-path limiter in the authenticated session so normal
            // calls do not write to MySQL for every candidate. A periodic
            // account-wide guard still prevents bypass by rotating sessions.
            session_rate_limit(
                'call_signal',
                900,
                60,
                'Call signaling is temporarily rate limited.'
            );
            $guardTick = ((int)($_SESSION['call_signal_guard_tick'] ?? 0) + 1) % 30;
            $_SESSION['call_signal_guard_tick'] = $guardTick;
            if ($guardTick === 1) {
                rate_limit(
                    'call_signal_guard',
                    60,
                    300,
                    (string)$user['id'],
                    'subject',
                    'Call signaling is temporarily rate limited.'
                );
            }

            $data = body_json();

            $callId = (int)($data['call_id'] ?? 0);
            $signalType = strtolower(trim((string)($data['signal_type'] ?? '')));

            if (!in_array($signalType, ['offer','answer','ice','restart'], true)) {
                fail('Invalid call signal.');
            }

            $payloadValue = normalized_call_signal_payload(
                $signalType,
                $data['payload'] ?? null
            );
            $payload = json_encode(
                $payloadValue,
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR
            );

            // Persist the small session limiter update, then release PHP's
            // per-session file lock before touching call state. ICE trickle,
            // message sync, and call polling can now run concurrently instead
            // of queueing behind each other on shared-host PHP.
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_write_close();
            }

            $pdo = db();
            $call = require_call_participant($pdo, $callId, (int)$user['id']);

            if (!in_array((string)$call['status'], ['ringing','active'], true)) {
                fail('This call has ended.', 409);
            }

            $heartbeatColumn = (int)$call['caller_id'] === (int)$user['id']
                ? 'caller_heartbeat'
                : 'callee_heartbeat';
            $lastHeartbeat = (int)($call[$heartbeatColumn] ?? 0);
            $heartbeatNow = time();
            if ($lastHeartbeat < $heartbeatNow - 5) {
                $pdo->prepare(
                    "UPDATE calls SET {$heartbeatColumn} = ? WHERE id = ?"
                )->execute([$heartbeatNow, $callId]);
            }

            $pdo->prepare(
                'INSERT INTO call_signals
                 (call_id, sender_id, signal_type, payload, created_at)
                 VALUES (?, ?, ?, ?, ?)'
            )->execute([
                $callId,
                (int)$user['id'],
                $signalType,
                $payload,
                time()
            ]);

            ok(['signal_id' => (int)$pdo->lastInsertId()], 201);

        case 'call_poll':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            session_rate_limit(
                'call_poll',
                300,
                60,
                'Call updates are being requested too quickly.'
            );
            $userId = (int)$user['id'];
            $callId = max(0, (int)($_GET['call_id'] ?? 0));
            $afterSignal = max(0, (int)($_GET['after_signal'] ?? 0));
            $includeOther = !isset($_GET['include_other']) || (int)$_GET['include_other'] !== 0;

            // Call polling is latency-sensitive and can overlap media signals
            // or message sync. Do not hold PHP's session lock during database
            // work once authentication/rate-limit state has been persisted.
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_write_close();
            }

            $pdo = db();

            // Call cleanup is globally leased so active users do not all run
            // the same status-history UPDATE.
            if (claim_maintenance_slot($pdo, 'stale_calls', 20)) {
                cleanup_stale_calls($pdo);
            }

            if ($callId > 0) {
                $call = require_call_participant($pdo, $callId, $userId);
                $heartbeatColumn = (int)$call['caller_id'] === $userId
                    ? 'caller_heartbeat'
                    : 'callee_heartbeat';

                $lastHeartbeat = (int)($call[$heartbeatColumn] ?? 0);
                $heartbeatNow = time();
                if ($lastHeartbeat < $heartbeatNow - 5) {
                    $pdo->prepare(
                        "UPDATE calls SET {$heartbeatColumn} = ? WHERE id = ?"
                    )->execute([$heartbeatNow, $callId]);
                }

                // If the other side disappeared from an active call, end it
                // instead of leaving a permanent busy call behind.
                if ((string)$call['status'] === 'active') {
                    $otherHeartbeat = (int)$call['caller_id'] === $userId
                        ? (int)($call['callee_heartbeat'] ?? 0)
                        : (int)($call['caller_heartbeat'] ?? 0);

                    if ($otherHeartbeat > 0 && $otherHeartbeat < time() - CALL_HEARTBEAT_GRACE_SECONDS) {
                        $pdo->prepare(
                            "UPDATE calls SET status = 'ended', ended_at = ? WHERE id = ?"
                        )->execute([time(), $callId]);
                        $call['status'] = 'ended';
                        $call['ended_at'] = time();
                    }
                }

                $otherId = (int)$call['caller_id'] === $userId
                    ? (int)$call['callee_id']
                    : (int)$call['caller_id'];

                $other = null;
                if ($includeOther) {
                    $otherStmt = $pdo->prepare(
                        'SELECT id, username, display_name, about, accent, avatar_url, avatar_style,
                                last_seen_at, account_role
                         FROM users WHERE id = ? LIMIT 1'
                    );
                    $otherStmt->execute([$otherId]);
                    $other = $otherStmt->fetch();
                }

                // after_signal is an acknowledgement from this participant:
                // those peer-originated rows have already been applied locally
                // and can be removed. Each signal has exactly one receiver, so
                // this bounds the signaling table without risking the peer.
                if ($afterSignal > 0) {
                    $pdo->prepare(
                        'DELETE FROM call_signals
                         WHERE call_id = ?
                           AND id <= ?
                           AND sender_id <> ?
                         LIMIT 200'
                    )->execute([$callId, $afterSignal, $userId]);
                }

                $signalsStmt = $pdo->prepare(
                    'SELECT id, signal_type, payload, created_at
                     FROM call_signals
                     WHERE call_id = ?
                       AND id > ?
                       AND sender_id <> ?
                     ORDER BY id ASC
                     LIMIT 100'
                );
                $signalsStmt->execute([$callId, $afterSignal, $userId]);

                $signals = [];
                foreach ($signalsStmt->fetchAll() as $signal) {
                    $signals[] = [
                        'id' => (int)$signal['id'],
                        'signal_type' => (string)$signal['signal_type'],
                        'payload' => json_decode((string)$signal['payload'], true),
                        'created_at' => (int)$signal['created_at'],
                    ];
                }

                ok([
                    'call' => [
                        'id' => (int)$call['id'],
                        'conversation_id' => (int)$call['conversation_id'],
                        'caller_id' => (int)$call['caller_id'],
                        'callee_id' => (int)$call['callee_id'],
                        'call_type' => (string)$call['call_type'],
                        'status' => (string)$call['status'],
                        'created_at' => (int)$call['created_at'],
                        'answered_at' => $call['answered_at'] !== null ? (int)$call['answered_at'] : null,
                        'ended_at' => $call['ended_at'] !== null ? (int)$call['ended_at'] : null,
                        'other' => $other ? public_user($other) : null,
                    ],
                    'signals' => $signals
                ]);
            }

            $incomingStmt = $pdo->prepare(
                "SELECT c.*,
                        u.username AS caller_username,
                        u.display_name AS caller_display_name,
                        u.about AS caller_about,
                        u.accent AS caller_accent,
                        u.avatar_url AS caller_avatar_url,
                        u.avatar_style AS caller_avatar_style,
                        u.last_seen_at AS caller_last_seen_at,
                        u.account_role AS caller_account_role,
                        COALESCE(cs.ringtone, 'classic') AS recipient_ringtone,
                        COALESCE(cs.call_banner_text, '') AS recipient_call_banner_text,
                        COALESCE(cs.call_banner_style, 'glass') AS recipient_call_banner_style,
                        COALESCE(fn.nickname, '') AS recipient_nickname
                 FROM calls c
                 INNER JOIN users u ON u.id = c.caller_id
                 LEFT JOIN conversation_settings cs
                   ON cs.conversation_id = c.conversation_id
                  AND cs.user_id = c.callee_id
                 LEFT JOIN friend_nicknames fn
                   ON fn.viewer_id = c.callee_id
                  AND fn.friend_id = c.caller_id
                 WHERE c.callee_id = ?
                   AND c.status = 'ringing'
                   AND c.created_at >= ?
                 ORDER BY c.id DESC
                 LIMIT 1"
            );
            $incomingStmt->execute([$userId, time() - CALL_RING_TTL_SECONDS]);
            $incoming = $incomingStmt->fetch();

            if (!$incoming) {
                ok(['incoming' => null]);
            }

            ok([
                'incoming' => [
                    'id' => (int)$incoming['id'],
                    'conversation_id' => (int)$incoming['conversation_id'],
                    'caller_id' => (int)$incoming['caller_id'],
                    'callee_id' => (int)$incoming['callee_id'],
                    'call_type' => (string)$incoming['call_type'],
                    'status' => (string)$incoming['status'],
                    'created_at' => (int)$incoming['created_at'],
                    'ringtone' => (string)($incoming['recipient_ringtone'] ?? 'classic'),
                    'call_banner_text' => (string)($incoming['recipient_call_banner_text'] ?? ''),
                    'call_banner_style' => (string)($incoming['recipient_call_banner_style'] ?? 'glass'),
                    'other' => public_user([
                        'id' => (int)$incoming['caller_id'],
                        'username' => (string)$incoming['caller_username'],
                        'display_name' => (string)$incoming['caller_display_name'],
                        'about' => (string)$incoming['caller_about'],
                        'accent' => (string)$incoming['caller_accent'],
                        'avatar_url' => (string)$incoming['caller_avatar_url'],
                        'avatar_style' => (string)($incoming['caller_avatar_style'] ?? ''),
                        'last_seen_at' => (int)$incoming['caller_last_seen_at'],
                        'account_role' => (string)($incoming['caller_account_role'] ?? 'member'),
                    ]) + [
                        'nickname' => (string)($incoming['recipient_nickname'] ?? '')
                    ]
                ]
            ]);

        case 'messages':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            // Due scheduled messages are released by the lightweight inbox
            // heartbeat/conversation endpoints. Keep initial history loading
            // free of a global scheduled-message scan.
            $userId = (int)$user['id'];
            $cid = (int)($_GET['conversation_id'] ?? 0);
            $after = max(0, (int)($_GET['after'] ?? 0));
            $before = max(0, (int)($_GET['before'] ?? 0));
            $limit = min(100, max(1, (int)($_GET['limit'] ?? 60)));
            $fetchLimit = $limit + 1;

            $conversation = require_member($cid, $userId);
            $pdo = db();
            purge_expired_messages($pdo, $cid);

            $clearedBefore = max(
                0,
                (int)($conversation['cleared_before_message_id'] ?? 0)
            );

            $where = [
                'm.conversation_id = ?',
                'm.id > ?',
                '(m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())'
            ];
            $params = [$cid, $clearedBefore];
            $order = 'DESC';

            if ($after > 0) {
                $where[] = 'm.id > ?';
                $params[] = $after;
                $order = 'ASC';
            } elseif ($before > 0) {
                $where[] = 'm.id < ?';
                $params[] = $before;
            }

            $sql =
                'SELECT
                    m.id, m.conversation_id, m.sender_id, m.body, m.body_encrypted, m.body_compact, m.body_format, m.repeat_count, m.e2ee_payload, m.created_at, m.updated_at,
                    m.message_type, m.attachment_url, m.attachment_token, m.attachment_mime, m.attachment_name,
                    m.attachment_size, m.duration_ms, m.expires_at,
                    m.edited_at, m.deleted_at, m.reply_to_id,
                    sender.username AS sender_username,
                    sender.display_name AS sender_display_name,
                    sender.accent AS sender_accent,
                    sender.avatar_url AS sender_avatar_url,
                    sender.avatar_style AS sender_avatar_style,
                    sender.account_role AS sender_role,
                    reply.body AS reply_body,
                    reply.body_encrypted AS reply_body_encrypted,
                    reply.body_compact AS reply_body_compact,
                    reply.body_format AS reply_body_format,
                    reply.e2ee_payload AS reply_e2ee_payload,
                    reply.message_type AS reply_message_type,
                    reply.expires_at AS reply_expires_at,
                    reply.deleted_at AS reply_deleted_at,
                    reply_sender.display_name AS reply_sender_display_name
                 FROM messages m
                 INNER JOIN users sender ON sender.id = m.sender_id
                 LEFT JOIN messages reply ON reply.id = m.reply_to_id
                 LEFT JOIN users reply_sender ON reply_sender.id = reply.sender_id
                 WHERE ' . implode(' AND ', $where) .
                " ORDER BY m.id {$order} LIMIT {$fetchLimit}";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
            $hasMore = count($rows) > $limit;
            if ($hasMore) {
                $rows = array_slice($rows, 0, $limit);
            }

            if ($order === 'DESC') $rows = array_reverse($rows);

            ok([
                'messages' => map_messages($pdo, $rows, $user),
                'has_more' => $hasMore,
                'receipt' => receipt_state($pdo, $cid, $userId),
                'typing' => conversation_typing_users($pdo, $cid, $userId),
                'change_seq' => conversation_change_seq($pdo, $cid),
            ]);

        case 'sync':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            release_session_lock();
            // Do not scan scheduled messages on every active long-poll.
            // inbox_state runs frequently and owns due-message release.
            $userId = (int)$user['id'];
            $cid = (int)($_GET['conversation_id'] ?? 0);
            $after = max(0, (int)($_GET['after'] ?? 0));
            $cursor = max(0, (int)($_GET['cursor'] ?? 0));
            $cursorId = max(0, (int)($_GET['cursor_id'] ?? 0));
            $knownSeq = max(0, (int)($_GET['known_seq'] ?? 0));
            $waitMs = min(3000, max(0, (int)($_GET['wait_ms'] ?? 0)));

            $conversation = require_member($cid, $userId);
            $pdo = db();
            $currentSeq = (int)($conversation['change_seq'] ?? 0);

            // Long-poll only when the browser is already caught up. Closing
            // the PHP session lock first is critical: sends/settings/logout
            // from the same browser must never wait behind this request.
            if ($waitMs > 0 && $currentSeq <= $knownSeq) {
                if (session_status() === PHP_SESSION_ACTIVE) {
                    session_write_close();
                }

                $deadline = microtime(true) + ($waitMs / 1000);
                $seqStmt = $pdo->prepare(
                    'SELECT change_seq
                     FROM conversations
                     WHERE id = ?
                     LIMIT 1'
                );

                $pollStartedAt = microtime(true);

                while (microtime(true) < $deadline) {
                    // Stay extremely responsive at the start of a fresh poll,
                    // then back off while a conversation is idle. This cuts
                    // MySQL wake-up queries roughly in half on long-running
                    // chats without making active back-and-forth messaging
                    // feel slower.
                    $elapsed = microtime(true) - $pollStartedAt;
                    $sleepMicros = $elapsed < 1.5
                        ? 45000
                        : ($elapsed < 5.0 ? 80000 : 140000);
                    usleep($sleepMicros);

                    $seqStmt->execute([$cid]);
                    $value = $seqStmt->fetchColumn();

                    if ($value === false) break;

                    $currentSeq = (int)$value;

                    if ($currentSeq > $knownSeq) {
                        break;
                    }
                }
            }

            // A password change / device revocation can happen while this
            // request is waiting with its PHP session lock released. Recheck
            // the database generation before returning any message content.
            revalidate_user_generation($pdo, $user);
            purge_expired_messages($pdo, $cid);

            // Most long-polls time out with no changes. Once the client has a
            // non-zero cursor, avoid the expensive message/reply/reaction scan
            // entirely when the conversation sequence is still unchanged.
            // Expiry cleanup runs first because it can legitimately bump seq.
            $postWaitSeq = conversation_change_seq($pdo, $cid);
            if ($cursor > 0 && $cursorId === 0 && $postWaitSeq <= $knownSeq) {
                ok([
                    'messages' => [],
                    // Do not advance the update cursor on an idle timeout.
                    // A concurrent edit can have an updated_at just before this
                    // response but commit its change_seq just after our check.
                    // Keeping the cursor stable guarantees that next sync can
                    // still retrieve that edit.
                    'cursor' => $cursor,
                    'cursor_id' => $cursorId,
                    'has_more' => false,
                    'receipt' => null,
                    'typing' => conversation_typing_users($pdo, $cid, $userId),
                    'change_seq' => $postWaitSeq,
                    'long_poll' => $waitMs > 0
                ]);
            }

            $clearedBefore = max(
                0,
                (int)($conversation['cleared_before_message_id'] ?? 0)
            );

            // Freeze the top of this sync window so writes arriving while the
            // result is assembled are cleanly picked up by the next request.
            $syncUntil = now_ms();
            // Keep each realtime response modest. The client drains has_more in short
            // bursts, so a smaller batch lowers peak PHP/PDO/JSON memory without
            // sacrificing catch-up correctness.
            $limit = min(100, max(24, (int)($_GET['limit'] ?? 80)));
            $fetchLimit = $limit + 1;

            $stmt = $pdo->prepare(
                'SELECT
                    m.id, m.conversation_id, m.sender_id, m.body, m.body_encrypted, m.body_compact, m.body_format, m.repeat_count, m.e2ee_payload, m.created_at, m.updated_at,
                    m.message_type, m.attachment_url, m.attachment_token, m.attachment_mime, m.attachment_name,
                    m.attachment_size, m.duration_ms, m.expires_at,
                    m.edited_at, m.deleted_at, m.reply_to_id,
                    sender.username AS sender_username,
                    sender.display_name AS sender_display_name,
                    sender.accent AS sender_accent,
                    sender.avatar_url AS sender_avatar_url,
                    sender.avatar_style AS sender_avatar_style,
                    sender.account_role AS sender_role,
                    reply.body AS reply_body,
                    reply.body_encrypted AS reply_body_encrypted,
                    reply.body_compact AS reply_body_compact,
                    reply.body_format AS reply_body_format,
                    reply.e2ee_payload AS reply_e2ee_payload,
                    reply.message_type AS reply_message_type,
                    reply.expires_at AS reply_expires_at,
                    reply.deleted_at AS reply_deleted_at,
                    reply_sender.display_name AS reply_sender_display_name,
                    m.updated_at AS sync_changed_at
                 FROM messages m
                 INNER JOIN users sender ON sender.id = m.sender_id
                 LEFT JOIN messages reply ON reply.id = m.reply_to_id
                 LEFT JOIN users reply_sender ON reply_sender.id = reply.sender_id
                 WHERE m.conversation_id = ?
                   AND m.id > ?
                   AND m.updated_at <= ?
                   AND (
                     m.id > ?
                     OR m.updated_at > ?
                     OR (
                       m.updated_at = ?
                       AND m.id > ?
                     )
                   )
                 ORDER BY
                   m.updated_at ASC,
                   m.id ASC
                 LIMIT ' . $fetchLimit
            );
            $stmt->execute([
                $cid,
                $clearedBefore,
                $syncUntil,
                $after,
                $cursor,
                $cursor,
                $cursorId
            ]);

            $rows = $stmt->fetchAll();
            $hasMore = count($rows) > $limit;

            if ($hasMore) {
                $rows = array_slice($rows, 0, $limit);
            }

            $newestMessageId = 0;
            $nextCursor = $cursor;
            $nextCursorId = $cursorId;

            foreach ($rows as $row) {
                $newestMessageId = max($newestMessageId, (int)$row['id']);

                $changedAt = (int)$row['sync_changed_at'];

                if (
                    $changedAt > $nextCursor ||
                    ($changedAt === $nextCursor && (int)$row['id'] > $nextCursorId)
                ) {
                    $nextCursor = $changedAt;
                    $nextCursorId = (int)$row['id'];
                }
            }

            if (!$hasMore) {
                $nextCursor = $syncUntil;
                $nextCursorId = 0;
            }

            $finalSeq = conversation_change_seq($pdo, $cid);

            // Receipt aggregates are only capable of changing when the
            // conversation sequence changes. Idle long-poll timeouts are by
            // far the common case, so do not run receipt aggregation queries
            // when the client is still on the same sequence.
            $receipt = $finalSeq > $knownSeq
                ? receipt_state($pdo, $cid, $userId)
                : null;

            ok([
                'messages' => map_messages($pdo, $rows, $user),
                'cursor' => $nextCursor,
                'cursor_id' => $nextCursorId,
                'has_more' => $hasMore,
                'receipt' => $receipt,
                'typing' => conversation_typing_users($pdo, $cid, $userId),
                // A partial batch has not consumed the current sequence yet.
                // Keep the older acknowledgement until its final page drains.
                'change_seq' => $hasMore ? $knownSeq : $postWaitSeq,
                'long_poll' => $waitMs > 0
            ]);

        case 'delivery_receipts':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            release_session_lock();

            $data = body_json();
            $rawItems = $data['items'] ?? [];

            if (!is_array($rawItems)) {
                fail('Invalid delivery receipts.');
            }

            $requested = [];
            foreach (array_slice($rawItems, 0, 100) as $item) {
                if (!is_array($item)) continue;

                $cid = max(0, (int)($item['conversation_id'] ?? 0));
                $messageId = max(0, (int)($item['message_id'] ?? 0));
                if ($cid > 0 && $messageId > 0) {
                    $requested[$cid] = max($requested[$cid] ?? 0, $messageId);
                }
            }

            if (!$requested) {
                ok(['acked' => []]);
            }

            $pdo = db();
            $userId = (int)$user['id'];
            $messageIds = array_values(array_unique(array_map('intval', array_values($requested))));
            $messagePlaceholders = implode(',', array_fill(0, count($messageIds), '?'));

            // Validate all requested message/conversation pairs in one indexed
            // query instead of one SELECT per conversation.
            $validate = $pdo->prepare(
                "SELECT m.id, m.conversation_id, m.sender_id
                 FROM messages m
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = m.conversation_id
                  AND cm.user_id = ?
                 WHERE m.id IN ({$messagePlaceholders})"
            );
            $validate->execute(array_merge([$userId], $messageIds));

            $validByConversation = [];
            foreach ($validate->fetchAll() as $row) {
                $cid = (int)$row['conversation_id'];
                $messageId = (int)$row['id'];
                if (
                    isset($requested[$cid]) &&
                    (int)$requested[$cid] === $messageId &&
                    (int)$row['sender_id'] !== $userId
                ) {
                    $validByConversation[$cid] = $messageId;
                }
            }

            if (!$validByConversation) {
                ok(['acked' => []]);
            }

            $conversationIds = array_map('intval', array_keys($validByConversation));
            $conversationPlaceholders = implode(',', array_fill(0, count($conversationIds), '?'));

            // Fetch existing high-water marks in one query. Only genuinely
            // advancing receipts are written and only those chats get a
            // change_seq bump, making retries nearly free.
            $existingStmt = $pdo->prepare(
                "SELECT conversation_id, last_delivered_message_id
                 FROM conversation_deliveries
                 WHERE user_id = ?
                   AND conversation_id IN ({$conversationPlaceholders})"
            );
            $existingStmt->execute(array_merge([$userId], $conversationIds));
            $existing = [];
            foreach ($existingStmt->fetchAll() as $row) {
                $existing[(int)$row['conversation_id']] =
                    (int)$row['last_delivered_message_id'];
            }

            $advancing = [];
            foreach ($validByConversation as $cid => $messageId) {
                if ($messageId > (int)($existing[(int)$cid] ?? 0)) {
                    $advancing[(int)$cid] = (int)$messageId;
                }
            }

            if ($advancing) {
                $now = time();
                $valueSql = [];
                $params = [];

                foreach ($advancing as $cid => $messageId) {
                    $valueSql[] = '(?, ?, ?, ?)';
                    array_push($params, $cid, $userId, $messageId, $now);
                }

                $pdo->beginTransaction();
                try {
                    $upsert = $pdo->prepare(
                        'INSERT INTO conversation_deliveries
                         (conversation_id, user_id, last_delivered_message_id, delivered_at)
                         VALUES ' . implode(',', $valueSql) . '
                         ON DUPLICATE KEY UPDATE
                           delivered_at = IF(
                             VALUES(last_delivered_message_id) > last_delivered_message_id,
                             VALUES(delivered_at),
                             delivered_at
                           ),
                           last_delivered_message_id = GREATEST(
                             last_delivered_message_id,
                             VALUES(last_delivered_message_id)
                           )'
                    );
                    $upsert->execute($params);

                    $changedIds = array_map('intval', array_keys($advancing));
                    $changedPlaceholders = implode(',', array_fill(0, count($changedIds), '?'));
                    $pdo->prepare(
                        "UPDATE conversations
                         SET change_seq = change_seq + 1
                         WHERE id IN ({$changedPlaceholders})"
                    )->execute($changedIds);

                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    throw $e;
                }
            }

            $acked = [];
            foreach ($validByConversation as $cid => $messageId) {
                $acked[] = [
                    'conversation_id' => (int)$cid,
                    'message_id' => (int)$messageId,
                ];
            }

            ok(['acked' => $acked]);


        case 'read_receipt':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            release_session_lock();

            $data = body_json();
            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $messageId = max(0, (int)($data['message_id'] ?? 0));

            if ($cid <= 0 || $messageId <= 0) {
                fail('Invalid read receipt.');
            }

            require_member($cid, $userId);
            $pdo = db();

            $stmt = $pdo->prepare(
                'SELECT m.id
                 FROM messages m
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = m.conversation_id
                  AND cm.user_id = ?
                 WHERE m.id = ?
                   AND m.conversation_id = ?
                   AND m.id > cm.cleared_before_message_id
                   AND m.deleted_at IS NULL
                   AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                 LIMIT 1'
            );
            $stmt->execute([$userId, $messageId, $cid]);

            if (!$stmt->fetchColumn()) {
                fail('Message not found.', 404);
            }

            $deliveryChanged = mark_delivered(
                $pdo,
                $cid,
                $userId,
                $messageId,
                false
            );
            $readChanged = mark_read(
                $pdo,
                $cid,
                $userId,
                $messageId,
                false
            );

            if ($deliveryChanged || $readChanged) {
                touch_conversation_change($pdo, $cid);
            }

            ok([
                'message_id' => $messageId,
                'change_seq' => conversation_change_seq($pdo, $cid)
            ]);

        case 'send':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            // Most send throttling stays in the authenticated session so the
            // normal message path does not need a rate-limit transaction for
            // every single message. A periodic account-wide database guard
            // still prevents bypass by rotating sessions/devices.
            session_rate_limit(
                'message_send',
                120,
                60,
                'You are sending messages too quickly. Wait a moment and try again.'
            );

            // Founder Protection Mode is an emergency traffic brake, not the
            // normal chat limiter. Cache it briefly in the authenticated
            // session so enabling protection does not add a metadata query to
            // every message send on busy installs.
            if (!is_founder_user($user)) {
                $protectionCachedAt = (int)($_SESSION['owner_protection_cached_at'] ?? 0);
                if ($protectionCachedAt < time() - 15) {
                    $_SESSION['owner_protection_enabled'] =
                        app_meta_value(db(), 'owner_protection_mode_v1') === '1';
                    $_SESSION['owner_protection_cached_at'] = time();
                }

                if (!empty($_SESSION['owner_protection_enabled'])) {
                    session_rate_limit(
                        'message_send_protected',
                        30,
                        60,
                        'SilkNex is in protection mode. Slow down for a moment and try again.'
                    );
                }
            }

            $sendGuardTick = ((int)($_SESSION['message_send_guard_tick'] ?? 0) + 1) % 12;
            $_SESSION['message_send_guard_tick'] = $sendGuardTick;
            if ($sendGuardTick === 1) {
                rate_limit(
                    'message_send_guard',
                    60,
                    300,
                    (string)$user['id'],
                    'subject',
                    'You are sending messages too quickly. Wait a moment and try again.'
                );
            }

            // The limiter/CSRF checks above are the only session-dependent
            // work. Release the per-session lock before message validation and
            // MySQL writes so rapid sends/receipts/call updates can overlap.
            release_session_lock();
            $data = body_json();

            $userId = (int)$user['id'];
            $cid = (int)($data['conversation_id'] ?? 0);
            $text = clean($data['body'] ?? '', MAX_MESSAGE);
            $e2eePayload = normalize_e2ee_payload($data['e2ee_payload'] ?? '');
            $replyTo = isset($data['reply_to_id']) && (int)$data['reply_to_id'] > 0
                ? (int)$data['reply_to_id']
                : null;

            $clientNonce = strtolower(trim((string)($data['client_nonce'] ?? '')));
            if ($clientNonce === '') $clientNonce = bin2hex(random_bytes(16));

            if (!preg_match('/^[a-f0-9]{32}$/', $clientNonce)) {
                fail('Invalid message request.', 400);
            }

            $conversation = require_member($cid, $userId);
            $pdo = db();
            require_direct_friendship($pdo, $conversation, $userId);
            if ($e2eePayload !== '') {
                validate_e2ee_envelope_for_conversation($pdo, $e2eePayload, $cid, $userId);
            }
            // Do not run expiry deletion on the latency-critical send path.
            // Read queries already hide expired rows immediately, while the
            // shared maintenance lease reclaims them in bounded background
            // sweeps without making every sender pay for cleanup.

            // Idempotence check comes before attachment validation so a retry
            // succeeds even after its upload was already consumed.
            $existingStmt = $pdo->prepare(
                'SELECT id, conversation_id FROM messages
                 WHERE sender_id = ? AND client_nonce = ?
                 UNION ALL
                 SELECT m.id, m.conversation_id
                 FROM message_repeat_nonces r
                 INNER JOIN messages m ON m.id=r.message_id
                 WHERE r.sender_id=? AND r.client_nonce=?
                 LIMIT 1'
            );
            $existingStmt->execute([$userId, $clientNonce, $userId, $clientNonce]);
            $existing = $existingStmt->fetch();

            $messageId = 0;
            $created = false;
            $changeSeq = 0;

            if ($existing) {
                if ((int)$existing['conversation_id'] !== $cid) {
                    fail('Invalid message request.', 409);
                }
                $messageId = (int)$existing['id'];
            } else {
                $uploadToken = strtolower(trim((string)($data['upload_token'] ?? '')));
                $stickerId = max(0, (int)($data['sticker_id'] ?? 0));
                $externalGif = is_array($data['external_gif'] ?? null)
                    ? $data['external_gif']
                    : null;
                $messageType = 'text';
                $attachmentUrl = null;
                $attachmentToken = null;
                $attachmentMime = null;
                $attachmentName = null;
                $attachmentSize = 0;
                $durationMs = min(7200000, max(0, (int)($data['duration_ms'] ?? 0)));
                $upload = null;
                $hasAttachment = false;

                $attachmentModes =
                    ($uploadToken !== '' ? 1 : 0) +
                    ($stickerId > 0 ? 1 : 0) +
                    ($externalGif !== null ? 1 : 0);
                if ($attachmentModes > 1) {
                    fail('Choose one attachment type at a time.');
                }

                if ($uploadToken !== '') {
                    $upload = get_owned_upload($pdo, $userId, $uploadToken, $e2eePayload !== '' ? 'message_e2ee' : 'message');

                    if (!$upload || $upload['used_at'] !== null) {
                        fail('That attachment is no longer available. Upload it again.', 409);
                    }

                    $messageType = (string)$upload['media_type'];
                    $attachmentToken = $uploadToken;
                    $attachmentMime = (string)$upload['mime_type'];
                    $attachmentName = (string)$upload['original_name'];
                    $attachmentSize = (int)$upload['file_size'];
                    $hasAttachment = true;
                } elseif ($stickerId > 0) {
                    $stickerStmt = $pdo->prepare(
                        'SELECT ss.upload_token, u.mime_type, u.original_name, u.file_size
                         FROM saved_stickers ss
                         INNER JOIN uploads u
                           ON u.token = ss.upload_token
                                  AND u.purpose = \'sticker\'
                         WHERE ss.id = ? AND ss.user_id = ?
                         LIMIT 1'
                    );
                    $stickerStmt->execute([$stickerId, $userId]);
                    $sticker = $stickerStmt->fetch();

                    if (!$sticker) fail('Sticker not found.', 404);

                    $messageType = 'sticker';
                    $attachmentToken = (string)$sticker['upload_token'];
                    $attachmentMime = (string)$sticker['mime_type'];
                    $attachmentName = (string)$sticker['original_name'];
                    $attachmentSize = (int)$sticker['file_size'];
                    $hasAttachment = true;
                } elseif ($externalGif !== null) {
                    $gifUrl = giphy_media_url((string)($externalGif['url'] ?? ''));
                    if ($gifUrl === '') fail('Invalid GIPHY media URL.');

                    $giphyId = clean($externalGif['id'] ?? '', 80);
                    if ($giphyId !== '' && !preg_match('/^[A-Za-z0-9_-]+$/', $giphyId)) {
                        fail('Invalid GIPHY item.');
                    }

                    $messageType = 'gif';
                    $attachmentUrl = $gifUrl;
                    $attachmentMime = 'image/gif';
                    $attachmentName = clean(
                        $externalGif['title'] ?? 'GIPHY GIF',
                        120
                    ) ?: 'GIPHY GIF';
                    $attachmentSize = 0;
                    $hasAttachment = true;
                }

                if ($text === '' && $e2eePayload === '' && !$hasAttachment) {
                    fail('Message cannot be empty.');
                }

                if ($replyTo !== null) {
                    $stmt = $pdo->prepare(
                        'SELECT id
                         FROM messages
                         WHERE id = ?
                           AND conversation_id = ?
                           AND id > ?
                           AND deleted_at IS NULL
                           AND (expires_at IS NULL OR expires_at > UNIX_TIMESTAMP())
                         LIMIT 1'
                    );
                    $stmt->execute([
                        $replyTo,
                        $cid,
                        max(0, (int)($conversation['cleared_before_message_id'] ?? 0))
                    ]);
                    if (!$stmt->fetchColumn()) $replyTo = null;
                }

                $now = time();
                $changedAt = now_ms();
                $compactBody = ($text === '' || $e2eePayload !== '') ? '' : encrypted_message_blob($text);
                $disappearingSeconds = (int)($conversation['disappearing_seconds'] ?? 0);
                $expiresAt = $disappearingSeconds > 0
                    ? $now + $disappearingSeconds
                    : null;

                $pdo->beginTransaction();

                try {
                    $merged = false;
                    if ($text !== '' && $e2eePayload === '' && !$hasAttachment && $replyTo === null) {
                        // Serialize only eligible text sends per conversation,
                        // so simultaneous devices cannot create duplicate rows.
                        $lock = $pdo->prepare('SELECT id FROM conversations WHERE id=? FOR UPDATE');
                        $lock->execute([$cid]);
                        $lastStmt = $pdo->prepare(
                            'SELECT id,sender_id,body,body_encrypted,body_compact,body_format,
                                    e2ee_payload,message_type,reply_to_id,deleted_at,expires_at,
                                    created_at,repeat_count
                             FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT 1 FOR UPDATE'
                        );
                        $lastStmt->execute([$cid]);
                        $last = $lastStmt->fetch();
                        if ($last && (int)$last['sender_id'] === $userId &&
                            (string)$last['message_type'] === 'text' &&
                            (string)($last['e2ee_payload'] ?? '') === '' &&
                            $last['reply_to_id'] === null && $last['deleted_at'] === null &&
                            ((int)($last['expires_at'] ?? 0) === 0 || (int)$last['expires_at'] > $now) &&
                            (int)$last['created_at'] >= $now - 600 &&
                            (int)$last['repeat_count'] < 50 &&
                            hash_equals(
                                message_plain_body(
                                    (string)$last['body'], (int)$last['body_encrypted'],
                                    $last['body_compact'], (int)$last['body_format']
                                ),
                                $text
                            )) {
                            $messageId = (int)$last['id'];
                            $pdo->prepare(
                                'INSERT INTO message_repeat_nonces(sender_id,client_nonce,message_id)
                                 VALUES(?,?,?)'
                            )->execute([$userId,$clientNonce,$messageId]);
                            $pdo->prepare(
                                'UPDATE messages SET repeat_count=repeat_count+1,updated_at=GREATEST(updated_at+1,?),
                                 expires_at=COALESCE(?,expires_at) WHERE id=?'
                            )->execute([$changedAt,$expiresAt,$messageId]);
                            $merged = true;
                        }
                    }
                    if (!$merged) {
                    $pdo->prepare(
                        "INSERT INTO messages
                         (conversation_id, sender_id, body, body_encrypted,
                          body_compact, body_format, e2ee_payload, reply_to_id,
                          created_at, updated_at, client_nonce, message_type,
                          attachment_url, attachment_token, attachment_mime,
                          attachment_name, attachment_size, duration_ms, expires_at)
                         VALUES (?, ?, '', 1, ?, 1, NULLIF(?, ''), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                    )->execute([
                        $cid,
                        $userId,
                        $compactBody,
                        $e2eePayload,
                        $replyTo,
                        $now,
                        $changedAt,
                        $clientNonce,
                        $messageType,
                        $attachmentUrl,
                        $attachmentToken,
                        $attachmentMime,
                        $attachmentName,
                        $attachmentSize,
                        $durationMs,
                        $expiresAt
                    ]);

                    $messageId = (int)$pdo->lastInsertId();
                    v77_review_flags($user, $cid, $clientNonce, is_array($data['school_flags'] ?? null) ? $data['school_flags'] : []);
                    }

                    if ($upload !== null) {
                        $pdo->prepare(
                            'UPDATE uploads SET used_at = ? WHERE id = ? AND used_at IS NULL'
                        )->execute([$now, (int)$upload['id']]);

                        if ($pdo->query('SELECT ROW_COUNT()')->fetchColumn() == 0) {
                            throw new RuntimeException('Attachment was already used.');
                        }
                    }

                    // A new message should bring a previously deleted/hidden chat
                    // back for every member, while each member's cleared history
                    // cutoff still prevents old messages from reappearing.
                    $pdo->prepare(
                        'UPDATE conversation_members
                         SET hidden_at = NULL
                         WHERE conversation_id = ?'
                    )->execute([$cid]);

                    // Mark the sender read before the final activity bump so the
                    // returned sequence already includes both changes. This
                    // avoids an extra change-sequence SELECT on every send.
                    mark_read($pdo, $cid, $userId, $messageId, false);
                    $changeSeq = bump_conversation_change($pdo, $cid, $now, false);
                    if (!$merged) {
                        queue_push_job($pdo,$userId,$cid,'message',$messageId,null);
                    }

                    $pdo->commit();
                    $created = true;
                } catch (PDOException $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();

                    if ((string)$e->getCode() === '23000') {
                        $existingStmt->execute([$userId, $clientNonce, $userId, $clientNonce]);
                        $existing = $existingStmt->fetch();

                        if ($existing && (int)$existing['conversation_id'] === $cid) {
                            $messageId = (int)$existing['id'];
                        } else {
                            throw $e;
                        }
                    } else {
                        throw $e;
                    }
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    throw $e;
                }
            }

            // Fan-out sidebar wakeups after the message transaction. Large group
            // chats can touch many realtime-state rows; doing that while holding
            // the message/conversation transaction open amplifies lock contention.
            // Running it here keeps the critical send transaction short. Retried
            // idempotent sends intentionally wake again, so a transient failure
            // after commit repairs itself on retry without duplicating a message.
            bump_conversation_inbox($pdo, $cid);

            $stmt = $pdo->prepare(
                'SELECT
                    m.id, m.conversation_id, m.sender_id, m.body, m.body_encrypted, m.body_compact, m.body_format, m.repeat_count, m.e2ee_payload, m.created_at, m.updated_at,
                    m.message_type, m.attachment_url, m.attachment_token, m.attachment_mime, m.attachment_name,
                    m.attachment_size, m.duration_ms, m.expires_at,
                    m.edited_at, m.deleted_at, m.reply_to_id,
                    sender.username AS sender_username,
                    sender.display_name AS sender_display_name,
                    sender.accent AS sender_accent,
                    sender.avatar_url AS sender_avatar_url,
                    sender.avatar_style AS sender_avatar_style,
                    sender.account_role AS sender_role,
                    reply.body AS reply_body,
                    reply.body_encrypted AS reply_body_encrypted,
                    reply.body_compact AS reply_body_compact,
                    reply.body_format AS reply_body_format,
                    reply.e2ee_payload AS reply_e2ee_payload,
                    reply.message_type AS reply_message_type,
                    reply.expires_at AS reply_expires_at,
                    reply.deleted_at AS reply_deleted_at,
                    reply_sender.display_name AS reply_sender_display_name
                 FROM messages m
                 INNER JOIN users sender ON sender.id = m.sender_id
                 LEFT JOIN messages reply ON reply.id = m.reply_to_id
                 LEFT JOIN users reply_sender ON reply_sender.id = reply.sender_id
                 WHERE m.id = ?
                 LIMIT 1'
            );
            $stmt->execute([$messageId]);
            $messageRow = $stmt->fetch();

            if (!$messageRow) fail('Message could not be loaded.', 500);

            $mappedMessage = map_message($messageRow, $user);
            $mappedMessage['reactions'] = [];

            // A newly created message cannot have reactions yet, so avoid an
            // unnecessary reaction query on the normal send path. Idempotent
            // retries still reload reactions in case the message is older.
            if (!$created) {
                $mappedMessage = map_messages($pdo, [$messageRow], $user)[0];
            }

            // The sender already has its previous receipt state; live sync will
            // deliver recipient read/delivery changes. Avoid computing receipt
            // aggregates on the latency-critical send response.
            if ($changeSeq <= 0) {
                $changeSeq = conversation_change_seq($pdo, $cid);
            }

            ok(
                [
                    'message' => $mappedMessage,
                    'created' => $created,
                    'change_seq' => $changeSeq
                ],
                $created ? 201 : 200
            );

        case 'message_reaction':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            session_rate_limit(
                'message_reaction',
                180,
                60,
                'You are reacting too quickly.'
            );
            $reactionGuardTick = ((int)($_SESSION['reaction_guard_tick'] ?? 0) + 1) % 20;
            $_SESSION['reaction_guard_tick'] = $reactionGuardTick;
            if ($reactionGuardTick === 1) {
                rate_limit(
                    'message_reaction_guard',
                    55,
                    300,
                    (string)$user['id'],
                    'subject',
                    'You are reacting too quickly.'
                );
            }
            release_session_lock();

            $data = body_json();
            $userId = (int)$user['id'];
            $messageId = max(0, (int)($data['message_id'] ?? 0));
            $reaction = strtolower(trim((string)($data['reaction'] ?? '')));
            $allowedReactions = ['love','laugh','wow','sad','fire','yes'];

            if ($messageId <= 0) fail('Invalid message.');
            if ($reaction !== '' && !in_array($reaction, $allowedReactions, true)) {
                fail('Invalid reaction.');
            }

            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT m.conversation_id, c.kind
                 FROM messages m
                 INNER JOIN conversations c ON c.id = m.conversation_id
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = m.conversation_id
                  AND cm.user_id = ?
                 WHERE m.id = ?
                   AND m.id > cm.cleared_before_message_id
                   AND m.deleted_at IS NULL
                   AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                 LIMIT 1'
            );
            $stmt->execute([$userId, $messageId]);
            $message = $stmt->fetch();
            if (!$message) fail('Message not found.', 404);

            $cid = (int)$message['conversation_id'];
            if ((string)$message['kind'] === 'dm') {
                require_direct_friendship($pdo, require_member($cid, $userId), $userId);
            }

            $changedAt = now_ms();
            $pdo->beginTransaction();

            try {
                if ($reaction === '') {
                    $pdo->prepare(
                        'DELETE FROM message_reactions WHERE message_id = ? AND user_id = ?'
                    )->execute([$messageId, $userId]);
                } else {
                    $now = time();
                    $pdo->prepare(
                        'INSERT INTO message_reactions
                         (message_id, user_id, reaction, created_at, updated_at)
                         VALUES (?, ?, ?, ?, ?)
                         ON DUPLICATE KEY UPDATE
                           reaction = VALUES(reaction),
                           updated_at = VALUES(updated_at)'
                    )->execute([$messageId, $userId, $reaction, $now, $now]);
                }

                $pdo->prepare(
                    'UPDATE messages SET updated_at = ? WHERE id = ?'
                )->execute([$changedAt, $messageId]);

                $changeSeq = bump_conversation_change($pdo, $cid, time());
                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            $reactionStmt = $pdo->prepare(
                'SELECT r.user_id, r.reaction, r.updated_at,
                        u.display_name, u.accent, u.avatar_url, u.avatar_style
                 FROM message_reactions r
                 INNER JOIN users u ON u.id = r.user_id AND u.disabled_at IS NULL
                 WHERE r.message_id = ?
                 ORDER BY r.updated_at ASC, r.user_id ASC'
            );
            $reactionStmt->execute([$messageId]);

            $reactions = array_map(
                static fn(array $item): array => [
                    'user_id' => (int)$item['user_id'],
                    'reaction' => (string)$item['reaction'],
                    'display_name' => (string)$item['display_name'],
                    'accent' => (string)($item['accent'] ?? 'silver'),
                    'avatar_url' => media_reference_url((string)($item['avatar_url'] ?? '')),
                    'avatar_style' => normalize_avatar_style($item['avatar_style'] ?? []),
                    'updated_at' => (int)$item['updated_at'],
                ],
                $reactionStmt->fetchAll()
            );

            ok([
                'message_id' => $messageId,
                'reactions' => $reactions,
                'updated_at' => $changedAt,
                'change_seq' => $changeSeq,
            ]);

        case 'message_reminders':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $pdo = db();

            $reminderStmt = $pdo->prepare(
                "SELECT
                    r.message_id, r.conversation_id, r.remind_at, r.created_at AS reminder_created_at,
                    m.sender_id, m.message_type, m.body, m.body_encrypted, m.body_compact,
                    m.body_format, m.repeat_count, m.e2ee_payload, m.created_at AS message_created_at,
                    sender.display_name AS sender_display_name,
                    c.kind AS conversation_kind,
                    CASE
                      WHEN c.kind = 'group' THEN COALESCE(NULLIF(c.name, ''), 'Group')
                      ELSE COALESCE(
                        (
                          SELECT other_user.display_name
                          FROM conversation_members other_member
                          INNER JOIN users other_user
                            ON other_user.id = other_member.user_id
                           AND other_user.disabled_at IS NULL
                          WHERE other_member.conversation_id = c.id
                            AND other_member.user_id <> ?
                          ORDER BY other_member.user_id
                          LIMIT 1
                        ),
                        'Direct message'
                      )
                    END AS conversation_title
                 FROM message_reminders r
                 INNER JOIN messages m
                   ON m.id = r.message_id
                  AND m.conversation_id = r.conversation_id
                  AND m.deleted_at IS NULL
                  AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                 INNER JOIN conversations c ON c.id = r.conversation_id
                 INNER JOIN conversation_members viewer_member
                   ON viewer_member.conversation_id = r.conversation_id
                  AND viewer_member.user_id = r.user_id
                 INNER JOIN users sender
                   ON sender.id = m.sender_id
                  AND sender.disabled_at IS NULL
                 WHERE r.user_id = ?
                 ORDER BY r.remind_at ASC, r.message_id ASC
                 LIMIT 100"
            );
            $reminderStmt->execute([$userId, $userId]);

            $reminders = [];
            foreach ($reminderStmt->fetchAll() as $reminderRow) {
                $e2eePayload = (string)($reminderRow['e2ee_payload'] ?? '');
                $preview = '';
                if ($e2eePayload === '') {
                    $preview = message_plain_body(
                        (string)($reminderRow['body'] ?? ''),
                        (int)($reminderRow['body_encrypted'] ?? 0),
                        $reminderRow['body_compact'] ?? null,
                        (int)($reminderRow['body_format'] ?? 0)
                    );
                    $preview = censor_for_kid($preview, $user);
                }

                $reminders[] = [
                    'message_id' => (int)$reminderRow['message_id'],
                    'conversation_id' => (int)$reminderRow['conversation_id'],
                    'conversation_title' => (string)$reminderRow['conversation_title'],
                    'sender_id' => (int)$reminderRow['sender_id'],
                    'sender_display_name' => (string)$reminderRow['sender_display_name'],
                    'message_type' => (string)$reminderRow['message_type'],
                    'message_created_at' => (int)$reminderRow['message_created_at'],
                    'remind_at' => (int)$reminderRow['remind_at'],
                    'reminder_created_at' => (int)$reminderRow['reminder_created_at'],
                    'preview' => $preview,
                    'e2ee_payload' => $e2eePayload,
                ];
            }
            ok(['reminders' => $reminders, 'server_time' => time()]);

        case 'message_reminder_set':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('message_reminder_set', 240, 600, (string)$user['id'], 'device');
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = max(0, (int)($data['conversation_id'] ?? 0));
            $messageId = max(0, (int)($data['message_id'] ?? 0));
            $remindAt = max(0, (int)($data['remind_at'] ?? 0));
            $now = time();
            if ($cid <= 0 || $messageId <= 0) fail('Invalid message.');
            if ($remindAt < $now + 30 || $remindAt > $now + 31536000) {
                fail('Choose a reminder between 30 seconds and one year from now.');
            }
            require_member($cid, $userId);
            release_session_lock();
            $pdo = db();

            $messageStmt = $pdo->prepare(
                'SELECT id
                 FROM messages
                 WHERE id = ?
                   AND conversation_id = ?
                   AND deleted_at IS NULL
                   AND (expires_at IS NULL OR expires_at > UNIX_TIMESTAMP())
                 LIMIT 1'
            );
            $messageStmt->execute([$messageId, $cid]);
            if (!$messageStmt->fetchColumn()) fail('Message not found.', 404);

            $pdo->prepare(
                'INSERT INTO message_reminders
                    (user_id, message_id, conversation_id, remind_at, created_at)
                 VALUES (?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                    conversation_id = VALUES(conversation_id),
                    remind_at = VALUES(remind_at),
                    created_at = VALUES(created_at)'
            )->execute([$userId, $messageId, $cid, $remindAt, $now]);

            ok([
                'message_id' => $messageId,
                'conversation_id' => $cid,
                'remind_at' => $remindAt,
            ]);

        case 'message_reminder_delete':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('message_reminder_delete', 360, 600, (string)$user['id'], 'device');
            $data = body_json();
            $userId = (int)$user['id'];
            $messageId = max(0, (int)($data['message_id'] ?? 0));
            if ($messageId <= 0) fail('Invalid reminder.');
            release_session_lock();
            $pdo = db();
            $pdo->prepare(
                'DELETE FROM message_reminders WHERE user_id = ? AND message_id = ?'
            )->execute([$userId, $messageId]);
            ok(['message_id' => $messageId, 'deleted' => true]);

        case 'message_stars':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            $cid = max(0, (int)($_GET['conversation_id'] ?? 0));
            if ($cid > 0) require_member($cid, $userId);
            release_session_lock();
            $pdo = db();

            $sql = "SELECT s.message_id, s.conversation_id, s.starred_at,
                           m.sender_id, m.message_type, m.body, m.body_encrypted,
                           m.body_compact, m.body_format, m.repeat_count, m.e2ee_payload, m.created_at,
                           sender.display_name AS sender_display_name
                    FROM message_stars s
                    INNER JOIN messages m
                      ON m.id = s.message_id
                     AND m.conversation_id = s.conversation_id
                     AND m.deleted_at IS NULL
                     AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                    INNER JOIN conversation_members cm
                      ON cm.conversation_id = s.conversation_id
                     AND cm.user_id = s.user_id
                    INNER JOIN users sender
                      ON sender.id = m.sender_id
                     AND sender.disabled_at IS NULL
                    WHERE s.user_id = ?";
            $params = [$userId];
            if ($cid > 0) {
                $sql .= " AND s.conversation_id = ?";
                $params[] = $cid;
            }
            $sql .= " ORDER BY s.starred_at DESC, s.message_id DESC LIMIT 250";

            $starStmt = $pdo->prepare($sql);
            $starStmt->execute($params);

            $stars = [];
            foreach ($starStmt->fetchAll() as $starRow) {
                $e2eePayload = (string)($starRow['e2ee_payload'] ?? '');
                $preview = '';
                if ($e2eePayload === '') {
                    $preview = message_plain_body(
                        (string)($starRow['body'] ?? ''),
                        (int)($starRow['body_encrypted'] ?? 0),
                        $starRow['body_compact'] ?? null,
                        (int)($starRow['body_format'] ?? 0)
                    );
                    $preview = censor_for_kid($preview, $user);
                }
                $stars[] = [
                    'message_id' => (int)$starRow['message_id'],
                    'conversation_id' => (int)$starRow['conversation_id'],
                    'sender_id' => (int)$starRow['sender_id'],
                    'sender_display_name' => (string)$starRow['sender_display_name'],
                    'message_type' => (string)$starRow['message_type'],
                    'created_at' => (int)$starRow['created_at'],
                    'starred_at' => (int)$starRow['starred_at'],
                    'preview' => $preview,
                    'e2ee_payload' => $e2eePayload,
                ];
            }
            ok(['stars' => $stars]);

        case 'message_star_toggle':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('message_star', 180, 600, (string)$user['id'], 'device');
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = max(0, (int)($data['conversation_id'] ?? 0));
            $messageId = max(0, (int)($data['message_id'] ?? 0));
            if ($cid <= 0 || $messageId <= 0) fail('Invalid message.');
            require_member($cid, $userId);
            release_session_lock();
            $pdo = db();

            $messageStmt = $pdo->prepare(
                'SELECT id
                 FROM messages
                 WHERE id = ?
                   AND conversation_id = ?
                   AND deleted_at IS NULL
                   AND (expires_at IS NULL OR expires_at > UNIX_TIMESTAMP())
                 LIMIT 1'
            );
            $messageStmt->execute([$messageId, $cid]);
            if (!$messageStmt->fetchColumn()) fail('Message not found.', 404);

            $existingStar = $pdo->prepare(
                'SELECT 1 FROM message_stars
                 WHERE user_id = ? AND message_id = ?
                 LIMIT 1'
            );
            $existingStar->execute([$userId, $messageId]);

            if ($existingStar->fetchColumn()) {
                $pdo->prepare(
                    'DELETE FROM message_stars
                     WHERE user_id = ? AND message_id = ?'
                )->execute([$userId, $messageId]);
                ok([
                    'conversation_id' => $cid,
                    'message_id' => $messageId,
                    'starred' => false,
                ]);
            }

            $now = time();
            $pdo->prepare(
                'INSERT INTO message_stars
                 (user_id, message_id, conversation_id, starred_at)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                   conversation_id = VALUES(conversation_id),
                   starred_at = VALUES(starred_at)'
            )->execute([$userId, $messageId, $cid, $now]);

            ok([
                'conversation_id' => $cid,
                'message_id' => $messageId,
                'starred' => true,
                'starred_at' => $now,
            ]);

        case 'message_pins':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            $cid = max(0, (int)($_GET['conversation_id'] ?? 0));
            if ($cid <= 0) fail('Invalid conversation.');
            require_member($cid, $userId);
            release_session_lock();
            $pdo = db();

            $pinStmt = $pdo->prepare(
                "SELECT p.message_id, p.pinned_by, p.pinned_at,
                        m.conversation_id, m.sender_id, m.message_type,
                        m.body, m.body_encrypted, m.body_compact, m.body_format,
                        m.e2ee_payload, m.created_at,
                        sender.display_name AS sender_display_name
                 FROM message_pins p
                 INNER JOIN messages m
                   ON m.id = p.message_id
                  AND m.conversation_id = p.conversation_id
                  AND m.deleted_at IS NULL
                  AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                 INNER JOIN users sender
                   ON sender.id = m.sender_id
                  AND sender.disabled_at IS NULL
                 WHERE p.conversation_id = ?
                 ORDER BY p.pinned_at DESC, p.message_id DESC
                 LIMIT 100"
            );
            $pinStmt->execute([$cid]);

            $pins = [];
            foreach ($pinStmt->fetchAll() as $pinRow) {
                $e2eePayload = (string)($pinRow['e2ee_payload'] ?? '');
                $preview = '';
                if ($e2eePayload === '') {
                    $preview = message_plain_body(
                        (string)($pinRow['body'] ?? ''),
                        (int)($pinRow['body_encrypted'] ?? 0),
                        $pinRow['body_compact'] ?? null,
                        (int)($pinRow['body_format'] ?? 0)
                    );
                    $preview = censor_for_kid($preview, $user);
                }
                $pins[] = [
                    'message_id' => (int)$pinRow['message_id'],
                    'conversation_id' => (int)$pinRow['conversation_id'],
                    'sender_id' => (int)$pinRow['sender_id'],
                    'sender_display_name' => (string)$pinRow['sender_display_name'],
                    'message_type' => (string)$pinRow['message_type'],
                    'created_at' => (int)$pinRow['created_at'],
                    'pinned_by' => (int)$pinRow['pinned_by'],
                    'pinned_at' => (int)$pinRow['pinned_at'],
                    'preview' => $preview,
                    'e2ee_payload' => $e2eePayload,
                ];
            }
            ok(['pins' => $pins]);

        case 'message_pin_toggle':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            rate_limit('message_pin', 120, 600, (string)$user['id'], 'device');
            $data = body_json();
            $userId = (int)$user['id'];
            $cid = max(0, (int)($data['conversation_id'] ?? 0));
            $messageId = max(0, (int)($data['message_id'] ?? 0));
            if ($cid <= 0 || $messageId <= 0) fail('Invalid message.');
            require_member($cid, $userId);
            release_session_lock();
            $pdo = db();

            $messageStmt = $pdo->prepare(
                'SELECT id
                 FROM messages
                 WHERE id = ?
                   AND conversation_id = ?
                   AND deleted_at IS NULL
                   AND (expires_at IS NULL OR expires_at > UNIX_TIMESTAMP())
                 LIMIT 1'
            );
            $messageStmt->execute([$messageId, $cid]);
            if (!$messageStmt->fetchColumn()) fail('Message not found.', 404);

            $existingPin = $pdo->prepare(
                'SELECT 1 FROM message_pins
                 WHERE conversation_id = ? AND message_id = ?
                 LIMIT 1'
            );
            $existingPin->execute([$cid, $messageId]);

            if ($existingPin->fetchColumn()) {
                $pdo->prepare(
                    'DELETE FROM message_pins
                     WHERE conversation_id = ? AND message_id = ?'
                )->execute([$cid, $messageId]);
                ok([
                    'conversation_id' => $cid,
                    'message_id' => $messageId,
                    'pinned' => false,
                ]);
            }

            $pdo->prepare(
                'INSERT INTO message_pins
                    (conversation_id, message_id, pinned_by, pinned_at)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                    pinned_by = VALUES(pinned_by),
                    pinned_at = VALUES(pinned_at)'
            )->execute([$cid, $messageId, $userId, time()]);

            ok([
                'conversation_id' => $cid,
                'message_id' => $messageId,
                'pinned' => true,
            ]);

        case 'saved_messages':
            if ($method !== 'GET') fail('Method not allowed.', 405);
            $user = current_user();
            $userId = (int)$user['id'];
            release_session_lock();
            $pdo = db();

            $savedStmt = $pdo->prepare(
                "SELECT
                    sm.message_id,
                    sm.created_at AS saved_at,
                    m.conversation_id,
                    m.sender_id,
                    m.body,
                    m.body_encrypted,
                    m.body_compact,
                    m.body_format,
                    m.e2ee_payload,
                    m.message_type,
                    m.created_at,
                    sender.display_name AS sender_display_name,
                    c.kind AS conversation_kind,
                    CASE
                      WHEN c.kind = 'group'
                        THEN COALESCE(NULLIF(c.name, ''), 'Group')
                      ELSE COALESCE(
                        (
                          SELECT other_user.display_name
                          FROM conversation_members other_member
                          INNER JOIN users other_user
                            ON other_user.id = other_member.user_id
                           AND other_user.disabled_at IS NULL
                          WHERE other_member.conversation_id = c.id
                            AND other_member.user_id <> ?
                          ORDER BY other_member.user_id
                          LIMIT 1
                        ),
                        'Direct message'
                      )
                    END AS conversation_title
                 FROM saved_messages sm
                 INNER JOIN messages m
                   ON m.id = sm.message_id
                  AND m.deleted_at IS NULL
                  AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                 INNER JOIN conversations c ON c.id = m.conversation_id
                 INNER JOIN conversation_members own_membership
                   ON own_membership.conversation_id = m.conversation_id
                  AND own_membership.user_id = sm.user_id
                  AND m.id > own_membership.cleared_before_message_id
                 INNER JOIN users sender
                   ON sender.id = m.sender_id
                  AND sender.disabled_at IS NULL
                 WHERE sm.user_id = ?
                 ORDER BY sm.created_at DESC, sm.message_id DESC
                 LIMIT 200"
            );
            $savedStmt->execute([$userId, $userId]);

            $savedItems = [];
            foreach ($savedStmt->fetchAll() as $savedRow) {
                $e2eePayload = (string)($savedRow['e2ee_payload'] ?? '');
                $preview = '';
                if ($e2eePayload === '') {
                    $preview = message_plain_body(
                        (string)($savedRow['body'] ?? ''),
                        (int)($savedRow['body_encrypted'] ?? 0),
                        $savedRow['body_compact'] ?? null,
                        (int)($savedRow['body_format'] ?? 0)
                    );
                    $preview = censor_for_kid($preview, $user);
                }

                $savedItems[] = [
                    'message_id' => (int)$savedRow['message_id'],
                    'conversation_id' => (int)$savedRow['conversation_id'],
                    'sender_id' => (int)$savedRow['sender_id'],
                    'sender_display_name' => (string)$savedRow['sender_display_name'],
                    'conversation_kind' => (string)$savedRow['conversation_kind'],
                    'conversation_title' => (string)$savedRow['conversation_title'],
                    'message_type' => (string)$savedRow['message_type'],
                    'created_at' => (int)$savedRow['created_at'],
                    'saved_at' => (int)$savedRow['saved_at'],
                    'preview' => $preview,
                    'e2ee_payload' => $e2eePayload,
                ];
            }

            ok(['items' => $savedItems]);

        case 'saved_message_toggle':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            $userId = (int)$user['id'];
            $messageId = max(0, (int)($data['message_id'] ?? 0));
            if ($messageId <= 0) fail('Invalid message.');
            release_session_lock();
            $pdo = db();

            $savedMessageStmt = $pdo->prepare(
                'SELECT m.conversation_id
                 FROM messages m
                 INNER JOIN conversation_members cm
                   ON cm.conversation_id = m.conversation_id
                  AND cm.user_id = ?
                 WHERE m.id = ?
                   AND m.id > cm.cleared_before_message_id
                   AND m.deleted_at IS NULL
                   AND (m.expires_at IS NULL OR m.expires_at > UNIX_TIMESTAMP())
                 LIMIT 1'
            );
            $savedMessageStmt->execute([$userId, $messageId]);
            $conversationId = (int)($savedMessageStmt->fetchColumn() ?: 0);
            if ($conversationId <= 0) fail('Message not found.', 404);

            $deleteSaved = $pdo->prepare(
                'DELETE FROM saved_messages WHERE user_id = ? AND message_id = ?'
            );
            $deleteSaved->execute([$userId, $messageId]);

            if ($deleteSaved->rowCount() > 0) {
                ok([
                    'message_id' => $messageId,
                    'conversation_id' => $conversationId,
                    'saved' => false,
                ]);
            }

            $pdo->prepare(
                'INSERT IGNORE INTO saved_messages (user_id, message_id, created_at)
                 VALUES (?, ?, ?)'
            )->execute([$userId, $messageId, time()]);

            ok([
                'message_id' => $messageId,
                'conversation_id' => $conversationId,
                'saved' => true,
            ]);

        case 'edit':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            release_session_lock();

            $messageId = (int)($data['message_id'] ?? 0);
            $text = clean($data['body'] ?? '', MAX_MESSAGE);
            $e2eePayload = normalize_e2ee_payload($data['e2ee_payload'] ?? '');
            if ($text === '' && $e2eePayload === '') fail('Message cannot be empty.');

            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT conversation_id, message_type
                 FROM messages
                 WHERE id = ?
                   AND sender_id = ?
                   AND deleted_at IS NULL
                   AND (expires_at IS NULL OR expires_at > UNIX_TIMESTAMP())
                 LIMIT 1'
            );
            $stmt->execute([$messageId, (int)$user['id']]);
            $row = $stmt->fetch();

            if (!$row) fail('Message not found.', 404);
            if ((string)$row['message_type'] !== 'text') {
                fail('Only text messages can be edited.');
            }
            if ($e2eePayload !== '') {
                validate_e2ee_envelope_for_conversation(
                    $pdo, $e2eePayload, (int)$row['conversation_id'], (int)$user['id']
                );
            }

            $now = time();
            $changedAt = now_ms();
            $compactBody = $e2eePayload !== '' ? '' : encrypted_message_blob($text);

            $pdo->beginTransaction();

            try {
                $pdo->prepare(
                    "UPDATE messages
                     SET body = '',
                         body_encrypted = 1,
                         body_compact = ?,
                         body_format = 1,
                         e2ee_payload = NULLIF(?, ''),
                         edited_at = ?,
                         updated_at = ?
                     WHERE id = ?"
                )->execute([$compactBody, $e2eePayload, $now, $changedAt, $messageId]);

                $editNonce = strtolower(trim((string)($data['edit_nonce'] ?? '')));
                if (preg_match('/^[a-f0-9]{32}$/', $editNonce)) {
                    v77_review_flags($user, (int)$row['conversation_id'], $editNonce, is_array($data['school_flags'] ?? null) ? $data['school_flags'] : []);
                }
                touch_reply_dependents(
                    $pdo,
                    (int)$row['conversation_id'],
                    $messageId,
                    $changedAt
                );

                $changeSeq = bump_conversation_change(
                    $pdo,
                    (int)$row['conversation_id'],
                    $now
                );

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            ok([
                'message_id' => $messageId,
                'body' => $e2eePayload !== '' ? '' : censor_for_kid($text, $user),
                'e2ee_payload' => $e2eePayload,
                'edited_at' => $now,
                'updated_at' => $changedAt,
                'change_seq' => $changeSeq
            ]);

        case 'delete':
            if ($method !== 'POST') fail('Method not allowed.', 405);
            $user = current_user();
            require_csrf();
            $data = body_json();
            release_session_lock();

            $messageId = (int)($data['message_id'] ?? 0);

            $pdo = db();
            $stmt = $pdo->prepare(
                'SELECT conversation_id, attachment_url, attachment_token
                 FROM messages
                 WHERE id = ? AND sender_id = ? AND deleted_at IS NULL
                 LIMIT 1'
            );
            $stmt->execute([$messageId, (int)$user['id']]);
            $row = $stmt->fetch();

            if (!$row) fail('Message not found.', 404);

            $now = time();
            $changedAt = now_ms();

            $pdo->beginTransaction();

            try {
                $pdo->prepare(
                    "UPDATE messages
                     SET body = '',
                         body_encrypted = 1,
                         body_compact = NULL,
                         body_format = 1,
                         e2ee_payload = NULL,
                         attachment_url = NULL,
                         attachment_token = NULL,
                         attachment_mime = NULL,
                         attachment_name = NULL,
                         attachment_size = 0,
                         duration_ms = 0,
                         deleted_at = ?,
                         updated_at = ?
                     WHERE id = ?"
                )->execute([$now, $changedAt, $messageId]);

                touch_reply_dependents(
                    $pdo,
                    (int)$row['conversation_id'],
                    $messageId,
                    $changedAt
                );

                $changeSeq = bump_conversation_change(
                    $pdo,
                    (int)$row['conversation_id'],
                    $now
                );

                $pdo->commit();
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }

            $attachmentToken = (string)($row['attachment_token'] ?? '');

            if (preg_match('/^[a-f0-9]{48}$/', $attachmentToken)) {
                // A saved sticker can be referenced by many messages and by
                // saved_stickers itself. Delete only when no live reference
                // remains instead of destroying the shared upload here.
                delete_upload_if_unreferenced(
                    $pdo,
                    $attachmentToken,
                    (int)$user['id']
                );
            } else {
                // Legacy plaintext attachment cleanup. Only old one-use
                // message uploads use this path.
                $attachmentUrl = (string)($row['attachment_url'] ?? '');

                if (str_starts_with($attachmentUrl, 'uploads/')) {
                    $pdo->prepare(
                        "DELETE FROM uploads
                         WHERE user_id = ?
                           AND file_url = ?
                           AND purpose = 'message'"
                    )->execute([(int)$user['id'], $attachmentUrl]);

                    $attachmentPath = resolve_upload_storage_path($attachmentUrl);
                    if ($attachmentPath !== null && is_file($attachmentPath)) {
                        @unlink($attachmentPath);
                    }
                }
            }

            ok([
                'message_id' => $messageId,
                'deleted_at' => $now,
                'updated_at' => $changedAt,
                'change_seq' => $changeSeq
            ]);

        default:
            fail('Unknown API action.', 404);
    }
} catch (Throwable $e) {
    error_log('[SilkNex] ' . $e->getMessage() . "\n" . $e->getTraceAsString());
    fail('SilkNex hit a server error. Check your database settings and PHP error log.', 500);
}
