<?php
declare(strict_types=1);
// Loaded only by api.php. Reuse its authentication, CSRF, encryption and DB layer.
if (!defined('SILKNEX_COMMUNITY_LOADED')) { http_response_code(404); exit; }
function v77_schema(): array {
 $tail=' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
 return array_map(fn($s)=>$s.$tail,[
 "CREATE TABLE IF NOT EXISTS sn_schools(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,domain VARCHAR(190) NOT NULL UNIQUE,seats INT UNSIGNED NOT NULL,extras TEXT NOT NULL,created_at BIGINT UNSIGNED NOT NULL)",
 "CREATE TABLE IF NOT EXISTS sn_accounts(user_id BIGINT UNSIGNED PRIMARY KEY,email VARCHAR(190) NULL UNIQUE,verified_at BIGINT UNSIGNED NULL,school_id BIGINT UNSIGNED NULL,school_role VARCHAR(16) NOT NULL DEFAULT 'student',pending_email VARCHAR(190) NULL,token_hash CHAR(64) NULL,token_expires BIGINT UNSIGNED NULL,KEY idx_school(school_id,user_id),CONSTRAINT fk_sn_account_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)",
 "CREATE TABLE IF NOT EXISTS sn_spaces(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,owner_id BIGINT UNSIGNED NOT NULL,school_id BIGINT UNSIGNED NULL,invite_hash CHAR(64) NULL UNIQUE,rank_names TEXT NOT NULL,created_at BIGINT UNSIGNED NOT NULL,KEY idx_space_school(school_id))",
 "CREATE TABLE IF NOT EXISTS sn_space_members(space_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,rank_level INT NOT NULL DEFAULT 10,PRIMARY KEY(space_id,user_id),KEY idx_member_user(user_id,space_id),FOREIGN KEY(space_id) REFERENCES sn_spaces(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)",
 "CREATE TABLE IF NOT EXISTS sn_channels(conversation_id BIGINT UNSIGNED PRIMARY KEY,space_id BIGINT UNSIGNED NOT NULL,archived TINYINT NOT NULL DEFAULT 0,FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,FOREIGN KEY(space_id) REFERENCES sn_spaces(id) ON DELETE CASCADE,KEY idx_channel_space(space_id,archived))",
 "CREATE TABLE IF NOT EXISTS sn_flags(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,school_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,conversation_id BIGINT UNSIGNED NOT NULL,client_nonce CHAR(32) NOT NULL,categories VARCHAR(200) NOT NULL,status VARCHAR(16) NOT NULL DEFAULT 'open',created_at BIGINT UNSIGNED NOT NULL,reviewed_by BIGINT UNSIGNED NULL,UNIQUE KEY uq_flag(user_id,client_nonce),KEY idx_school_flags(school_id,status,id))",
 "CREATE TABLE IF NOT EXISTS sn_room_members(conversation_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,token_hash CHAR(64) NOT NULL,seen_at BIGINT UNSIGNED NOT NULL,PRIMARY KEY(conversation_id,user_id),KEY idx_room_seen(seen_at))",
 "CREATE TABLE IF NOT EXISTS sn_room_signals(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,conversation_id BIGINT UNSIGNED NOT NULL,sender_id BIGINT UNSIGNED NOT NULL,target_id BIGINT UNSIGNED NOT NULL,target_token CHAR(64) NOT NULL,payload TEXT NOT NULL,created_at BIGINT UNSIGNED NOT NULL,KEY idx_room_target(conversation_id,target_id,id),KEY idx_signal_expiry(created_at))"
 ]);
}
function v77_query(string $sql,array $args=[]): PDOStatement { $s=db()->prepare($sql);$s->execute($args);return $s; }
function v77_account(int $id): array {
 $a=v77_query('SELECT a.*,s.name AS school_name,s.extras,s.seats FROM sn_accounts a LEFT JOIN sn_schools s ON s.id=a.school_id WHERE a.user_id=?',[$id])->fetch();
 return $a?:['user_id'=>$id,'email'=>null,'verified_at'=>null,'school_id'=>null,'school_role'=>'student'];
}
function v77_full(array $user): array { $a=v77_account((int)$user['id']);if(!is_founder_user($user)&&empty($a['verified_at']))fail('Verify your email in Account & spaces to unlock this feature.',403);return $a; }
function v77_school_staff(array $u): array { $a=v77_full($u);if(empty($a['school_id'])||$a['school_role']!=='teacher')fail('A school teacher account is required.',403);return $a; }
function v77_space(int $id,int $uid,int $rank=10,bool $lock=false): array {
 $s=v77_query('SELECT s.*,m.rank_level FROM sn_spaces s JOIN sn_space_members m ON m.space_id=s.id WHERE s.id=? AND m.user_id=?'.($lock?' FOR UPDATE':''),[$id,$uid])->fetch();
 if(!$s||(int)$s['rank_level']<$rank)fail('This server rank cannot perform that action.',403);
 $a=v77_account($uid);if(!empty($a['school_id'])&&(int)$s['school_id']!==(int)$a['school_id'])fail('School accounts can use only their approved school spaces.',403);
 if(!empty($s['school_id'])&&$rank>=20&&($a['school_role']??'')!=='teacher')fail('Only teachers manage school workspaces.',403);return $s;
}
function v77_channel_access(int $cid,int $uid): void {
 $row=v77_query('SELECT c.archived,s.school_id,m.rank_level FROM sn_channels c JOIN sn_spaces s ON s.id=c.space_id LEFT JOIN sn_space_members m ON m.space_id=s.id AND m.user_id=? WHERE c.conversation_id=?',[$uid,$cid])->fetch();
 if($row&&($row['archived']||$row['rank_level']===null))fail('This channel is no longer available.',403);
 if($row){$a=v77_account($uid);if(!empty($a['school_id'])&&(int)$row['school_id']!==(int)$a['school_id'])fail('This channel is outside your school.',403);}
}
function v77_guard(string $action,string $method): void {
 $restricted=['upload','send','edit','schedule_message','create_conversation','group_change_propose','group_change_vote','call_start','call_answer','stories','story_views','story_view','giphy_config','story_create','story_publish','sticker_save','saved_sticker_create','custom_emoji_create','friend_request','friend_request_send','friend_respond','people','search_users','friend_suggestions','stickers','sticker_save_message','canvas_save','board_create','board_update','pulse_set'];
 if(!in_array($action,$restricted,true))return;
 $u=current_user();$a=v77_account((int)$u['id']);if(is_founder_user($u)&&empty($a['school_id']))return;
 $school=!empty($a['school_id']);$limited=empty($a['verified_at']);
 if(!$school&&!$limited)return;
 if($action==='upload')fail($school?'School accounts use text-only messages and cannot upload media.':'Verify your email before uploading media.',403);
 $data=$method==='POST'?body_json():[];
 if(in_array($action,['send','edit'],true)) {
  if(!empty($data['upload_token'])||!empty($data['sticker_id'])||!empty($data['external_gif']))fail('This account can send text only.',403);
  $cid=(int)($data['conversation_id']??0);
  if($action==='edit')$cid=(int)v77_query('SELECT conversation_id FROM messages WHERE id=? AND sender_id=?',[(int)($data['message_id']??0),(int)$u['id']])->fetchColumn();
  if($school) {
   $s=v77_query('SELECT s.school_id FROM sn_channels c JOIN sn_spaces s ON s.id=c.space_id JOIN conversation_members m ON m.conversation_id=c.conversation_id AND m.user_id=? WHERE c.conversation_id=? AND c.archived=0',[(int)$u['id'],$cid])->fetchColumn();
   if((int)$s!==(int)$a['school_id'])fail('School messaging is limited to your approved class channels.',403);
  } elseif($action==='send')rate_limit('unverified_text',25,86400,(string)$u['id'],'subject','Email-unverified accounts can send 25 text messages per day.');
  return;
 }
 if($limited||$school)fail($school?'This feature is unavailable for managed school accounts. Use your class workspace.':'Verify your email to unlock this feature.',403);
}
function v77_create_channel(int $spaceId,string $name,int $owner): int {
 if((int)v77_query('SELECT COUNT(*) FROM sn_channels WHERE space_id=? AND archived=0',[$spaceId])->fetchColumn()>=12)fail('A server supports up to 12 active channels.',409);
 $now=time();v77_query("INSERT INTO conversations(kind,name,created_by,created_at,updated_at) VALUES('group',?,?,?,?)",[$name,$owner,$now,$now]);$cid=(int)db()->lastInsertId();
 v77_query('INSERT INTO sn_channels(conversation_id,space_id) VALUES(?,?)',[$cid,$spaceId]);
 v77_query('INSERT INTO conversation_members(conversation_id,user_id,joined_at) SELECT ?,user_id,? FROM sn_space_members WHERE space_id=?',[$cid,$now,$spaceId]);
 v77_query('INSERT INTO conversation_reads(conversation_id,user_id,last_read_message_id,read_at) SELECT ?,user_id,0,? FROM sn_space_members WHERE space_id=?',[$cid,$now,$spaceId]);return $cid;
}
function v77_review_flags(array $u,int $cid,string $nonce,array $categories): void {
 $a=v77_account((int)$u['id']);if(empty($a['school_id']))return;
 $valid=['harassment','threats','sexual_content','self_harm','substances','personal_information'];
 $categories=array_values(array_intersect($valid,array_filter($categories,'is_string')));if(!$categories)return;
 v77_query('INSERT IGNORE INTO sn_flags(school_id,user_id,conversation_id,client_nonce,categories,created_at) VALUES(?,?,?,?,?,?)',[(int)$a['school_id'],(int)$u['id'],$cid,$nonce,implode(',',$categories),time()]);
}
function v77_route(string $action,string $method): void {
 if(!str_starts_with($action,'community_'))return;
 $u=current_user();$uid=(int)$u['id'];
 $read=['community_boot','community_spaces','community_space','community_stats','community_schools','community_flags'];
 if(in_array($action,$read,true)){if($method!=='GET')fail('Method not allowed.',405);$d=$_GET;}
 else {if($method!=='POST')fail('Method not allowed.',405);require_csrf();session_rate_limit('community_write',120,60);$d=body_json();}
 switch($action){
 case 'community_boot':
  $a=v77_account($uid);ok(['account'=>['email'=>$a['email'],'verified'=>!empty($a['verified_at']),'school_id'=>$a['school_id'],'school_name'=>$a['school_name']??null,'school_role'=>$a['school_role'],'founder'=>is_founder_user($u)],'pricing'=>['base_cents'=>1500,'extra_cents'=>200,'basis'=>'per student per contracted billing period','extras'=>['class_projects'=>'Teacher-managed class projects']]]);
 case 'community_email_request':
  rate_limit('email_verify_request',5,3600,(string)$uid,'subject');
  $email=strtolower(trim((string)($d['email']??'')));if(strlen($email)>190||!filter_var($email,FILTER_VALIDATE_EMAIL))fail('Enter a valid email address.');
  $a=v77_account($uid);if(!empty($a['school_id'])&&$a['email']!==$email)fail('A teacher or Founder must manage changes to a school identity.',403);
  $from=(string)(getenv('SILKNEX_MAIL_FROM')?:config()['mail_from']??'');
  if(!filter_var($from,FILTER_VALIDATE_EMAIL))fail('Email delivery is not configured. The site owner must set SILKNEX_MAIL_FROM and enable PHP mail delivery.',503);
  if(v77_query('SELECT user_id FROM sn_accounts WHERE email=? AND user_id<>?',[$email,$uid])->fetchColumn())fail('This email is already associated with an account.',409);
  $token=bin2hex(random_bytes(16));$hash=hash('sha256',$token);
  v77_query('INSERT INTO sn_accounts(user_id,pending_email,token_hash,token_expires) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE pending_email=VALUES(pending_email),token_hash=VALUES(token_hash),token_expires=VALUES(token_expires)',[$uid,$email,$hash,time()+900]);
  if(!function_exists('mail')||!@mail($email,'Verify your Silknex account',"Your verification code is:\n\n".$token."\n\nExpires in 15 minutes. If you did not request this, ignore it.",'From: '.$from)) {
   v77_query('UPDATE sn_accounts SET token_hash=NULL,token_expires=NULL WHERE user_id=? AND token_hash=?',[$uid,$hash]);fail('Email could not be sent. Ask the site owner to check mail delivery.',503);
  }ok(['sent'=>true]);
 case 'community_email_verify':
  rate_limit('email_verify',10,900,(string)$uid,'subject');$token=strtolower(trim((string)($d['code']??'')));if(!preg_match('/^[a-f0-9]{32}$/',$token))fail('Enter the code from your email.');
  $pdo=db();$pdo->beginTransaction();try{
   $a=v77_query('SELECT * FROM sn_accounts WHERE user_id=? FOR UPDATE',[$uid])->fetch();
   if(!$a||empty($a['token_hash'])||!hash_equals($a['token_hash'],hash('sha256',$token))||(int)$a['token_expires']<time()){ $pdo->rollBack();fail('Verification code is invalid or expired.',400); }
   $domain=substr(strrchr($a['pending_email'],'@'),1);$school=v77_query('SELECT * FROM sn_schools WHERE domain=? FOR UPDATE',[$domain])->fetch();
   if($school&&(int)($a['school_id']??0)!==(int)$school['id']&&(int)v77_query('SELECT COUNT(*) FROM sn_accounts WHERE school_id=? AND school_role=\'student\'',[$school['id']])->fetchColumn()>=(int)$school['seats']){$pdo->rollBack();fail('This school has no available seats. Ask its administrator.',409);}
   v77_query('UPDATE sn_accounts SET email=pending_email,verified_at=?,school_id=?,pending_email=NULL,token_hash=NULL,token_expires=NULL WHERE user_id=?',[time(),$a['school_id']??($school['id']??null),$uid]);if($a['school_id']||$school)v77_query("UPDATE scheduled_messages SET status='cancelled' WHERE sender_id=? AND status='pending'",[$uid]);$pdo->commit();
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}ok(['verified'=>true]);
 case 'community_schools':
  require_founder();ok(['schools'=>v77_query('SELECT id,name,domain,seats,extras FROM sn_schools ORDER BY id DESC LIMIT 100')->fetchAll()]);
 case 'community_school_save':
  require_founder();$name=clean($d['name']??'',100);$domain=strtolower(trim((string)($d['domain']??'')));$seats=(int)($d['seats']??0);$extras=array_values(array_intersect(['class_projects'],(array)($d['extras']??[])));
  if($name===''||!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/',$domain)||$seats<1||$seats>100000)fail('Enter a school name, exact verified school domain and seat count.');
  // Lock the school before counting enrollment, using the same school lock as verification.
  $pdo=db();$pdo->beginTransaction();try{
   v77_query('INSERT INTO sn_schools(name,domain,seats,extras,created_at) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),seats=VALUES(seats),extras=VALUES(extras)',[$name,$domain,$seats,json_encode($extras),time()]);
   $id=(int)v77_query('SELECT id FROM sn_schools WHERE domain=? FOR UPDATE',[$domain])->fetchColumn();
   $enrolled=(int)v77_query("SELECT COUNT(*) FROM sn_accounts WHERE verified_at IS NOT NULL AND school_role='student' AND SUBSTRING_INDEX(email,'@',-1)=?",[$domain])->fetchColumn();
   if($seats<$enrolled){$pdo->rollBack();fail('Seat count cannot be below current verified enrollment.',409);}
   v77_query("UPDATE sn_accounts SET school_id=? WHERE school_id IS NULL AND verified_at IS NOT NULL AND SUBSTRING_INDEX(email,'@',-1)=?",[$id,$domain]);
   v77_query("UPDATE scheduled_messages sm JOIN sn_accounts a ON a.user_id=sm.sender_id SET sm.status='cancelled' WHERE a.school_id=? AND sm.status='pending'",[$id]);
   owner_audit($pdo,$uid,'school.configure',$domain,['seats'=>$seats,'extras'=>$extras]);$pdo->commit();
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
  ok(['school_id'=>$id,'quote_cents'=>$seats*(1500+200*count($extras)),'billing_active'=>false]);
 case 'community_teacher_set':
  require_founder();$sid=(int)($d['school_id']??0);$teacher=filter_var($d['teacher']??false,FILTER_VALIDATE_BOOL);$pdo=db();$pdo->beginTransaction();try{
   $school=v77_query('SELECT * FROM sn_schools WHERE id=? FOR UPDATE',[$sid])->fetch();if(!$school){$pdo->rollBack();fail('School not found.',404);}
   $target=v77_query('SELECT u.id,a.school_role FROM users u JOIN sn_accounts a ON a.user_id=u.id WHERE u.username=? AND a.school_id=? AND a.verified_at IS NOT NULL FOR UPDATE',[clean($d['username']??'',24),$sid])->fetch();
   if(!$target){$pdo->rollBack();fail('Choose a verified account enrolled in this school.',404);}
   if(!$teacher&&$target['school_role']!=='student'&&(int)v77_query("SELECT COUNT(*) FROM sn_accounts WHERE school_id=? AND school_role='student'",[$sid])->fetchColumn()>=(int)$school['seats']){$pdo->rollBack();fail('Add a student seat before changing this teacher to a student.',409);}
   v77_query('UPDATE sn_accounts SET school_role=? WHERE user_id=?',[$teacher?'teacher':'student',$target['id']]);owner_audit($pdo,$uid,'school.role',(string)$target['id'],['role'=>$teacher?'teacher':'student']);$pdo->commit();
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}ok();
 case 'community_spaces':
  v77_full($u);ok(['spaces'=>v77_query('SELECT s.id,s.name,s.school_id,m.rank_level,s.rank_names FROM sn_spaces s JOIN sn_space_members m ON m.space_id=s.id WHERE m.user_id=? ORDER BY s.id DESC LIMIT 100',[$uid])->fetchAll()]);
 case 'community_space_create':
 case 'community_class_create':
  $a=v77_full($u);$school=null;
  if($action==='community_class_create'){$a=v77_school_staff($u);$school=(int)$a['school_id'];if(!in_array('class_projects',json_decode($a['extras']??'[]',true)?:[],true))fail('The school must enable the $2 class-project add-on.',403);}
  elseif(!empty($a['school_id']))fail('School accounts use teacher-managed classes.',403);
  $name=clean($d['name']??'',100);if($name==='')fail('Choose a server or class name.');rate_limit('space_create',10,3600,(string)$uid,'subject');
  $invite=bin2hex(random_bytes(16));$pdo=db();$pdo->beginTransaction();try{
   v77_query('INSERT INTO sn_spaces(name,owner_id,school_id,invite_hash,rank_names,created_at) VALUES(?,?,?,?,?,?)',[$name,$uid,$school,$school?null:hash('sha256',$invite),json_encode(['10'=>'Member','20'=>'Moderator','30'=>'Admin','40'=>'Owner']),time()]);$sid=(int)$pdo->lastInsertId();
   v77_query('INSERT INTO sn_space_members(space_id,user_id,rank_level) VALUES(?,?,40)',[$sid,$uid]);
   $names=array_values(array_unique(array_filter(array_map('trim',explode(',',(string)($d['usernames']??''))))));if(count($names)>29)throw new RuntimeException('A class supports up to 30 participants.');
   if($school)foreach($names as $name){$id=v77_query('SELECT u.id FROM users u JOIN sn_accounts a ON a.user_id=u.id WHERE u.username=? AND a.school_id=? AND a.verified_at IS NOT NULL AND u.disabled_at IS NULL',[$name,$school])->fetchColumn();if(!$id)throw new RuntimeException('Every class member must verify an email for this school.');if((int)$id!==$uid)v77_query('INSERT INTO sn_space_members(space_id,user_id,rank_level) VALUES(?,?,10)',[$sid,$id]);}
   $cid=v77_create_channel($sid,'general',$uid);$pdo->commit();bump_conversation_inbox($pdo,$cid);
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}ok(['space_id'=>$sid,'conversation_id'=>$cid,'invite'=>$school?null:$invite],201);
 case 'community_space_join':
  $a=v77_full($u);if(!empty($a['school_id']))fail('Teachers enroll school accounts in classes.',403);
  $token=strtolower(trim((string)($d['invite']??'')));if(!preg_match('/^[a-f0-9]{32}$/',$token))fail('Invalid invite code.');rate_limit('space_join',20,3600,(string)$uid,'subject');
  $pdo=db();$pdo->beginTransaction();try{
   $s=v77_query('SELECT * FROM sn_spaces WHERE invite_hash=? AND school_id IS NULL FOR UPDATE',[hash('sha256',$token)])->fetch();if(!$s){$pdo->rollBack();fail('Invite is invalid or expired.',404);} $sid=(int)$s['id'];
   if(!v77_query('SELECT user_id FROM sn_space_members WHERE space_id=? AND user_id=?',[$sid,$uid])->fetchColumn()&&(int)v77_query('SELECT COUNT(*) FROM sn_space_members WHERE space_id=?',[$sid])->fetchColumn()>=30){$pdo->rollBack();fail('This server has reached its 30-member limit.',409);}
   v77_query('INSERT IGNORE INTO sn_space_members(space_id,user_id,rank_level) VALUES(?,?,10)',[$sid,$uid]);
   v77_query('INSERT IGNORE INTO conversation_members(conversation_id,user_id,joined_at) SELECT conversation_id,?,? FROM sn_channels WHERE space_id=? AND archived=0',[$uid,time(),$sid]);
   v77_query('INSERT IGNORE INTO conversation_reads(conversation_id,user_id,last_read_message_id,read_at) SELECT conversation_id,?,0,? FROM sn_channels WHERE space_id=? AND archived=0',[$uid,time(),$sid]);$pdo->commit();bump_user_realtime($pdo,$uid,'inbox_seq');
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}ok(['space_id'=>$sid]);
 case 'community_space':
  $sid=(int)($d['space_id']??0);$s=v77_space($sid,$uid);unset($s['invite_hash']);ok(['space'=>$s,'channels'=>v77_query('SELECT c.conversation_id,c.archived,v.name FROM sn_channels c JOIN conversations v ON v.id=c.conversation_id WHERE c.space_id=? AND c.archived=0 ORDER BY c.conversation_id LIMIT 12',[$sid])->fetchAll(),'members'=>v77_query('SELECT u.id,u.username,u.display_name,m.rank_level FROM sn_space_members m JOIN users u ON u.id=m.user_id WHERE m.space_id=? ORDER BY m.rank_level DESC,u.id LIMIT 30',[$sid])->fetchAll()]);
 case 'community_channel_create':
  $sid=(int)($d['space_id']??0);$name=clean($d['name']??'',60);if(!$name)fail('Enter a channel name.');$pdo=db();$pdo->beginTransaction();try{$s=v77_space($sid,$uid,30,true);if($s['school_id'])v77_school_staff($u);$cid=v77_create_channel($sid,$name,$uid);$pdo->commit();bump_conversation_inbox($pdo,$cid);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}ok(['conversation_id'=>$cid]);
 case 'community_channel_delete':
  $cid=(int)($d['conversation_id']??0);$sid=(int)v77_query('SELECT space_id FROM sn_channels WHERE conversation_id=?',[$cid])->fetchColumn();$s=v77_space($sid,$uid,30);if($s['school_id'])v77_school_staff($u);
  v77_query('UPDATE sn_channels SET archived=1 WHERE conversation_id=?',[$cid]);v77_query('UPDATE conversation_members SET hidden_at=? WHERE conversation_id=?',[time(),$cid]);bump_conversation_inbox(db(),$cid);ok(['archived'=>true]);
 case 'community_rank_set':
  $sid=(int)($d['space_id']??0);$s=v77_space($sid,$uid,40);$target=(int)($d['user_id']??0);$rank=(int)($d['rank']??0);if($target===(int)$s['owner_id']||!in_array($rank,[10,20,30],true))fail('The owner rank is protected. Choose Member, Moderator or Admin.');
  if($s['school_id'])fail('School ranks are assigned through school administration.',403);
  v77_query('UPDATE sn_space_members SET rank_level=? WHERE space_id=? AND user_id=?',[$rank,$sid,$target]);ok();
 case 'community_member_remove':
  $sid=(int)($d['space_id']??0);$target=(int)($d['user_id']??0);$pdo=db();$pdo->beginTransaction();try{
   $s=v77_space($sid,$uid,20,true);if($s['school_id'])v77_school_staff($u);
   $rank=v77_query('SELECT rank_level FROM sn_space_members WHERE space_id=? AND user_id=? FOR UPDATE',[$sid,$target])->fetchColumn();
   if($rank===false||$target===(int)$s['owner_id']||(int)$rank>=(int)$s['rank_level']){$pdo->rollBack();fail('You can remove only members below your rank.',403);}
   v77_query('DELETE m FROM conversation_members m JOIN sn_channels c ON c.conversation_id=m.conversation_id WHERE c.space_id=? AND m.user_id=?',[$sid,$target]);
   v77_query('DELETE r FROM sn_room_members r JOIN sn_channels c ON c.conversation_id=r.conversation_id WHERE c.space_id=? AND r.user_id=?',[$sid,$target]);
   v77_query('DELETE FROM sn_space_members WHERE space_id=? AND user_id=?',[$sid,$target]);$pdo->commit();bump_user_realtime($pdo,$target,'inbox_seq');
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}ok();
 case 'community_rank_names':
  $sid=(int)($d['space_id']??0);v77_space($sid,$uid,40);$names=[];foreach([10,20,30,40] as $r){$name=clean($d['names'][(string)$r]??'',24);if(!$name)fail('Give each rank a name.');$names[(string)$r]=$name;}v77_query('UPDATE sn_spaces SET rank_names=? WHERE id=?',[json_encode($names),$sid]);ok();
 case 'community_invite_rotate':
  $sid=(int)($d['space_id']??0);$s=v77_space($sid,$uid,30);if($s['school_id'])fail('School classes do not use public invite codes.',403);$token=bin2hex(random_bytes(16));v77_query('UPDATE sn_spaces SET invite_hash=? WHERE id=?',[hash('sha256',$token),$sid]);ok(['invite'=>$token]);
 case 'community_flags':
  $a=v77_school_staff($u);$before=max(0,(int)($d['before']??0));ok(['flags'=>v77_query('SELECT f.id,f.categories,f.status,f.created_at,u.username FROM sn_flags f JOIN users u ON u.id=f.user_id WHERE f.school_id=? AND f.status=\'open\' AND (?=0 OR f.id<?) ORDER BY f.id DESC LIMIT 50',[$a['school_id'],$before,$before])->fetchAll()]);
 case 'community_flag_review':
  $a=v77_school_staff($u);$id=(int)($d['id']??0);v77_query("UPDATE sn_flags SET status='reviewed',reviewed_by=? WHERE id=? AND school_id=?",[$uid,$id,$a['school_id']]);ok();
 case 'community_stats':
  require_founder();$now=time();$accounts=v77_query('SELECT COUNT(*) AS verified,SUM(school_id IS NOT NULL) AS school_accounts FROM sn_accounts WHERE verified_at IS NOT NULL')->fetch();
  $schools=v77_query('SELECT seats,extras FROM sn_schools LIMIT 10000')->fetchAll();$quote=0;foreach($schools as $s)$quote+=(int)$s['seats']*(1500+200*count(json_decode($s['extras'],true)?:[]));
  ok(['stats'=>['verified_accounts'=>(int)$accounts['verified'],'school_accounts'=>(int)$accounts['school_accounts'],'servers'=>(int)v77_query('SELECT COUNT(*) FROM sn_spaces')->fetchColumn(),'schools'=>count($schools),'school_quote_cents'=>$quote,'open_review_flags'=>(int)v77_query("SELECT COUNT(*) FROM sn_flags WHERE status='open'")->fetchColumn(),'active_group_participants'=>(int)v77_query('SELECT COUNT(*) FROM sn_room_members WHERE seen_at>?',[$now-45])->fetchColumn(),'online_now'=>(int)v77_query('SELECT COUNT(*) FROM users WHERE disabled_at IS NULL AND online_until>?',[$now])->fetchColumn(),'sampled_at'=>$now]]);
 default:v77_room_route($action,$method,$d,$u);
 }
}
function v77_room_route(string $action,string $method,array $d,array $u): never {
 if(!in_array($action,['community_room_join','community_room_poll','community_room_signal','community_room_leave'],true))fail('Unknown community action.',404);
 $a=v77_full($u);$uid=(int)$u['id'];$cid=(int)($d['conversation_id']??0);$conv=require_member($cid,$uid);if($conv['kind']!=='group')fail('Choose a group conversation.');
 if(!empty($a['school_id'])){$sid=v77_query('SELECT s.school_id FROM sn_channels c JOIN sn_spaces s ON s.id=c.space_id WHERE c.conversation_id=? AND c.archived=0',[$cid])->fetchColumn();if((int)$sid!==(int)$a['school_id'])fail('School calls are limited to approved class channels.',403);}
 if(!is_founder_user($u)&&app_meta_value(db(),'owner_calls_paused_v1')==='1'&&$action==='community_room_join')fail('New calls are temporarily paused.',503);
 $now=time();
 if($action==='community_room_join'){
  rate_limit('group_call_join',30,600,(string)$uid,'subject');$pdo=db();$pdo->beginTransaction();try{
   v77_query('SELECT id FROM conversations WHERE id=? FOR UPDATE',[$cid]);v77_query('DELETE FROM sn_room_members WHERE conversation_id=? AND seen_at<?',[$cid,$now-45]);
   $exists=v77_query('SELECT user_id FROM sn_room_members WHERE conversation_id=? AND user_id=?',[$cid,$uid])->fetchColumn();if(!$exists&&(int)v77_query('SELECT COUNT(*) FROM sn_room_members WHERE conversation_id=?',[$cid])->fetchColumn()>=6){$pdo->rollBack();fail('This group call has reached its six-person limit.',409);}
   $token=bin2hex(random_bytes(24));v77_query('INSERT INTO sn_room_members(conversation_id,user_id,token_hash,seen_at) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE token_hash=VALUES(token_hash),seen_at=VALUES(seen_at)',[$cid,$uid,hash('sha256',$token),$now]);$pdo->commit();
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
  v77_query('DELETE FROM sn_room_signals WHERE created_at<? LIMIT 500',[$now-300]);ok(['token'=>$token,'ice_servers'=>call_ice_servers_for_user($u),'max_participants'=>6]);
 }
 $token=(string)($d['token']??'');$hash=hash('sha256',$token);$member=v77_query('SELECT token_hash FROM sn_room_members WHERE conversation_id=? AND user_id=? AND seen_at>?',[$cid,$uid,$now-45])->fetchColumn();if(!$member||!hash_equals((string)$member,$hash))fail('This group-call session ended. Join again.',409);
 if($action==='community_room_leave'){v77_query('DELETE FROM sn_room_members WHERE conversation_id=? AND user_id=? AND token_hash=?',[$cid,$uid,$hash]);ok();}
 if($action==='community_room_poll'){
  v77_query('UPDATE sn_room_members SET seen_at=? WHERE conversation_id=? AND user_id=? AND token_hash=?',[$now,$cid,$uid,$hash]);
  $peers=v77_query('SELECT m.user_id,m.token_hash AS session,u.display_name FROM sn_room_members m JOIN users u ON u.id=m.user_id WHERE m.conversation_id=? AND m.seen_at>? AND u.disabled_at IS NULL ORDER BY m.user_id LIMIT 6',[$cid,$now-45])->fetchAll();
  $signals=v77_query('SELECT id,sender_id,payload FROM sn_room_signals WHERE conversation_id=? AND target_id=? AND target_token=? AND id>? AND created_at>? ORDER BY id LIMIT 100',[$cid,$uid,$hash,max(0,(int)($d['after']??0)),$now-300])->fetchAll();ok(['peers'=>$peers,'signals'=>$signals]);
 }
 session_rate_limit('group_signal',180,60);$target=(int)($d['target_id']??0);if($target===$uid)fail('Invalid call target.');
 $payload=$d['payload']??null;if(!is_array($payload)||!in_array($payload['type']??'', ['offer','answer','candidate'],true))fail('Invalid signaling payload.');
 $payload['session']=$member;
 $json=json_encode($payload,JSON_UNESCAPED_SLASHES);if(!is_string($json)||strlen($json)>32768)fail('Signaling payload is too large.');
 $targetToken=v77_query('SELECT token_hash FROM sn_room_members WHERE conversation_id=? AND user_id=? AND seen_at>?',[$cid,$target,$now-45])->fetchColumn();if(!$targetToken)fail('This participant left the call.',409);
 v77_query('INSERT INTO sn_room_signals(conversation_id,sender_id,target_id,target_token,payload,created_at) VALUES(?,?,?,?,?,?)',[$cid,$uid,$target,$targetToken,$json,$now]);ok();
}
