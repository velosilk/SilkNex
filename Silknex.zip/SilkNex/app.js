(() => {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];

  // One compact-shell decision keeps JS behavior aligned with the final CSS.
  // The short/coarse clause catches modern phones in landscape without forcing
  // normal desktop/laptop windows into the mobile navigation model.
  function usesMobileShell() {
    try {
      const query = window.matchMedia?.(
        "(max-width: 900px), (pointer: coarse) and (max-height: 540px)"
      );
      if (query) return Boolean(query.matches);
    } catch {}
    return (window.innerWidth || document.documentElement.clientWidth) <= 900;
  }

  function synchronizeAppShell() {
    const app = $("#appView");
    const chatOpen = Boolean(state.me && state.activeId);
    app?.classList.toggle("mobile-chat-open", chatOpen);
    app?.classList.toggle("desktop-chat-active", chatOpen);
  }

  // Compatibility helpers used by media, polling, and older embedded browsers.
  // They preserve the modern fast path while keeping optional APIs from making
  // core chat features fail when a browser exposes only part of the platform.
  function createAbortController() {
    if (typeof AbortController === "function") {
      try { return new AbortController(); } catch {}
    }
    return { signal: undefined, abort() {} };
  }

  function isFileLike(value) {
    return typeof Blob !== "undefined" && value instanceof Blob;
  }

  function fileFromBlob(blob, name, options = {}) {
    if (!(blob instanceof Blob)) throw new TypeError("Expected a Blob.");
    const safeName = String(name || "file").slice(0, 180) || "file";
    const type = String(options.type || blob.type || "application/octet-stream");
    const lastModified = Number(options.lastModified || Date.now());

    if (typeof File === "function") {
      try {
        return new File([blob], safeName, { type, lastModified });
      } catch {}
    }

    // Older Safari/Android WebViews can expose file inputs but not a constructible
    // File(). FormData accepts Blob plus an explicit filename, so annotate a
    // sliced Blob with the fields the rest of SilkNex reads.
    const fallback = blob.slice(0, blob.size, type);
    try { Object.defineProperty(fallback, "name", { value: safeName, configurable: true }); }
    catch { try { fallback.name = safeName; } catch {} }
    try { Object.defineProperty(fallback, "lastModified", { value: lastModified, configurable: true }); }
    catch { try { fallback.lastModified = lastModified; } catch {} }
    return fallback;
  }

  function decodeImageElement(image) {
    if (!image) return Promise.reject(new Error("Image is unavailable."));
    if (image.complete && image.naturalWidth > 0) return Promise.resolve();
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        image.removeEventListener("load", loaded);
        image.removeEventListener("error", failed);
        error ? reject(error) : resolve();
      };
      const loaded = () => finish();
      const failed = () => finish(new Error("Could not decode image."));
      const timer = setTimeout(() => finish(new Error("That image took too long to open.")), 15000);
      image.addEventListener("load", loaded, { once: true });
      image.addEventListener("error", failed, { once: true });
      if (typeof image.decode === "function") {
        try { image.decode().then(loaded, () => { if (image.complete) image.naturalWidth > 0 ? loaded() : failed(); }); }
        catch { if (image.complete) failed(); }
      }
    });
  }

  const state = {
    authMode: "login",
    authBusy: false,
    authGeneration: 0,
    me: null,
    csrf: "",

    conversations: [],
    conversationsLoaded: false,
    conversationFingerprint: "",
    inboxSignature: "",
    friendSignature: "",
    friends: [],
    incomingFriends: [],
    outgoingFriends: [],
    friendsLoaded: false,
    friendSearchRequestId: 0,
    lastConversationRefreshAt: 0,
    lastRealtimeActivityAt: Date.now(),
    conversationLoadPromise: null,
    mobileViewportBaseline: 0,
    mobileViewportWidth: 0,
    mobileViewportRaf: 0,
    mobileViewportNeedsComposer: false,
    mobileHistoryChatId: 0,
    draftSaveTimer: null,
    deliveryAckByConversation: new Map(),
    deliveryAckInFlight: new Map(),
    chatFilter: "all",
    conversationRequestId: 0,

    activeId: 0,
    activeConversation: null,
    messages: new Map(),
    firstMessageId: 0,
    syncAfterId: 0,
    hasNewerHistory: false,
    historyRequestId: 0,
    lastMessageId: 0,
    hasOlder: false,
    receipt: { recipient_count: 0, delivered_up_to: 0, read_up_to: 0 },
    lastReadAckId: 0,
    readAckInFlightId: 0,
    readAckRequest: null,
    readAckFailures: 0,
    readAckRetryTimer: null,
    readAckRetryAt: 0,
    syncCursor: 0,
    syncCursorId: 0,
    changeSeq: 0,
    syncBusy: false,
    syncFailures: 0,
    syncController: null,
    openConversationController: null,
    syncHasMore: false,
    pollTimer: null,
    globalPollTimer: null,
    globalPollController: null,
    globalPollFailures: 0,
    pollTick: 0,
    lastForegroundRefreshAt: 0,
    foregroundRefreshPromise: null,
    auxiliaryBootstrapTimer: null,
    expiryTimer: null,
    crossTabChannel: null,
    lastCrossTabSyncAt: 0,

    selectedPeople: [],
    peopleSearchRequestId: 0,
    selectedAccent: "silver",

    replyTo: null,
    editingMessage: null,
    deletingMessageId: 0,
    retryNonces: new Map(),
    textSendsInFlightByConversation: new Map(),
    sendQueueTails: new Map(),
    attachmentSendBusy: false,
    attachmentUploadBusy: false,
    attachmentUploadXhr: null,
    scheduledMessages: [],
    groupAvatarToken: "",
    groupAvatarPreviewUrl: "",

    pendingAttachment: null,
    attachmentObjectUrl: "",
    giphySdkKey: "",
    giphyEnabled: null,
    giphyClient: null,
    giphySdkPromise: null,
    giphySearchTimer: null,
    giphyRequestId: 0,
    giphyResults: [],
    savedStickers: [],
    savedMessageIds: new Set(),
    mediaHoldMessage: null,
    mediaHoldTimer: null,
    mediaHoldStart: null,
    stickerSourceImage: null,
    stickerSourceUrl: "",
    stickerSourceRevocable: false,
    stickerFlipX: false,
    stickerDrawMode: "draw",
    stickerEraseMask: null,
    stickerDrawHistory: [],
    stickerDrawPointer: null,
    gifSourceMessage: null,
    gifEncoderBusy: false,
    voiceRecorder: null,
    voiceStream: null,
    voiceChunks: [],
    voiceStartedAt: 0,
    recordingMode: "",
    recordingStarting: false,
    recordingGeneration: 0,
    recordingTimer: null,
    recordPressTimer: null,
    recordStopTimer: null,
    recordPointerDown: false,
    recordHoldStarted: false,
    lastRecordTapAt: 0,
    cancelCurrentRecording: false,
    mobileRecordingTap: false,

    avatarToken: "",
    avatarCrop: null,
    avatarStyleDraft: null,
    avatarBuilderOpen: false,
    avatarUsingStyle: false,

    stories: [],
    storyGroups: [],
    activeStoryGroupIndex: -1,
    activeStoryIndex: -1,
    storyTimer: null,
    storyTimerStartedAt: 0,
    storyTimerRemainingMs: 6000,
    lastStoryRefreshAt: 0,
    storiesLoadPromise: null,
    pendingStoryFile: null,
    pendingStoryPreviewUrl: "",
    storyGestureStart: null,
    storyPaused: false,
    storyWheelLockUntil: 0,
    storyViewQueue: new Set(),
    storyViewFlushTimer: null,
    removeAvatar: false,
    avatarPreviewUrl: "",

    themeChoice: "dark",
    iconStyleChoice: "auto",
    fontScaleChoice: "normal",
    fontFamilyChoice: "system",
    uiAccentChoice: "silver",
    bubbleStyleChoice: "rounded",
    messageDensityChoice: "normal",
    chatWidthChoice: "normal",
    reduceMotionChoice: false,
    easyModeChoice: false,
    wallpaperChoice: "neo",
    wallpaperToken: "",
    wallpaperPreviewUrl: "",
    notificationsChoice: false,

    chatWallpaperChoice: "default",
    chatWallpaperToken: "",
    chatWallpaperPreviewUrl: "",
    chatRingtoneChoice: "classic",
    chatBubbleStyleChoice: "default",
    chatDensityChoice: "default",
    chatFontScaleChoice: "default",
    chatDisappearingChoice: 0,

    notificationRegistration: null,
    pushSubscribed: false,
    notifiedIds: new Set(),
    pendingOpenConversationId: 0,
    pendingOpenFriends: false,
    pendingAnswerCallId: 0,

    lastFocus: null,

    incomingCall: null,
    incomingCallTimer: null,
    incomingCallPollBusy: false,
    callStarting: false,
    ringtoneTimer: null,
    ringbackTimer: null,
    ringtoneContext: null,
    ringtonePrimed: false,
    call: null,
    callWakeLock: null,
    callIceServers: null,
    callIceConfigLoadedAt: 0,
    callStatsTimer: null,
    avatarDataUrlCache: new Map(),

    // v40 secure messaging / UX state
    e2eeRegisterPromise: null,
    typingUsers: [],
    typingLastSentAt: 0,
    typingStopTimer: null,
    typingConversationId: 0,
    presenceTimer: null,
    presenceActive: false,
    presenceLastSentAt: 0,
    presenceInFlight: null,
    presencePending: null,
    globalLoaderCount: 0,
    globalLoaderTimer: null,
    stickerDrawHistory: [],
    stickerDrawMode: "draw",
    stickerDrawPointer: null,
    stickerEraseMask: null,
    stickerEraseHistory: [],

    // v44: encrypted visual media is decrypted only when it approaches the
    // visible chat viewport. This keeps long image-heavy conversations fast.
    deferredMediaObservers: new Map(),
  };

  function jitteredDelay(baseMs, spread = 0.18) {
    const base = Math.max(0, Number(baseMs) || 0);
    if (base === 0) return 0;
    const range = Math.max(0, Math.min(0.45, Number(spread) || 0));
    const factor = 1 + ((Math.random() * 2 - 1) * range);
    return Math.max(0, Math.round(base * factor));
  }

  function apiUrl(action, params = {}) {
    const url = new URL("api.php", window.location.href);
    url.searchParams.set("action", action);

    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null) {
        url.searchParams.set(key, String(value));
      }
    }

    return url.toString();
  }

  const PASSIVE_API_ACTIONS = new Set([
    "sync", "inbox_state", "call_poll", "delivery_receipts", "read_receipt",
    "typing", "ad_status", "ad_event", "ad_events_batch", "presence", "story_view", "story_views"
  ]);

  function setGlobalLoading(active, label = "Loading…") {
    const loader = $("#globalLogoLoader");
    if (!loader) return;

    state.globalLoaderCount = Math.max(
      0,
      Number(state.globalLoaderCount || 0) + (active ? 1 : -1)
    );

    const labelNode = $("#globalLoaderLabel");
    if (active && labelNode) labelNode.textContent = label;

    if (state.globalLoaderCount < 1) {
      clearTimeout(state.globalLoaderTimer);
      state.globalLoaderTimer = null;
      loader.classList.add("hidden");
      loader.removeAttribute("data-delayed");
      return;
    }

    // Fast API calls should feel instant, not flash a blocking spinner for a
    // single frame. Only reveal the global logo loader when work lasts long
    // enough for a progress affordance to be useful.
    if (loader.classList.contains("hidden") && !state.globalLoaderTimer) {
      loader.dataset.delayed = "true";
      state.globalLoaderTimer = setTimeout(() => {
        state.globalLoaderTimer = null;
        if (state.globalLoaderCount > 0) {
          loader.classList.remove("hidden");
          loader.removeAttribute("data-delayed");
        }
      }, 160);
    }
  }

  async function api(action, options = {}, params = {}) {
    const requestSession = state.me;
    const method = String(options.method || "GET").toUpperCase();
    const headers = {
      Accept: "application/json",
      ...(options.headers || {}),
    };
    let body = options.body;

    const isFormData = typeof FormData !== "undefined" && body instanceof FormData;

    if (body !== undefined && !isFormData && typeof body !== "string") {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(body);
    }

    if (!["GET", "HEAD"].includes(method) && state.csrf) {
      headers["X-CSRF-Token"] = state.csrf;
    }

    // Mobile radios can leave a fetch pending for a long time while switching
    // between Wi‑Fi and cellular. Bound requests so sends/calls recover instead
    // of leaving controls stuck. Uploads get a much larger window; long-poll
    // sync still fits comfortably inside its own server wait.
    const timeoutMs = Number.isFinite(Number(options.timeoutMs))
      ? Math.max(0, Number(options.timeoutMs))
      : (isFormData ? 300000 : action === "sync" ? 22000 : 30000);
    const controller = createAbortController();
    const sourceSignal = options.signal || null;
    let timedOut = false;
    let timeoutId = null;

    const forwardAbort = () => {
      try { controller.abort(sourceSignal?.reason); } catch { controller.abort(); }
    };

    if (sourceSignal) {
      if (sourceSignal.aborted) {
        forwardAbort();
      } else {
        sourceSignal.addEventListener("abort", forwardAbort, { once: true });
      }
    }

    let timeoutPromise = null;
    if (timeoutMs > 0) {
      timeoutPromise = new Promise((_, reject) => {
        timeoutId = setTimeout(() => {
          timedOut = true;
          try {
            if (typeof DOMException === "function") {
              controller.abort(new DOMException("Request timed out", "TimeoutError"));
            } else {
              controller.abort();
            }
          } catch {
            try { controller.abort(); } catch {}
          }

          // AbortController is missing in some older embedded webviews. Reject
          // the race as well so a stalled fetch still releases the UI.
          const timeoutError = new Error("Request timed out");
          timeoutError.name = "AbortError";
          reject(timeoutError);
        }, timeoutMs);
      });
    }

    let response;
    let data;
    const showLoader = !PASSIVE_API_ACTIONS.has(action) && options.showLoader !== false;
    if (showLoader) setGlobalLoading(true, options.loadingLabel || "Loading…");

    try {
      const request = fetch(apiUrl(action, params), {
        method,
        headers,
        body,
        credentials: "same-origin",
        cache: "no-store",
        signal: controller.signal,
        keepalive: Boolean(options.keepalive),
      });
      response = timeoutPromise ? await Promise.race([request, timeoutPromise]) : await request;
      // The same deadline covers headers AND the response body, including
      // webviews without a constructible AbortController.
      try {
        const bodyRequest = response.json();
        data = timeoutPromise ? await Promise.race([bodyRequest, timeoutPromise]) : await bodyRequest;
        if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error();
      } catch (bodyError) {
        if (timedOut || controller.signal?.aborted || sourceSignal?.aborted) throw bodyError;
        const error = new Error("Silknex received an invalid server response.");
        error.status = response.status;
        error.code = "invalid_response";
        throw error;
      }
    } catch (fetchError) {
      if (fetchError?.code === "invalid_response") throw fetchError;
      if (fetchError?.name === "AbortError" && sourceSignal?.aborted) {
        throw fetchError;
      }

      if (timedOut) {
        const error = new Error(
          navigator.onLine
            ? "The server took too long to respond. Try again."
            : "You are offline."
        );
        error.status = 0;
        error.code = "timeout";
        throw error;
      }

      if (fetchError?.name === "AbortError") {
        throw fetchError;
      }

      const error = new Error(
        navigator.onLine
          ? "Silknex could not reach the server."
          : "You are offline."
      );
      error.status = 0;
      throw error;
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
      sourceSignal?.removeEventListener?.("abort", forwardAbort);
      if (showLoader) setGlobalLoading(false);
    }

    if (!response.ok || data.ok === false) {
      if (response.status === 423 && data.access_block) window.SilknexAccessBlock?.render(data.access_block);
      if (response.status === 401 && state.me && state.me === requestSession) {
        showAuth("Your login ended. Sign in again.");
      }

      const error = new Error(data.error || "Request failed.");
      error.status = response.status;
      throw error;
    }

    return data;
  }

  function toast(message) {
    const element = $("#toast");
    element.textContent = String(message || "");
    element.classList.add("show");

    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => {
      element.classList.remove("show");
    }, 2800);
  }

  function closeFullscreenMedia() {
    const modal = $("#fullscreenMediaModal");
    if (!modal) return;
    const wasOpen = !modal.classList.contains("hidden");
    const stage = $("#fullscreenMediaStage");
    const video = stage?.querySelector("video");
    try { video?.pause?.(); } catch {}
    stage?.replaceChildren();
    modal.classList.add("hidden");
    if (wasOpen) {
      window.dispatchEvent(new CustomEvent("silknex:modal", {
        detail: { open: false, id: "fullscreenMediaModal" }
      }));
    }
  }

  function openFullscreenMedia(url, type = "image", alt = "Media") {
    if (!url) return;
    const modal = $("#fullscreenMediaModal");
    const stage = $("#fullscreenMediaStage");
    if (!modal || !stage) return;
    stage.replaceChildren();
    let media;
    if (type === "video") {
      media = document.createElement("video");
      media.controls = true;
      media.autoplay = true;
      media.playsInline = true;
    } else {
      media = document.createElement("img");
      media.alt = alt || "Media";
      media.decoding = "async";
      media.loading = "eager";
      try { media.fetchPriority = "high"; } catch {}
    }
    media.src = url;
    stage.appendChild(media);
    modal.classList.remove("hidden");
    window.dispatchEvent(new CustomEvent("silknex:modal", {
      detail: { open: true, id: "fullscreenMediaModal" }
    }));
    $("#fullscreenMediaClose")?.focus?.();
  }

  function makeClientNonce() {
    const bytes = new Uint8Array(16);

    if (window.crypto?.getRandomValues) {
      window.crypto.getRandomValues(bytes);
    } else {
      for (let index = 0; index < bytes.length; index += 1) {
        bytes[index] = Math.floor(Math.random() * 256);
      }
    }

    return [...bytes]
      .map((value) => value.toString(16).padStart(2, "0"))
      .join("");
  }

  function bytesToBase64Url(value) {
    const bytes = value instanceof ArrayBuffer
      ? new Uint8Array(value)
      : new Uint8Array(value.buffer, value.byteOffset, value.byteLength);

    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);

    return btoa(binary)
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/g, "");
  }

  function base64UrlToBytes(value) {
    const normalized = String(value || "")
      .replace(/-/g, "+")
      .replace(/_/g, "/");

    const padded = normalized + "=".repeat((4 - (normalized.length % 4)) % 4);
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);

    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }

    return bytes;
  }

  async function ensureE2EERegistration() {
    if (!state.me || !window.SilknexE2EE) {
      throw new Error("Secure messaging is unavailable in this browser.");
    }
    if (!state.e2eeRegisterPromise) {
      const userId = Number(state.me.id);
      const epoch = Number(state.sessionEpoch || 0);
      const pending = window.SilknexE2EE
        .register((...args) => {
          if (Number(state.me?.id) !== userId || Number(state.sessionEpoch || 0) !== epoch) {
            return Promise.reject(new Error("Sign-in session changed."));
          }
          return api(...args);
        })
        .catch((error) => {
          if (state.e2eeRegisterPromise === pending) state.e2eeRegisterPromise = null;
          throw error;
        });
      state.e2eeRegisterPromise = pending;
    }
    return state.e2eeRegisterPromise;
  }

  function localKidFilter(text) {
    let output = String(text || "");
    if (!state.me?.kid_mode || !output) return output;

    output = output
      .replace(/\b(?:https?:\/\/|www\.)\S+/giu, "[link hidden]")
      .replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/giu, "[email hidden]");

    const words = Array.isArray(state.me.kid_blocked_words)
      ? state.me.kid_blocked_words
      : [];
    const leet = {
      a: "[a@4]", e: "[e3]", i: "[i1!]", o: "[o0]",
      s: "[s$5]", t: "[t7]", g: "[g69]", l: "[l1]"
    };

    for (const raw of words) {
      const word = String(raw || "").trim().toLowerCase();
      if (!word) continue;
      const pieces = [];
      for (const char of Array.from(word)) {
        if (/\s/u.test(char)) {
          pieces.push("[\\W_]+");
          continue;
        }
        const safe = leet[char] || char.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        pieces.push(`(?:${safe}){1,3}[\\W_]*`);
      }
      if (pieces.length) pieces[pieces.length - 1] = pieces[pieces.length - 1].replace("[\\W_]*", "");
      try {
        output = output.replace(
          new RegExp(`(?<![\\p{L}\\p{N}])${pieces.join("")}(?![\\p{L}\\p{N}])`, "giu"),
          "••••"
        );
      } catch {}
    }
    return output;
  }

  async function decryptIncomingMessage(message) {
    if (!message) return message;
    let next = message;

    if (message.e2ee_payload && window.SilknexE2EE) {
      next = await window.SilknexE2EE.decryptMessage(message);
    }

    if (next?.reply?.e2ee_payload && window.SilknexE2EE) {
      try {
        const payload = await window.SilknexE2EE.decryptEnvelope(
          next.reply.e2ee_payload,
          next.conversation_id
        );
        next = {
          ...next,
          reply: {
            ...next.reply,
            body: String(payload?.text || "") || "Attachment",
          },
        };
      } catch {
        next = {
          ...next,
          reply: { ...next.reply, body: "Older reply unavailable on this device" },
        };
      }
    }

    if (next && !next.deleted_at) {
      next = {
        ...next,
        body: localKidFilter(next.body),
        reply: next.reply
          ? { ...next.reply, body: localKidFilter(next.reply.body) }
          : null,
      };
    }
    return next;
  }

  async function mapWithConcurrency(items, mapper) {
    const list = Array.isArray(items) ? items : [];
    const output = new Array(list.length);
    let cursor = 0;
    const efficient = document.documentElement.dataset.performance === "efficient";
    const workerCount = Math.min(efficient ? 2 : 4, list.length);
    await Promise.all(Array.from({ length: workerCount }, async () => {
      while (cursor < list.length) {
        const index = cursor++;
        output[index] = await mapper(list[index], index);
      }
    }));
    return output;
  }

  async function decryptIncomingMessages(messages) {
    return mapWithConcurrency(messages, decryptIncomingMessage);
  }

  async function encryptMessagePayload(conversationId, nonce, payload) {
    await ensureE2EERegistration();
    return window.SilknexE2EE.encryptPayload(
      api,
      Number(conversationId),
      String(nonce || ""),
      payload || {}
    );
  }

  function initials(name) {
    return (
      String(name || "N")
        .trim()
        .split(/\s+/)
        .slice(0, 2)
        .map((part) => part[0] || "")
        .join("")
        .toUpperCase() || "N"
    );
  }

  function accentClass(accent) {
    const allowed = ["silver", "steel", "graphite", "frost", "smoke"];
    return `accent-${allowed.includes(accent) ? accent : "silver"}`;
  }

  const ICON_PATHS = {
    friends: ["M6.7 10.4a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z","M1.9 19.6c.7-4.1 2.5-6 4.8-6s4.1 1.9 4.8 6","M15.8 7.2v6.4","M12.6 10.4H19"],
    chat: ["M4 5.5h16v11H9l-5 3v-14Z","M8 10h8","M8 13h5"],
    lock: ["M6 10h12v10H6Z","M8.5 10V7.5a3.5 3.5 0 0 1 7 0V10","M12 14v2"],
    compose: ["M4 4.5h8.5","M4 4.5v15h15v-8.2","M10.6 13.4 17.9 6a1.7 1.7 0 0 1 2.4 2.4l-7.4 7.3-3 .6.7-2.9Z"],
    settings: ["M12 3.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17Z","M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z","M12 1v2.5","M12 20.5V23","M1 12h2.5","M20.5 12H23","m4.2 4.2 1.8 1.8","m18 18 1.8 1.8","m19.8 4.2-1.8 1.8","M6 18l-1.8 1.8"],
    search: ["M10.3 17.1a6.8 6.8 0 1 1 0-13.6 6.8 6.8 0 0 1 0 13.6Z","m15.5 15.5 4.5 4.5"],
    back: ["m14.5 5-7 7 7 7","M8 12h12"],
    phone: ["M6.1 3.5 9 7.2 7.4 9.6c1.3 2.9 3.1 4.7 6 6l2.4-1.6 3.7 2.9-1.5 3c-.4.8-1.3 1.2-2.2 1-7.3-1.7-12-6.4-13.7-13.7-.2-.9.2-1.8 1-2.2l3-1.5Z"],
    video: ["M4 6h11v12H4Z","m15 10 5-3v10l-5-3"],
    more: ["M6 12h.01","M12 12h.01","M18 12h.01"],
    down: ["m6 9 6 6 6-6"],
    close: ["M6 6l12 12","M18 6 6 18"],
    attach: ["m9 12.8 5.8-5.8a3.4 3.4 0 1 1 4.8 4.8l-7.8 7.8a5 5 0 0 1-7-7l8-8","m8 16 7.7-7.7"],
    mic: ["M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3Z","M5.5 11.5a6.5 6.5 0 0 0 13 0","M12 18v3","M9 21h6"],
    clock: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z","M12 7v5l3.5 2"],
    send: ["M3 11.2 21 3l-7.8 18-2.2-7.6L3 11.2Z","m11 2.2 10-9.2"],
    image: ["M4 5h16v14H4Z","m5 15 3.5-4 3 3 2-2 3.5 3","M9 9h.01"],
    gif: ["M4 6h16v12H4Z","M7.5 10.2h2.7v3.6H7.5v-3.6Z","M12.5 10.2v3.6","M16 10.2h2.5","M16 12h2"],
    sticker: ["M5 4h14v9.5L12.5 20H5V4Z","M12.5 20v-6.5H19","M8 8h8","M8 11h5"],
    play: ["m9 7 8 5-8 5Z"],
    pin: ["M8 4h8l-1.4 5 2.9 2.9H6.5L9.4 9 8 4Z","M12 12v8"],
    bookmark: ["M6 4h12v17l-6-4-6 4V4Z"],
    archive: ["M4 7h16v13H4V7Z","M3 4h18v4H3V4Z","M9 12h6"],
    trash: ["M4 7h16","M9 7V4h6v3","M7 7l1 13h8l1-13","M10 10v7","M14 10v7"],
    reply: ["m10 7-6 5 6 5","M5 12h8c4 0 6 2 6 6"],
    edit: ["m5 19 1-4 9.8-9.8a2.1 2.1 0 1 1 3 3L9 18l-4 1Z"],
    heart: ["M12 20S4 15.5 4 9.8C4 6.7 7.7 5 10 7.3L12 9.4l2-2.1C16.3 5 20 6.7 20 9.8 20 15.5 12 20 12 20Z"],
    spark: ["m12 3 1.6 5.4L19 10l-5.4 1.6L12 17l-1.6-5.4L5 10l5.4-1.6L12 3Z"],
    camera: ["M4 7h3l1.5-2h7L17 7h3v12H4Z","M12 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z"],
    flip: ["M7 7h10l-2.7-2.7","M17 17H7l2.7 2.7","M20 9a8 8 0 0 0-1-2","M4 15a8 8 0 0 0 1 2"],
    speaker: ["M5 10v4h4l5 4V6l-5 4H5Z","M17 9a4 4 0 0 1 0 6","M19.5 6.5a7.5 7.5 0 0 1 0 11"],
    share: ["M8 4h8v6h4l-8 8-8-8h4V4Z"],
    copy: ["M9 8h10v11H9Z","M5 15H4V4h11v1"],
    download: ["M12 3v12","m7.5 10.5 4.5 4.5 4.5-4.5","M5 20h14"],
    minimize: ["M6 10h12","m8 14 4 4 4-4"],
    check: ["m5 12 4 4 10-10"],
    doubleCheck: ["m2.5 12 4 4 8-8","m9 13 3 3 9-10"],
    smile: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z","M8.5 10h.01","M15.5 10h.01","M8.5 14c1.7 2.2 5.3 2.2 7 0"],
    eye: ["M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6Z","M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z"],
    eyeOff: ["M3 3l18 18","M10.6 6.2A10.8 10.8 0 0 1 12 6c6.1 0 9.5 6 9.5 6a13.8 13.8 0 0 1-2.8 3.6","M6.2 6.2C3.7 8 2.5 12 2.5 12s3.4 6 9.5 6c1.6 0 3-.4 4.2-1","M9.8 9.8a3.2 3.2 0 0 0 4.4 4.4"]
  };

  function iconNode(name, className = "neo-icon") {
    const paths = ICON_PATHS[name] || ICON_PATHS.spark;
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("focusable", "false");
    svg.classList.add(...className.split(/\s+/).filter(Boolean));

    for (const d of paths) {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", d);
      path.setAttribute("fill", "none");
      path.setAttribute("stroke", "currentColor");
      path.setAttribute("stroke-width", "1.75");
      path.setAttribute("stroke-linecap", "round");
      path.setAttribute("stroke-linejoin", "round");
      path.setAttribute("vector-effect", "non-scaling-stroke");
      svg.appendChild(path);
    }
    return svg;
  }

  function setButtonContent(button, iconName, label = "") {
    if (!button) return;
    button.replaceChildren();
    button.appendChild(iconNode(iconName));
    if (label) {
      const span = document.createElement("span");
      span.className = "button-label";
      span.textContent = label;
      button.appendChild(span);
    }
  }

  function hydrateIcons(scope = document) {
    const items = [];
    if (scope instanceof Element && scope.matches?.("[data-icon]")) items.push(scope);
    for (const item of scope.querySelectorAll?.("[data-icon]") || []) items.push(item);

    for (const item of items) {
      if (item.querySelector(":scope > .neo-icon")) continue;
      item.insertBefore(iconNode(item.dataset.icon || "spark"), item.firstChild);
    }
  }

  const AVATAR_DEFAULT = Object.freeze({
    skin: "warm",
    face_shape: "oval",
    hair: "crop",
    hair_color: "espresso",
    eyes: "round",
    eye_color: "brown",
    brows: "soft",
    nose: "soft",
    mouth: "smile",
    face_detail: "none",
    outfit: "hoodie",
    outfit_color: "blue",
    outfit_pattern: "solid",
    background: "neo",
    background_pattern: "clean",
    accessory: "none",
    accessory_color: "charcoal",
    headwear: "none",
    facial_hair: "none",
    facial_hair_opacity: "100",
    skin_hex: "",
    hair_hex: "",
    outfit_hex: "",
    background_hex: "",
    accessory_hex: "",
    face_width: "100",
    face_length: "100",
    jaw_width: "100",
    eye_scale: "100",
    iris_size: "100",
    lashes: "none",
    eye_spacing: "100",
    eye_height: "100",
    nose_scale: "100",
    mouth_width: "100",
    brow_height: "100",
    ear_size: "100",
    neck_width: "100",
    eye_tilt: "100",
    brow_thickness: "100",
    nose_width: "100",
    lip_fullness: "100",
    hair_volume: "100",
    hair_highlight: "none",
    makeup: "none",
    face_decal: "none",
    hair_highlight_hex: "",
    eye_hex: "",
    lip_hex: "",
  });

  const AVATAR_PALETTE = {
    skin: {
      porcelain: "#f6d9c6", fair: "#edc2a8", warm: "#dca47f", olive: "#c99368",
      tan: "#bd7c55", brown: "#8f573c", deep: "#5e392d", ebony: "#40271f"
    },
    hair: {
      black: "#17181c", espresso: "#35241f", brown: "#5b3d2c", auburn: "#7b3829",
      blonde: "#d9b96e", platinum: "#e8e3d8", blue: "#334b83", pink: "#a85d7d",
      teal: "#287d7d", silver: "#9ca3ad", red: "#a63e3e", purple: "#654b93",
      copper: "#b05f3c", green: "#3c7658"
    },
    outfit: {
      charcoal: "#2d3138", silver: "#8a929e", blue: "#4d6fd5", green: "#3d8c6b",
      purple: "#7057c7", orange: "#ca7140", pink: "#b75f88", red: "#a6464b",
      teal: "#327e83", yellow: "#c49b42", white: "#e9eaed"
    },
    background: {
      neo: "#242833", blue: "#365d9e", mint: "#3d776c", violet: "#684f92",
      sunset: "#9b5d50", mono: "#5d626b", rose: "#8f536c", ocean: "#2f7285",
      forest: "#375f45", gold: "#8a7041", coral: "#a85e66", lavender: "#6d659b"
    },
    eyes: {
      brown: "#6a4432", dark_brown: "#33261f", hazel: "#7b6b3f", green: "#52755b",
      blue: "#4f7394", gray: "#75808c", amber: "#a8742e"
    },
    accessory: {
      charcoal: "#24272d", silver: "#aeb4bd", gold: "#d2aa57", blue: "#4d70ca",
      pink: "#b75f88", red: "#a6464b", white: "#eceef1"
    }
  };

  function normalizedAvatarStyle(style) {
    const merged = { ...AVATAR_DEFAULT, ...(style && typeof style === "object" ? style : {}) };
    for (const key of ["skin_hex","hair_hex","outfit_hex","background_hex","accessory_hex","hair_highlight_hex","eye_hex","lip_hex"]) {
      const value = String(merged[key] || "");
      merged[key] = /^#[0-9a-f]{6}$/i.test(value) ? value.toLowerCase() : "";
    }
    const clampAvatar = (value, min, max) => String(Math.max(min, Math.min(max, Number(value || 100))));
    merged.face_width = clampAvatar(merged.face_width, 82, 120);
    merged.face_length = clampAvatar(merged.face_length, 86, 116);
    merged.jaw_width = clampAvatar(merged.jaw_width, 82, 122);
    merged.eye_scale = clampAvatar(merged.eye_scale, 75, 135);
    merged.iris_size = clampAvatar(merged.iris_size, 65, 145);
    merged.eye_spacing = clampAvatar(merged.eye_spacing, 75, 130);
    merged.eye_height = clampAvatar(merged.eye_height, 88, 112);
    merged.nose_scale = clampAvatar(merged.nose_scale, 78, 125);
    merged.mouth_width = clampAvatar(merged.mouth_width, 78, 128);
    merged.brow_height = clampAvatar(merged.brow_height, 86, 116);
    merged.ear_size = clampAvatar(merged.ear_size, 80, 124);
    merged.neck_width = clampAvatar(merged.neck_width, 80, 125);
    merged.eye_tilt = clampAvatar(merged.eye_tilt, 82, 118);
    merged.brow_thickness = clampAvatar(merged.brow_thickness, 70, 145);
    merged.nose_width = clampAvatar(merged.nose_width, 76, 132);
    merged.lip_fullness = clampAvatar(merged.lip_fullness, 72, 140);
    merged.hair_volume = clampAvatar(merged.hair_volume, 82, 125);
    merged.facial_hair_opacity = clampAvatar(merged.facial_hair_opacity, 20, 100);
    if (!["none", "soft", "full", "cat"].includes(String(merged.lashes || ""))) {
      merged.lashes = "none";
    }
    return merged;
  }

  function avatarSvgElement(style, expression = "") {
    const s = normalizedAvatarStyle(style);
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 128 128");
    svg.setAttribute("aria-hidden", "true");
    svg.classList.add("neo-avatar-svg");

    const add = (tag, attrs = {}) => {
      const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
      for (const [key, value] of Object.entries(attrs)) el.setAttribute(key, String(value));
      svg.appendChild(el);
      return el;
    };

    const skin = s.skin_hex || AVATAR_PALETTE.skin[s.skin] || AVATAR_PALETTE.skin.warm;
    const hair = s.hair_hex || AVATAR_PALETTE.hair[s.hair_color] || AVATAR_PALETTE.hair.espresso;
    const outfit = s.outfit_hex || AVATAR_PALETTE.outfit[s.outfit_color] || AVATAR_PALETTE.outfit.blue;
    const bg = s.background_hex || AVATAR_PALETTE.background[s.background] || AVATAR_PALETTE.background.neo;
    const accessoryColor = s.accessory_hex || AVATAR_PALETTE.accessory[s.accessory_color] || AVATAR_PALETTE.accessory.charcoal;
    const faceWidthScale = Math.max(.82, Math.min(1.2, Number(s.face_width || 100) / 100));
    const faceLengthScale = Math.max(.86, Math.min(1.16, Number(s.face_length || 100) / 100));
    const jawWidthScale = Math.max(.82, Math.min(1.22, Number(s.jaw_width || 100) / 100));
    const eyeScale = Math.max(.75, Math.min(1.35, Number(s.eye_scale || 100) / 100));
    const irisScale = Math.max(.65, Math.min(1.45, Number(s.iris_size || 100) / 100));
    const eyeSpacingScale = Math.max(.75, Math.min(1.3, Number(s.eye_spacing || 100) / 100));
    const eyeHeightOffset = (Number(s.eye_height || 100) - 100) * .085;
    const noseScale = Math.max(.78, Math.min(1.25, Number(s.nose_scale || 100) / 100));
    const mouthWidthScale = Math.max(.78, Math.min(1.28, Number(s.mouth_width || 100) / 100));
    const browHeightOffset = (Number(s.brow_height || 100) - 100) * -.09;
    const earScale = Math.max(.8, Math.min(1.24, Number(s.ear_size || 100) / 100));
    const neckScale = Math.max(.8, Math.min(1.25, Number(s.neck_width || 100) / 100));
    const eyeTiltDegrees = (Number(s.eye_tilt || 100) - 100) * .22;
    const browThicknessScale = Math.max(.7, Math.min(1.45, Number(s.brow_thickness || 100) / 100));
    const noseWidthScale = Math.max(.76, Math.min(1.32, Number(s.nose_width || 100) / 100));
    const lipFullnessScale = Math.max(.72, Math.min(1.4, Number(s.lip_fullness || 100) / 100));
    const hairVolumeScale = Math.max(.82, Math.min(1.25, Number(s.hair_volume || 100) / 100));
    const facialHairOpacity = Math.max(.2, Math.min(1, Number(s.facial_hair_opacity || 100) / 100));
    const irisColor = s.eye_hex || AVATAR_PALETTE.eyes[s.eye_color] || AVATAR_PALETTE.eyes.brown;
    const lipColor = s.lip_hex || "#6d3538";
    const mixHex = (a, b, amount) => {
      const parse = (hex) => {
        const clean = String(hex || "#000000").replace("#", "");
        return [0, 2, 4].map((offset) => parseInt(clean.slice(offset, offset + 2), 16) || 0);
      };
      const left = parse(a);
      const right = parse(b);
      return `#${left.map((value, index) => Math.round(value * (1 - amount) + right[index] * amount).toString(16).padStart(2, "0")).join("")}`;
    };
    const skinShade = mixHex(skin, "#321b18", .24);
    const skinHighlight = mixHex(skin, "#fff7ef", .22);
    const hairHighlight = s.hair_highlight_hex || mixHex(hair, "#fffaf2", .30);

    add("rect", { x:0, y:0, width:128, height:128, rx:28, fill:bg });
    if (s.background_pattern === "dots") {
      for (const [cx,cy] of [[18,20],[42,13],[104,25],[113,59],[20,92],[92,105]]) {
        add("circle",{cx,cy,r:3,fill:"#fff",opacity:".11"});
      }
    } else if (s.background_pattern === "rings") {
      add("circle",{cx:105,cy:25,r:22,fill:"none",stroke:"#fff","stroke-width":"3",opacity:".11"});
      add("circle",{cx:20,cy:109,r:29,fill:"none",stroke:"#000","stroke-width":"4",opacity:".08"});
    } else if (s.background_pattern === "grid") {
      for (const x of [16,40,64,88,112]) add("path",{d:`M${x} 0v128`,stroke:"#fff","stroke-width":"1",opacity:".055"});
      for (const y of [16,40,64,88,112]) add("path",{d:`M0 ${y}h128`,stroke:"#fff","stroke-width":"1",opacity:".055"});
    } else if (s.background_pattern === "halo") {
      add("circle",{cx:64,cy:53,r:46,fill:"none",stroke:"#fff","stroke-width":"9",opacity:".08"});
    } else if (s.background_pattern === "diagonal") {
      for (const offset of [-80,-48,-16,16,48,80,112]) {
        add("path",{d:`M${offset} 128 128 ${offset}`,stroke:"#fff","stroke-width":"9",opacity:".055"});
      }
    } else if (s.background_pattern === "stars") {
      for (const [cx,cy,r] of [[18,19,2.2],[42,31,1.5],[104,20,2],[112,68,1.6],[21,94,2.1],[94,108,1.4],[72,16,1.2]]) {
        add("circle",{cx,cy,r,fill:"#fff",opacity:".22"});
      }
    } else if (s.background_pattern === "checker") {
      for (let y=0;y<4;y+=1) for (let x=0;x<4;x+=1) {
        if ((x+y)%2===0) add("rect",{x:x*32,y:y*32,width:32,height:32,fill:"#fff",opacity:".035"});
      }
    } else if (s.background_pattern === "aurora") {
      add("path",{d:"M-10 88Q26 28 63 66T138 28",fill:"none",stroke:"#fff","stroke-width":"18",opacity:".075","stroke-linecap":"round"});
      add("path",{d:"M-8 105Q31 54 66 82T136 51",fill:"none",stroke:"#8fffe6","stroke-width":"11",opacity:".08","stroke-linecap":"round"});
    } else if (s.background_pattern === "sparkles") {
      for (const [cx,cy,r] of [[18,22,2.7],[39,16,1.3],[103,24,2.1],[112,53,1.1],[19,96,1.9],[101,103,2.5]]) {
        add("path",{d:`M${cx-r} ${cy}h${r*2}M${cx} ${cy-r}v${r*2}`,stroke:"#fff","stroke-width":"1.2","stroke-linecap":"round",opacity:".28"});
      }
    }
    add("circle", { cx:103, cy:23, r:17, fill:"#ffffff", opacity:".07" });
    add("circle", { cx:25, cy:106, r:25, fill:"#000000", opacity:".08" });

    if (["jacket","blazer","bomber","denim","varsity"].includes(s.outfit)) {
      add("path",{d:"M22 128c3-27 19-39 42-39s39 12 42 39H22Z",fill:outfit});
      add("path",{d:"M64 92 50 128h28L64 92Z",fill:"#f2f3f5",opacity:s.outfit === "blazer" ? ".92" : ".72"});
      if (s.outfit === "blazer") {
        add("path",{d:"M51 97 61 110 52 128M77 97 67 110 76 128",fill:"none",stroke:"#111","stroke-width":"2.4",opacity:".28"});
      } else if (s.outfit === "bomber") {
        add("path",{d:"M29 105q8-10 18-12M99 105q-8-10-18-12M29 124h70",fill:"none",stroke:"#fff","stroke-width":"3",opacity:".16"});
      } else if (s.outfit === "denim") {
        add("path",{d:"M35 101v27M93 101v27M43 108h12M73 108h12",fill:"none",stroke:"#fff","stroke-width":"1.6",opacity:".28"});
      } else if (s.outfit === "varsity") {
        add("path",{d:"M24 128c2-20 9-31 20-35l8 35H24ZM104 128c-2-20-9-31-20-35l-8 35h28Z",fill:"#fff",opacity:".20"});
        add("text",{x:83,y:113,"text-anchor":"middle",fill:"#fff","font-size":"13","font-weight":"900",opacity:".55"}).textContent="S";
      }
    } else if (s.outfit === "shirt") {
      add("path",{d:"M20 128c2-25 20-39 44-39s42 14 44 39H20Z",fill:outfit});
      add("path",{d:"m52 92 12 12 12-12-4 23H56l-4-23Z",fill:"#fff",opacity:".85"});
    } else if (s.outfit === "tank") {
      add("path",{d:"M24 128c3-23 17-36 40-36s37 13 40 36H24Z",fill:outfit});
      add("path",{d:"M47 93v20M81 93v20",stroke:skin,"stroke-width":"8","stroke-linecap":"round"});
    } else if (s.outfit === "turtleneck") {
      add("path",{d:"M20 128c2-26 19-39 44-39s42 13 44 39H20Z",fill:outfit});
      add("rect",{x:50,y:88,width:28,height:17,rx:7,fill:outfit});
    } else if (s.outfit === "vest") {
      add("path",{d:"M22 128c3-25 19-38 42-38s39 13 42 38H22Z",fill:"#e9eaed"});
      add("path",{d:"M30 128c2-20 11-31 24-35l10 17 10-17c13 4 22 15 24 35H30Z",fill:outfit});
    } else if (s.outfit === "jersey") {
      add("path",{d:"M20 128c2-26 19-39 44-39s42 13 44 39H20Z",fill:outfit});
      add("path",{d:"M55 94h18",stroke:"#fff","stroke-width":"3",opacity:".35"});
      add("text",{x:64,y:119,"text-anchor":"middle",fill:"#fff","font-size":"17","font-weight":"800",opacity:".55"}).textContent="27";
    } else if (s.outfit === "dress") {
      add("path",{d:"M24 128c4-24 18-37 40-37s36 13 40 37H24Z",fill:outfit});
      add("path",{d:"M52 92q12 16 24 0",fill:"none",stroke:"#fff","stroke-width":"2.8",opacity:".34"});
    } else if (s.outfit === "overalls") {
      add("path",{d:"M20 128c2-26 19-39 44-39s42 13 44 39H20Z",fill:"#e8e9eb"});
      add("path",{d:"M44 101h40v27H44zM46 96l8 14M82 96l-8 14",fill:outfit,stroke:outfit,"stroke-width":"5","stroke-linecap":"round"});
      add("circle",{cx:53,cy:104,r:1.7,fill:"#fff",opacity:".55"});
      add("circle",{cx:75,cy:104,r:1.7,fill:"#fff",opacity:".55"});
    } else {
      add("path",{d:"M20 128c2-26 19-39 44-39s42 13 44 39H20Z",fill:outfit});
      if (s.outfit === "hoodie") add("path",{d:"M43 96c4 12 38 12 42 0",fill:"none",stroke:"#111",opacity:".18","stroke-width":"5","stroke-linecap":"round"});
      if (s.outfit === "sweater") add("path",{d:"M42 112h44",fill:"none",stroke:"#fff",opacity:".12","stroke-width":"4"});
    }
    if (s.outfit_pattern === "stripe") {
      add("path",{d:"M28 115h72",fill:"none",stroke:"#fff","stroke-width":"5",opacity:".22"});
    } else if (s.outfit_pattern === "badge") {
      add("circle",{cx:84,cy:112,r:7,fill:"#fff",opacity:".26"});
      add("path",{d:"M81 112h6M84 109v6",stroke:"#fff","stroke-width":"1.8",opacity:".72"});
    } else if (s.outfit_pattern === "split") {
      add("path",{d:"M64 93c22 0 39 13 44 35H64V93Z",fill:"#fff",opacity:".13"});
    } else if (s.outfit_pattern === "checker") {
      for (const [x,y] of [[35,104],[50,119],[65,104],[80,119]]) {
        add("rect",{x,y,width:15,height:15,fill:"#fff",opacity:".10"});
      }
    } else if (s.outfit_pattern === "gradient") {
      add("path",{d:"M22 128c4-17 13-28 27-34l30 34H22Z",fill:"#fff",opacity:".13"});
    }

    const neckWidth = 18 * neckScale;
    add("rect",{x:(64-neckWidth/2).toFixed(2),y:77,width:neckWidth.toFixed(2),height:23,rx:Math.min(9, neckWidth/2),fill:skin});
    add("circle",{cx:39,cy:59,r:(10 * earScale).toFixed(2),fill:skin});
    add("circle",{cx:89,cy:59,r:(10 * earScale).toFixed(2),fill:skin});
    const faceShape = {
      round: {rx:32.5,ry:34.5},
      soft_square: {rx:31.5,ry:36.5},
      heart: {rx:32,ry:38.5},
      oval: {rx:31,ry:38},
      long: {rx:29,ry:41},
      diamond: {rx:30,ry:39.5},
      square: {rx:32.5,ry:37},
      triangle: {rx:30.5,ry:39},
      pear: {rx:31.5,ry:39},
    }[s.face_shape] || {rx:31,ry:38};
    const faceRx = faceShape.rx * faceWidthScale * (.96 + .04 * jawWidthScale);
    const faceRy = faceShape.ry * faceLengthScale;
    add("ellipse",{cx:64,cy:58,rx:faceRx.toFixed(2),ry:faceRy.toFixed(2),fill:skin});
    add("ellipse",{cx:55,cy:49,rx:(faceRx * .63).toFixed(2),ry:(faceRy * .70).toFixed(2),fill:skinHighlight,opacity:".12"});
    add("path",{d:`M${(64 + faceRx * .58).toFixed(2)} 42q8 19 0 38q-5 11-16 16`,fill:"none",stroke:skinShade,"stroke-width":"2.2",opacity:".16","stroke-linecap":"round"});
    if (Math.abs(jawWidthScale - 1) > .025) {
      const jawHalf = 18 * jawWidthScale;
      add("path",{d:`M${(64-jawHalf).toFixed(2)} 78 Q64 ${(95 + (faceLengthScale-1)*12).toFixed(2)} ${(64+jawHalf).toFixed(2)} 78 Q64 91 ${(64-jawHalf).toFixed(2)} 78Z`,fill:skin});
    }
    if (s.face_shape === "heart") {
      add("path",{d:"M45 31q19-14 38 0",fill:skin,stroke:skin,"stroke-width":"6","stroke-linecap":"round"});
    }
    // Small anatomical cues keep the avatar readable at icon size while making
    // the face feel more human than a flat emoji.
    add("path",{d:"M37 57q-4 2-2 8q2 4 5 2",fill:"none",stroke:skinShade,"stroke-width":"1.4",opacity:".46","stroke-linecap":"round"});
    add("path",{d:"M91 57q4 2 2 8q-2 4-5 2",fill:"none",stroke:skinShade,"stroke-width":"1.4",opacity:".46","stroke-linecap":"round"});
    add("ellipse",{cx:64,cy:80,rx:19,ry:6,fill:"#7b4635",opacity:".045"});

    const hairPaths = {
      crop:"M34 49c1-24 13-35 31-35 21 0 31 13 30 37-7-11-18-17-31-17-12 0-23 5-30 15Z",
      textured_crop:"M33 49c1-24 14-35 32-35 18 0 29 11 31 34l-8-9-7 6-8-8-9 8-9-7-12 11Z",
      taper_fade:"M35 47c3-21 14-32 30-32 17 0 27 10 29 30-8-6-18-10-29-10-12 0-22 4-30 12Zm-2 1 5 14-4 8-3-15Z",
      curly_fade:"M34 48c1-23 14-35 31-35 15 0 27 9 30 28-5-4-10-5-14-3-4-10-15-11-20-3-8-8-17 0-27 13Z",
      curtain:"M32 51c1-25 14-38 32-38 19 0 32 13 33 38-7-12-17-18-27-19l-6 18-7-18c-10 2-19 8-25 19Z",
      slick_back:"M34 48c1-23 13-35 31-35 18 0 29 11 31 33-14-9-37-11-62 2Zm7-22q23-13 45 0-25-5-45 0Z",
      undercut:"M34 48c2-20 13-31 30-31 16 0 27 9 31 27-11-8-23-10-36-7-9 2-16 6-25 11Z",
      wolf_cut:"M30 51c1-26 15-39 34-39 18 0 32 13 34 37l-6-5-5 16-8-12-8 17-8-14-10 13-6-15-7 10-10-8Z",
      messy_bun:"M31 51c1-23 14-36 33-36s32 13 33 36c-8-10-20-16-33-16S40 41 31 51Zm22-35c-5-13 20-18 25-5 3 9-5 13-12 11-6 2-11-1-13-6Z",
      low_bun:"M32 50c1-22 14-35 32-35s31 13 32 35c-8-10-20-15-32-15S40 40 32 50Zm44 32c14-2 19 14 8 20-11 6-20-6-12-14Z",
      box_braids:"M30 49c1-23 15-36 34-36s33 13 34 36l-4 50-6-1 1-44-7 47-6-1 1-48-8 50-6-1 1-49-8 49-6-1 2-48-9 45-6-1 3-48-10 43-6-2 6-42Z",
      cornrows:"M34 49c1-23 13-36 30-36 18 0 30 13 31 36-9-9-20-14-31-14s-22 5-30 14Zm7-22q23 8 46 0M39 33q25 8 50 1",
      quiff:"M34 49c0-20 8-34 29-36 12-1 21 3 28 12-11-2-16 4-23 8 13-1 22 3 27 13-18-8-37-9-61 3Z",
      waves:"M33 49c2-24 16-36 34-35 18 1 29 12 29 35-7-8-13-12-20-14-8-3-13 5-21 3-7-2-10-3-22 11Z",
      curls:"M31 50c0-24 16-39 35-38 19 1 34 17 31 40-7-7-12-8-18-9-3-10-16-11-21-4-8-6-16 2-27 11Z",
      bob:"M30 57c-2-30 13-44 34-44s37 16 34 48c-4 19-10 27-14 31l-3-37c-4-14-30-17-36 0l-2 37c-7-8-11-19-13-35Z",
      long:"M29 55c-2-29 13-43 35-43 23 0 38 15 35 45l-4 41-14-1 2-43c-6-18-31-18-38 0l1 43-14 1-3-43Z",
      bun:"M32 51c1-22 14-35 32-35s31 13 32 35c-8-11-20-16-32-16s-24 5-32 16Zm21-35c0-12 22-13 23 0-8-3-16-3-23 0Z",
      ponytail:"M32 50c1-23 14-36 32-36s31 13 32 36c-8-10-20-16-32-16S40 40 32 50Zm57-16c18 3 22 20 14 40-2-15-8-24-19-27l5-13Z",
      side_part:"M33 49c1-22 12-35 31-35 19 0 30 11 32 33-12-10-26-13-43-9-7 2-13 6-20 11Z",
      afro:"M28 52c-9-7-5-20 4-23-3-12 9-20 19-16 4-11 22-11 26 0 11-5 22 6 18 17 11 2 14 17 4 24-12-7-20-12-31-12-11 0-23 5-36 14Z",
      locs:"M29 50c0-23 14-37 35-37 20 0 34 14 35 37l-4 48-8-1 1-42-7 45-7-1 1-47-7 49-8-1V52l-7 46-8-1 2-44-8 45-8-1-2-47Z",
      mohawk:"M38 48c4-10 10-16 19-18-2-12 4-20 10-27 0 10 5 16 10 22 7-4 13-4 17-2-3 8-3 14 1 23-17-8-36-8-57-2Z",
      bald:"M35 45c3-20 15-30 29-30 16 0 28 11 30 31-17-7-42-7-59-1Z",
      buzz:"M35 45c2-20 14-30 29-30 17 0 29 11 30 31-15-11-43-11-59-1Z",
      hijab:"M29 57c0-30 14-45 35-45 23 0 36 17 35 46l-8 55H37l-8-56Zm17-8c4-15 32-15 36 0v21c-4 18-32 18-36 0V49Z",
      pixie:"M34 49c2-22 13-34 31-34 14 0 25 7 30 21-8-4-15-3-21 1 7 0 13 3 18 9-17-7-37-7-58 3Z",
      braids:"M31 49c1-23 14-36 33-36s32 13 33 36c-8-9-19-14-33-14S39 40 31 49Zm3 6 7 43m8-48 4 51m41-46-7 43m-8-48-4 51",
      shag:"M29 51c2-26 16-39 35-38 18 1 32 14 34 37l-8-8-6 14-8-12-11 13-10-14-9 12-6-12-11 8Z",
      french_crop:"M33 49c2-23 15-34 32-34 18 0 28 10 31 31-11-7-21-9-31-8-11 0-21 4-32 11Zm8-13q23-8 45 1-23-2-45 4Z",
      low_fade:"M35 48c3-19 14-31 30-31 17 0 28 10 30 29-10-7-20-10-31-10-11 0-20 4-29 12Zm-2 3 4 11-3 6-3-11Z",
      mid_fade:"M35 47c3-20 14-32 30-32 17 0 28 10 30 30-9-7-19-11-31-11-12 0-21 5-29 13Zm-1 1 3 16-4 5-2-15Z",
      high_fade:"M36 45c4-19 14-29 29-29 17 0 27 9 29 27-10-6-20-9-30-9-11 0-20 4-28 11Zm-2 5 3 12-3 7-2-14Z",
      pompadour:"M33 50c0-17 7-30 22-34 2-11 24-14 35-3-8-1-12 4-17 8 11-2 20 5 23 23-17-8-39-9-65 0Z",
      comb_over:"M33 49c2-22 13-34 31-34 18 0 29 10 31 31-12-9-28-12-45-6-6 2-11 5-17 9Zm11-20q25-10 44 1-23-3-44 5Z",
      two_block:"M31 52c0-25 14-39 33-39 20 0 34 14 34 39-7-8-14-13-22-15l-5 16-8-15-9 13-9-12-14 13Z",
      french_bob:"M29 58c-2-31 13-45 35-45s37 16 34 47c-2 17-7 25-13 31l-3-34c-5-15-31-17-37 0l-2 34c-7-7-12-18-14-33Zm14 22q21 9 42 0",
      layers:"M28 56c-2-30 14-45 36-45 23 0 39 16 36 46l-3 44-12-3 1-43-9 47-9-2 1-48-10 49-9-2 2-46-11 44-10-2-3-39Z",
      space_buns:"M31 51c1-23 14-36 33-36s32 13 33 36c-8-10-20-16-33-16S40 41 31 51Zm2-30c-10-10 7-24 18-13 6 7-1 15-8 14Zm62 0c10-10-7-24-18-13-6 7 1 15 8 14Z",
      high_ponytail:"M32 50c1-23 14-36 32-36s31 13 32 36c-8-10-20-16-32-16S40 40 32 50Zm46-31c18-2 30 11 27 31-5-13-14-19-28-18l1-13Z",
      taper_afro:"M29 51c-7-6-4-18 4-21-2-10 9-18 18-14 5-10 21-10 26 0 10-4 20 6 17 16 9 2 12 14 5 21-10-6-20-10-31-10-11 0-22 4-31 10Z",
      loc_bun:"M30 50c0-23 14-37 34-37 20 0 34 14 35 37l-4 47-8-1 1-41-7 44-7-1 1-46-8 48-8-1 1-48-8 46-8-1-1-46Zm22-35c0-12 23-14 24 0-8-3-16-3-24 0Z",
      twists:"M30 49c1-23 14-36 34-36 19 0 33 13 34 36l-6 48-6-1 3-43-8 46-6-1 4-47-9 48-6-1 2-47-8 46-6-1 3-46-9 45-6-2 6-44Z",
      dutch_braids:"M31 49c1-23 14-36 33-36s32 13 33 36c-8-9-19-14-33-14S39 40 31 49Zm10 0c-7 15-8 31-5 49m15-52c-4 18-4 36-1 55m37-52c7 15 8 31 5 49m-15-52c4 18 4 36 1 55",
      spiky:"M33 51 38 31l9 7 3-18 11 11 8-20 7 19 12-9-1 18 10-3-4 17c-17-9-39-10-60-2Z"
    };
    const hairPath = hairPaths[s.hair] || hairPaths.crop;
    if (s.hair !== "bald" && hairPath) {
      // Fit hair to the generated head. Hair width follows the face width,
      // while hair height tracks the face length without moving the hairline.
      const hairFitX = hairVolumeScale * (.88 + faceWidthScale * .12);
      const hairFitY = hairVolumeScale * (.76 + faceLengthScale * .24);
      const hairFitYShift = (faceLengthScale - 1) * -2.8;
      const hairTransform =
        `translate(64 ${(48 + hairFitYShift).toFixed(2)}) ` +
        `scale(${hairFitX.toFixed(3)} ${hairFitY.toFixed(3)}) translate(-64 -48)`;
      add("path",{d:hairPath,fill:"#000000",opacity:".10",transform:`${hairTransform} translate(0 1.4)`});
      add("path",{d:hairPath,fill:hair,transform:hairTransform});
      if (s.hair_highlight === "soft") {
        add("path",{d:hairPath,fill:hairHighlight,opacity:".14",transform:`${hairTransform} translate(0 -1.5)`});
      } else if (s.hair_highlight === "streaks") {
        add("path",{d:hairPath,fill:"none",stroke:hairHighlight,"stroke-width":"3.1",opacity:".34","stroke-dasharray":"11 8","stroke-linecap":"round",transform:`${hairTransform} translate(0 -1)`});
      } else if (s.hair_highlight === "tips") {
        add("path",{d:hairPath,fill:"none",stroke:hairHighlight,"stroke-width":"4.2",opacity:".30","stroke-dasharray":"5 10","stroke-linecap":"round",transform:`${hairTransform} translate(0 3)`});
      }
      if (!["cornrows","braids","dutch_braids"].includes(s.hair)) {
        add("path",{d:hairPath,fill:"none",stroke:"#ffffff","stroke-width":"1.6",opacity:".075","stroke-linejoin":"round",transform:`${hairTransform} translate(0 -1)`});
      }
    }

    const browStroke = (s.brows === "bold" ? 4.3 : s.brows === "tapered" ? 2.5 : 3) * browThicknessScale;
    const leftBrow =
      s.brows === "arched" ? "M44 52q7-7 14 0" :
      s.brows === "high_arch" ? "M44 53q7-10 14-1" :
      s.brows === "rounded" ? "M44 53q7-5 14 0" :
      s.brows === "straight" ? "M44 51h14" :
      s.brows === "tapered" ? "M44 52q8-4 14-1" :
      s.brows === "feathered" ? "M44 53q7-5 14-1" : "M44 52q7-3 14 0";
    const rightBrow =
      s.brows === "arched" ? "M70 52q7-7 14 0" :
      s.brows === "high_arch" ? "M70 52q7-10 14 1" :
      s.brows === "rounded" ? "M70 53q7-5 14 0" :
      s.brows === "straight" ? "M70 51h14" :
      s.brows === "tapered" ? "M70 51q6-3 14 1" :
      s.brows === "feathered" ? "M70 52q7-5 14-1" : "M70 52q7-3 14 0";
    if (expression === "sad") {
      add("path",{d:"M44 55q7-6 14-1",fill:"none",stroke:hair,"stroke-width":browStroke,"stroke-linecap":"round",transform:`translate(0 ${browHeightOffset.toFixed(2)})`});
      add("path",{d:"M70 54q7-5 14 1",fill:"none",stroke:hair,"stroke-width":browStroke,"stroke-linecap":"round",transform:`translate(0 ${browHeightOffset.toFixed(2)})`});
    } else {
      add("path",{d:leftBrow,fill:"none",stroke:hair,"stroke-width":browStroke,"stroke-linecap":"round",transform:`translate(0 ${browHeightOffset.toFixed(2)})`});
      add("path",{d:rightBrow,fill:"none",stroke:hair,"stroke-width":browStroke,"stroke-linecap":"round",transform:`translate(0 ${browHeightOffset.toFixed(2)})`});
    }

    const eye = (cx, mode, side, scale = 1) => {
      if (expression === "love") {
        const x = cx;
        add("path",{
          d:`M${x} 68c-8-5-8-13-2-13 3 0 5 2 6 4 1-2 3-4 6-4 6 0 6 8-2 13l-4 3-4-3Z`,
          fill:"#d95773",
          transform:`translate(${-4} 0)`
        });
        return;
      }
      if (expression === "laugh" || mode === "sleepy" || (expression === "yes" && side === "right") || (mode === "wink" && side === "right")) {
        add("path",{d:`M${cx-7} ${62+eyeHeightOffset}q7 6 14 0`,fill:"none",stroke:"#272421","stroke-width":"3.6","stroke-linecap":"round"});
        return;
      }
      const ry = (mode === "bright" ? 5.5 : mode === "soft" ? 4 : mode === "almond" ? 3.6 : mode === "hooded" ? 3.2 : mode === "monolid" ? 2.8 : mode === "cat" ? 3.5 : 5) * eyeScale;
      const rx = (mode === "wide" ? 6.4 : ["almond","hooded","monolid","cat"].includes(mode) ? 6 : 5.2) * eyeScale;
      const eyeY = 62 + eyeHeightOffset;
      const eyeTilt = side === "left" ? eyeTiltDegrees : -eyeTiltDegrees;
      add("ellipse",{cx,cy:eyeY.toFixed(2),rx:rx.toFixed(2),ry:ry.toFixed(2),fill:"#fff",transform:`rotate(${eyeTilt.toFixed(2)} ${cx} ${eyeY.toFixed(2)})`});
      const irisX = cx + (side==="left" ? 1 : -1);
      add("circle",{cx:irisX,cy:eyeY.toFixed(2),r:((mode === "wide" ? 3.15 : 2.9) * Math.min(1.12, eyeScale) * irisScale).toFixed(2),fill:irisColor});
      add("circle",{cx:irisX,cy:eyeY.toFixed(2),r:(1.45 * Math.min(1.22, irisScale)).toFixed(2),fill:"#171717"});
      add("circle",{cx:cx+(side==="left"?2:0),cy:(eyeY-1).toFixed(2),r:.8,fill:"#fff"});
    };
    const leftEyeX = 64 - 13 * eyeSpacingScale;
    const rightEyeX = 64 + 13 * eyeSpacingScale;
    eye(leftEyeX,s.eyes,"left", eyeScale);
    eye(rightEyeX,s.eyes,"right", eyeScale);

    if (s.lashes !== "none" && expression !== "love") {
      const lashStroke = s.lashes === "full" ? 1.7 : 1.15;
      const lashLength = s.lashes === "full" ? 4.2 : s.lashes === "cat" ? 5 : 3;
      const leftOuter = leftEyeX - 5.3 * eyeScale;
      const rightOuter = rightEyeX + 5.3 * eyeScale;
      const eyeY = 60 + eyeHeightOffset;
      add("path",{d:`M${leftOuter.toFixed(2)} ${eyeY.toFixed(2)}l${(-lashLength).toFixed(2)} -${(lashLength*.55).toFixed(2)}`,fill:"none",stroke:"#211b22","stroke-width":lashStroke,"stroke-linecap":"round"});
      add("path",{d:`M${rightOuter.toFixed(2)} ${eyeY.toFixed(2)}l${lashLength.toFixed(2)} -${(lashLength*.55).toFixed(2)}`,fill:"none",stroke:"#211b22","stroke-width":lashStroke,"stroke-linecap":"round"});
      if (s.lashes === "full") {
        add("path",{d:`M${(leftOuter+2.2).toFixed(2)} ${(eyeY-.8).toFixed(2)}l-2.1 -3M${(rightOuter-2.2).toFixed(2)} ${(eyeY-.8).toFixed(2)}l2.1 -3`,fill:"none",stroke:"#211b22","stroke-width":"1.2","stroke-linecap":"round"});
      }
    }

    if (s.makeup === "liner" || s.makeup === "bold") {
      const stroke = s.makeup === "bold" ? 2.1 : 1.35;
      add("path",{d:`M${(leftEyeX-7).toFixed(2)} ${(59+eyeHeightOffset).toFixed(2)}q7 -4 14 0`,fill:"none",stroke:"#211b22","stroke-width":stroke,"stroke-linecap":"round"});
      add("path",{d:`M${(rightEyeX-7).toFixed(2)} ${(59+eyeHeightOffset).toFixed(2)}q7 -4 14 0`,fill:"none",stroke:"#211b22","stroke-width":stroke,"stroke-linecap":"round"});
    }
    if (s.makeup === "rosy" || s.makeup === "bold") {
      add("ellipse",{cx:45,cy:75,rx:7.5,ry:3.1,fill:"#db7586",opacity:s.makeup === "bold" ? ".24" : ".15"});
      add("ellipse",{cx:83,cy:75,rx:7.5,ry:3.1,fill:"#db7586",opacity:s.makeup === "bold" ? ".24" : ".15"});
    }

    const nosePath = {
      button:"M61 68q3 5 7 0",
      straight:"M64 64v10",
      wide:"M59 72q5 4 10 0",
      petite:"M62 70q2 3 5 0",
      aquiline:"M63 63q5 5 1 12",
      upturned:"M60 72q4-3 8 0",
      soft:"M63 64q-2 8 1 10",
    }[s.nose] || "M63 64q-2 8 1 10";
    add("path",{d:nosePath,fill:"none",stroke:skinShade,"stroke-width":"2","stroke-linecap":"round",opacity:".75",transform:`translate(64 70) scale(${(noseScale*noseWidthScale).toFixed(3)} ${noseScale.toFixed(3)}) translate(-64 -70)`});

    if (s.face_detail === "blush") {
      add("ellipse",{cx:45,cy:75,rx:7,ry:3,fill:"#d96d7d",opacity:".18"});
      add("ellipse",{cx:83,cy:75,rx:7,ry:3,fill:"#d96d7d",opacity:".18"});
    } else if (s.face_detail === "freckles") {
      for (const [cx,cy] of [[49,72],[54,74],[58,72],[70,72],[74,74],[79,72]]) add("circle",{cx,cy,r:.9,fill:"#8f5c43",opacity:".6"});
    } else if (s.face_detail === "beauty_mark") {
      add("circle",{cx:82,cy:77,r:1.4,fill:"#49342d",opacity:".85"});
    } else if (s.face_detail === "sun_kiss") {
      add("path",{d:"M45 74q19 5 38 0",fill:"none",stroke:"#b66c58","stroke-width":"2",opacity:".28","stroke-dasharray":"1 4"});
    } else if (s.face_detail === "cheek_mark") {
      add("path",{d:"M82 76l4 2-4 2",fill:"none",stroke:"#8d5649","stroke-width":"1.7",opacity:".7"});
    } else if (s.face_detail === "freckles_dense") {
      for (const [cx,cy] of [[45,70],[49,73],[53,71],[57,74],[60,71],[68,71],[72,74],[76,71],[80,73],[84,70]]) {
        add("circle",{cx,cy,r:.85,fill:"#855540",opacity:".62"});
      }
    } else if (s.face_detail === "under_eye") {
      add("path",{d:"M43 68q8 4 16 0M69 68q8 4 16 0",fill:"none",stroke:"#855849","stroke-width":"1.4",opacity:".25"});
    } else if (s.face_detail === "scar_brow") {
      add("path",{d:"M78 47l5 9",fill:"none",stroke:"#9b6653","stroke-width":"1.6",opacity:".72","stroke-linecap":"round"});
    } else if (s.face_detail === "dimples") {
      add("path",{d:"M46 82q3 3 6 0M76 82q3 3 6 0",fill:"none",stroke:"#8d5b4a","stroke-width":"1.6","stroke-linecap":"round",opacity:".48"});
    }

    if (s.face_decal === "star") {
      add("path",{d:"m87 72 1.4 3 3.3.3-2.5 2.2.8 3.2-3-1.7-2.8 1.7.7-3.2-2.4-2.2 3.2-.3Z",fill:accessoryColor,opacity:".72"});
    } else if (s.face_decal === "heart") {
      add("path",{d:"M84 74c0-4 5-4 6-1 1-3 6-3 6 1 0 4-6 8-6 8s-6-4-6-8Z",fill:accessoryColor,opacity:".66",transform:"scale(.72) translate(35 28)"});
    } else if (s.face_decal === "bolt") {
      add("path",{d:"m88 70-5 8h4l-2 7 8-10h-4l3-5Z",fill:accessoryColor,opacity:".68"});
    }

    const mouthMode = expression || s.mouth;
    const mouthTransform = `translate(64 82) scale(${mouthWidthScale.toFixed(3)} ${lipFullnessScale.toFixed(3)}) translate(-64 -82)`;
    if (mouthMode === "wow") {
      add("ellipse",{cx:64,cy:82,rx:6,ry:8,fill:lipColor,transform:mouthTransform});
    } else if (mouthMode === "sad") {
      add("path",{d:"M54 86q10-8 20 0",fill:"none",stroke:lipColor,"stroke-width":"3","stroke-linecap":"round",transform:mouthTransform});
    } else if (mouthMode === "laugh" || mouthMode === "fire" || mouthMode === "grin") {
      add("path",{d:"M52 80q12 15 24 0c-4 17-20 17-24 0Z",fill:lipColor,transform:mouthTransform});
      add("path",{d:"M56 82h16",stroke:"#fff","stroke-width":"3","stroke-linecap":"round",transform:mouthTransform});
    } else if (mouthMode === "open") {
      add("ellipse",{cx:64,cy:82,rx:7,ry:5,fill:lipColor,transform:mouthTransform});
    } else if (mouthMode === "neutral") {
      add("path",{d:"M56 82h16",fill:"none",stroke:lipColor,"stroke-width":"3","stroke-linecap":"round",transform:mouthTransform});
    } else if (mouthMode === "smirk") {
      add("path",{d:"M55 83q12 4 19-3",fill:"none",stroke:lipColor,"stroke-width":"3","stroke-linecap":"round",transform:mouthTransform});
    } else if (mouthMode === "kiss") {
      add("path",{d:"M59 81q5-4 10 0-5 5-10 0Z",fill:lipColor,transform:mouthTransform});
    } else if (mouthMode === "cool") {
      add("path",{d:"M55 82q9 4 18 0",fill:"none",stroke:lipColor,"stroke-width":"3","stroke-linecap":"round",transform:mouthTransform});
    } else {
      add("path",{d:"M54 80q10 10 20 0",fill:"none",stroke:lipColor,"stroke-width":"3","stroke-linecap":"round",transform:mouthTransform});
    }

    if (s.facial_hair === "stubble") {
      for (let i=0;i<18;i++) add("circle",{cx:48+(i%6)*6,cy:78+Math.floor(i/6)*5,r:.7,fill:"#332620",opacity:(.55*facialHairOpacity).toFixed(3)});
    } else if (s.facial_hair === "mustache") {
      add("path",{d:"M53 77q6-5 11 0 5-5 11 0-6 5-11 1-5 4-11-1Z",fill:hair,opacity:facialHairOpacity.toFixed(3)});
    } else if (s.facial_hair === "beard") {
      add("path",{d:"M43 76c2 24 11 31 21 31s20-7 22-31c-5 12-12 18-22 18S48 88 43 76Z",fill:hair,opacity:(.9*facialHairOpacity).toFixed(3)});
    } else if (s.facial_hair === "goatee") {
      add("path",{d:"M58 88q6 6 12 0l-2 14h-8Z",fill:hair,opacity:(.9*facialHairOpacity).toFixed(3)});
    } else if (s.facial_hair === "boxed_beard") {
      add("path",{d:"M45 75c1 18 7 27 19 27s18-9 19-27c-4 11-10 16-19 16s-15-5-19-16Z",fill:hair,opacity:(.84*facialHairOpacity).toFixed(3)});
      add("path",{d:"M52 77q6-5 12 0 6-5 12 0-6 5-12 2-6 3-12-2Z",fill:hair,opacity:facialHairOpacity.toFixed(3)});
    } else if (s.facial_hair === "full_beard") {
      add("path",{d:"M41 72c0 27 9 39 23 39s24-12 24-39c-5 14-13 21-24 21S46 86 41 72Z",fill:hair,opacity:(.94*facialHairOpacity).toFixed(3)});
      add("path",{d:"M51 76q7-6 13 0 7-6 14 0-7 6-14 2-6 4-13-2Z",fill:hair,opacity:facialHairOpacity.toFixed(3)});
    } else if (s.facial_hair === "soul_patch") {
      add("path",{d:"M60 89q4 3 8 0l-1 9h-6Z",fill:hair,opacity:(.9*facialHairOpacity).toFixed(3)});
    }

    if (["glasses","round_glasses","square_glasses","sunglasses"].includes(s.accessory)) {
      const darkLens = s.accessory === "sunglasses";
      if (s.accessory === "round_glasses") {
        add("circle",{cx:51,cy:62,r:9,fill:darkLens ? accessoryColor : "none",stroke:accessoryColor,"stroke-width":"3",opacity:darkLens?".82":"1"});
        add("circle",{cx:77,cy:62,r:9,fill:darkLens ? accessoryColor : "none",stroke:accessoryColor,"stroke-width":"3",opacity:darkLens?".82":"1"});
      } else {
        const radius = s.accessory === "square_glasses" ? 2.5 : 5;
        add("rect",{x:41,y:54,width:20,height:16,rx:radius,fill:darkLens ? accessoryColor : "none",stroke:accessoryColor,"stroke-width":"3",opacity:darkLens?".82":"1"});
        add("rect",{x:67,y:54,width:20,height:16,rx:radius,fill:darkLens ? accessoryColor : "none",stroke:accessoryColor,"stroke-width":"3",opacity:darkLens?".82":"1"});
      }
      add("path",{d:"M61 61h6",stroke:accessoryColor,"stroke-width":"3","stroke-linecap":"round"});
    } else if (s.accessory === "aviator") {
      add("path",{d:"M40 55q11-4 22 0l-2 15q-9 5-18-2Z",fill:accessoryColor,opacity:".32",stroke:accessoryColor,"stroke-width":"2.5"});
      add("path",{d:"M66 55q11-4 22 0l-2 13q-9 7-18 2Z",fill:accessoryColor,opacity:".32",stroke:accessoryColor,"stroke-width":"2.5"});
      add("path",{d:"M61 59h6",stroke:accessoryColor,"stroke-width":"2.5","stroke-linecap":"round"});
    } else if (s.accessory === "heart_glasses") {
      add("path",{d:"M41 58c0-6 8-7 10-2 2-5 10-4 10 2 0 6-10 12-10 12s-10-6-10-12Z",fill:accessoryColor,opacity:".5",stroke:accessoryColor,"stroke-width":"1.8"});
      add("path",{d:"M67 58c0-6 8-7 10-2 2-5 10-4 10 2 0 6-10 12-10 12s-10-6-10-12Z",fill:accessoryColor,opacity:".5",stroke:accessoryColor,"stroke-width":"1.8"});
      add("path",{d:"M61 59h6",stroke:accessoryColor,"stroke-width":"2.2"});
    } else if (s.accessory === "earrings") {
      add("circle",{cx:38,cy:70,r:3,fill:accessoryColor});
      add("circle",{cx:90,cy:70,r:3,fill:accessoryColor});
    } else if (s.accessory === "nose_ring") {
      add("circle",{cx:69,cy:72,r:3.2,fill:"none",stroke:accessoryColor,"stroke-width":"1.8"});
    } else if (s.accessory === "hoop_earrings") {
      add("circle",{cx:37,cy:72,r:5.2,fill:"none",stroke:accessoryColor,"stroke-width":"2"});
      add("circle",{cx:91,cy:72,r:5.2,fill:"none",stroke:accessoryColor,"stroke-width":"2"});
    } else if (s.accessory === "studs") {
      add("circle",{cx:38,cy:68,r:2.1,fill:accessoryColor});
      add("circle",{cx:90,cy:68,r:2.1,fill:accessoryColor});
    } else if (s.accessory === "septum") {
      add("path",{d:"M60 73q4 7 8 0",fill:"none",stroke:accessoryColor,"stroke-width":"1.8","stroke-linecap":"round"});
    } else if (s.accessory === "lip_ring") {
      add("circle",{cx:72,cy:83,r:2.8,fill:"none",stroke:accessoryColor,"stroke-width":"1.6"});
    } else if (s.accessory === "chain") {
      add("path",{d:"M45 99q19 14 38 0",fill:"none",stroke:accessoryColor,"stroke-width":"3","stroke-linecap":"round"});
      add("circle",{cx:64,cy:106,r:3,fill:accessoryColor});
    } else if (s.accessory === "monocle") {
      add("circle",{cx:77,cy:62,r:10,fill:"none",stroke:accessoryColor,"stroke-width":"2.5"});
      add("path",{d:"M86 69q6 12 3 29",fill:"none",stroke:accessoryColor,"stroke-width":"2"});
    } else if (s.accessory === "brow_ring") {
      add("circle",{cx:82,cy:51,r:3,fill:"none",stroke:accessoryColor,"stroke-width":"1.6"});
    } else if (s.accessory === "pearl_chain") {
      for (let x=48; x<=80; x+=5.4) add("circle",{cx:x,cy:104+Math.abs(64-x)*.12,r:2,fill:accessoryColor,opacity:".92"});
    } else if (s.accessory === "choker") {
      add("path",{d:"M47 101q17 7 34 0",fill:"none",stroke:accessoryColor,"stroke-width":"4","stroke-linecap":"round"});
    } else if (s.accessory === "hearing_aid") {
      add("path",{d:"M91 55q8 4 5 15l-5 6",fill:"none",stroke:accessoryColor,"stroke-width":"3","stroke-linecap":"round"});
      add("circle",{cx:91,cy:76,r:2.5,fill:accessoryColor});
    } else if (s.accessory === "face_bandage") {
      add("rect",{x:77,y:72,width:15,height:6,rx:3,fill:"#e9d6be",transform:"rotate(-14 84.5 75)"});
      add("path",{d:"M82 72v6M87 71v6",stroke:"#b8a58e","stroke-width":"1",opacity:".65"});
    } else if (s.accessory === "earbuds") {
      add("circle",{cx:37,cy:67,r:3.2,fill:accessoryColor});
      add("circle",{cx:91,cy:67,r:3.2,fill:accessoryColor});
      add("path",{d:"M37 69v8M91 69v8",stroke:accessoryColor,"stroke-width":"2.5","stroke-linecap":"round"});
    } else if (s.accessory === "cap") {
      add("path",{d:"M34 43c2-20 14-27 30-27s29 8 31 27H34Z",fill:accessoryColor});
      add("path",{d:"M62 42h38c-5-6-17-8-38-8v8Z",fill:"#171b22",opacity:".55"});
    } else if (s.accessory === "headphones") {
      add("path",{d:"M31 61c0-21 13-37 33-37s33 16 33 37",fill:"none",stroke:accessoryColor,"stroke-width":"6","stroke-linecap":"round"});
      add("rect",{x:27,y:57,width:10,height:22,rx:5,fill:accessoryColor});
      add("rect",{x:91,y:57,width:10,height:22,rx:5,fill:accessoryColor});
    }

    if (s.headwear === "beanie") {
      add("path",{d:"M34 42c2-20 14-29 30-29 17 0 29 10 31 29H34Z",fill:accessoryColor});
      add("rect",{x:33,y:38,width:63,height:9,rx:4.5,fill:accessoryColor,opacity:".88"});
    } else if (s.headwear === "bandana") {
      add("path",{d:"M35 37q29-15 58 1l-3 10q-27-11-53 0Z",fill:accessoryColor});
      add("path",{d:"M91 42l15 9-12 4Z",fill:accessoryColor});
    } else if (s.headwear === "durag") {
      add("path",{d:"M34 39q30-19 60 0l-4 13q-26-13-52 0Z",fill:accessoryColor});
      add("path",{d:"M91 43q9 18 2 38l-8-4q5-17 0-30Z",fill:accessoryColor,opacity:".9"});
    } else if (s.headwear === "cap" || s.headwear === "snapback" || s.headwear === "sports_cap") {
      add("path",{d:"M34 42c2-19 14-27 30-27s28 8 31 27H34Z",fill:accessoryColor});
      add("path",{d:s.headwear === "snapback" ? "M55 41h46c-9-7-24-10-46-8v8Z" : "M62 41h39c-8-7-20-9-39-8v8Z",fill:accessoryColor,opacity:".78"});
      if (s.headwear === "sports_cap") add("text",{x:64,y:34,"text-anchor":"middle",fill:"#fff","font-size":"12","font-weight":"900",opacity:".72"}).textContent="S";
    } else if (s.headwear === "headphones") {
      add("path",{d:"M31 60c0-21 13-37 33-37s33 16 33 37",fill:"none",stroke:accessoryColor,"stroke-width":"6","stroke-linecap":"round"});
      add("rect",{x:27,y:56,width:10,height:23,rx:5,fill:accessoryColor});
      add("rect",{x:91,y:56,width:10,height:23,rx:5,fill:accessoryColor});
    } else if (s.headwear === "crown") {
      add("path",{d:"M40 31 47 15l10 10 8-15 9 15 11-10 4 17H40Z",fill:accessoryColor});
    } else if (s.headwear === "bucket") {
      add("path",{d:"M38 19h52l5 24H33l5-24Z",fill:accessoryColor});
      add("path",{d:"M26 42q38-10 76 0",fill:"none",stroke:accessoryColor,"stroke-width":"8","stroke-linecap":"round"});
    } else if (s.headwear === "beret") {
      add("path",{d:"M35 34c8-19 42-25 57-7l-7 13H39Z",fill:accessoryColor});
      add("path",{d:"M59 16q5-7 10 0",fill:"none",stroke:accessoryColor,"stroke-width":"3","stroke-linecap":"round"});
    } else if (s.headwear === "fedora") {
      add("path",{d:"M42 14h44l5 25H37l5-25Z",fill:accessoryColor});
      add("path",{d:"M28 40q36-9 72 0",fill:"none",stroke:accessoryColor,"stroke-width":"7","stroke-linecap":"round"});
      add("path",{d:"M41 31h49",stroke:"#111","stroke-width":"4",opacity:".25"});
    } else if (s.headwear === "cat_ears") {
      add("path",{d:"M39 35 42 13l15 17M89 35 86 13 71 30",fill:accessoryColor,stroke:accessoryColor,"stroke-width":"4","stroke-linejoin":"round"});
    } else if (s.headwear === "hood") {
      add("path",{d:"M28 58c-2-31 12-48 36-48s38 17 36 48l-10-4c0-22-9-34-26-34S38 32 38 54l-10 4Z",fill:accessoryColor,opacity:".92"});
    } else if (s.headwear === "visor") {
      add("path",{d:"M36 30q28-10 56 0l-3 9q-25-7-50 0Z",fill:accessoryColor});
      add("path",{d:"M59 38h42q-8 8-42 7Z",fill:accessoryColor,opacity:".85"});
    } else if (s.headwear === "cowboy") {
      add("path",{d:"M43 12h42l6 27H37l6-27Z",fill:accessoryColor});
      add("path",{d:"M22 40q42-13 84 0-11 11-84 0Z",fill:accessoryColor});
    } else if (s.headwear === "tiara") {
      add("path",{d:"M42 33 48 19l10 9 7-15 8 15 10-9 4 14Z",fill:"none",stroke:accessoryColor,"stroke-width":"3","stroke-linejoin":"round"});
      add("circle",{cx:65,cy:18,r:2.5,fill:accessoryColor});
    } else if (s.headwear === "flower") {
      for (const [cx,cy] of [[88,24],[95,29],[91,36],[82,35],[80,27]]) add("circle",{cx,cy,r:5,fill:accessoryColor});
      add("circle",{cx:87,cy:30,r:4,fill:"#f0c760"});
    } else if (s.headwear === "headband") {
      add("path",{d:"M34 37q30-15 60 0",fill:"none",stroke:accessoryColor,"stroke-width":"7","stroke-linecap":"round"});
    } else if (s.headwear === "bow") {
      add("path",{d:"M82 25c-8-10-16-6-13 4 3 7 10 7 15 4 5 3 12 3 15-4 3-10-5-14-13-4Z",fill:accessoryColor});
      add("circle",{cx:84,cy:29,r:4,fill:accessoryColor,opacity:".82"});
    }

    if (expression === "yes") {
      add("circle",{cx:105,cy:25,r:13,fill:"#46c982"});
      add("path",{d:"M99 25l4 4 8-9",fill:"none",stroke:"#fff","stroke-width":"3.4","stroke-linecap":"round","stroke-linejoin":"round"});
    }

    if (expression === "fire") {
      add("path",{d:"M101 27c9 8 7 16 1 22 1-6-4-7-2-13-7 6-9 13-4 18-14-3-16-18-6-27 0 6 4 6 6 10 1-5 3-8 5-10Z",fill:"#ffb349"});
    }

    return svg;
  }

  function avatarStyleDataUrl(style, expression = "") {
    const normalized = normalizedAvatarStyle(style);
    const key = JSON.stringify([normalized, expression || ""]);
    const cached = state.avatarDataUrlCache.get(key);
    if (cached) return cached;

    const svg = avatarSvgElement(normalized, expression);
    const markup = new XMLSerializer().serializeToString(svg);
    const url = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(markup)}`;

    state.avatarDataUrlCache.set(key, url);
    const avatarCacheLimit =
      document.documentElement.dataset.performance === "efficient" ? 24 : 48;
    while (state.avatarDataUrlCache.size > avatarCacheLimit) {
      const oldest = state.avatarDataUrlCache.keys().next().value;
      state.avatarDataUrlCache.delete(oldest);
    }
    return url;
  }

  function setAvatar(element, name, accent = "silver", avatarUrl = "", avatarStyle = null, expression = "") {
    if (!element) return;

    const sizeClasses = ["avatar-lg", "avatar-xl", "call-avatar", "avatar-reaction"].filter(
      (className) => element.classList.contains(className)
    );

    element.className = `avatar ${accentClass(accent)} ${sizeClasses.join(" ")}`.trim();
    element.replaceChildren();

    if (avatarUrl) {
      const image = document.createElement("img");
      image.src = avatarUrl;
      image.alt = "";
      const criticalAvatar = Boolean(
        element.closest?.(".chat-header,.me-bar,.call-stage,.incoming-call-card,.profile-card")
      );
      image.loading = criticalAvatar ? "eager" : "lazy";
      image.decoding = "async";
      if (criticalAvatar) {
        try { image.fetchPriority = "high"; } catch {}
      }

      image.addEventListener("error", () => {
        element.replaceChildren();
        if (avatarStyle && Object.keys(avatarStyle).length) {
          const fallback = document.createElement("img");
          fallback.src = avatarStyleDataUrl(avatarStyle, expression);
          fallback.alt = "";
          fallback.decoding = "async";
          element.appendChild(fallback);
          element.classList.add("custom-avatar");
        } else {
          element.textContent = initials(name);
        }
      }, { once: true });

      element.appendChild(image);
      return;
    }

    if (avatarStyle && typeof avatarStyle === "object" && Object.keys(avatarStyle).length) {
      const image = document.createElement("img");
      image.src = avatarStyleDataUrl(avatarStyle, expression);
      image.alt = "";
      image.decoding = "async";
      element.appendChild(image);
      element.classList.add("custom-avatar");
      return;
    }

    element.textContent = initials(name);
  }

  function formatTime(timestamp) {
    if (!timestamp) return "";
    return new Date(Number(timestamp) * 1000).toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    });
  }

  function formatListTime(timestamp) {
    if (!timestamp) return "";

    const date = new Date(Number(timestamp) * 1000);
    const now = new Date();

    if (date.toDateString() === now.toDateString()) {
      return formatTime(timestamp);
    }

    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);

    if (date.toDateString() === yesterday.toDateString()) {
      return "Yesterday";
    }

    return date.toLocaleDateString([], {
      month: "short",
      day: "numeric",
    });
  }

  function formatFileSize(bytes) {
    const size = Number(bytes || 0);

    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  }

  function messageDayKey(timestamp) {
    const date = new Date(Number(timestamp) * 1000);
    return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
  }

  function messageDayLabel(timestamp) {
    const date = new Date(Number(timestamp) * 1000);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);

    if (date.toDateString() === today.toDateString()) return "Today";
    if (date.toDateString() === yesterday.toDateString()) return "Yesterday";

    return date.toLocaleDateString([], {
      month: "short",
      day: "numeric",
      year: date.getFullYear() === today.getFullYear() ? undefined : "numeric",
    });
  }

  function setSyncStatus(kind, label) {
    const element = $("#syncStatus");
    if (!element) return;

    element.classList.remove("busy", "error");
    if (kind) element.classList.add(kind);

    const labelElement = element.querySelector("span:last-child");
    if (labelElement) labelElement.textContent = label;
  }

  function passwordRequirements(password) {
    return {
      length: password.length >= 8,
      number: /\d/.test(password),
      symbol: /[^A-Za-z0-9\s]/.test(password),
    };
  }

  function passwordIsValid(password) {
    const rules = passwordRequirements(password);
    return rules.length && rules.number && rules.symbol;
  }

  function updatePasswordRules() {
    const password = $("#authPassword").value;
    const rules = passwordRequirements(password);

    $("#ruleLength").classList.toggle("passed", rules.length);
    $("#ruleNumber").classList.toggle("passed", rules.number);
    $("#ruleSymbol").classList.toggle("passed", rules.symbol);
  }

  function setAuthError(message = "") {
    const element = $("#authError");
    element.textContent = message;
    element.classList.toggle("visible", Boolean(message));
  }

  function setAuthMode(mode) {
    if (!["login", "signup"].includes(mode) || state.authBusy) return;

    state.authMode = mode;
    const signup = mode === "signup";

    $("#authTabs").classList.toggle("signup", signup);
    $("#loginTab").classList.toggle("active", !signup);
    $("#signupTab").classList.toggle("active", signup);
    $("#passwordRules").classList.toggle("hidden", !signup);
    $("#confirmPasswordField").classList.toggle("hidden", !signup);
    $("#authPasswordConfirm").required = signup;
    $("#authPassword").autocomplete = signup ? "new-password" : "current-password";
    $("#authPassword").placeholder = signup
      ? "8+ characters, number + symbol"
      : "Your password";
    $("#authSubmit").textContent = signup ? "Create account" : "Log in";

    // Never carry a revealed password across the Login/Create account tabs.
    // The eye remains an explicit, temporary user action.
    ["authPassword", "authPasswordConfirm"].forEach((id) => {
      const input = document.getElementById(id);
      const toggle = document.querySelector(`[data-password-target="${id}"]`);
      if (input) input.type = "password";
      if (toggle) {
        toggle.setAttribute("aria-pressed", "false");
        toggle.setAttribute("aria-label", "Show password");
        toggle.title = "Show password";
        setButtonContent(toggle, "eye");
      }
    });

    if (!signup) $("#authPasswordConfirm").value = "";
    setAuthError("");
    updatePasswordRules();
  }

  function prefersLightTheme() {
    return Boolean(
      window.matchMedia?.("(prefers-color-scheme: light)")?.matches
    );
  }

  function resolvedTheme(choice) {
    if (choice === "dark") choice = "amoled";
    const value = ["system", "dark", "light", "amoled"].includes(choice)
      ? choice
      : "dark";

    if (value === "system") {
      return prefersLightTheme() ? "light" : "amoled";
    }

    return value;
  }

  function resolvedIconStyle(choice, themeChoice = state.themeChoice) {
    const value = ["auto", "dark", "light"].includes(choice)
      ? choice
      : "auto";

    if (value !== "auto") return value;
    return resolvedTheme(themeChoice) === "light" ? "light" : "dark";
  }

  function applyAppIcon(choice = state.iconStyleChoice, themeChoice = state.themeChoice) {
    const normalized = ["auto", "dark", "light"].includes(choice)
      ? choice
      : "auto";
    const resolved = resolvedIconStyle(normalized, themeChoice);
    const root = document.documentElement;

    state.iconStyleChoice = normalized;
    root.dataset.iconStyle = resolved;

    const favicon = $("#faviconPng");
    const apple = $("#appleTouchIcon");
    const manifest = $("#appManifest");

    if (favicon) favicon.href = resolved === "light" ? "app-icon-white.png" : "app-icon-black.png";
    if (apple) apple.href = resolved === "light" ? "app-icon-white.png" : "app-icon-black.png";
    if (manifest) manifest.href = `manifest-${resolved}.webmanifest`;

    try {
      window.SilknexStorage.setItem("neochat-icon-style", normalized);
    } catch {}

    return resolved;
  }

  function notificationIcon() {
    const style = resolvedIconStyle(
      state.me?.app_icon_style || state.iconStyleChoice || "auto",
      state.me?.theme || state.themeChoice || "dark"
    );
    return "app-icon-black.png";
  }

  function notificationBadge() {
    const style = resolvedIconStyle(
      state.me?.app_icon_style || state.iconStyleChoice || "auto",
      state.me?.theme || state.themeChoice || "dark"
    );
    return "app-icon-black.png";
  }

  const notificationAvatarCache = new Map();

  async function notificationSafeIcon(rawUrl) {
    const fallback = notificationIcon();
    const raw = String(rawUrl || "").trim();
    if (!raw) return fallback;

    let parsed;
    try {
      parsed = new URL(raw, window.location.href);
    } catch {
      return fallback;
    }

    if (parsed.origin !== window.location.origin) {
      return parsed.protocol === "https:" ? parsed.href : fallback;
    }

    if (parsed.searchParams.get("action") === "notification_media") {
      return parsed.href;
    }

    if (parsed.searchParams.get("action") !== "media") {
      return parsed.href;
    }

    const token = String(parsed.searchParams.get("token") || "").toLowerCase();
    if (!/^[a-f0-9]{48}$/.test(token)) return fallback;

    const cached = notificationAvatarCache.get(token);
    if (cached && Number(cached.expiresAt || 0) > Date.now() + 60000) {
      return cached.url;
    }

    try {
      const data = await api("notification_icon", {}, { token });
      const url = String(data.url || "");
      const expiresAt = Number(data.expires_at || 0) * 1000;
      if (url) {
        if (notificationAvatarCache.size >= 48) {
          const firstKey = notificationAvatarCache.keys().next().value;
          if (firstKey) notificationAvatarCache.delete(firstKey);
        }
        notificationAvatarCache.set(token, { url, expiresAt });
        return url;
      }
    } catch {}

    return fallback;
  }

  function applyAppearance(user = state.me) {
    let rememberedTheme = "dark";
    let rememberedIconStyle = "auto";

    try {
      rememberedTheme =
        window.SilknexStorage.getItem("neochat-theme-choice") ||
        window.SilknexStorage.getItem("neochat-theme") ||
        "dark";
      rememberedIconStyle =
        window.SilknexStorage.getItem("neochat-icon-style") || "auto";
    } catch {}

    const themeChoice = ["system", "dark", "light", "amoled"].includes(user?.theme)
      ? (user.theme === "dark" ? "amoled" : user.theme)
      : rememberedTheme;
    const iconStyle = ["auto", "dark", "light"].includes(user?.app_icon_style)
      ? user.app_icon_style
      : rememberedIconStyle;
    const theme = resolvedTheme(themeChoice);
    const fontScale = user?.font_scale || "normal";
    const fontFamily = user?.font_family || "system";
    const uiAccent = user?.ui_accent || "silver";
    const bubbleStyle = user?.bubble_style || "rounded";
    const density = user?.message_density || "normal";
    const chatWidth = user?.chat_width || "normal";
    const reduceMotion = Boolean(user?.reduce_motion);
    const easyMode = Boolean(user?.easy_mode || user?.kid_mode);

    state.themeChoice = themeChoice;
    state.iconStyleChoice = iconStyle;

    document.documentElement.dataset.themeChoice = themeChoice;
    document.documentElement.dataset.theme = theme;
    document.documentElement.dataset.font = fontScale;
    document.documentElement.dataset.fontFamily = fontFamily;
    document.documentElement.dataset.uiAccent = uiAccent;
    document.documentElement.dataset.bubbles = bubbleStyle;
    document.documentElement.dataset.density = density;
    document.documentElement.dataset.chatWidth = chatWidth;
    document.documentElement.dataset.reduceMotion = reduceMotion ? "true" : "false";
    document.documentElement.dataset.easyMode = easyMode ? "true" : "false";

    try {
      window.SilknexStorage.setItem("neochat-theme-choice", themeChoice);
      window.SilknexStorage.setItem("neochat-theme", themeChoice);
    } catch {}

    applyAppIcon(iconStyle, themeChoice);

    const color = theme === "light"
      ? "#f3f5f8"
      : theme === "amoled"
        ? "#000000"
        : "#090a0d";
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", color);
    document
      .querySelector('meta[name="apple-mobile-web-app-status-bar-style"]')
      ?.setAttribute("content", theme === "light" ? "default" : "black-translucent");
  }

  function isFounderRole(role) {
    return ["founder_ceo", "cofounder_ceo"].includes(String(role || ""));
  }

  function founderBadgeNode(role = "founder_ceo") {
    const badge = document.createElement("span");
    badge.className = "founder-badge";
    badge.textContent = role === "cofounder_ceo" ? "CO-FOUNDER/CEO" : "FOUNDER/CEO";
    badge.title = "SilkNex " + badge.textContent;
    return badge;
  }

  function renderMe() {
    if (!state.me) return;

    $("#meName").textContent = state.me.display_name;
    $("#meUsername").textContent = `@${state.me.username}`;
    if ($("#meRoleBadge")) { $("#meRoleBadge").textContent = founderBadgeNode(state.me.role).textContent; $("#meRoleBadge").classList.toggle("hidden", !isFounderRole(state.me.role)); }
    $("#meKidBadge").classList.toggle("hidden", !state.me.kid_mode);

    setAvatar(
      $("#meAvatar"),
      state.me.display_name,
      state.me.accent,
      state.me.avatar_url,
      state.me.avatar_style
    );

    applyAppearance(state.me);
  }

  function scheduleAuxiliaryBootstrap() {
    clearTimeout(state.auxiliaryBootstrapTimer);

    const run = () => {
      if (!state.me) return;

      Promise.allSettled([
        loadFriends({ notify: false }),
        loadStories(),
      ]).catch(() => {});

      if (
        state.me?.notifications_enabled &&
        "Notification" in window &&
        Notification.permission === "granted"
      ) {
        ensurePushSubscription().catch(() => {});
      }

      flushPushQueue();
    };

    if ("requestIdleCallback" in window) {
      window.requestIdleCallback(run, { timeout: 900 });
      return;
    }

    state.auxiliaryBootstrapTimer = setTimeout(run, 180);
  }

  function showApp() {
    if ($("#authView")?.contains(document.activeElement)) document.activeElement?.blur?.();
    updateMobileViewport();
    synchronizeAppShell();
    $("#authView").classList.add("hidden");
    $("#appView").classList.remove("hidden");
    setupCrossTabChannel();
    renderMe();
    schedulePresenceHeartbeat({ immediate: true });
    window.SilknexBoot?.stage?.("security", "loading");
    ensureE2EERegistration()
      .then(() => {
        window.SilknexBoot?.stage?.("security", "ready");
        window.SilknexBoot?.progress?.(88, "Secure messaging ready…");
      })
      .catch((error) => {
        window.SilknexBoot?.stage?.("security", "error");
        console.warn("SilkNex E2EE device registration failed:", error);
      });
    window.dispatchEvent(new CustomEvent("silknex:session", {
      detail: { signedIn: true, userId: Number(state.me?.id || 0) }
    }));
    // Render the Add Story control immediately; story network data can arrive
    // later without blocking creation on mobile.
    renderStoriesRail();
    scheduleGlobalPoll();
    scheduleIncomingCallPoll();
    scheduleAuxiliaryBootstrap();

    if (state.pendingAnswerCallId) {
      setTimeout(() => processPendingCallAnswer(), 0);
    } else if (state.pendingOpenConversationId) {
      const conversationId = state.pendingOpenConversationId;
      state.pendingOpenConversationId = 0;
      setTimeout(() => openConversation(conversationId), 0);
    } else if (state.pendingOpenFriends) {
      state.pendingOpenFriends = false;
      setTimeout(openFriends, 0);
    }
  }

  function showAuth(message = "") {
    state.sessionEpoch = Number(state.sessionEpoch || 0) + 1;
    document.getElementById("voiceRecordingRetry")?.remove();
    clearTimeout(state.recordTapTimer);
    clearDeferredMediaObservers();
    $$("#messages audio, #messages video").forEach((media) => {
      try { media.pause(); media.removeAttribute("src"); media.load(); } catch {}
    });
    clearPendingAttachment();
    // Save the current user's draft under their user/chat-scoped key before
    // clearing account state. The visible composer is then wiped so a second
    // account on the same device can never see the previous user's text.
    if (state.me && state.activeId) {
      persistDraft(state.activeId);
    }

    clearTimeout(state.pollTimer);
    clearTimeout(state.globalPollTimer);
    clearTimeout(state.presenceTimer);
    state.presenceTimer = null;
    state.presencePending = null;
    state.presenceInFlight = null;
    state.presenceActive = false;
    state.presenceLastSentAt = 0;
    state.globalPollController?.abort();
    state.globalPollController = null;
    state.globalPollFailures = 0;
    clearTimeout(state.incomingCallTimer);
    state.syncController?.abort();
    state.syncController = null;
    state.openConversationController?.abort();
    state.openConversationController = null;
    state.syncBusy = false;
    state.conversationRequestId += 1;
    state.conversationLoadPromise = null;
    clearTimeout(state.draftSaveTimer);
    state.draftSaveTimer = null;
    clearTimeout(state.auxiliaryBootstrapTimer);
    state.auxiliaryBootstrapTimer = null;
    clearTimeout(state.storyViewFlushTimer);
    state.storyViewFlushTimer = null;
    state.storyViewQueue.clear();
    clearTimeout(state.expiryTimer);
    state.expiryTimer = null;
    clearTimeout(state.giphySearchTimer);
    state.giphySearchTimer = null;
    state.giphyRequestId += 1;
    clearTimeout(state.mediaHoldTimer);
    state.mediaHoldTimer = null;
    state.mediaHoldMessage = null;
    state.foregroundRefreshPromise = null;
    state.lastForegroundRefreshAt = 0;

    // Session expiry can happen while a sheet is open. Close all app-only
    // surfaces before revealing login so stale settings/media never sit over
    // the authentication screen.
    $("#modalOverlay")?.classList.add("hidden");
    $$(".modal").forEach((modal) => modal.classList.add("hidden"));
    $("#attachmentMenu")?.classList.add("hidden");
    clearStoryPlayback();
    if (state.attachmentObjectUrl) {
      try { URL.revokeObjectURL(state.attachmentObjectUrl); } catch {}
      state.attachmentObjectUrl = "";
    }

    if (state.call) cleanupCall();
    if (
      state.voiceRecorder?.state === "recording" ||
      state.recordingStarting
    ) {
      stopActiveRecording(true);
    }
    stopRingtone();

    if (state.activeId) clearCurrentMobileChatHistory(state.activeId);
    state.me = null;
    state.csrf = "";
    state.e2eeRegisterPromise = null;
    state.typingUsers = [];
    clearTimeout(state.typingStopTimer);
    state.typingStopTimer = null;
    window.SilknexE2EE?.clearMediaCache?.();
    window.dispatchEvent(new CustomEvent("silknex:session", {
      detail: { signedIn: false, userId: 0 }
    }));
    state.activeId = 0;
    state.mobileHistoryChatId = 0;
    state.activeConversation = null;
    state.messages.clear();
    state.changeSeq = 0;
    state.syncFailures = 0;
    state.conversations = [];
    state.conversationsLoaded = false;
    state.conversationFingerprint = "";
    state.inboxSignature = "";
    state.friendSignature = "";
    state.friends = [];
    state.incomingFriends = [];
    state.outgoingFriends = [];
    state.friendsLoaded = false;
    state.lastConversationRefreshAt = 0;
    state.deliveryAckByConversation.clear();
    state.deliveryAckInFlight.clear();
    state.receipt = { recipient_count: 0, delivered_up_to: 0, read_up_to: 0 };
    state.lastReadAckId = 0;
    state.readAckInFlightId = 0;
    state.readAckRequest = null;
    state.readAckFailures = 0;
    clearTimeout(state.readAckRetryTimer);
    state.readAckRetryTimer = null;
    state.readAckRetryAt = 0;
    state.pendingAttachment = null;
    state.replyTo = null;
    state.editingMessage = null;
    state.deletingMessageId = 0;
    state.giphyResults = [];
    state.savedStickers = [];
    state.retryNonces.clear();
    state.textSendsInFlightByConversation.clear();
    state.sendQueueTails.clear();
    state.attachmentSendBusy = false;
    state.pushSubscribed = false;
    try { state.crossTabChannel?.close?.(); } catch {}
    state.crossTabChannel = null;
    state.incomingCall = null;
    state.stories = [];
    state.storyGroups = [];
    state.lastStoryRefreshAt = 0;
    state.storiesLoadPromise = null;
    state.storyGestureStart = null;
    state.storyPaused = false;
    clearTimeout(state.storyTimer);
    state.storyTimer = null;
    clearStoryComposer();

    $("#incomingCall").classList.add("hidden");
    $("#messages")?.replaceChildren();
    $("#messageInput").value = "";
    $("#replyBar")?.classList.add("hidden");
    $("#attachmentPreview")?.classList.add("hidden");
    $("#attachmentThumb")?.replaceChildren();
    $("#recordingBar")?.classList.add("hidden");
    $("#friendGate")?.classList.add("hidden");
    $("#chatView")?.classList.add("hidden");
    $("#emptyState")?.classList.remove("hidden");
    $("#conversationList")?.replaceChildren();
    state.notifiedIds.clear();
    state.savedMessageIds.clear();
    state.avatarDataUrlCache.clear();
    updateComposer();

    $("#appView").classList.add("hidden");
    $("#appView").classList.remove("mobile-chat-open");
    $("#appView").classList.remove("desktop-chat-active");
    $("#authView").classList.remove("hidden");

    document.title = "SilkNex";
    setAuthMode("login");
    setAuthError(message);
  }

  async function submitAuth(event) {
    event.preventDefault();
    if (state.authBusy) return;

    const mode = state.authMode;
    const username = $("#authUsername").value.trim();
    const password = $("#authPassword").value;
    const passwordConfirm = $("#authPasswordConfirm").value;

    if (mode === "signup") {
      if (!passwordIsValid(password)) {
        setAuthError(
          "Password needs at least 8 characters, 1 number, and 1 symbol."
        );
        return;
      }

      if (password !== passwordConfirm) {
        setAuthError("The passwords do not match.");
        return;
      }
    }

    state.authGeneration = Number(state.authGeneration || 0) + 1;
    state.authBusy = true;
    setAuthError("");
    $("#authSubmit").disabled = true;
    $("#loginTab").disabled = true;
    $("#signupTab").disabled = true;

    let data;

    try {
      data = await api(mode, {
        method: "POST",
        body: {
          username,
          password,
          password_confirm: mode === "signup" ? passwordConfirm : undefined,
        },
      });
    } catch (error) {
      setAuthError(error.message);
      return;
    } finally {
      state.authBusy = false;
      $("#authSubmit").disabled = false;
      $("#loginTab").disabled = false;
      $("#signupTab").disabled = false;
    }

    state.me = data.user;
    state.csrf = data.csrf;
    $("#authPassword").value = "";
    $("#authPasswordConfirm").value = "";
    setAuthError("");
    showApp();

    toast(mode === "signup" ? "Account created." : "Welcome back.");

    loadConversations().catch(() => setSyncStatus("error", "Retrying…"));
  }

  async function restoreSession() {
    const generation = Number(state.authGeneration || 0);
    const isCurrent = () => generation === Number(state.authGeneration || 0);
    let firstInboxTask = null;

    try {
      let data = null;
      const warmSession = await window.SilknexBoot?.session?.();

      if (!isCurrent()) return;
      if (warmSession) {
        if (warmSession.ok) {
          data = warmSession.data;
        } else if (Number(warmSession.status || 0) === 401) {
          const error = new Error("Sign in required.");
          error.status = 401;
          throw error;
        } else if (warmSession.offline || navigator.onLine === false) {
          const error = new Error("You are offline.");
          error.status = 0;
          throw error;
        }
        // A timed-out/failed warm request is only an optimization failure.
        // Retry once through the normal bounded API path before giving up.
      }

      if (!data) {
        data = await api("me", { showLoader: false, timeoutMs: 8000 });
      }

      if (!isCurrent()) return;
      state.me = data.user;
      state.csrf = data.csrf;
      window.SilknexBoot?.progress?.(74, "Preparing your conversations…");
      showApp();

      firstInboxTask = (async () => {
        const warmInbox = await window.SilknexBoot?.conversations?.();
        if (!isCurrent()) return;
        if (warmInbox?.ok && warmInbox.data) {
          await loadConversations(warmInbox.data);
        } else {
          await loadConversations();
        }
        window.SilknexBoot?.stage?.("chats", "ready");
        window.SilknexBoot?.progress?.(92, "Finishing your workspace…");
      })().catch(() => {
        if (!isCurrent()) return;
        window.SilknexBoot?.stage?.("chats", "error");
        setSyncStatus("error", "Retrying…");
        loadConversations().catch(() => {});
      });

      // Give a fast first inbox enough time to paint behind the splash, but
      // never hold startup hostage to a slow mobile network.
      await Promise.race([
        firstInboxTask,
        new Promise((resolve) => setTimeout(resolve, 420)),
      ]);
    } catch (error) {
      if (!isCurrent()) return;
      if (Number(error?.status || 0) === 401) {
        window.SilknexBoot?.stage?.("chats", "skip");
        window.SilknexBoot?.stage?.("security", "skip");
        showAuth("");
      } else {
        showAuth(error?.message || "SilkNex could not start.");
      }
    } finally {
      window.dispatchEvent(new Event("silknex:startup-ready"));
      window.SilknexBoot?.ready?.("Ready");
    }
  }

  async function logout() {
    state.authGeneration = Number(state.authGeneration || 0) + 1;
    document.getElementById("voiceRecordingRetry")?.remove();
    if (state.call) {
      await endCall();
    }

    // Push cleanup and session revocation are independent. A browser that
    // cannot unregister Push must never prevent the server logout from
    // happening, and the current CSRF token is already valid—no extra /me
    // round-trip is needed.
    try {
      await removePushSubscription();
    } catch {}

    try {
      await api("logout", { method: "POST", body: {} });
    } catch {}

    // Keep multiple SilkNex tabs in the same browser privacy-safe: once one
    // tab signs out, every open tab clears its visible chat UI immediately.
    broadcastSilkNex({ type: "logout" });
    closeModal();
    showAuth();
  }

  async function usePasskey() {
    if (!window.PublicKeyCredential || !navigator.credentials || !window.isSecureContext) {
      setAuthError("Passkeys need HTTPS and a browser with passkey support.");
      return;
    }

    state.authGeneration = Number(state.authGeneration || 0) + 1;
    $("#passkeyLoginBtn").disabled = true;
    setAuthError("");

    try {
      const optionsData = await api("passkey_login_options");
      const publicKey = optionsData.publicKey;
      publicKey.challenge = base64UrlToBytes(publicKey.challenge);

      const credential = await navigator.credentials.get({ publicKey });
      if (!credential) throw new Error("Passkey sign-in was canceled.");

      const data = await api("passkey_login_finish", {
        method: "POST",
        body: {
          id: bytesToBase64Url(credential.rawId),
          clientDataJSON: bytesToBase64Url(credential.response.clientDataJSON),
          authenticatorData: bytesToBase64Url(credential.response.authenticatorData),
          signature: bytesToBase64Url(credential.response.signature),
          userHandle: credential.response.userHandle
            ? bytesToBase64Url(credential.response.userHandle)
            : null,
        },
      });

      state.me = data.user;
      state.csrf = data.csrf;
      showApp();
      toast("Signed in with passkey.");
      loadConversations().catch(() => setSyncStatus("error", "Retrying…"));
    } catch (error) {
      if (error?.name === "NotAllowedError") {
        setAuthError("Passkey sign-in was canceled.");
      } else {
        setAuthError(error.message || "Passkey sign-in failed.");
      }
    } finally {
      $("#passkeyLoginBtn").disabled = false;
    }
  }

  async function registerServiceWorker() {
    if (!("serviceWorker" in navigator)) return;

    try {
      state.notificationRegistration = await navigator.serviceWorker.register(
        "sw.js?v=77.0",
        { updateViaCache: "none" }
      );
      // Do not let an installed PWA sit on an old shell after a deployment.
      // updateViaCache:none bypasses intermediary caches; update() also asks the
      // browser to compare the worker immediately during this launch.
      state.notificationRegistration.update().catch(() => {});
    } catch {
      state.notificationRegistration = null;
    }
  }

  async function showBrowserNotification(title, body, tag, data = {}) {
    if (!state.me?.notifications_enabled) return;
    if (!("Notification" in window) || Notification.permission !== "granted") return;

    // The open app already has live UI, unread badges, and an incoming-call
    // banner/ringtone. Avoid duplicating that with an OS notification while
    // the user is actively looking at SilkNex.
    if (
      !data.force_local_notification &&
      document.visibilityState === "visible" &&
      (typeof document.hasFocus !== "function" || document.hasFocus())
    ) {
      return;
    }

    // When Web Push is active, a hidden/closed app is already notified by the
    // service worker. Avoid creating a second notification from background
    // polling in an existing hidden tab/PWA window.
    if (
      document.visibilityState === "hidden" &&
      state.pushSubscribed &&
      !data.force_local_notification
    ) {
      return;
    }

    const isCallNotification = String(data.type || "") === "call";
    const options = {
      body: String(body || (isCallNotification ? "Incoming call" : "New SilkNex message")),
      icon: await notificationSafeIcon(data.avatar_url || data.icon || ""),
      badge: notificationBadge(),
      tag: String(tag || "neochat"),
      renotify: true,
      silent: false,
      requireInteraction: isCallNotification,
      data,
    };

    if (isCallNotification) {
      options.vibrate = [420, 160, 420, 160, 620];
      options.actions = [
        { action: "open-call", title: "Answer" },
        { action: "dismiss-call", title: "Dismiss" },
      ];
    }

    try {
      const registration =
        state.notificationRegistration ||
        (await navigator.serviceWorker?.ready);

      if (registration?.showNotification) {
        await registration.showNotification(title, options);
      } else {
        new Notification(title, options);
      }
    } catch {}
  }

  async function requestNotifications() {
    if (!("Notification" in window)) {
      toast("This browser does not support notifications.");
      return false;
    }

    let permission = Notification.permission;

    if (permission === "default") {
      permission = await Notification.requestPermission();
    }

    if (permission !== "granted") {
      toast("Notifications were not enabled.");
      return false;
    }

    return true;
  }

  async function ensurePushSubscription() {
    if (
      !state.me ||
      !("serviceWorker" in navigator) ||
      !("PushManager" in window) ||
      !("Notification" in window) ||
      Notification.permission !== "granted"
    ) {
      state.pushSubscribed = false;
      return false;
    }

    const registration =
      state.notificationRegistration ||
      (await navigator.serviceWorker.ready);

    if (!registration?.pushManager) return false;

    let subscription = await registration.pushManager.getSubscription();

    if (!subscription) {
      const keyData = await api("push_public_key");
      const key = base64UrlToBytes(keyData.public_key);

      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: key,
      });
    }

    const json = subscription.toJSON();
    const p256dh = json.keys?.p256dh;
    const auth = json.keys?.auth;

    if (!p256dh || !auth) return false;

    await api("push_subscribe", {
      method: "POST",
      body: {
        endpoint: subscription.endpoint,
        p256dh,
        auth,
        icon_style: resolvedIconStyle(
          state.iconStyleChoice || state.me?.app_icon_style || "auto",
          state.themeChoice || state.me?.theme || "dark"
        ),
      },
    });

    state.pushSubscribed = true;
    return true;
  }

  async function removePushSubscription() {
    if (!("serviceWorker" in navigator)) {
      state.pushSubscribed = false;
      return;
    }

    try {
      const registration =
        state.notificationRegistration ||
        (await navigator.serviceWorker.ready);
      const subscription = await registration?.pushManager?.getSubscription?.();

      if (subscription) {
        try {
          await api("push_unsubscribe", {
            method: "POST",
            body: { endpoint: subscription.endpoint },
          });
        } catch {}

        await subscription.unsubscribe();
      } else if (state.me) {
        try {
          await api("push_unsubscribe", {
            method: "POST",
            body: {},
          });
        } catch {}
      }
    } catch {}

    state.pushSubscribed = false;
  }

  function flushPushQueue({ immediate = false } = {}) {
    if (!state.me || !state.csrf) return;

    clearTimeout(flushPushQueue.timer);
    flushPushQueue.timer = setTimeout(() => {
      flushPushQueue.timer = null;
      if (!state.me || !state.csrf) return;

      api("push_flush", {
        method: "POST",
        body: {},
        keepalive: true,
      }).catch(() => {});
    }, immediate ? 0 : 220);
  }

  flushPushQueue.timer = null;

  function notifyConversation(conversation) {
    if (document.visibilityState === "visible" && state.activeId === conversation.id) {
      return;
    }
    if (window.SilknexV52?.quietHoursActive?.()) {
      return;
    }

    const preview = conversation.last_message?.body || "New message";

    showBrowserNotification(
      conversation.title,
      preview,
      `chat-${conversation.id}`,
      {
        conversation_id: conversation.id,
        avatar_url:
          conversation.kind === "group"
            ? (conversation.avatar_url || "")
            : (conversation.last_message?.sender_avatar_url || conversation.avatar_url || ""),
      }
    );
  }

  async function acknowledgeDeliveryItems(items) {
    if (!state.me || !Array.isArray(items) || !items.length) return;

    const requestItems = [];

    for (const item of items) {
      const conversationId = Number(item.conversation_id || 0);
      const messageId = Number(item.message_id || 0);

      if (!conversationId || !messageId) continue;

      const acked = state.deliveryAckByConversation.get(conversationId) || 0;
      const pending = state.deliveryAckInFlight.get(conversationId) || 0;

      if (messageId <= acked || messageId <= pending) continue;

      state.deliveryAckInFlight.set(conversationId, messageId);
      requestItems.push({
        conversation_id: conversationId,
        message_id: messageId,
      });
    }

    if (!requestItems.length) return;

    try {
      const data = await api("delivery_receipts", {
        method: "POST",
        body: { items: requestItems },
      });

      for (const item of data.acked || []) {
        const conversationId = Number(item.conversation_id || 0);
        const messageId = Number(item.message_id || 0);

        if (!conversationId || !messageId) continue;

        state.deliveryAckByConversation.set(
          conversationId,
          Math.max(
            state.deliveryAckByConversation.get(conversationId) || 0,
            messageId
          )
        );
      }

      if (data.signature) {
        state.inboxSignature = String(data.signature);
      }
    } catch {
      // The next chat-list/live-sync response will retry.
    } finally {
      for (const item of requestItems) {
        const pending = state.deliveryAckInFlight.get(item.conversation_id);

        if (pending === item.message_id) {
          state.deliveryAckInFlight.delete(item.conversation_id);
        }
      }
    }
  }

  function acknowledgeConversationDeliveries(conversations) {
    const items = [];

    for (const conversation of conversations || []) {
      const message = conversation.last_message;

      if (
        !message ||
        Number(message.sender_id || 0) === Number(state.me?.id || 0)
      ) {
        continue;
      }

      items.push({
        conversation_id: conversation.id,
        message_id: message.id,
      });
    }

    acknowledgeDeliveryItems(items).catch(() => {});
  }

  async function loadConversations(prefetchedData = null) {
    if (!state.me) return;
    if (state.conversationLoadPromise) return state.conversationLoadPromise;

    const userId = Number(state.me.id || 0);
    const requestId = ++state.conversationRequestId;
    const session = state.me;
    const previousConversations = new Map(state.conversations.map(item => [Number(item.id), item]));
    const canReuseSnapshot = state.conversationsLoaded &&
      Date.now() - Number(state.lastFullConversationRefreshAt || 0) < 45000;
    const previousUnread = new Map(
      state.conversations.map((item) => [
        item.id,
        Number(item.unread_count || 0),
      ])
    );

    const task = (async () => {
      const data =
        prefetchedData && typeof prefetchedData === "object"
          ? prefetchedData
          : await api("conversations", {}, canReuseSnapshot ? { known_signature: state.conversationSnapshotSignature || "" } : {});

      if (
        requestId !== state.conversationRequestId ||
        Number(state.me?.id || 0) !== userId || state.me !== session
      ) return;

      if (data.unchanged && canReuseSnapshot) {
        state.lastConversationRefreshAt = Date.now();
        return;
      }

      const nextConversations = await mapWithConcurrency(
        data.conversations, async (conversation) => {
          if (!conversation?.last_message?.e2ee_payload) return conversation;
          const previous = previousConversations.get(Number(conversation.id))?.last_message;
          if (!state.me?.kid_mode && previous?.previewDecrypted &&
            Number(previous.id) === Number(conversation.last_message.id) &&
            previous.e2ee_payload === conversation.last_message.e2ee_payload) {
            return { ...conversation, last_message: { ...conversation.last_message,
              body: previous.body, e2ee_meta: previous.e2ee_meta, previewDecrypted: true } };
          }
          const decrypted = await decryptIncomingMessage({
            ...conversation.last_message,
            conversation_id: conversation.id,
            sender_username: "",
            sender_display_name: conversation.title,
          });
          return {
            ...conversation,
            last_message: {
              ...conversation.last_message,
              body: decrypted?.body || "Older message unavailable on this device",
              e2ee_meta: decrypted?.e2ee_meta || null,
              previewDecrypted: Boolean(decrypted?.e2ee_meta),
            },
          };
        }
      );

      // Decryption can outlive a logout, account switch or newer inbox load.
      if (requestId !== state.conversationRequestId || Number(state.me?.id || 0) !== userId || state.me !== session) return;

      if (state.conversationsLoaded) {
        for (const conversation of nextConversations) {
          const before = previousUnread.get(conversation.id) || 0;
          const now = Number(conversation.unread_count || 0);

          if (now > before) {
            notifyConversation(conversation);
          }
        }
      }

      const fingerprint = JSON.stringify(nextConversations);

      state.conversations = nextConversations;
      state.conversationsLoaded = true;
      state.inboxSignature = String(data.signature || state.inboxSignature || "");
      state.lastConversationRefreshAt = Date.now();
      state.lastFullConversationRefreshAt = Date.now();
      state.conversationSnapshotSignature = String(data.signature || "");

      acknowledgeConversationDeliveries(nextConversations);

      if (fingerprint === state.conversationFingerprint) {
        updateUnreadSummary();
        return;
      }

      state.conversationFingerprint = fingerprint;
      renderConversations();
    })();

    state.conversationLoadPromise = task;

    try {
      return await task;
    } finally {
      if (state.conversationLoadPromise === task) {
        state.conversationLoadPromise = null;
      }
    }
  }

  function updateUnreadSummary() {
    const unreadTotal = state.conversations.reduce(
      (sum, conversation) =>
        sum + Math.max(
          Number(conversation.unread_count || 0),
          conversation.manual_unread ? 1 : 0
        ),
      0
    );

    const badge = $("#totalUnreadBadge");
    const summary = $("#unreadSummary");
    const filterCount = $("#unreadFilterCount");
    if (badge) badge.textContent = unreadTotal > 999 ? "999+" : String(unreadTotal);
    if (summary) summary.classList.toggle("hidden", unreadTotal < 1);
    if (filterCount) {
      filterCount.textContent = unreadTotal > 99 ? "99+" : String(unreadTotal);
      filterCount.classList.toggle("hidden", unreadTotal < 1);
    }

    document.title = unreadTotal > 0
      ? `(${Math.min(99, unreadTotal)}) SilkNex`
      : state.activeConversation?.title
        ? `${state.activeConversation.title} · SilkNex`
        : "SilkNex";

    try {
      if (unreadTotal > 0) navigator.setAppBadge?.(unreadTotal);
      else navigator.clearAppBadge?.();
    } catch {}
  }

  function renderConversations() {
    const list = $("#conversationList");
    const query = $("#chatSearch").value.trim().toLowerCase();

    let visible = state.conversations.filter((conversation) => {
      // Draft text is intentionally session-local, but it should still be
      // searchable so partially written conversations are easy to find.
      const draft = readDraftValue(conversation.id);
      return `${conversation.title} ${conversation.subtitle} ${draft}`
        .toLowerCase()
        .includes(query);
    });

    if (state.chatFilter === "archived") {
      visible = visible.filter((conversation) => Boolean(conversation.archived));
    } else {
      visible = visible.filter((conversation) => !conversation.archived);
      if (state.chatFilter === "unread") {
        visible = visible.filter((conversation) => Number(conversation.unread_count || 0) > 0 || Boolean(conversation.manual_unread));
      } else if (state.chatFilter === "groups") {
        visible = visible.filter((conversation) => conversation.kind === "group");
      } else if (state.chatFilter === "favorites") {
        visible = visible.filter((conversation) => Boolean(conversation.favorite));
      }
    }

    visible.sort((a, b) => {
      const pinDiff = Number(Boolean(b.pinned)) - Number(Boolean(a.pinned));
      if (pinDiff) return pinDiff;
      if (a.pinned && b.pinned) {
        const pinnedDiff = Number(b.pinned_at || 0) - Number(a.pinned_at || 0);
        if (pinnedDiff) return pinnedDiff;
      }
      const favoriteDiff = Number(Boolean(b.favorite)) - Number(Boolean(a.favorite));
      if (favoriteDiff) return favoriteDiff;
      if (a.favorite && b.favorite) {
        const favoriteAtDiff = Number(b.favorite_at || 0) - Number(a.favorite_at || 0);
        if (favoriteAtDiff) return favoriteAtDiff;
      }
      return Number(b.updated_at || 0) - Number(a.updated_at || 0);
    });

    updateUnreadSummary();

    if (!visible.length) {
      const empty = document.createElement("div");
      empty.className = "chat-empty-message conversation-empty-state";

      const message = document.createElement("span");
      message.textContent = query
        ? "No chats match your search."
        : state.chatFilter === "unread"
          ? "No unread chats."
          : state.chatFilter === "groups"
            ? "No group chats yet."
            : state.chatFilter === "favorites"
              ? "No favorite chats yet."
              : state.chatFilter === "archived"
                ? "No archived chats."
                : "No conversations yet.";
      empty.appendChild(message);

      if (!query && state.chatFilter === "all") {
        const actions = document.createElement("div");
        actions.className = "conversation-empty-actions";

        const start = document.createElement("button");
        start.type = "button";
        start.className = "primary compact";
        start.textContent = "Start a chat";
        start.addEventListener("click", openNewChat);

        const friends = document.createElement("button");
        friends.type = "button";
        friends.className = "secondary-btn compact";
        friends.textContent = "Find friends";
        friends.addEventListener("click", openFriends);

        actions.append(start, friends);
        empty.appendChild(actions);
      }

      list.replaceChildren(empty);
      return;
    }

    // Build the whole sidebar off-DOM and swap it in once. This avoids a
    // layout/repaint for every conversation on large accounts.
    const fragment = document.createDocumentFragment();

    for (const conversation of visible) {
      const wrap = document.createElement("div");
      wrap.className =
        "conversation-wrap" +
        (conversation.id === state.activeId ? " active" : "") +
        (conversation.pinned ? " pinned" : "") +
        (conversation.favorite ? " favorite" : "") +
        (conversation.archived ? " archived" : "");

      const button = document.createElement("button");
      button.type = "button";
      button.className =
        "conversation" + (conversation.id === state.activeId ? " active" : "");
      button.dataset.conversationId = String(conversation.id);

      const avatar = document.createElement("div");
      if (conversation.kind === "group") {
        if (conversation.avatar_url) {
          setAvatar(avatar, conversation.title, "graphite", conversation.avatar_url);
        } else {
          avatar.className = "avatar accent-graphite";
          avatar.replaceChildren(iconNode("friends"));
        }
      } else {
        setAvatar(
          avatar,
          conversation.title,
          conversation.avatar_accent,
          conversation.avatar_url,
          conversation.avatar_style
        );
        if (conversation.online) avatar.classList.add("online-ring");
      }

      const copy = document.createElement("div");
      copy.className = "conversation-copy";

      const top = document.createElement("div");
      top.className = "conversation-top";

      const name = document.createElement("div");
      name.className = "conversation-name";
      name.textContent = conversation.title;

      if (isFounderRole(conversation.role)) {
        name.appendChild(founderBadgeNode(conversation.role));
      }

      if (conversation.pinned) {
        const pinMark = document.createElement("span");
        pinMark.className = "pin-mark";
        pinMark.appendChild(iconNode("pin"));
        pinMark.title = "Pinned chat";
        name.appendChild(pinMark);
      }

      if (conversation.favorite) {
        const favoriteMark = document.createElement("span");
        favoriteMark.className = "favorite-mark";
        favoriteMark.appendChild(iconNode("heart"));
        favoriteMark.title = "Favorite chat";
        name.appendChild(favoriteMark);
      }

      const time = document.createElement("div");
      time.className = "conversation-time";
      time.textContent = formatListTime(conversation.last_message?.created_at);
      top.append(name, time);

      const bottom = document.createElement("div");
      bottom.className = "conversation-bottom";

      const preview = document.createElement("div");
      preview.className = "conversation-preview";
      const draft = readDraftValue(conversation.id).trim();
      if (draft) {
        preview.classList.add("has-draft");
        preview.textContent = `Draft: ${draft.replace(/\s+/g, " ").slice(0, 120)}`;
      } else {
        preview.textContent =
          conversation.last_message?.body ||
          (conversation.kind === "group" ? conversation.subtitle : "Start chatting");
      }
      bottom.appendChild(preview);

      const unread = Number(conversation.unread_count || 0);
      const manualUnread = Boolean(conversation.manual_unread);
      if (unread > 0 || manualUnread) {
        const unreadBadge = document.createElement("span");
        unreadBadge.className = "unread-badge";
        unreadBadge.textContent = unread > 99
          ? "99+"
          : unread > 0
            ? String(unread)
            : "•";
        unreadBadge.title = manualUnread && unread < 1
          ? "Marked unread"
          : `${unread} unread message${unread === 1 ? "" : "s"}`;
        bottom.appendChild(unreadBadge);
      }

      copy.append(top, bottom);
      button.append(avatar, copy);
      button.addEventListener("click", () => openConversation(conversation.id));

      const actions = document.createElement("div");
      actions.className = "conversation-quick-actions";

      const pin = document.createElement("button");
      pin.type = "button";
      pin.className = "conversation-action";
      setButtonContent(pin, "pin");
      pin.classList.toggle("active", Boolean(conversation.pinned));
      pin.title = conversation.pinned ? "Unpin chat" : "Pin chat";
      pin.setAttribute("aria-label", pin.title);
      pin.addEventListener("click", (event) => {
        event.stopPropagation();
        togglePinConversation(conversation.id, !conversation.pinned);
      });

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "conversation-action danger";
      setButtonContent(remove, "trash");
      remove.title = "Delete chat";
      remove.setAttribute("aria-label", "Delete chat");
      remove.addEventListener("click", (event) => {
        event.stopPropagation();
        deleteConversationFromList(conversation);
      });

      const favorite = document.createElement("button");
      favorite.type = "button";
      favorite.className = "conversation-action";
      setButtonContent(favorite, "heart");
      favorite.classList.toggle("active", Boolean(conversation.favorite));
      favorite.title = conversation.favorite ? "Remove from favorites" : "Add to favorites";
      favorite.setAttribute("aria-label", favorite.title);
      favorite.addEventListener("click", (event) => {
        event.stopPropagation();
        updateConversationListState(conversation.id, {
          favorite: !conversation.favorite,
          archived: Boolean(conversation.archived),
        });
      });

      const archive = document.createElement("button");
      archive.type = "button";
      archive.className = "conversation-action";
      setButtonContent(archive, "archive");
      archive.classList.toggle("active", Boolean(conversation.archived));
      archive.title = conversation.archived ? "Unarchive chat" : "Archive chat";
      archive.setAttribute("aria-label", archive.title);
      archive.addEventListener("click", (event) => {
        event.stopPropagation();
        updateConversationListState(conversation.id, {
          favorite: Boolean(conversation.favorite),
          archived: !conversation.archived,
        });
      });

      actions.id = `conversation-actions-${conversation.id}`;
      actions.setAttribute("aria-label", `Actions for ${conversation.title}`);
      for (const control of [pin, favorite, archive, remove]) {
        const label = document.createElement("span");
        label.textContent = control.title;
        control.append(label);
      }
      const options = document.createElement("button");
      options.type = "button";
      options.className = "conversation-options round-btn";
      options.setAttribute("aria-label", `Actions for ${conversation.title}`);
      options.setAttribute("aria-expanded", "false");
      options.setAttribute("aria-controls", actions.id);
      setButtonContent(options, "more");
      const closeActions = () => {
        wrap.classList.remove("options-open");
        options.setAttribute("aria-expanded", "false");
      };
      options.addEventListener("click", () => {
        const open = !wrap.classList.contains("options-open");
        $$(".conversation-wrap.options-open").forEach(item => {
          item.classList.remove("options-open");
          item.querySelector(".conversation-options")?.setAttribute("aria-expanded", "false");
        });
        wrap.classList.toggle("options-open", open);
        options.setAttribute("aria-expanded", String(open));
      });
      wrap.addEventListener("keydown", event => {
        if (event.key === "Escape" && wrap.classList.contains("options-open")) {
          event.preventDefault(); event.stopPropagation(); closeActions(); options.focus();
        }
        if (event.key === "ContextMenu" || (event.shiftKey && event.key === "F10")) {
          event.preventDefault(); wrap.classList.add("options-open");
          options.setAttribute("aria-expanded", "true"); pin.focus();
        }
      });
      wrap.addEventListener("focusout", event => {
        if (!wrap.contains(event.relatedTarget)) closeActions();
      });
      actions.addEventListener("click", closeActions);
      actions.append(pin, favorite, archive, remove);
      wrap.append(button, options, actions);
      fragment.appendChild(wrap);
    }

    list.replaceChildren(fragment);
  }

  async function updateConversationListState(conversationId, nextState) {
    const conversation = state.conversations.find((item) => item.id === Number(conversationId));
    if (!conversation) return;

    const previous = {
      favorite: Boolean(conversation.favorite),
      favorite_at: conversation.favorite_at ?? null,
      archived: Boolean(conversation.archived),
      archived_at: conversation.archived_at ?? null,
      pinned: Boolean(conversation.pinned),
      pinned_at: conversation.pinned_at ?? null,
    };

    const now = Math.floor(Date.now() / 1000);
    conversation.favorite = Boolean(nextState.favorite);
    conversation.favorite_at = conversation.favorite ? now : null;
    conversation.archived = Boolean(nextState.archived);
    conversation.archived_at = conversation.archived ? now : null;
    if (conversation.archived) {
      conversation.pinned = false;
      conversation.pinned_at = null;
    }
    renderConversations();

    try {
      await api("conversation_list_state", {
        method: "POST",
        body: {
          conversation_id: conversation.id,
          favorite: conversation.favorite,
          archived: conversation.archived,
        },
        showLoader: false,
      });
      state.conversationFingerprint = "";
      await loadConversations();
      toast(conversation.archived
        ? "Chat archived."
        : conversation.favorite !== previous.favorite
          ? (conversation.favorite ? "Added to favorites." : "Removed from favorites.")
          : "Chat restored.");
    } catch (error) {
      Object.assign(conversation, previous);
      renderConversations();
      toast(error.message);
    }
  }

  async function togglePinConversation(conversationId, pinned) {
    const conversation = state.conversations.find((item) => item.id === conversationId);
    if (!conversation) return;

    const previous = Boolean(conversation.pinned);
    conversation.pinned = Boolean(pinned);
    conversation.pinned_at = pinned ? Math.floor(Date.now() / 1000) : null;
    renderConversations();

    try {
      await api("pin_conversation", {
        method: "POST",
        body: { conversation_id: conversationId, pinned: Boolean(pinned) },
      });
      state.conversationFingerprint = "";
      await loadConversations();
    } catch (error) {
      conversation.pinned = previous;
      renderConversations();
      toast(error.message);
    }
  }

  async function deleteConversationFromList(conversation) {
    if (!conversation?.id) return;
    if (!window.confirm(`Delete ${conversation.title} from your chats?`)) return;

    try {
      await api("delete_conversation", {
        method: "POST",
        body: { conversation_id: conversation.id },
      });

      clearDraft(conversation.id);
      if (state.activeId === conversation.id) {
        state.syncController?.abort();
        state.syncController = null;
        state.syncBusy = false;
        clearTimeout(state.pollTimer);
        clearTimeout(state.expiryTimer);
        state.expiryTimer = null;
        state.activeId = 0;
        state.activeConversation = null;
        state.messages.clear();
        $("#appView").classList.remove("mobile-chat-open");
        $("#appView").classList.remove("desktop-chat-active");
        $("#chatView").classList.add("hidden");
        $("#emptyState").classList.remove("hidden");
        window.dispatchEvent(new CustomEvent("silknex:conversation", {
          detail: { id: 0, conversation: null }
        }));
      }

      state.conversations = state.conversations.filter((item) => item.id !== conversation.id);
      state.conversationFingerprint = "";
      renderConversations();
      await loadConversations();
      toast("Chat deleted.");
    } catch (error) {
      toast(error.message);
    }
  }

  function applyChatWallpaper(preferences = state.activeConversation?.preferences) {
    const container = $("#chatWallpaper");
    if (!container) return;

    const specific = preferences || {
      wallpaper: "default",
      wallpaper_url: "",
      bubble_style: "default",
      density: "default",
      chat_font_scale: "default",
    };

    let wallpaper = specific.wallpaper || "default";
    let url = specific.wallpaper_url || "";

    if (wallpaper === "default") {
      wallpaper = state.me?.wallpaper || "neo";
      url = state.me?.wallpaper_url || "";
    }

    const bubbleStyle =
      specific.bubble_style && specific.bubble_style !== "default"
        ? specific.bubble_style
        : state.me?.bubble_style || "rounded";

    const density =
      specific.density && specific.density !== "default"
        ? specific.density
        : state.me?.message_density || "normal";

    const chatFontScale =
      specific.chat_font_scale && specific.chat_font_scale !== "default"
        ? specific.chat_font_scale
        : state.me?.font_scale || "normal";

    container.className = "chat-wallpaper";

    if (state.activeConversation?.kind === "group") {
      container.classList.add("group-chat");
    }

    container.dataset.bubbles = bubbleStyle;
    container.dataset.density = density;
    container.dataset.font = chatFontScale;
    container.dataset.chatWidth = state.me?.chat_width || "normal";
    container.style.backgroundImage = "";
    container.style.backgroundSize = "";
    container.style.backgroundPosition = "";

    if (wallpaper === "custom" && url) {
      container.classList.add("custom-wallpaper");
      container.style.backgroundImage =
        `linear-gradient(color-mix(in srgb, var(--bg) 12%, transparent), color-mix(in srgb, var(--bg) 12%, transparent)), url("${String(url).replace(/["\\]/g, "")}")`;
      container.style.backgroundSize = "cover";
      container.style.backgroundPosition = "center";
    } else {
      container.classList.add(`wallpaper-${wallpaper || "neo"}`);
    }
  }

  function pushMobileChatHistory(conversationId) {
    if (!usesMobileShell() || !conversationId) return;

    const currentId = Number(history.state?.neochatChat || 0);
    if (currentId === Number(conversationId)) {
      state.mobileHistoryChatId = Number(conversationId);
      return;
    }

    try {
      history.pushState(
        { ...(history.state || {}), neochatChat: Number(conversationId) },
        "",
        window.location.href
      );
      state.mobileHistoryChatId = Number(conversationId);
    } catch {}
  }

  function clearCurrentMobileChatHistory(conversationId) {
    if (!usesMobileShell()) return;
    if (Number(history.state?.neochatChat || 0) !== Number(conversationId || 0)) return;

    try {
      const next = { ...(history.state || {}) };
      delete next.neochatChat;
      history.replaceState(next, "", window.location.href);
    } catch {}
    state.mobileHistoryChatId = 0;
  }

  async function openConversation(id, { skipHistory = false } = {}) {
    document.getElementById("voiceRecordingRetry")?.remove();
    clearTimeout(state.recordTapTimer);
    id = Number(id);
    if (!id) return;

    if (state.activeId) {
      persistDraft(state.activeId);
    }

    if (
      state.voiceRecorder?.state === "recording" ||
      state.recordingStarting
    ) {
      stopActiveRecording(true);
    }

    state.syncController?.abort();
    state.syncController = null;
    state.openConversationController?.abort();
    const openController = createAbortController();
    state.openConversationController = openController;
    state.syncBusy = false;

    state.activeId = id;
    state.activeConversation = null;
    window.dispatchEvent(new CustomEvent("silknex:conversation", {
      detail: { id, conversation: null, opening: true }
    }));
    state.messages.clear();
    state.firstMessageId = 0;
    state.syncAfterId = 0;
    state.hasNewerHistory = false;
    state.historyRequestId += 1;
    state.lastMessageId = 0;
    state.hasOlder = false;
    state.receipt = { recipient_count: 0, delivered_up_to: 0, read_up_to: 0 };
    state.lastReadAckId = 0;
    state.readAckInFlightId = 0;
    state.readAckRequest = null;
    state.readAckFailures = 0;
    clearTimeout(state.readAckRetryTimer);
    state.readAckRetryTimer = null;
    state.readAckRetryAt = 0;
    state.syncCursor = 0;
    state.syncCursorId = 0;
    state.changeSeq = 0;
    state.syncFailures = 0;
    state.syncHasMore = false;
    state.replyTo = null;
    clearPendingAttachment();

    clearTimeout(state.pollTimer);

    clearDeferredMediaObservers();
    window.SilknexE2EE?.clearMediaUrls?.();
    $("#messages").replaceChildren();
    $("#friendGate").classList.add("hidden");
    // Do not leave the mobile composer disabled while the conversation request is
    // in flight. The backend still enforces friendship/member permissions, and
    // renderFriendGate() applies the real locked state as soon as metadata lands.
    setComposerFriendLocked(false);
    $("#emptyState").classList.add("hidden");
    $("#chatView").classList.remove("hidden");
    $("#replyBar").classList.add("hidden");
    $("#olderBtn").classList.add("hidden");
    $("#appView").classList.add("mobile-chat-open");
    $("#appView").classList.add("desktop-chat-active");
    if (!skipHistory) pushMobileChatHistory(id);
    restoreDraft(id);
    renderConversations();

    try {
      setSyncStatus("busy", "Opening…");

      const [data] = await Promise.all([
        api("conversation", { signal: openController.signal }, { id }),
        loadMessages({ initial: true, signal: openController.signal }),
      ]);

      if (state.activeId !== id) return;

      state.activeConversation = data.conversation;
      state.changeSeq = Math.max(
        state.changeSeq,
        Number(data.conversation.change_seq || 0)
      );
      renderChatHeader();
      applyChatWallpaper(data.conversation.preferences);
      window.dispatchEvent(new CustomEvent("silknex:conversation", {
        detail: { id, conversation: data.conversation }
      }));

      loadConversations().catch(() => {});
      schedulePoll();
      setSyncStatus("", "Up to date");

      if (!usesMobileShell()) $("#messageInput").focus();
    } catch (error) {
      if (error?.name !== "AbortError" && state.activeId === id) {
        setSyncStatus("error", "Couldn’t open");
        toast(error.message);
      }
    } finally {
      if (state.openConversationController === openController) {
        state.openConversationController = null;
      }
    }
  }

  function closeMobileChat({ fromHistory = false } = {}) {
    if (!usesMobileShell()) return;
    document.getElementById("voiceRecordingRetry")?.remove();
    clearTimeout(state.recordTapTimer);

    if (
      !fromHistory &&
      state.activeId &&
      Number(history.state?.neochatChat || 0) === Number(state.activeId)
    ) {
      try {
        history.back();
        return;
      } catch {}
    }

    if (state.activeId) persistDraft(state.activeId);

    clearPendingAttachment();
    if (
      state.voiceRecorder?.state === "recording" ||
      state.recordingStarting
    ) {
      stopActiveRecording(true);
    }

    clearTimeout(state.pollTimer);
    clearTimeout(state.expiryTimer);
    state.expiryTimer = null;
    state.syncController?.abort();
    state.syncController = null;
    state.openConversationController?.abort();
    state.openConversationController = null;
    state.syncBusy = false;
    state.activeId = 0;
    state.mobileHistoryChatId = 0;
    state.activeConversation = null;
    state.messages.clear();
    state.firstMessageId = 0;
    state.syncAfterId = 0;
    state.hasNewerHistory = false;
    state.historyRequestId += 1;
    state.lastMessageId = 0;
    state.hasOlder = false;
    state.syncCursor = 0;
    state.syncCursorId = 0;
    state.syncHasMore = false;
    state.receipt = { recipient_count: 0, delivered_up_to: 0, read_up_to: 0 };
    state.lastReadAckId = 0;
    state.readAckInFlightId = 0;
    state.readAckRequest = null;
    state.readAckFailures = 0;
    clearTimeout(state.readAckRetryTimer);
    state.readAckRetryTimer = null;
    state.readAckRetryAt = 0;
    state.changeSeq = 0;
    state.syncFailures = 0;
    state.replyTo = null;
    clearDeferredMediaObservers();
    window.SilknexE2EE?.clearMediaUrls?.();
    $("#messages")?.replaceChildren();
    $("#appView").classList.remove("mobile-chat-open");
    $("#appView").classList.remove("desktop-chat-active");
    $("#chatView").classList.add("hidden");
    $("#emptyState").classList.remove("hidden");
    document.title = "SilkNex";
    window.dispatchEvent(new CustomEvent("silknex:conversation", {
      detail: { id: 0, conversation: null }
    }));
    renderConversations();
    scheduleGlobalPoll();
  }

  function setComposerFriendLocked(locked) {
    const input = $("#messageInput");
    if (input) {
      input.disabled = false;
      input.readOnly = Boolean(locked);
      input.setAttribute("aria-disabled", locked ? "true" : "false");
    }

    for (const id of ["attachBtn", "voiceBtn", "scheduleBtn"]) {
      const el = $(`#${id}`);
      if (el) el.disabled = Boolean(locked);
    }

    const sendButton = $("#sendBtn");
    if (sendButton) {
      sendButton.disabled = Boolean(locked) || state.attachmentSendBusy;
    }

    $("#messageForm")?.classList.toggle("friend-locked", Boolean(locked));
    if (!locked) updateComposer();
  }

  function renderFriendGate() {
    const conversation = state.activeConversation;
    const gate = $("#friendGate");
    if (!conversation || conversation.kind !== "dm" || conversation.can_message) {
      gate.classList.add("hidden");
      setComposerFriendLocked(false);
      return;
    }

    gate.classList.remove("hidden");
    setComposerFriendLocked(true);
    const relation = conversation.friendship?.status || "none";
    const action = $("#friendGateAction");
    action.disabled = false;
    action.dataset.mode = relation;

    if (relation === "incoming") {
      $("#friendGateTitle").textContent = "Friend request waiting";
      $("#friendGateText").textContent = `${conversation.title} wants to be friends. Accept to start messaging and calling.`;
      action.textContent = "Accept";
    } else if (relation === "outgoing") {
      $("#friendGateTitle").textContent = "Friend request sent";
      $("#friendGateText").textContent = `Waiting for ${conversation.title} to accept before you can message or call.`;
      action.textContent = "Requested";
      action.disabled = true;
    } else {
      $("#friendGateTitle").textContent = "Add this person to chat";
      $("#friendGateText").textContent = "You both need to be friends before messages and calls are enabled.";
      action.textContent = "Add friend";
    }
  }

  async function handleFriendGateAction() {
    const conversation = state.activeConversation;
    if (!conversation || conversation.kind !== "dm") return;
    const relation = conversation.friendship?.status || "none";

    if (relation === "incoming") {
      await respondFriendRequest(conversation.friendship?.request_id, true);
      await refreshActiveConversation();
      return;
    }

    if (relation === "none" && conversation.other_user_id) {
      const button = $("#friendGateAction");
      button.disabled = true;
      try {
        const data = await api("friend_request", {
          method: "POST",
          body: { user_id: conversation.other_user_id },
        });
        conversation.friendship = {
          status: data.status || "outgoing",
          request_id: Number(data.request_id || 0),
        };
        conversation.can_message = false;
        conversation.can_call = false;
        renderChatHeader();
        await loadFriends({ notify: false });
        toast("Friend request sent.");
      } catch (error) {
        toast(error.message);
        button.disabled = false;
      }
    }
  }

  function renderChatHeader() {
    const conversation = state.activeConversation;
    if (!conversation) return;

    $("#chatTitle").textContent = conversation.title;
    $("#chatSubtitle").textContent = conversation.subtitle;
    $("#chatRoleBadge")?.classList.add("hidden");

    const canCall = Boolean(conversation.can_call);
    $("#audioCallBtn").classList.toggle("hidden", !canCall);
    $("#videoCallBtn").classList.toggle("hidden", !canCall);
    renderFriendGate();

    if (conversation.kind === "group") {
      if (conversation.avatar_url) {
        setAvatar($("#chatAvatar"), conversation.title, "graphite", conversation.avatar_url);
      } else {
        $("#chatAvatar").className = "avatar accent-graphite";
        $("#chatAvatar").replaceChildren(iconNode("friends"));
      }
      return;
    }

    const other = conversation.members?.find((member) => member.id !== state.me.id);

    if (other) {
      setAvatar(
        $("#chatAvatar"),
        other.display_name,
        other.accent,
        other.avatar_url,
        other.avatar_style
      );

      if (other.online) $("#chatAvatar").classList.add("online-ring");

      if (other.nickname) $("#chatTitle").textContent = other.nickname;
      if ($("#chatRoleBadge")) { $("#chatRoleBadge").textContent = founderBadgeNode(other.role).textContent; $("#chatRoleBadge").classList.toggle("hidden", !isFounderRole(other.role)); }
      $("#chatSubtitle").textContent = other.online
        ? `@${other.username} · online`
        : `@${other.username}`;
    }
  }

  function messageReceiptStatus(messageId) {
    if (!state.receipt || Number(state.receipt.recipient_count || 0) < 1) {
      return { icon: "", label: "" };
    }

    if (Number(state.receipt.read_up_to || 0) >= messageId) {
      return { icon: "doubleCheck", label: "Seen", seen: true };
    }

    if (Number(state.receipt.delivered_up_to || 0) >= messageId) {
      return { icon: "doubleCheck", label: "Delivered", seen: false };
    }

    return { icon: "check", label: "Sent", seen: false };
  }

  function refreshReceiptIndicators() {
    $$("#messages .message.mine").forEach((row) => {
      const messageId = Number(row.dataset.messageId || 0);
      const message = state.messages.get(messageId);

      if (!message || message.deleted_at) return;

      const foot = row.querySelector(".message-foot");
      if (!foot) return;

      const status = messageReceiptStatus(messageId);
      let receipt = foot.querySelector(".receipt");

      if (!status.icon) {
        receipt?.remove();
        return;
      }

      if (!receipt) {
        receipt = document.createElement("span");
        receipt.className = "receipt";
        foot.appendChild(receipt);
      }

      receipt.classList.toggle("seen", Boolean(status.seen));
      receipt.replaceChildren(iconNode(status.icon, "neo-icon receipt-icon"));
      receipt.title = status.label;
      receipt.setAttribute("aria-label", status.label);
    });
  }

  function giphyCustomerId() {
    const key = "neochat:giphy-customer-id";
    try {
      const existing = window.SilknexStorage.getItem(key);
      if (existing) return existing;

      const value = window.crypto?.randomUUID?.() || makeClientNonce();
      window.SilknexStorage.setItem(key, value);
      return value;
    } catch {
      return makeClientNonce();
    }
  }

  async function ensureGiphyConfig() {
    if (state.giphyEnabled !== null) return state.giphyEnabled;

    try {
      const data = await api("giphy_config");
      state.giphyEnabled = Boolean(data.enabled);
      state.giphySdkKey = state.giphyEnabled ? String(data.sdk_key || "") : "";
    } catch {
      state.giphyEnabled = false;
      state.giphySdkKey = "";
    }

    return state.giphyEnabled;
  }

  async function ensureGiphyClient() {
    const enabled = await ensureGiphyConfig();
    if (!enabled || !state.giphySdkKey) return null;
    if (state.giphyClient) return state.giphyClient;

    if (!state.giphySdkPromise) {
      state.giphySdkPromise = import("https://esm.sh/@giphy/js-fetch-api@5.8.0?bundle")
        .then((module) => {
          if (typeof module?.GiphyFetch !== "function") {
            throw new Error("GIPHY SDK did not expose GiphyFetch.");
          }
          return module.GiphyFetch;
        })
        .catch((error) => {
          state.giphySdkPromise = null;
          throw error;
        });
    }

    const GiphyFetch = await state.giphySdkPromise;
    state.giphyClient = new GiphyFetch(state.giphySdkKey);
    return state.giphyClient;
  }

  function giphyAnalytics(item, action) {
    const raw = item?.analytics?.[action]?.url;
    if (!raw) return;

    try {
      const url = new URL(raw);
      url.searchParams.set("customer_id", giphyCustomerId());
      url.searchParams.set("ts", String(Date.now()));
      fetch(url.toString(), {
        method: "GET",
        mode: "no-cors",
        credentials: "omit",
        cache: "no-store",
        keepalive: true,
      }).catch(() => {});
    } catch {}
  }

  function giphyPreviewUrl(item) {
    const images = item?.images || {};
    return (
      images.fixed_width_small?.webp ||
      images.fixed_width?.webp ||
      images.fixed_width_small?.url ||
      images.fixed_width?.url ||
      images.downsized?.url ||
      images.original?.url ||
      ""
    );
  }

  function giphySendUrl(item) {
    const images = item?.images || {};
    return (
      images.downsized_medium?.url ||
      images.downsized?.url ||
      images.fixed_height?.url ||
      images.original?.url ||
      ""
    );
  }

  function renderGiphyResults(items) {
    const grid = $("#giphyResults");
    grid.replaceChildren();
    state.giphyResults = items;

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "giphy-empty";
      empty.textContent = "No GIFs found.";
      grid.appendChild(empty);
      return;
    }

    for (const item of items) {
      const preview = giphyPreviewUrl(item);
      const sendUrl = giphySendUrl(item);
      if (!preview || !sendUrl) continue;

      const button = document.createElement("button");
      button.type = "button";
      button.className = "giphy-tile";
      button.setAttribute("aria-label", item.title || "Send GIF");

      const image = document.createElement("img");
      image.src = preview;
      image.alt = item.title || "GIPHY GIF";
      image.loading = "lazy";
      image.decoding = "async";
      image.addEventListener("load", () => giphyAnalytics(item, "onload"), {
        once: true,
      });

      button.appendChild(image);
      button.addEventListener("click", async () => {
        if (button.disabled) return;
        button.disabled = true;
        giphyAnalytics(item, "onclick");

        const conversationId = Number(state.activeId || 0);
        const replyToId = state.replyTo?.id || null;
        const success = await sendPreparedMessage({
          conversationId,
          externalGif: {
            id: String(item.id || ""),
            url: sendUrl,
            title: String(item.title || "GIPHY GIF").slice(0, 120),
          },
          optimisticMedia: {
            message_type: "gif",
            attachment_url: preview,
            attachment_name: item.title || "GIPHY GIF",
          },
          replyToId,
        });

        if (success) {
          giphyAnalytics(item, "onsent");
          if (state.activeId === conversationId) {
            if (Number(state.replyTo?.id || 0) === Number(replyToId || 0)) {
              cancelReply();
            }
            closeModal();
          }
        } else {
          button.disabled = false;
        }
      });

      grid.appendChild(button);
    }
  }

  async function loadGiphy(query = "") {
    const requestId = ++state.giphyRequestId;
    let client = null;

    try {
      client = await ensureGiphyClient();
    } catch {
      client = null;
    }

    if (requestId !== state.giphyRequestId) return;

    const enabled = Boolean(client);
    $("#giphySetup").classList.toggle("hidden", enabled);
    $("#giphyResults").classList.toggle("hidden", !enabled);

    if (!enabled) {
      $("#giphyStatus").textContent = state.giphyEnabled
        ? "GIPHY SDK could not load"
        : "GIPHY needs an SDK key";
      return;
    }

    const exactQuery = String(query || "").trim().slice(0, 50);
    $("#giphyStatus").textContent = exactQuery
      ? `Searching “${exactQuery}”`
      : "Trending GIFs";

    const language = String(navigator.language || "en").split("-")[0];
    const options = {
      limit: 24,
      rating: "pg-13",
    };
    if (/^[a-z]{2}$/i.test(language)) options.lang = language.toLowerCase();

    let timeoutId = null;
    try {
      const request = exactQuery
        ? client.search(exactQuery, options)
        : client.trending(options);

      const result = await Promise.race([
        request,
        new Promise((_, reject) => {
          timeoutId = setTimeout(
            () => reject(new DOMException("GIPHY SDK timed out.", "TimeoutError")),
            12000
          );
        }),
      ]);

      if (requestId !== state.giphyRequestId) return;
      const items = Array.isArray(result?.data) ? result.data : [];
      renderGiphyResults(items);
      $("#giphyStatus").textContent = exactQuery
        ? `Results for “${exactQuery}”`
        : "Trending GIFs";
    } catch (error) {
      if (requestId !== state.giphyRequestId) return;
      $("#giphyResults").replaceChildren();
      const failed = document.createElement("div");
      failed.className = "giphy-empty";
      failed.textContent = error?.name === "TimeoutError"
        ? "GIPHY took too long to respond. Try again."
        : "GIFs could not load. Check the GIPHY SDK key and connection.";
      $("#giphyResults").appendChild(failed);
      $("#giphyStatus").textContent =
        error?.name === "TimeoutError" ? "GIPHY timed out" : "GIPHY unavailable";
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  }

  function openGiphyPicker() {
    if (!state.activeId || !state.activeConversation?.can_message) return;
    $("#attachmentMenu").classList.add("hidden");
    $("#giphySearch").value = "";
    $("#giphyResults").replaceChildren();
    $("#giphySetup").classList.add("hidden");
    openModal("#giphyModal");
    loadGiphy("").catch(() => {});
  }

  function scheduleGiphySearch() {
    clearTimeout(state.giphySearchTimer);
    state.giphySearchTimer = setTimeout(() => {
      state.giphySearchTimer = null;
      loadGiphy($("#giphySearch").value).catch(() => {});
    }, 240);
  }

  async function loadStickerLibrary() {
    const grid = $("#stickerLibrary");
    const empty = $("#stickerEmpty");
    grid.replaceChildren();

    try {
      const data = await api("stickers");
      state.savedStickers = Array.isArray(data.stickers) ? data.stickers : [];
    } catch (error) {
      toast(error.message);
      state.savedStickers = [];
    }

    empty.classList.toggle("hidden", state.savedStickers.length > 0);

    for (const sticker of state.savedStickers) {
      const tile = document.createElement("div");
      tile.className = "sticker-tile";

      const send = document.createElement("button");
      send.type = "button";
      send.className = "sticker-send";
      send.setAttribute("aria-label", "Send sticker");

      const image = document.createElement("img");
      image.src = sticker.url;
      image.alt = "Custom sticker";
      image.loading = "lazy";
      image.decoding = "async";
      send.appendChild(image);

      send.addEventListener("click", async () => {
        if (send.disabled) return;
        send.disabled = true;
        const conversationId = Number(state.activeId || 0);
        const replyToId = state.replyTo?.id || null;
        const success = await sendPreparedMessage({
          conversationId,
          stickerId: Number(sticker.id),
          optimisticMedia: {
            message_type: "sticker",
            attachment_url: sticker.url,
            attachment_name: sticker.name || "Sticker",
          },
          replyToId,
        });
        if (success) {
          if (state.activeId === conversationId) {
            if (Number(state.replyTo?.id || 0) === Number(replyToId || 0)) {
              cancelReply();
            }
            closeModal();
          }
        } else {
          send.disabled = false;
        }
      });

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "sticker-delete";
      remove.setAttribute("aria-label", "Delete sticker");
      remove.title = "Delete sticker";
      remove.appendChild(iconNode("close"));
      remove.addEventListener("click", async () => {
        remove.disabled = true;
        try {
          await api("sticker_delete", {
            method: "POST",
            body: { sticker_id: sticker.id },
          });
          await loadStickerLibrary();
        } catch (error) {
          toast(error.message);
          remove.disabled = false;
        }
      });

      tile.append(send, remove);
      grid.appendChild(tile);
    }
  }

  function openStickerLibrary() {
    if (!state.activeId || !state.activeConversation?.can_message) return;
    $("#attachmentMenu").classList.add("hidden");
    openModal("#stickerLibraryModal");
    loadStickerLibrary().catch(() => {});
  }

  function roundedRectPath(context, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    context.beginPath();
    context.moveTo(x + r, y);
    context.arcTo(x + width, y, x + width, y + height, r);
    context.arcTo(x + width, y + height, x, y + height, r);
    context.arcTo(x, y + height, x, y, r);
    context.arcTo(x, y, x + width, y, r);
    context.closePath();
  }

  function resetStickerDrawing() {
    const canvas = $("#stickerDrawCanvas");
    const context = canvas?.getContext?.("2d");
    context?.clearRect(0, 0, canvas.width, canvas.height);
    const mask = document.createElement("canvas");
    mask.width = canvas?.width || 512;
    mask.height = canvas?.height || 512;
    state.stickerEraseMask = mask;
    state.stickerDrawHistory = [];
    state.stickerDrawPointer = null;
  }

  function resetStickerTransform() {
    const defaults = {
      stickerZoom: "100",
      stickerRotate: "0",
      stickerOffsetX: "0",
      stickerOffsetY: "0",
      stickerOutlineWidth: "12",
      stickerShadow: "soft",
      stickerCutoutStrength: "48",
    };
    for (const [id, value] of Object.entries(defaults)) {
      const field = $(`#${id}`);
      if (field) field.value = value;
    }
    state.stickerFlipX = false;
    $("#stickerFlipBtn")?.classList.remove("active");
    renderStickerMaker();
  }

  function sourceStickerGeometry(image, size, padding, fit) {
    const inner = Math.max(8, size - padding * 2);
    const sourceRatio = image.naturalWidth / Math.max(1, image.naturalHeight);
    const targetRatio = 1;
    let drawWidth;
    let drawHeight;
    if ((fit === "cover" && sourceRatio > targetRatio) ||
        (fit === "contain" && sourceRatio < targetRatio)) {
      drawHeight = inner;
      drawWidth = drawHeight * sourceRatio;
    } else {
      drawWidth = inner;
      drawHeight = drawWidth / sourceRatio;
    }
    return { inner, drawWidth, drawHeight };
  }

  function stickerTransformValues() {
    return {
      zoom: Math.max(.5, Math.min(2.5, Number($("#stickerZoom")?.value || 100) / 100)),
      rotate: Math.max(-180, Math.min(180, Number($("#stickerRotate")?.value || 0))),
      offsetX: Math.max(-160, Math.min(160, Number($("#stickerOffsetX")?.value || 0))),
      offsetY: Math.max(-160, Math.min(160, Number($("#stickerOffsetY")?.value || 0))),
      flipX: Boolean(state.stickerFlipX),
    };
  }

  async function openStickerMakerFromFile(file) {
    if (!file || !/^image\/(?:jpeg|png|webp)$/i.test(String(file.type || ""))) {
      if (file) toast("Choose a JPEG, PNG, or WebP image.");
      return;
    }
    if (file.size > 24 * 1024 * 1024) {
      toast("Choose an image smaller than 24 MB.");
      return;
    }

    const url = URL.createObjectURL(file);
    const image = new Image();
    image.decoding = "async";
    image.src = url;
    try {
      await decodeImageElement(image);
    } catch {
      URL.revokeObjectURL(url);
      toast("That image could not be opened.");
      return;
    }

    if (state.stickerSourceRevocable && state.stickerSourceUrl?.startsWith?.("blob:")) {
      try { URL.revokeObjectURL(state.stickerSourceUrl); } catch {}
    }
    state.stickerSourceImage = image;
    state.stickerSourceUrl = url;
    state.stickerSourceRevocable = true;
    resetStickerDrawing();
    setStickerDrawMode("draw");
    $("#stickerFit").value = "contain";
    $("#stickerShape").value = "original";
    $("#stickerOutline").value = "white";
    $("#stickerPadding").value = "16";
    resetStickerTransform();
    $("#stickerLibraryModal")?.classList.add("hidden");
    $("#stickerMakerModal").classList.remove("hidden");
    renderStickerMaker();
  }

  async function autoCutoutStickerBackground() {
    const image = state.stickerSourceImage;
    const mask = state.stickerEraseMask;
    const output = $("#stickerMakerCanvas");
    if (!image || !mask || !output || state.stickerCutoutBusy) return;
    const button = $("#stickerAutoCutoutBtn");
    const label = button?.textContent;
    state.stickerCutoutBusy = true;
    if (button) { button.disabled = true; button.textContent = "Removing background…"; button.setAttribute("aria-busy", "true"); }
    try {
      // Let the busy state paint before touching pixels on slower phones.
      await new Promise(resolve => setTimeout(resolve, 0));
      await runStickerAutoCutout(image, mask, output);
    } catch (error) {
      toast(error?.message || "Auto cutout failed. Use the Erase brush instead.");
    } finally {
      state.stickerCutoutBusy = false;
      if (button) { button.disabled = false; button.textContent = label; button.removeAttribute("aria-busy"); }
    }
  }

  async function runStickerAutoCutout(image, mask, output) {
    const current = () => state.stickerSourceImage === image && state.stickerEraseMask === mask &&
      !$("#stickerMakerModal")?.classList.contains("hidden");
    if (!current()) return;
    const size = output.width;
    const scratch = document.createElement("canvas");
    scratch.width = size;
    scratch.height = size;
    try {
    const context = scratch.getContext("2d", { alpha: true, willReadFrequently: true });
    if (!context) throw new Error("This browser could not prepare the image. Try the Erase brush.");
    const padding = Math.max(0, Math.min(96, Number($("#stickerPadding")?.value || 0)));
    const fit = $("#stickerFit")?.value || "contain";
    const { drawWidth, drawHeight } = sourceStickerGeometry(image, size, padding, fit);
    const transform = stickerTransformValues();

    context.save();
    context.translate(size / 2 + transform.offsetX, size / 2 + transform.offsetY);
    context.rotate(transform.rotate * Math.PI / 180);
    context.scale((transform.flipX ? -1 : 1) * transform.zoom, transform.zoom);
    context.drawImage(image, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
    context.restore();

    let imageData;
    try {
      imageData = context.getImageData(0, 0, size, size);
    } catch {
      toast("Auto cutout could not read this image. Use the Erase brush instead.");
      return;
    }

    const data = imageData.data;
    const threshold = Math.max(18, Math.min(110, Number($("#stickerCutoutStrength")?.value || 48)));
    const visited = new Uint8Array(size * size);
    const remove = new Uint8Array(size * size);
    const queue = new Int32Array(size * size);
    let qHead = 0;
    let qTail = 0;

    // Estimate the background from many opaque perimeter samples. Median RGB
    // handles shadows and uneven walls better than relying on one corner.
    const edgeColors = [];
    const collect = (x, y) => {
      const px = (y * size + x) * 4;
      if (data[px + 3] > 32) edgeColors.push([data[px], data[px + 1], data[px + 2]]);
    };
    const edgeStep = Math.max(2, Math.floor(size / 128));
    for (let i = 0; i < size; i += edgeStep) {
      collect(i, 0); collect(i, size - 1); collect(0, i); collect(size - 1, i);
    }

    // With the default sticker padding, the canvas border is transparent.
    // Sample the first/last opaque pixels on rows and columns as well, so
    // contained or rotated photos have a usable image perimeter.
    if (!edgeColors.length) {
      for (let y = 0; y < size; y += edgeStep) {
        let left = 0, right = size - 1;
        while (left < size && data[(y * size + left) * 4 + 3] <= 32) left++;
        while (right > left && data[(y * size + right) * 4 + 3] <= 32) right--;
        if (left < size) { collect(left, y); collect(right, y); }
      }
      for (let x = 0; x < size; x += edgeStep) {
        let top = 0, bottom = size - 1;
        while (top < size && data[(top * size + x) * 4 + 3] <= 32) top++;
        while (bottom > top && data[(bottom * size + x) * 4 + 3] <= 32) bottom--;
        if (top < size) { collect(x, top); collect(x, bottom); }
      }
    }
    if (!edgeColors.length) {
      toast("Could not identify the background. Use the Erase brush instead.");
      return;
    }

    const median = (channel) => {
      const values = edgeColors.map((color) => color[channel]).sort((a, b) => a - b);
      return values[Math.floor(values.length / 2)];
    };
    const bg = [median(0), median(1), median(2)];

    const colorDistance = (px) => {
      const dr = data[px] - bg[0];
      const dg = data[px + 1] - bg[1];
      const db = data[px + 2] - bg[2];
      return Math.sqrt(dr * dr * .30 + dg * dg * .52 + db * db * .18);
    };

    const isSkinLike = (px) => {
      const r = data[px];
      const g = data[px + 1];
      const b = data[px + 2];
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const cb = 128 - .168736 * r - .331264 * g + .5 * b;
      const cr = 128 + .5 * r - .418688 * g - .081312 * b;
      return r > 45 && g > 20 && b > 10 &&
        max - min > 7 && r >= g * .92 && r > b * .88 &&
        cb > 70 && cb < 145 && cr > 126 && cr < 185;
    };

    // Detect a likely face/skin cluster only to protect people from being eaten
    // by the background flood fill. This is intentionally conservative.
    let skinCount = 0;
    let skinX = 0;
    let skinY = 0;
    for (let y = Math.floor(size * .10); y < Math.floor(size * .78); y += 4) {
      for (let x = Math.floor(size * .16); x < Math.floor(size * .84); x += 4) {
        const px = (y * size + x) * 4;
        if (data[px + 3] > 80 && isSkinLike(px)) {
          skinCount += 1;
          skinX += x;
          skinY += y;
        }
      }
    }

    let detectedFace = null;
    if (typeof window.FaceDetector === "function") {
      try {
        const detector = new window.FaceDetector({ fastMode: true, maxDetectedFaces: 1 });
        let faceTimer;
        let faces;
        try {
          faces = await Promise.race([detector.detect(scratch), new Promise(resolve => {
            faceTimer = setTimeout(() => resolve([]), 2000);
          })]);
        } finally { clearTimeout(faceTimer); }
        const box = faces?.[0]?.boundingBox;
        if (box && box.width > 12 && box.height > 12) detectedFace = box;
      } catch {}
    }

    if (!current()) return;
    const portraitLikely =
      Boolean(detectedFace) ||
      skinCount >= Math.max(18, Math.floor(size / 18));
    const faceCx = detectedFace
      ? detectedFace.x + detectedFace.width / 2
      : portraitLikely && skinCount
        ? skinX / skinCount
        : size / 2;
    const faceCy = detectedFace
      ? detectedFace.y + detectedFace.height / 2
      : portraitLikely && skinCount
        ? skinY / skinCount
        : size * .38;
    const protectRx = detectedFace
      ? Math.max(size * .18, detectedFace.width * .95)
      : size * .23;
    const protectRy = detectedFace
      ? Math.max(size * .30, detectedFace.height * 1.95)
      : size * .38;

    const protectPortrait = (x, y, px) => {
      if (!portraitLikely) return false;
      const dx = (x - faceCx) / protectRx;
      const dy = (y - (faceCy + protectRy * .20)) / protectRy;
      return dx * dx + dy * dy < 1 &&
        (isSkinLike(px) || colorDistance(px) > threshold * .42);
    };

    const edgeStrength = (x, y, px) => {
      if (x <= 0 || y <= 0 || x >= size - 1 || y >= size - 1) return 0;
      const right = px + 4;
      const down = px + size * 4;
      return (
        Math.abs(data[px] - data[right]) +
        Math.abs(data[px + 1] - data[right + 1]) +
        Math.abs(data[px + 2] - data[right + 2]) +
        Math.abs(data[px] - data[down]) +
        Math.abs(data[px + 1] - data[down + 1]) +
        Math.abs(data[px + 2] - data[down + 2])
      ) / 6;
    };

    const push = (x, y) => {
      if (x < 0 || y < 0 || x >= size || y >= size) return;
      const index = y * size + x;
      if (visited[index]) return;
      visited[index] = 1;
      const px = index * 4;
      const transparent = data[px + 3] <= 8;
      if (!transparent && protectPortrait(x, y, px)) return;

      const distance = colorDistance(px);
      const edge = edgeStrength(x, y, px);
      if (transparent || (distance <= threshold && edge <= Math.max(13, threshold * .32))) {
        remove[index] = 1;
        queue[qTail++] = index;
      }
    };

    for (let x = 0; x < size; x += 1) {
      push(x, 0);
      push(x, size - 1);
    }
    for (let y = 1; y < size - 1; y += 1) {
      push(0, y);
      push(size - 1, y);
    }

    while (qHead < qTail) {
      if (qHead > 0 && qHead % 8192 === 0) {
        await new Promise(resolve => setTimeout(resolve, 0));
        if (!current()) return;
      }
      const index = queue[qHead++];
      const x = index % size;
      const y = Math.floor(index / size);
      push(x - 1, y);
      push(x + 1, y);
      push(x, y - 1);
      push(x, y + 1);
    }

    if (!current()) return;
    const maskContext = mask.getContext("2d");
    if (!maskContext) throw new Error("This browser could not prepare the sticker mask.");
    snapshotStickerDrawing();
    const maskData = maskContext.getImageData(0, 0, size, size);

    for (let i = 0; i < remove.length; i += 1) {
      if (!remove[i]) continue;
      const px = i * 4;
      const x = i % size;
      const y = Math.floor(i / size);
      const bordersForeground =
        (x > 0 && !remove[i - 1]) ||
        (x + 1 < size && !remove[i + 1]) ||
        (y > 0 && !remove[i - size]) ||
        (y + 1 < size && !remove[i + size]);
      const alpha = bordersForeground ? 205 : 255;
      maskData.data[px] = 255;
      maskData.data[px + 1] = 255;
      maskData.data[px + 2] = 255;
      maskData.data[px + 3] = Math.max(maskData.data[px + 3], alpha);
    }

    maskContext.putImageData(maskData, 0, 0);
    renderStickerMaker();
    toast(
      portraitLikely
        ? "Person-aware cutout applied. Use Restore or Undo for fine adjustments."
        : "Background removed. Use Restore or Undo for fine adjustments."
    );
    } finally { scratch.width = 1; scratch.height = 1; }
  }

  function snapshotStickerDrawing() {
    const canvas = $("#stickerDrawCanvas");
    const context = canvas?.getContext?.("2d");
    const maskContext = state.stickerEraseMask?.getContext?.("2d");
    if (!canvas || !context || !maskContext) return;
    state.stickerDrawHistory ||= [];
    state.stickerDrawHistory.push({
      draw: context.getImageData(0, 0, canvas.width, canvas.height),
      erase: maskContext.getImageData(0, 0, canvas.width, canvas.height),
    });
    if (state.stickerDrawHistory.length > 8) state.stickerDrawHistory.shift();
  }

  function undoStickerDrawing() {
    const canvas = $("#stickerDrawCanvas");
    const context = canvas?.getContext?.("2d");
    const maskContext = state.stickerEraseMask?.getContext?.("2d");
    if (!canvas || !context || !maskContext) return;
    const previous = state.stickerDrawHistory?.pop?.();
    context.clearRect(0, 0, canvas.width, canvas.height);
    maskContext.clearRect(0, 0, canvas.width, canvas.height);
    if (previous?.draw) context.putImageData(previous.draw, 0, 0);
    if (previous?.erase) maskContext.putImageData(previous.erase, 0, 0);
    renderStickerMaker();
  }

  function setStickerDrawMode(mode) {
    state.stickerDrawMode = ["erase", "restore"].includes(mode) ? mode : "draw";
    $("#stickerDrawModeBtn")?.classList.toggle("active", state.stickerDrawMode === "draw");
    $("#stickerEraseModeBtn")?.classList.toggle("active", state.stickerDrawMode === "erase");
    $("#stickerRestoreModeBtn")?.classList.toggle("active", state.stickerDrawMode === "restore");
  }

  function stickerCanvasPoint(event) {
    const canvas = $("#stickerDrawCanvas");
    const rect = canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (canvas.width / Math.max(1, rect.width)),
      y: (event.clientY - rect.top) * (canvas.height / Math.max(1, rect.height)),
    };
  }

  function beginStickerDraw(event) {
    if (event.button !== undefined && event.button !== 0) return;
    const canvas = $("#stickerDrawCanvas");
    if (!canvas) return;
    event.preventDefault();
    snapshotStickerDrawing();
    const point = stickerCanvasPoint(event);
    state.stickerDrawPointer = {
      id: event.pointerId,
      x: point.x,
      y: point.y,
    };
    try { canvas.setPointerCapture?.(event.pointerId); } catch {}
    continueStickerDraw(event);
  }

  function continueStickerDraw(event) {
    const pointer = state.stickerDrawPointer;
    const canvas = $("#stickerDrawCanvas");
    if (!pointer || !canvas || pointer.id !== event.pointerId) return;
    event.preventDefault();
    const point = stickerCanvasPoint(event);
    const drawingContext = canvas.getContext("2d");
    const maskMode = state.stickerDrawMode === "erase" || state.stickerDrawMode === "restore";
    const context = maskMode
      ? state.stickerEraseMask?.getContext?.("2d")
      : drawingContext;
    if (!context) return;
    context.save();
    context.lineCap = "round";
    context.lineJoin = "round";
    context.lineWidth = Math.max(2, Math.min(96, Number($("#stickerBrushSize")?.value || 14)));
    context.globalCompositeOperation = state.stickerDrawMode === "restore"
      ? "destination-out"
      : "source-over";
    context.strokeStyle = maskMode
      ? "#ffffff"
      : ($("#stickerBrushColor")?.value || "#ffffff");
    context.beginPath();
    context.moveTo(pointer.x, pointer.y);
    context.lineTo(point.x, point.y);
    context.stroke();
    context.restore();
    if (maskMode) renderStickerMaker();
    pointer.x = point.x;
    pointer.y = point.y;
  }

  function endStickerDraw(event) {
    if (!state.stickerDrawPointer) return;
    if (event?.pointerId !== undefined && state.stickerDrawPointer.id !== event.pointerId) return;
    state.stickerDrawPointer = null;
  }

  function addStickerText() {
    const value = String($("#stickerTextInput")?.value || "").trim().slice(0, 32);
    if (!value) return;
    const canvas = $("#stickerDrawCanvas");
    const context = canvas?.getContext?.("2d");
    if (!canvas || !context) return;
    snapshotStickerDrawing();
    context.save();
    context.font = "800 58px system-ui, sans-serif";
    context.textAlign = "center";
    context.textBaseline = "middle";
    context.lineJoin = "round";
    context.lineWidth = 12;
    context.strokeStyle = "rgba(0,0,0,.88)";
    context.fillStyle = $("#stickerBrushColor")?.value || "#ffffff";
    context.strokeText(value, canvas.width / 2, canvas.height * .77, canvas.width - 52);
    context.fillText(value, canvas.width / 2, canvas.height * .77, canvas.width - 52);
    context.restore();
    $("#stickerTextInput").value = "";
  }

  async function openBlankStickerMaker() {
    const image = new Image();
    image.decoding = "async";
    image.src = "data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='512' height='512'/%3E";
    try { await image.decode?.(); } catch {}
    state.stickerSourceImage = image;
    state.stickerSourceUrl = "";
    state.stickerSourceRevocable = false;
    $("#stickerFit").value = "contain";
    $("#stickerShape").value = "original";
    $("#stickerOutline").value = "none";
    $("#stickerPadding").value = "0";
    resetStickerDrawing();
    setStickerDrawMode("draw");
    resetStickerTransform();
    $("#stickerMakerModal").classList.remove("hidden");
    $("#stickerLibraryModal")?.classList.add("hidden");
    renderStickerMaker();
  }

  function renderStickerMaker() {
    const image = state.stickerSourceImage;
    if (!image) return;

    const canvas = $("#stickerMakerCanvas");
    const context = canvas.getContext("2d", { alpha: true });
    const size = canvas.width;
    const padding = Math.max(0, Math.min(96, Number($("#stickerPadding").value || 0)));
    const inner = size - padding * 2;
    const fit = $("#stickerFit").value;
    const shape = $("#stickerShape").value;
    const outline = $("#stickerOutline").value;

    context.clearRect(0, 0, size, size);

    context.save();
    if (shape === "circle") {
      context.beginPath();
      context.arc(size / 2, size / 2, inner / 2, 0, Math.PI * 2);
      context.closePath();
    } else if (shape === "rounded") {
      roundedRectPath(context, padding, padding, inner, inner, Math.max(26, inner * 0.12));
    } else {
      context.beginPath();
      context.rect(padding, padding, inner, inner);
      context.closePath();
    }
    context.clip();

    const { drawWidth, drawHeight } = sourceStickerGeometry(image, size, padding, fit);
    const transform = stickerTransformValues();
    context.translate(size / 2 + transform.offsetX, size / 2 + transform.offsetY);
    context.rotate(transform.rotate * Math.PI / 180);
    context.scale((transform.flipX ? -1 : 1) * transform.zoom, transform.zoom);
    context.drawImage(image, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
    context.restore();

    const outlineWidth = Math.max(2, Math.min(28, Number($("#stickerOutlineWidth")?.value || 12)));
    const shadow = $("#stickerShadow")?.value || "soft";
    if (outline !== "none") {
      context.save();
      context.strokeStyle = outline === "black" ? "#111111" : "#ffffff";
      context.lineWidth = outlineWidth;
      context.lineJoin = "round";
      if (shadow !== "none") {
        context.shadowColor = shadow === "strong" ? "rgba(0,0,0,.55)" : "rgba(0,0,0,.28)";
        context.shadowBlur = shadow === "strong" ? 18 : 10;
        context.shadowOffsetY = shadow === "strong" ? 6 : 3;
      }
      if (shape === "circle") {
        context.beginPath();
        context.arc(size / 2, size / 2, Math.max(2, inner / 2 - outlineWidth / 2), 0, Math.PI * 2);
        context.closePath();
      } else if (shape === "rounded") {
        const inset = outlineWidth / 2;
        roundedRectPath(context, padding + inset, padding + inset, Math.max(2, inner - outlineWidth), Math.max(2, inner - outlineWidth), Math.max(20, inner * 0.11));
      } else {
        const inset = outlineWidth / 2;
        context.strokeRect(padding + inset, padding + inset, Math.max(2, inner - outlineWidth), Math.max(2, inner - outlineWidth));
        context.restore();
        // strokeRect draws immediately; continue so the transparency mask is
        // still applied to "Original" shaped stickers.
        if (state.stickerEraseMask) {
          context.save();
          context.globalCompositeOperation = "destination-out";
          context.drawImage(state.stickerEraseMask, 0, 0, size, size);
          context.restore();
        }
        return;
      }
      context.stroke();
      context.restore();
    }

    // The eraser mask removes pixels from the source image itself rather than
    // merely erasing doodles. This makes manual background removal real and
    // preserves alpha in the saved WebP/PNG sticker.
    if (state.stickerEraseMask) {
      context.save();
      context.globalCompositeOperation = "destination-out";
      context.drawImage(state.stickerEraseMask, 0, 0, size, size);
      context.restore();
    }
  }

  async function openStickerMakerFromMessage() {
    const message = state.mediaHoldMessage;
    if (!message?.attachment_url || message.message_type !== "image") return;

    $("#mediaHoldModal").classList.add("hidden");
    const image = new Image();
    image.decoding = "async";

    try {
      let sourceUrl = message.decrypted_attachment_url || message.attachment_url;
      if (!message.decrypted_attachment_url && message?.e2ee_meta?.media && window.SilknexE2EE) {
        sourceUrl = await window.SilknexE2EE.decryptMediaToUrl(message);
        message.decrypted_attachment_url = sourceUrl;
      }
      image.src = sourceUrl;
      await decodeImageElement(image);
    } catch {
      toast("That image could not be opened.");
      closeModal();
      return;
    }

    state.stickerSourceImage = image;
    state.stickerSourceUrl = message.decrypted_attachment_url || message.attachment_url;
    state.stickerSourceRevocable = false;
    resetStickerDrawing();
    setStickerDrawMode("draw");
    $("#stickerFit").value = "contain";
    $("#stickerShape").value = "rounded";
    $("#stickerOutline").value = "white";
    $("#stickerPadding").value = "28";
    resetStickerTransform();
    $("#stickerMakerModal").classList.remove("hidden");
    renderStickerMaker();
  }

  function canvasToBlob(canvas, type, quality) {
    return new Promise((resolve, reject) => {
      canvas.toBlob((blob) => {
        if (blob) resolve(blob);
        else reject(new Error("Could not create image."));
      }, type, quality);
    });
  }

  async function saveSticker() {
    if (!state.stickerSourceImage) return;
    const button = $("#saveStickerBtn");
    button.disabled = true;

    try {
      renderStickerMaker();
      const canvas = $("#stickerMakerCanvas");
      const drawCanvas = $("#stickerDrawCanvas");
      const composite = document.createElement("canvas");
      composite.width = canvas.width;
      composite.height = canvas.height;
      const compositeContext = composite.getContext("2d", { alpha: true });
      compositeContext.drawImage(canvas, 0, 0);
      if (drawCanvas) compositeContext.drawImage(drawCanvas, 0, 0);
      let blob;
      let extension = "webp";
      try {
        blob = await canvasToBlob(composite, "image/webp", 0.92);
      } catch {
        blob = await canvasToBlob(composite, "image/png");
        extension = "png";
      }
      if (!blob.size) throw new Error("Sticker is empty.");

      const file = fileFromBlob(blob, `sticker-${Date.now()}.${extension}`, {
        type: blob.type || (extension === "webp" ? "image/webp" : "image/png"),
      });

      await uploadFile(file, "sticker");
      closeModal();
      toast("Sticker saved.");
    } catch (error) {
      toast(error.message);
    } finally {
      button.disabled = false;
    }
  }

  function openMediaHold(message) {
    if (!message || message.deleted_at || message.pending) return;

    const isImage = message.message_type === "image" && Boolean(message.attachment_url);
    const isVideo =
      (message.message_type === "video" || message.message_type === "video_note") &&
      Boolean(message.attachment_url);
    const isSticker =
      message.message_type === "sticker" &&
      Boolean(message.attachment_url) &&
      Number(message.id || 0) > 0;

    if (!isImage && !isVideo && !isSticker) return;

    state.mediaHoldMessage = message;
    $("#makeStickerFromMediaBtn")?.classList.toggle("hidden", !isImage);
    $("#makeGifFromMediaBtn")?.classList.toggle("hidden", !isVideo);
    $("#saveStickerFromMessageBtn")?.classList.toggle("hidden", !isSticker);
    $("#mediaHoldHeading").textContent = isImage
      ? "Create from this photo"
      : isVideo
        ? "Create from this video"
        : "Sticker options";
    openModal("#mediaHoldModal");
  }

  async function saveStickerFromMessage() {
    const message = state.mediaHoldMessage;
    const messageId = Number(message?.id || 0);
    if (!messageId || message?.message_type !== "sticker") return;

    const button = $("#saveStickerFromMessageBtn");
    if (button?.disabled || !state.me) return;
    const session = state.me;
    if (button) button.disabled = true;
    try {
      await api("sticker_save_message", {
        method: "POST",
        body: { message_id: messageId },
        timeoutMs: 10000,
      });
      if (state.me !== session) return;
      state.savedStickers = [];
      if (state.mediaHoldMessage === message) closeModal("#mediaHoldModal");
      toast("Sticker saved to your library.");
    } catch (error) {
      toast(error?.message || "Could not save that sticker.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function installMediaLongPress(wrapper, message) {
    const canCreate =
      message.message_type === "image" ||
      message.message_type === "video" ||
      message.message_type === "video_note" ||
      message.message_type === "sticker";
    if (!canCreate || message.pending) return;

    let startX = 0;
    let startY = 0;
    let pointerId = null;
    let fired = false;

    const cancel = () => {
      clearTimeout(state.mediaHoldTimer);
      state.mediaHoldTimer = null;
      pointerId = null;
    };

    wrapper.addEventListener("pointerdown", (event) => {
      if (event.pointerType === "mouse" && event.button !== 0) return;
      if (event.target.closest("button,a")) return;
      startX = event.clientX;
      startY = event.clientY;
      pointerId = event.pointerId;
      fired = false;
      clearTimeout(state.mediaHoldTimer);
      state.mediaHoldTimer = setTimeout(() => {
        if (pointerId !== event.pointerId) return;
        if (wrapper.closest(".message")?.classList.contains("message-actions-open")) return;
        fired = true;
        wrapper.dataset.longPressed = "1";
        setTimeout(() => {
          delete wrapper.dataset.longPressed;
        }, 900);
        try { navigator.vibrate?.(20); } catch {}
        openMediaHold(message);
      }, 520);
    });

    wrapper.addEventListener("pointermove", (event) => {
      if (pointerId !== event.pointerId) return;
      if (Math.hypot(event.clientX - startX, event.clientY - startY) > 10) {
        cancel();
      }
    }, { passive: true });

    wrapper.addEventListener("pointerup", cancel);
    wrapper.addEventListener("pointercancel", cancel);
    wrapper.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      cancel();
      openMediaHold(message);
    });

    wrapper.addEventListener("click", (event) => {
      if (fired || wrapper.dataset.longPressed === "1") {
        event.preventDefault();
        event.stopPropagation();
        fired = false;
        delete wrapper.dataset.longPressed;
      }
    }, true);
  }

  function updateGifRangeUi() {
    const video = $("#gifMakerVideo");
    const duration = Number.isFinite(video.duration) ? video.duration : 0;
    const startInput = $("#gifStart");
    const lengthInput = $("#gifLength");
    const maxStart = Math.max(0, duration - 0.5);

    startInput.max = String(maxStart);
    let start = Math.min(maxStart, Math.max(0, Number(startInput.value || 0)));

    const maxLength = Math.max(0.5, Math.min(6, duration - start || 0.5));
    lengthInput.max = String(maxLength);
    let length = Math.min(maxLength, Math.max(0.5, Number(lengthInput.value || 3)));

    if (start + length > duration && duration > 0) {
      length = Math.max(0.5, duration - start);
    }

    startInput.value = String(start);
    lengthInput.value = String(length);
    $("#gifRangeLabel").textContent =
      `${start.toFixed(1)}s – ${(start + length).toFixed(1)}s`;
  }

  function seekVideo(video, time) {
    return new Promise((resolve, reject) => {
      const target = Math.max(0, Math.min(Number(video.duration || time), time));
      if (Math.abs(video.currentTime - target) < 0.015 && video.readyState >= 2) {
        resolve();
        return;
      }

      const timeout = setTimeout(() => {
        cleanup();
        reject(new Error("Video seek timed out."));
      }, 5000);
      const done = () => {
        cleanup();
        resolve();
      };
      const failed = () => {
        cleanup();
        reject(new Error("Video could not be read."));
      };
      const cleanup = () => {
        clearTimeout(timeout);
        video.removeEventListener("seeked", done);
        video.removeEventListener("error", failed);
      };
      video.addEventListener("seeked", done, { once: true });
      video.addEventListener("error", failed, { once: true });
      try {
        video.currentTime = target;
      } catch (error) {
        cleanup();
        reject(error);
      }
    });
  }

  function wrapGifCaption(context, text, maxWidth, maxLines = 2) {
    const words = String(text || "").trim().split(/\s+/).filter(Boolean);
    if (!words.length) return [];
    const lines = [];
    let current = "";

    for (const word of words) {
      const candidate = current ? `${current} ${word}` : word;
      if (!current || context.measureText(candidate).width <= maxWidth) {
        current = candidate;
        continue;
      }
      lines.push(current);
      current = word;
      if (lines.length >= maxLines - 1) break;
    }

    if (current && lines.length < maxLines) {
      const consumed = lines.join(" ").split(/\s+/).filter(Boolean).length;
      const remaining = words.slice(consumed).join(" ");
      let finalLine = remaining || current;
      while (finalLine && context.measureText(finalLine).width > maxWidth) {
        finalLine = finalLine.slice(0, -1);
      }
      if (remaining && finalLine.length < remaining.length) {
        finalLine = `${finalLine.replace(/[.…\s]+$/g, "")}…`;
        while (finalLine.length > 1 && context.measureText(finalLine).width > maxWidth) {
          finalLine = `${finalLine.slice(0, -2).replace(/[.…\s]+$/g, "")}…`;
        }
      }
      if (finalLine) lines.push(finalLine);
    }
    return lines.slice(0, maxLines);
  }

  function resetGifEditorControls() {
    const defaults = {
      gifFilter: "none",
      gifCrop: "original",
      gifSpeed: "1",
      gifRotate: "0",
      gifMirror: "none",
      gifColorQuality: "smooth",
      gifBrightness: "100",
      gifContrast: "100",
      gifSaturation: "100",
      gifCaption: "",
      gifCaptionPosition: "bottom",
      gifCaptionStyle: "outline",
      gifCaptionSize: "100",
      gifCaptionColor: "#ffffff",
    };
    for (const [id, value] of Object.entries(defaults)) {
      const field = $(`#${id}`);
      if (field) field.value = value;
    }
  }

  function gifPalette332() {
    const palette = new Uint8Array(256 * 3);
    for (let index = 0; index < 256; index += 1) {
      const r = (index >> 5) & 7;
      const g = (index >> 2) & 7;
      const b = index & 3;
      palette[index * 3] = Math.round((r / 7) * 255);
      palette[index * 3 + 1] = Math.round((g / 7) * 255);
      palette[index * 3 + 2] = Math.round((b / 3) * 255);
    }
    return palette;
  }

  function imageDataTo332(imageData, smooth = true) {
    const source = imageData.data;
    const out = new Uint8Array(source.length / 4);
    const width = Math.max(1, Number(imageData.width || 1));
    // Ordered dithering keeps gradients and skin tones from banding badly while
    // retaining the compact 256-color palette required by the small in-browser
    // GIF encoder. It is deterministic and uses no extra frame-sized buffers.
    const bayer4 = [
      0, 8, 2, 10,
      12, 4, 14, 6,
      3, 11, 1, 9,
      15, 7, 13, 5,
    ];
    const clampByte = (value) => Math.max(0, Math.min(255, value));
    for (let sourceIndex = 0, targetIndex = 0; sourceIndex < source.length; sourceIndex += 4, targetIndex += 1) {
      let r = source[sourceIndex];
      let g = source[sourceIndex + 1];
      let b = source[sourceIndex + 2];
      if (smooth) {
        const x = targetIndex % width;
        const y = Math.floor(targetIndex / width);
        const d = (bayer4[(y & 3) * 4 + (x & 3)] - 7.5);
        r = clampByte(r + d * 2.5);
        g = clampByte(g + d * 2.4);
        b = clampByte(b + d * 4.8);
      }
      out[targetIndex] =
        ((r >> 5) << 5) |
        ((g >> 5) << 2) |
        (b >> 6);
    }
    return out;
  }

  function lzwEncodeGif(indices) {
    // GIF's decoder builds its own dictionary even when we only emit literal
    // palette indices. Reset before the 9-bit dictionary reaches its first
    // width transition. This is intentionally simple and very robust across
    // Safari/Chrome/Firefox; for short chat GIFs the size tradeoff is small.
    const clearCode = 256;
    const endCode = 257;
    const codeSize = 9;
    const bytes = [];
    let accumulator = 0;
    let bits = 0;

    const emit = (code) => {
      accumulator |= code << bits;
      bits += codeSize;
      while (bits >= 8) {
        bytes.push(accumulator & 255);
        accumulator >>>= 8;
        bits -= 8;
      }
    };

    let index = 0;
    while (index < indices.length) {
      emit(clearCode);

      // After a clear, the decoder can consume 254 literal values while
      // remaining at a 9-bit code width. Clear again before the next value.
      const end = Math.min(indices.length, index + 254);
      while (index < end) {
        emit(indices[index]);
        index += 1;
      }
    }

    if (!indices.length) emit(clearCode);
    emit(endCode);

    if (bits > 0) bytes.push(accumulator & 255);
    return new Uint8Array(bytes);
  }

  function pushGifWord(target, value) {
    target.push(value & 255, (value >> 8) & 255);
  }

  function encodeGif(frames, width, height, delayCs) {
    // Build the GIF as compact typed-array chunks instead of one giant JS
    // number array. Large number arrays are extremely memory-expensive on
    // mobile browsers and used to make GIF creation spike RAM.
    const parts = [];
    const header = [];
    const asciiInto = (target, value) => {
      for (let index = 0; index < value.length; index += 1) {
        target.push(value.charCodeAt(index));
      }
    };

    asciiInto(header, "GIF89a");
    pushGifWord(header, width);
    pushGifWord(header, height);
    header.push(0xF7, 0, 0);
    header.push(...gifPalette332());
    header.push(0x21, 0xFF, 0x0B);
    asciiInto(header, "NETSCAPE2.0");
    header.push(0x03, 0x01, 0x00, 0x00, 0x00);
    parts.push(new Uint8Array(header));

    for (const frame of frames) {
      const frameBytes = [];
      frameBytes.push(0x21, 0xF9, 0x04, 0x04);
      pushGifWord(frameBytes, delayCs);
      frameBytes.push(0x00, 0x00);

      frameBytes.push(0x2C);
      pushGifWord(frameBytes, 0);
      pushGifWord(frameBytes, 0);
      pushGifWord(frameBytes, width);
      pushGifWord(frameBytes, height);
      frameBytes.push(0x00);

      const compressed = lzwEncodeGif(frame);
      frameBytes.push(0x08);
      for (let offset = 0; offset < compressed.length; offset += 255) {
        const length = Math.min(255, compressed.length - offset);
        frameBytes.push(length);
        for (let index = 0; index < length; index += 1) {
          frameBytes.push(compressed[offset + index]);
        }
      }
      frameBytes.push(0x00);
      parts.push(new Uint8Array(frameBytes));
    }

    parts.push(new Uint8Array([0x3B]));
    return new Blob(parts, { type: "image/gif" });
  }

  async function openGifMakerFromMessage() {
    const message = state.mediaHoldMessage;
    if (
      !message?.attachment_url ||
      !["video", "video_note"].includes(message.message_type)
    ) return;

    state.gifSourceMessage = message;
    $("#mediaHoldModal").classList.add("hidden");
    $("#gifMakerModal").classList.remove("hidden");

    const video = $("#gifMakerVideo");
    video.pause();
    let sourceUrl = message.decrypted_attachment_url || message.attachment_url;
    try {
      if (!message.decrypted_attachment_url && message?.e2ee_meta?.media && window.SilknexE2EE) {
        sourceUrl = await window.SilknexE2EE.decryptMediaToUrl(message);
        message.decrypted_attachment_url = sourceUrl;
      }
      video.src = sourceUrl;
      video.load();

      await new Promise((resolve, reject) => {
        if (video.readyState >= 1) {
          resolve();
          return;
        }
        const onLoaded = () => {
          cleanup();
          resolve();
        };
        const onError = () => {
          cleanup();
          reject(new Error("Video could not be opened."));
        };
        const cleanup = () => {
          video.removeEventListener("loadedmetadata", onLoaded);
          video.removeEventListener("error", onError);
        };
        video.addEventListener("loadedmetadata", onLoaded, { once: true });
        video.addEventListener("error", onError, { once: true });
      });

      const duration = Math.max(0.5, Number(video.duration || 0.5));
      $("#gifStart").value = "0";
      $("#gifLength").value = String(Math.min(3, duration));
      updateGifRangeUi();
    } catch (error) {
      toast(error.message);
      closeModal();
    }
  }

  async function openGifMakerFromFile(file) {
    if (!file || !state.activeId) return;
    if (!String(file.type || "").startsWith("video/") && !/\.(mov|mp4|webm|m4v)$/i.test(file.name || "")) {
      toast("Choose a video to create a GIF.");
      return;
    }
    if (file.size > 80 * 1024 * 1024) {
      toast("Choose a video smaller than 80 MB.");
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    state.gifSourceMessage = {
      conversation_id: state.activeId,
      message_type: "video",
      attachment_url: objectUrl,
      decrypted_attachment_url: objectUrl,
      revoke_url: objectUrl,
      local_creator_source: true,
    };

    $("#giphyModal")?.classList.add("hidden");
    $("#gifMakerModal").classList.remove("hidden");
    const video = $("#gifMakerVideo");
    video.pause();
    video.src = objectUrl;
    video.load();
    try {
      await new Promise((resolve, reject) => {
        if (video.readyState >= 1) return resolve();
        const onLoaded = () => { cleanup(); resolve(); };
        const onError = () => { cleanup(); reject(new Error("Video could not be opened.")); };
        const cleanup = () => {
          video.removeEventListener("loadedmetadata", onLoaded);
          video.removeEventListener("error", onError);
        };
        video.addEventListener("loadedmetadata", onLoaded, { once: true });
        video.addEventListener("error", onError, { once: true });
      });
      const duration = Math.max(.5, Number(video.duration || .5));
      $("#gifStart").value = "0";
      $("#gifLength").value = String(Math.min(3, duration));
      updateGifRangeUi();
    } catch (error) {
      URL.revokeObjectURL(objectUrl);
      state.gifSourceMessage = null;
      closeModal();
      toast(error.message);
    }
  }

  async function createCustomGif() {
    if (state.gifEncoderBusy || !state.gifSourceMessage) return;

    const conversationId = Number(
      state.gifSourceMessage.conversation_id || state.activeId || 0
    );
    const replyToId = state.activeId === conversationId
      ? (state.replyTo?.id || null)
      : null;
    if (!conversationId) return;

    const button = $("#createGifBtn");
    const progress = $("#gifMakerProgress");
    const progressFill = progress.querySelector("span");
    const video = $("#gifMakerVideo");

    state.gifEncoderBusy = true;
    button.disabled = true;
    progress.classList.remove("hidden");
    progressFill.style.width = "0%";

    try {
      const duration = Number(video.duration || 0);
      const start = Math.max(0, Number($("#gifStart").value || 0));
      const length = Math.max(0.5, Math.min(6, Number($("#gifLength").value || 3), duration - start));
      const requestedFps = Math.max(8, Math.min(15, Number($("#gifFps").value || 10)));
      const loopMode = $("#gifLoop").value || "normal";
      const boomerang = loopMode === "boomerang";
      const reverse = loopMode === "reverse";
      const target = Math.max(240, Math.min(640, Number($("#gifSize").value || 320)));
      const cropMode = $("#gifCrop")?.value || "original";
      const speed = Math.max(.5, Math.min(2, Number($("#gifSpeed")?.value || 1)));
      const rotation = [0, 90, 180, 270].includes(Number($("#gifRotate")?.value))
        ? Number($("#gifRotate").value)
        : 0;
      const mirror = $("#gifMirror")?.value || "none";
      const smoothColors = ($("#gifColorQuality")?.value || "smooth") !== "sharp";
      const brightness = Math.max(.7, Math.min(1.3, Number($("#gifBrightness")?.value || 100) / 100));
      const userContrast = Math.max(.7, Math.min(1.4, Number($("#gifContrast")?.value || 100) / 100));
      const userSaturation = Math.max(0, Math.min(1.8, Number($("#gifSaturation")?.value || 100) / 100));
      const captionScale = Math.max(.7, Math.min(1.5, Number($("#gifCaptionSize")?.value || 100) / 100));
      const captionColor = /^#[0-9a-f]{6}$/i.test(String($("#gifCaptionColor")?.value || ""))
        ? $("#gifCaptionColor").value
        : "#ffffff";

      // Keep browser memory and GIF size predictable on phones. Higher
      // resolutions automatically use fewer source frames; boomerang needs
      // roughly twice the output frames, so its source budget is lower.
      const deviceMemory = Number(navigator.deviceMemory || 0);
      const lowMemory = deviceMemory > 0 && deviceMemory <= 4;
      const maxSourceFrames = lowMemory
        ? (
          target >= 480
            ? (boomerang ? 10 : 20)
            : target >= 320
              ? (boomerang ? 16 : 32)
              : (boomerang ? 22 : 44)
        )
        : (
          target >= 480
            ? (boomerang ? 18 : 36)
            : target >= 320
              ? (boomerang ? 28 : 56)
              : (boomerang ? 36 : 72)
        );
      const sourceFrameCount = Math.max(
        2,
        Math.min(maxSourceFrames, Math.round(length * requestedFps))
      );
      const effectiveFps = sourceFrameCount / length;
      const sourceWidth = Math.max(1, Number(video.videoWidth || 1));
      const sourceHeight = Math.max(1, Number(video.videoHeight || 1));
      const sourceRatio = sourceWidth / sourceHeight;
      const cropRatios = {
        square: 1,
        portrait: 4 / 5,
        story: 9 / 16,
        landscape: 16 / 9,
      };
      const desiredRatio = cropRatios[cropMode] || sourceRatio;
      let sx = 0;
      let sy = 0;
      let sw = sourceWidth;
      let sh = sourceHeight;
      if (sourceRatio > desiredRatio) {
        sw = sourceHeight * desiredRatio;
        sx = (sourceWidth - sw) / 2;
      } else if (sourceRatio < desiredRatio) {
        sh = sourceWidth / desiredRatio;
        sy = (sourceHeight - sh) / 2;
      }

      const rotatedRatio = rotation === 90 || rotation === 270
        ? 1 / desiredRatio
        : desiredRatio;
      let width;
      let height;
      if (rotatedRatio >= 1) {
        width = target;
        height = Math.max(2, Math.round(target / rotatedRatio));
      } else {
        height = target;
        width = Math.max(2, Math.round(target * rotatedRatio));
      }
      width += width % 2;
      height += height % 2;

      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const context = canvas.getContext("2d", {
        alpha: false,
        willReadFrequently: true,
      });
      const caption = $("#gifCaption").value.trim().slice(0, 80);
      const captionPosition = $("#gifCaptionPosition")?.value || "bottom";
      const captionStyle = $("#gifCaptionStyle")?.value || "outline";
      const filterMode = $("#gifFilter")?.value || "none";
      const frames = [];

      video.pause();

      for (let index = 0; index < sourceFrameCount; index += 1) {
        const fraction = sourceFrameCount <= 1 ? 0 : index / (sourceFrameCount - 1);
        await seekVideo(video, start + fraction * length);

        context.save();
        context.fillStyle = "#000";
        context.fillRect(0, 0, width, height);
        context.translate(width / 2, height / 2);
        context.rotate(rotation * Math.PI / 180);
        const mirrorX = mirror === "horizontal" ? -1 : 1;
        const mirrorY = mirror === "vertical" ? -1 : 1;
        context.scale(mirrorX, mirrorY);
        const presetFilter = filterMode === "vivid"
          ? "saturate(1.35) contrast(1.08)"
          : filterMode === "punch"
            ? "saturate(1.55) contrast(1.18)"
            : filterMode === "warm"
              ? "sepia(.18) saturate(1.16) hue-rotate(-7deg)"
              : filterMode === "cool"
                ? "saturate(1.08) hue-rotate(12deg)"
                : filterMode === "cinema"
                  ? "contrast(1.14) saturate(.92) sepia(.08)"
                  : filterMode === "fade"
                    ? "contrast(.88) saturate(.82) brightness(1.08)"
                    : filterMode === "mono"
                      ? "grayscale(1) contrast(1.08)"
                      : "";
        context.filter = `${presetFilter} brightness(${brightness}) contrast(${userContrast}) saturate(${userSaturation})`.trim();
        const drawWidth = rotation === 90 || rotation === 270 ? height : width;
        const drawHeight = rotation === 90 || rotation === 270 ? width : height;
        context.drawImage(video, sx, sy, sw, sh, -drawWidth / 2, -drawHeight / 2, drawWidth, drawHeight);
        context.restore();

        if (caption) {
          context.save();
          const fontSize = Math.max(
            16,
            Math.round(Math.min(width, height) * 0.09 * captionScale)
          );
          context.font = `850 ${fontSize}px system-ui, sans-serif`;
          context.textAlign = "center";
          context.textBaseline = "middle";
          context.lineJoin = "round";
          const maxTextWidth = Math.max(80, width - Math.max(20, Math.round(width * .08)));
          const lines = wrapGifCaption(context, caption, maxTextWidth, 2);
          const lineHeight = Math.round(fontSize * 1.12);
          const totalHeight = Math.max(lineHeight, lines.length * lineHeight);
          const centerY = captionPosition === "top"
            ? Math.max(totalHeight / 2 + 8, Math.round(height * 0.06) + totalHeight / 2)
            : captionPosition === "center"
              ? height / 2
              : height - Math.max(10, Math.round(height * 0.05)) - totalHeight / 2;

          if (captionStyle === "box") {
            let widest = 0;
            for (const line of lines) widest = Math.max(widest, context.measureText(line).width);
            const padX = Math.max(8, Math.round(fontSize * .34));
            const padY = Math.max(5, Math.round(fontSize * .18));
            const boxWidth = Math.min(width - 12, widest + padX * 2);
            const boxHeight = totalHeight + padY * 2;
            context.fillStyle = "rgba(0,0,0,.72)";
            context.fillRect(
              (width - boxWidth) / 2,
              centerY - boxHeight / 2,
              boxWidth,
              boxHeight
            );
          }

          lines.forEach((line, lineIndex) => {
            const y = centerY - ((lines.length - 1) * lineHeight) / 2 + lineIndex * lineHeight;
            if (captionStyle === "black") {
              context.lineWidth = Math.max(2, Math.round(fontSize * 0.1));
              context.strokeStyle = "rgba(255,255,255,.86)";
              context.fillStyle = "#0a0a0b";
              context.strokeText(line, width / 2, y, maxTextWidth);
              context.fillText(line, width / 2, y, maxTextWidth);
            } else if (captionStyle === "box") {
              context.fillStyle = captionColor;
              context.fillText(line, width / 2, y, maxTextWidth);
            } else {
              context.lineWidth = Math.max(3, Math.round(fontSize * 0.18));
              context.strokeStyle = "rgba(0,0,0,.92)";
              context.fillStyle = captionColor;
              context.strokeText(line, width / 2, y, maxTextWidth);
              context.fillText(line, width / 2, y, maxTextWidth);
            }
          });
          context.restore();
        }

        frames.push(
          imageDataTo332(context.getImageData(0, 0, width, height), smoothColors)
        );

        progressFill.style.width = `${Math.round(((index + 1) / sourceFrameCount) * 72)}%`;
        if (index % 2 === 0) {
          await new Promise((resolve) => requestAnimationFrame(resolve));
        }
      }

      if (reverse) frames.reverse();

      if (boomerang && frames.length > 2) {
        for (let index = frames.length - 2; index > 0; index -= 1) {
          // Frames are read-only during encoding, so reuse the typed-array
          // reference instead of cloning every frame and doubling RAM.
          frames.push(frames[index]);
        }
      }

      progressFill.style.width = "82%";
      await new Promise((resolve) => setTimeout(resolve, 0));

      const delayCs = Math.max(2, Math.round(100 / (effectiveFps * speed)));
      const blob = encodeGif(frames, width, height, delayCs);
      if (!blob.size) throw new Error("GIF could not be created.");
      if (blob.size > 12 * 1024 * 1024) {
        throw new Error("That GIF is too large. Choose a smaller size or fewer frames.");
      }

      progressFill.style.width = "90%";
      const file = fileFromBlob(blob, `custom-${Date.now()}.gif`, {
        type: "image/gif",
      });
      const secureUpload = await secureUploadMessageFile(file, "gif");
      const uploaded = secureUpload.uploaded;
      progressFill.style.width = "96%";

      const optimisticUrl = URL.createObjectURL(blob);
      const success = await sendPreparedMessage({
        conversationId,
        uploadToken: uploaded.token,
        optimisticMedia: {
          message_type: "gif",
          attachment_url: optimisticUrl,
          attachment_name: file.name,
          revoke_url: optimisticUrl,
          e2ee_media: secureUpload.media,
        },
        replyToId,
      });

      if (!success) {
        throw new Error("GIF was created but could not be sent.");
      }

      progressFill.style.width = "100%";
      if (state.activeId === conversationId) {
        if (Number(state.replyTo?.id || 0) === Number(replyToId || 0)) {
          cancelReply();
        }
        state.gifEncoderBusy = false;
        closeModal();
      }
      toast("Custom GIF sent.");
    } catch (error) {
      toast(error.message);
    } finally {
      state.gifEncoderBusy = false;
      button.disabled = false;
      setTimeout(() => {
        progress.classList.add("hidden");
        progressFill.style.width = "0%";
      }, 250);
    }
  }

  function clearDeferredMediaObservers({ disconnectedOnly = false } = {}) {
    for (const [wrapper, observer] of state.deferredMediaObservers) {
      if (disconnectedOnly && wrapper?.isConnected) continue;
      try { observer.disconnect(); } catch {}
      state.deferredMediaObservers.delete(wrapper);
    }
  }

  function setMessageMediaSource(
    element,
    message,
    wrapper,
    { fullscreen = false, lazyDecrypt = false } = {}
  ) {
    const encrypted = Boolean(message?.e2ee_meta?.media);
    const deviceMemory = Number(navigator.deviceMemory || 0);
    const memoryTight =
      document.documentElement.dataset.performance === "efficient" ||
      navigator.connection?.saveData === true ||
      (deviceMemory > 0 && deviceMemory <= 4);
    let started = false;
    let loaded = false;
    let currentUrl = "";
    let unloadTimer = 0;
    let disposed = false;
    let mediaRequest = 0;

    const releaseDetachedMedia = () => {
      // A re-render may already have attached a replacement player for this ID.
      // Its shared URL/job must survive disposal of the previous row.
      const id = Number(message.id || 0);
      const replacement = id ? document.querySelector(`#messages .message[data-message-id="${id}"]`) : null;
      if (replacement && !replacement.contains(wrapper)) return;
      message.decrypted_attachment_url = "";
      window.SilknexE2EE.releaseMediaUrl?.(message.id);
    };

    const apply = (url) => {
      if (!url) return;
      currentUrl = url;
      loaded = true;
      started = false;
      message.decrypted_attachment_url = url;
      element.src = url;
      wrapper?.removeAttribute("aria-busy");
      if (element instanceof HTMLMediaElement) {
        try { element.load(); } catch {}
      }
      wrapper?.querySelector(".media-retry")?.remove();
      wrapper?.classList?.remove("media-decrypting", "media-deferred");

      if (fullscreen && !element.dataset.fullscreenBound) {
        element.dataset.fullscreenBound = "1";
        element.classList.add("media-fullscreen-target");
        element.tabIndex = 0;
        element.setAttribute("role", "button");
        element.setAttribute("aria-label", "Open media full screen");
        const open = () => {
          const source = message.decrypted_attachment_url || currentUrl;
          if (!source) return;
          openFullscreenMedia(
            source,
            element instanceof HTMLVideoElement ? "video" : "image",
            element.getAttribute("alt") || "Shared media"
          );
        };
        element.addEventListener("click", open);
        element.addEventListener("keydown", (event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            open();
          }
        });
      }
    };

    // A pending preview is already a local plaintext blob, not ciphertext.
    if (message.pending && String(message.attachment_url || "").startsWith("blob:")) {
      apply(message.attachment_url);
      return;
    }
    if ((message.e2ee_payload || encrypted) && (!encrypted || !window.SilknexE2EE)) {
      const notice = document.createElement("p");
      notice.textContent = "This attachment needs the original device encryption key. Its encrypted file cannot be played directly.";
      wrapper.replaceChildren(notice);
      return;
    }
    if (!encrypted) {
      apply(message.attachment_url);
      return;
    }

    const releaseLoadedMedia = () => {
      unloadTimer = 0;
      if (!loaded || !currentUrl || !wrapper?.isConnected) return;
      if (
        element instanceof HTMLMediaElement &&
        (!element.paused || document.pictureInPictureElement === element)
      ) {
        return;
      }

      element.removeAttribute("src");
      if (element instanceof HTMLMediaElement) {
        try { element.load(); } catch {}
      }
      try { window.SilknexE2EE.releaseMediaUrl?.(message.id); } catch {}
      message.decrypted_attachment_url = "";
      currentUrl = "";
      loaded = false;
      started = false;
      wrapper.classList.add("media-deferred");
    };

    const decrypt = () => {
      if (started || loaded) return;
      started = true;
      const request = ++mediaRequest;
      wrapper?.classList?.add("media-decrypting");
      wrapper?.setAttribute("aria-busy", "true");
      window.SilknexE2EE.decryptMediaToUrl(message)
        .then(url => { if (!disposed && request === mediaRequest && wrapper?.isConnected) apply(url); })
        .catch((error) => {
          if (disposed || request !== mediaRequest || !wrapper?.isConnected) return;
          started = false;
          loaded = false;
          wrapper?.removeAttribute("aria-busy");
          wrapper?.classList?.remove("media-decrypting", "media-deferred");
          element.removeAttribute("src");
          showRetry("Could not open this attachment. Check your connection and retry.");
        });
    };

    const showRetry = (label) => {
      let retry = wrapper.querySelector(".media-retry");
      if (!retry) {
        retry = document.createElement("button");
        retry.type = "button";
        retry.className = "secondary-btn media-retry";
        retry.addEventListener("click", () => {
          retry.disabled = true;
          retry.textContent = element.tagName === "AUDIO" ? "Opening voice message…" : "Opening attachment…";
          mediaRequest++;
          started = loaded = false;
          window.SilknexE2EE.releaseMediaUrl?.(message.id);
          decrypt();
        });
        wrapper.appendChild(retry);
      }
      retry.disabled = false;
      retry.textContent = label;
    };
    element.addEventListener("error", () => {
      if (disposed || !wrapper.isConnected) return;
      started = loaded = false;
      wrapper.removeAttribute("aria-busy");
      showRetry("Playback unavailable — retry loading");
    });

    // Voice notes are loaded on demand, so an inbox full of audio does not
    // decrypt every file and revoke earlier players through cache eviction.
    if (element.tagName === "AUDIO") {
      element.addEventListener("play", () => {
        document.querySelectorAll("#messages audio").forEach((other) => {
          if (other !== element && !other.paused) other.pause();
        });
        window.SilknexE2EE.setMediaPlaying?.(message.id, true);
      });
      for (const event of ["pause", "ended", "error"]) {
        element.addEventListener(event, () => window.SilknexE2EE.setMediaPlaying?.(message.id, false));
      }
      let visible = true;
      const unloadAudio = () => {
        if (disposed || visible || !loaded || !element.paused) return;
        releaseLoadedMedia();
        wrapper.classList.remove("media-deferred");
        showRetry("Load voice message");
      };
      const scheduleUnload = () => {
        clearTimeout(unloadTimer);
        if (!visible && element.paused) unloadTimer = setTimeout(unloadAudio, memoryTight ? 4000 : 8000);
      };
      const audioObserver = typeof IntersectionObserver === "function" ? new IntersectionObserver(entries => {
        visible = entries.some(entry => entry.isIntersecting || entry.intersectionRatio > 0);
        if (visible) clearTimeout(unloadTimer);
        else scheduleUnload();
      }, {root:document.getElementById("messages"),rootMargin:"180px 0px",threshold:0.01}) : null;
      audioObserver?.observe(wrapper);
      element.addEventListener("pause", scheduleUnload);
      element.addEventListener("ended", scheduleUnload);
      element.addEventListener("loadeddata", scheduleUnload);
      state.deferredMediaObservers.set(wrapper, { disconnect() {
        disposed = true;
        clearTimeout(unloadTimer);
        audioObserver?.disconnect();
        element.pause();
        element.removeAttribute("src");
        try { element.load(); } catch {}
        releaseDetachedMedia();
      } });
      showRetry("Load voice message");
      return;
    }

    if (
      lazyDecrypt &&
      wrapper &&
      typeof IntersectionObserver !== "undefined"
    ) {
      wrapper.classList.add("media-decrypting", "media-deferred");
      const observer = new IntersectionObserver(
        (entries) => {
          const visible = entries.some(
            (entry) => entry.isIntersecting || entry.intersectionRatio > 0
          );

          if (visible) {
            if (unloadTimer) {
              clearTimeout(unloadTimer);
              unloadTimer = 0;
            }
            decrypt();
            return;
          }

          // v61: once encrypted media has been well outside the chat viewport
          // for a while, drop both the decoded surface and its decrypted blob.
          // It is transparently decrypted again if the user scrolls back.
          if (loaded && !unloadTimer) {
            unloadTimer = setTimeout(
              releaseLoadedMedia,
              memoryTight ? 8000 : 22000
            );
          }
        },
        {
          root: document.getElementById("messages") || null,
          rootMargin: memoryTight ? "180px 0px" : "360px 0px",
          threshold: 0.01,
        }
      );
      state.deferredMediaObservers.set(wrapper, { disconnect() {
        disposed = true;
        clearTimeout(unloadTimer);
        observer.disconnect();
        element.removeAttribute("src");
        if (element instanceof HTMLMediaElement) {
          element.pause();
          try { element.load(); } catch {}
        }
        releaseDetachedMedia();
      } });
      observer.observe(wrapper);
      return;
    }

    decrypt();
  }

  function createMessageMedia(message) {
    if (!message.attachment_url || message.deleted_at || message.expired) {
      return null;
    }

    const wrapper = document.createElement("div");
    wrapper.className = "message-media";

    if (
      message.message_type === "image" ||
      message.message_type === "gif" ||
      message.message_type === "sticker"
    ) {
      const isSticker = message.message_type === "sticker";
      const image = document.createElement("img");
      image.alt =
        message.message_type === "gif"
          ? "GIF"
          : isSticker
            ? "Custom sticker"
            : "Shared image";
      image.loading = "lazy";
      image.decoding = "async";
      try { image.fetchPriority = "low"; } catch {}

      if (isSticker) {
        wrapper.classList.add("sticker-media");
      }

      image.addEventListener("error", () => {
        if (message.e2ee_payload || message.e2ee_meta?.media) return;
        wrapper.replaceChildren();

        const link = document.createElement("a");
        link.className = "media-fallback-link";
        link.href = message.attachment_url;
        link.target = "_blank";
        link.rel = "noopener";
        link.textContent =
          message.message_type === "gif"
            ? "Open GIF"
            : isSticker
              ? "Open sticker"
              : "Open image";
        wrapper.appendChild(link);
      }, { once: true });

      wrapper.appendChild(image);
      setMessageMediaSource(image, message, wrapper, { fullscreen: true, lazyDecrypt: true });
      if (message.message_type === "image") {
        installMediaLongPress(wrapper, message);
      }
      return wrapper;
    }

    if (message.message_type === "video" || message.message_type === "video_note") {
      const video = document.createElement("video");
      video.controls = true;
      video.playsInline = true;
      video.preload = "metadata";

      if (message.message_type === "video_note") {
        wrapper.classList.add("video-note-media");
        video.className = "video-note-player";
      }

      video.addEventListener("error", () => {
        if (message.e2ee_payload || message.e2ee_meta?.media) return;
        wrapper.replaceChildren();

        const link = document.createElement("a");
        link.className = "media-fallback-link";
        link.href = message.attachment_url;
        link.target = "_blank";
        link.rel = "noopener";
        link.textContent =
          message.message_type === "video_note"
            ? "Open video message"
            : "Open video";
        wrapper.appendChild(link);
      }, { once: true });

      wrapper.appendChild(video);
      setMessageMediaSource(video, message, wrapper, { fullscreen: true, lazyDecrypt: true });
      installMediaLongPress(wrapper, message);
      return wrapper;
    }

    if (message.message_type === "audio") {
      wrapper.classList.add("voice-message-media");

      const audio = document.createElement("audio");
      audio.controls = true;
      audio.preload = "metadata";
      audio.preservesPitch = true;

      const speed = document.createElement("button");
      speed.type = "button";
      speed.className = "voice-speed";
      speed.textContent = "1×";
      speed.setAttribute("aria-label", "Voice message playback speed 1 times");

      const speeds = [0.5, 1, 1.5, 2];
      let speedIndex = 1;

      speed.addEventListener("click", () => {
        speedIndex = (speedIndex + 1) % speeds.length;
        const rate = speeds[speedIndex];
        audio.playbackRate = rate;
        speed.textContent = `${rate}×`;
        speed.setAttribute(
          "aria-label",
          `Voice message playback speed ${rate} times`
        );
      });

      wrapper.append(audio, speed);
      setMessageMediaSource(audio, message, wrapper);
      return wrapper;
    }

    return null;
  }

  const AVATAR_REACTIONS = [
    { id: "love", label: "Love" },
    { id: "laugh", label: "Laugh" },
    { id: "wow", label: "Wow" },
    { id: "yes", label: "Yes" },
    { id: "fire", label: "Hype" },
    { id: "sad", label: "Sad" },
  ];

  function reactionAvatarStyle(user) {
    if (user?.avatar_style && Object.keys(user.avatar_style).length) {
      return user.avatar_style;
    }
    return AVATAR_DEFAULT;
  }

  function createReactionTray(message) {
    const reactions = Array.isArray(message.reactions) ? message.reactions : [];
    if (!reactions.length) return null;

    const tray = document.createElement("div");
    tray.className = "avatar-reaction-tray";

    for (const item of reactions.slice(0, 8)) {
      const button = document.createElement("button");
      button.type = "button";
      button.className =
        "avatar-reaction-chip" +
        (Number(item.user_id) === Number(state.me?.id) ? " mine" : "");
      button.title = `${item.display_name || "Someone"} · ${item.reaction}`;
      button.setAttribute("aria-label", button.title);

      const avatar = document.createElement("span");
      avatar.className = "avatar avatar-reaction";
      setAvatar(
        avatar,
        item.display_name || "SilkNex",
        item.accent || "silver",
        "",
        reactionAvatarStyle(item),
        item.reaction
      );
      button.appendChild(avatar);

      if (Number(item.user_id) === Number(state.me?.id)) {
        button.addEventListener("click", () => reactToMessage(message, ""));
      }
      tray.appendChild(button);
    }

    if (reactions.length > 8) {
      const more = document.createElement("span");
      more.className = "avatar-reaction-more";
      more.textContent = `+${reactions.length - 8}`;
      tray.appendChild(more);
    }

    return tray;
  }

  function createReactionPicker(message) {
    const picker = document.createElement("div");
    picker.className = "avatar-reaction-picker";
    picker.setAttribute("role", "menu");
    picker.setAttribute("aria-label", "React with your avatar");

    const currentReaction = (message.reactions || []).find(
      (item) => Number(item.user_id) === Number(state.me?.id)
    )?.reaction || "";

    for (const reaction of AVATAR_REACTIONS) {
      const button = document.createElement("button");
      button.type = "button";
      button.className =
        "avatar-reaction-option" +
        (currentReaction === reaction.id ? " active" : "");
      button.title = currentReaction === reaction.id
        ? `Remove ${reaction.label} reaction`
        : reaction.label;
      button.setAttribute("aria-label", button.title);

      const avatar = document.createElement("span");
      avatar.className = "avatar avatar-reaction";
      setAvatar(
        avatar,
        state.me?.display_name || "You",
        state.me?.accent || "silver",
        "",
        reactionAvatarStyle(state.me),
        reaction.id
      );
      button.appendChild(avatar);
      button.addEventListener("click", (event) => {
        event.stopPropagation();
        reactToMessage(message, currentReaction === reaction.id ? "" : reaction.id);
      });
      picker.appendChild(button);
    }

    return picker;
  }

  async function reactToMessage(message, reaction) {
    if (!message?.id || message.pending) return;

    const previous = Array.isArray(message.reactions) ? message.reactions : [];
    const me = Number(state.me?.id || 0);
    const withoutMe = previous.filter((item) => Number(item.user_id) !== me);

    if (reaction) {
      withoutMe.push({
        user_id: me,
        reaction,
        display_name: state.me.display_name,
        accent: state.me.accent,
        avatar_url: state.me.avatar_url,
        avatar_style: state.me.avatar_style || {},
        updated_at: Math.floor(Date.now() / 1000),
      });
    }

    const box = $("#messages");
    const fromBottom = Math.max(0, box.scrollHeight - box.scrollTop - box.clientHeight);
    const oldHeight = box.scrollHeight;

    state.messages.set(message.id, { ...message, reactions: withoutMe });
    rebuildMessages();
    if (fromBottom < 100) {
      box.scrollTop = box.scrollHeight;
    } else {
      box.scrollTop += box.scrollHeight - oldHeight;
    }

    try {
      const data = await api("message_reaction", {
        method: "POST",
        body: { message_id: message.id, reaction },
      });

      const latest = state.messages.get(message.id);
      if (latest) {
        state.messages.set(message.id, {
          ...latest,
          reactions: data.reactions || [],
          updated_at: Number(data.updated_at || latest.updated_at || 0),
        });
      }
      state.changeSeq = Math.max(state.changeSeq, Number(data.change_seq || 0));
      broadcastSilkNex({
        type: "conversation-changed",
        conversation_id: Number(message.conversation_id || state.activeId || 0),
      });
      rebuildMessages();
      if (fromBottom < 100) box.scrollTop = box.scrollHeight;
    } catch (error) {
      const latest = state.messages.get(message.id);
      if (latest) state.messages.set(message.id, { ...latest, reactions: previous });
      rebuildMessages();
      toast(error.message);
    }
  }

  function renderMessageText(target, body) {
    const value = String(body || "");
    target.replaceChildren();
    if (!value) return;

    const mentionRe = /@([A-Za-z0-9_.]{3,24})/g;
    let cursor = 0;
    let match;
    while ((match = mentionRe.exec(value))) {
      if (match.index > cursor) {
        target.appendChild(document.createTextNode(value.slice(cursor, match.index)));
      }
      const username = match[1];
      const mention = document.createElement("button");
      mention.type = "button";
      mention.className = "message-mention";
      mention.textContent = `@${username}`;
      mention.setAttribute("aria-label", `Open @${username}'s public profile`);
      mention.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        openUserProfile({ username, display_name: username });
      });
      target.appendChild(mention);
      cursor = mentionRe.lastIndex;
    }
    if (cursor < value.length) {
      target.appendChild(document.createTextNode(value.slice(cursor)));
    }
  }


  function installMessageActionHold(row, card, actions) {
    if (!row || !card || !actions) return;

    let timer = 0;
    let pointerId = null;
    let startX = 0;
    let startY = 0;
    let suppressClick = false;

    const closeOthers = () => {
      document.querySelectorAll(".message.message-actions-open").forEach((item) => {
        if (item === row) return;
        item.classList.remove("message-actions-open");
        item.querySelector(".message-actions")?.setAttribute("aria-hidden", "true");
      });
    };

    const open = () => {
      closeOthers();
      row.classList.add("message-actions-open");
      actions.setAttribute("aria-hidden", "false");
      suppressClick = true;
      try { navigator.vibrate?.(16); } catch {}
    };

    const close = () => {
      row.classList.remove("message-actions-open");
      actions.setAttribute("aria-hidden", "true");
    };

    const cancelTimer = () => {
      clearTimeout(timer);
      timer = 0;
      pointerId = null;
    };

    actions.setAttribute("aria-hidden", "true");
    card.tabIndex = 0;
    card.setAttribute("aria-keyshortcuts", "Shift+F10");
    card.setAttribute("aria-label", "Message. Press and hold for message actions.");

    card.addEventListener("pointerdown", (event) => {
      if (event.pointerType === "mouse" && event.button !== 0) return;
      if (event.target.closest("button,a,input,textarea,select,audio,video")) return;
      pointerId = event.pointerId;
      startX = event.clientX;
      startY = event.clientY;
      suppressClick = false;
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (pointerId !== event.pointerId) return;
        timer = 0;
        open();
      }, event.pointerType === "mouse" ? 430 : 360);
    });

    card.addEventListener("pointermove", (event) => {
      if (pointerId !== event.pointerId) return;
      if (Math.hypot(event.clientX - startX, event.clientY - startY) > 11) {
        cancelTimer();
      }
    }, { passive: true });

    card.addEventListener("pointerup", cancelTimer);
    card.addEventListener("pointercancel", cancelTimer);

    card.addEventListener("contextmenu", (event) => {
      if (event.target.closest("input,textarea,select")) return;
      event.preventDefault();
      cancelTimer();
      open();
    });

    card.addEventListener("keydown", (event) => {
      if (event.key === "ContextMenu" || (event.shiftKey && event.key === "F10")) {
        event.preventDefault();
        row.classList.contains("message-actions-open") ? close() : open();
      } else if (event.key === "Escape" && row.classList.contains("message-actions-open")) {
        event.preventDefault();
        close();
        card.focus({ preventScroll: true });
      }
    });

    card.addEventListener("click", (event) => {
      if (!suppressClick) return;
      if (event.target.closest(".message-actions")) return;
      event.preventDefault();
      event.stopPropagation();
      suppressClick = false;
    }, true);

    actions.addEventListener("click", (event) => {
      if (event.target.closest(".avatar-reaction-picker")) return;
      setTimeout(() => {
        if (!actions.querySelector(".avatar-reaction-picker.open")) close();
      }, 0);
    });

    if (!installMessageActionHold._outsideBound) {
      installMessageActionHold._outsideBound = true;
      document.addEventListener("pointerdown", (event) => {
        document.querySelectorAll(".message.message-actions-open").forEach((openRow) => {
          if (openRow.contains(event.target)) return;
          openRow.classList.remove("message-actions-open");
          openRow.querySelector(".message-actions")?.setAttribute("aria-hidden", "true");
        });
      }, { passive: true });
    }
  }

  function createMessageElement(message) {
    const mine = message.sender_id === state.me.id;
    const deleted = Boolean(message.deleted_at);

    const row = document.createElement("div");
    row.className =
      "message" +
      (mine ? " mine" : "") +
      (deleted ? " deleted" : "") +
      (message.pending ? " pending" : "");
    row.dataset.messageId = String(message.id);
    row.classList.add("v57-message-enter");
    row.addEventListener("animationend", () => {
      row.classList.remove("v57-message-enter");
    }, { once: true });

    const avatar = document.createElement("div");
    setAvatar(
      avatar,
      message.sender_display_name,
      message.sender_accent,
      message.sender_avatar_url,
      message.sender_avatar_style
    );

    avatar.classList.add("message-avatar");
    if (message.sender_username) {
      avatar.classList.add("message-avatar-clickable");
      avatar.setAttribute("role", "button");
      avatar.tabIndex = 0;
      avatar.setAttribute("aria-label", `Open @${message.sender_username}'s profile`);
      const openSenderProfile = (event) => {
        event?.preventDefault?.();
        event?.stopPropagation?.();
        openUserProfile({
          id: message.sender_id,
          username: message.sender_username,
          display_name: message.sender_display_name,
          accent: message.sender_accent,
          avatar_url: message.sender_avatar_url,
          avatar_style: message.sender_avatar_style,
          role: message.sender_role,
        });
      };
      avatar.addEventListener("click", openSenderProfile);
      avatar.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") openSenderProfile(event);
      });
    }

    const card = document.createElement("div");
    card.className = "message-card";

    const meta = document.createElement("div");
    meta.className = "message-meta";

    const sender = document.createElement("span");
    sender.textContent = mine ? "You" : message.sender_display_name;
    meta.appendChild(sender);
    const repeats = Math.max(1, Number(message.repeat_count || 1));
    if (repeats > 1) {
      const count = document.createElement("span");
      count.className = "message-repeat-count";
      count.textContent = `×${repeats}`;
      count.title = `Repeated ${repeats} times in a row`;
      meta.appendChild(count);
    }
    if (isFounderRole(message.sender_role)) {
      meta.appendChild(founderBadgeNode(message.sender_role));
    }

    const bubble = document.createElement("div");
    bubble.className = "message-bubble";
    if (message.message_type === "sticker" && !deleted) {
      bubble.classList.add("sticker-bubble");
    }

    if (message.reply) {
      const quote = document.createElement("div");
      quote.className = "reply-quote";

      const quoteName = document.createElement("strong");
      quoteName.textContent = message.reply.sender_display_name;

      const quoteText = document.createElement("span");
      quoteText.textContent = message.reply.body || "Attachment";

      quote.append(quoteName, quoteText);
      bubble.appendChild(quote);
    }

    const media = createMessageMedia(message);
    if (media) bubble.appendChild(media);

    const text = document.createElement("span");
    text.className = "message-text";

    if (deleted) {
      text.textContent = "Message deleted";
    } else if (message.body) {
      renderMessageText(text, message.body);
    } else if (!media) {
      text.textContent = "";
    }

    if (deleted || message.body || !media) {
      bubble.appendChild(text);
    }

    const foot = document.createElement("div");
    foot.className = "message-foot";

    const time = document.createElement("span");
    time.textContent = formatTime(message.created_at);
    foot.appendChild(time);

    if (message.edited_at && !deleted) {
      const edited = document.createElement("span");
      edited.textContent = "edited";
      foot.appendChild(edited);
    }

    if (mine && !deleted) {
      if (message.pending) {
        const pending = document.createElement("span");
        pending.className = "message-pending";
        pending.textContent = "Sending…";
        foot.appendChild(pending);
      }

      const status = message.pending
        ? { text: "", label: "", seen: false }
        : messageReceiptStatus(message.id);

      if (status.icon) {
        const receipt = document.createElement("span");
        receipt.className = "receipt" + (status.seen ? " seen" : "");
        receipt.appendChild(iconNode(status.icon, "neo-icon receipt-icon"));
        receipt.title = status.label;
        receipt.setAttribute("aria-label", status.label);
        foot.appendChild(receipt);
      }
    }

    bubble.appendChild(foot);
    card.append(meta, bubble);

    const reactionTray = !deleted ? createReactionTray(message) : null;
    if (reactionTray) card.appendChild(reactionTray);

    if (!deleted && !message.pending) {
      const actions = document.createElement("div");
      actions.className = "message-actions";

      const reactWrap = document.createElement("div");
      reactWrap.className = "message-react-wrap";

      const react = document.createElement("button");
      react.type = "button";
      react.className = "message-action icon-action";
      react.setAttribute("aria-label", "React with your avatar");
      react.title = "React";
      setButtonContent(react, "smile");

      const picker = createReactionPicker(message);
      react.addEventListener("click", (event) => {
        event.stopPropagation();
        const opening = picker.classList.toggle("open");
        if (opening) {
          document.querySelectorAll(".avatar-reaction-picker.open").forEach((item) => {
            if (item !== picker) item.classList.remove("open");
          });
        }
      });
      reactWrap.append(react, picker);
      actions.appendChild(reactWrap);

      const reply = document.createElement("button");
      reply.type = "button";
      reply.className = "message-action icon-action";
      reply.setAttribute("aria-label", "Reply");
      reply.title = "Reply";
      setButtonContent(reply, "reply");
      reply.addEventListener("click", () => beginReply(message));
      actions.appendChild(reply);

      const save = document.createElement("button");
      save.type = "button";
      save.className = "message-action icon-action";
      save.dataset.saveMessageId = String(message.id);
      save.setAttribute("aria-label", "Save message");
      save.title = "Save";
      setButtonContent(save, "bookmark");
      const updateSavedButton = (saved) => {
        save.classList.toggle("selected", Boolean(saved));
        save.setAttribute("aria-pressed", saved ? "true" : "false");
        save.title = saved ? "Remove from saved" : "Save";
        save.setAttribute("aria-label", saved ? "Remove from saved messages" : "Save message");
      };
      updateSavedButton(state.savedMessageIds.has(Number(message.id)));
      save.addEventListener("click", async () => {
        if (save.disabled) return;
        save.disabled = true;
        try {
          const result = await api(
            "saved_message_toggle",
            {
              method: "POST",
              body: { message_id: Number(message.id) },
              showLoader: false,
            }
          );
          if (result.saved) state.savedMessageIds.add(Number(message.id));
          else state.savedMessageIds.delete(Number(message.id));
          updateSavedButton(Boolean(result.saved));
          window.dispatchEvent(new CustomEvent("silknex:saved-message", {
            detail: {
              messageId: Number(message.id),
              saved: Boolean(result.saved),
            },
          }));
          toast(result.saved ? "Saved message." : "Removed from saved.");
        } catch (error) {
          toast(error.message || "Could not update saved messages.");
        } finally {
          save.disabled = false;
        }
      });
      actions.appendChild(save);

      if (message.message_type === "text" && message.body) {
        const copy = document.createElement("button");
        copy.type = "button";
        copy.className = "message-action icon-action";
        copy.setAttribute("aria-label", "Copy message text");
        copy.title = "Copy";
        setButtonContent(copy, "copy");
        copy.addEventListener("click", async () => {
          const text = String(message.body || "");
          if (!text) return;
          try {
            await navigator.clipboard.writeText(text);
            toast("Copied.");
          } catch {
            const fallback = document.createElement("textarea");
            fallback.value = text;
            fallback.setAttribute("readonly", "");
            fallback.style.position = "fixed";
            fallback.style.opacity = "0";
            document.body.appendChild(fallback);
            fallback.select();
            try {
              document.execCommand("copy");
              toast("Copied.");
            } finally {
              fallback.remove();
            }
          }
        });
        actions.appendChild(copy);

        if (navigator.share) {
          const share = document.createElement("button");
          share.type = "button";
          share.className = "message-action icon-action";
          share.setAttribute("aria-label", "Share message");
          share.title = "Share";
          setButtonContent(share, "share");
          share.addEventListener("click", async () => {
            try {
              await navigator.share({ text: String(message.body || "") });
            } catch (error) {
              if (error?.name !== "AbortError") toast("Could not open sharing.");
            }
          });
          actions.appendChild(share);
        }
      }

      if (mine && message.message_type === "text") {
        const edit = document.createElement("button");
        edit.type = "button";
        edit.className = "message-action icon-action";
        edit.setAttribute("aria-label", "Edit");
        edit.title = "Edit";
        setButtonContent(edit, "edit");
        edit.addEventListener("click", () => editMessage(message));
        actions.appendChild(edit);
      }

      if (mine) {
        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "message-action icon-action danger";
        remove.setAttribute("aria-label", "Delete");
        remove.title = "Delete";
        setButtonContent(remove, "trash");
        remove.addEventListener("click", () => deleteMessage(message.id));
        actions.appendChild(remove);
      }

      card.appendChild(actions);
      installMessageActionHold(row, card, actions);
    }

    row.append(avatar, card);
    return row;
  }

  function updateScrollNewestButton() {
    const box = $("#messages");
    const distance = box.scrollHeight - box.scrollTop - box.clientHeight;
    $("#scrollNewestBtn").classList.toggle("hidden", !state.hasNewerHistory && distance < 220);
    $("#scrollNewestBtn").setAttribute("aria-label", state.hasNewerHistory ? "Load latest messages" : "Scroll to latest messages");
  }

  function messageRenderFingerprint(message) {
    const mine = Number(message.sender_id || 0) === Number(state.me?.id || 0);
    const receipt = mine && !message.pending
      ? messageReceiptStatus(Number(message.id || 0))
      : null;

    // Only data that can change the rendered row belongs here. Keeping this
    // fingerprint small lets SilkNex reuse existing DOM nodes, which preserves
    // media playback and avoids repainting an entire long chat for one reaction.
    return JSON.stringify([
      message.id,
      message.sender_id,
      message.sender_display_name,
      message.sender_accent,
      message.sender_avatar_url,
      message.sender_avatar_style || null,
      message.sender_role || "member",
      message.body || "",
      message.created_at || 0,
      message.updated_at || 0,
      message.message_type || "text",
      message.attachment_url || "",
      message.attachment_mime || "",
      message.attachment_name || "",
      Number(message.attachment_size || 0),
      Number(message.duration_ms || 0),
      message.edited_at || null,
      message.deleted_at || null,
      message.expires_at || null,
      message.reply || null,
      message.reactions || [],
      Boolean(message.pending),
      receipt?.label || "",
      Boolean(receipt?.seen),
    ]);
  }

  function scheduleLocalMessageExpiry() {
    clearTimeout(state.expiryTimer);
    state.expiryTimer = null;
    if (!state.activeId || !state.messages.size) return;

    const nowSeconds = Date.now() / 1000;
    let nearest = Infinity;

    for (const message of state.messages.values()) {
      const expiresAt = Number(message.expires_at || 0);
      if (expiresAt > nowSeconds && expiresAt < nearest) nearest = expiresAt;
    }

    if (!Number.isFinite(nearest)) return;

    const delay = Math.max(80, Math.min(2147483000, Math.ceil((nearest - nowSeconds) * 1000) + 40));
    const conversationId = state.activeId;

    state.expiryTimer = setTimeout(() => {
      state.expiryTimer = null;
      if (state.activeId !== conversationId) return;

      const now = Date.now() / 1000;
      let changed = false;
      for (const [id, message] of state.messages) {
        const expiresAt = Number(message.expires_at || 0);
        if (expiresAt > 0 && expiresAt <= now) {
          state.messages.delete(id);
          changed = true;
        }
      }

      if (changed) rebuildMessages();
      else scheduleLocalMessageExpiry();

      // Server cleanup/change_seq remains authoritative; this just prevents an
      // expired message from lingering visually until the next network cycle.
      schedulePoll();
    }, delay);
  }

  function messageWindowLimit() {
    return document.documentElement.dataset.performance === "efficient" ? 120 : 240;
  }

  function trimMessageWindow(preferOlder = false) {
    const saved = [...state.messages.values()].filter(message => Number(message.id) > 0 && !message.pending)
      .sort((a, b) => Number(a.id) - Number(b.id));
    const limit = messageWindowLimit();
    if (saved.length <= limit) return;
    const evicted = preferOlder ? saved.slice(limit) : saved.slice(0, saved.length - limit);
    for (const message of evicted) {
      state.messages.delete(message.id);
      window.SilknexE2EE?.releaseMediaUrl?.(message.id);
    }
    if (preferOlder) state.hasNewerHistory = true;
    else state.hasOlder = true;
  }

  function reconcileMessageChildren(box, desired) {
    // Leave unchanged rows attached: moving them through a DocumentFragment
    // restarts observers/media and produces O(history) mutations for one message.
    const retained = new Set(desired);
    for (const child of [...box.childNodes]) if (!retained.has(child)) child.remove();
    let cursor = box.firstChild;
    for (const node of desired) {
      if (node === cursor) cursor = cursor.nextSibling;
      else box.insertBefore(node, cursor);
    }
    while (cursor) {
      const next = cursor.nextSibling;
      cursor.remove();
      cursor = next;
    }
  }

  function rebuildMessages({ preferOlder = state.hasNewerHistory } = {}) {
    const box = $("#messages");
    if (!box) return;

    trimMessageWindow(preferOlder);
    const ordered = [...state.messages.values()].sort((a, b) => {
      const timeDelta = Number(a.created_at || 0) - Number(b.created_at || 0);
      if (timeDelta) return timeDelta;

      if (Boolean(a.pending) !== Boolean(b.pending)) {
        return a.pending ? 1 : -1;
      }

      if (a.pending && b.pending) {
        const pendingDelta = Number(a.updated_at || 0) - Number(b.updated_at || 0);
        if (pendingDelta) return pendingDelta;
      }

      return Number(a.id || 0) - Number(b.id || 0);
    });

    // Keep references to existing message rows before the atomic replacement.
    // Unchanged rows are moved into the new fragment instead of recreated.
    const existingRows = new Map();
    box.querySelectorAll(".message[data-message-id]").forEach((row) => {
      existingRows.set(String(row.dataset.messageId || ""), row);
    });

    const desired = [];
    const separators = new Map([...box.querySelectorAll(".date-separator[data-day]")].map(node => [node.dataset.day, node]));
    let lastDay = "";
    let previous = null;

    if (!ordered.length) {
      const empty = document.createElement("div");
      empty.className = "chat-empty-message";
      empty.textContent = "No messages yet. Say hi.";
      desired.push(empty);
    }

    for (const message of ordered) {
      const day = messageDayKey(message.created_at);

      if (day !== lastDay) {
        let separator = separators.get(day);
        if (!separator) {
          separator = document.createElement("div");
          separator.className = "date-separator";
          separator.dataset.day = day;
          const label = document.createElement("span");
          label.textContent = messageDayLabel(message.created_at);
          separator.appendChild(label);
        }
        desired.push(separator);
        lastDay = day;
        previous = null;
      }

      const key = String(message.id);
      const fingerprint = messageRenderFingerprint(message);
      let element = existingRows.get(key);

      if (!element || element.dataset.renderFingerprint !== fingerprint) {
        element = createMessageElement(message);
        element.dataset.renderFingerprint = fingerprint;
      } else {
        existingRows.delete(key);
      }

      const compact =
        previous &&
        previous.sender_id === message.sender_id &&
        !previous.deleted_at &&
        !message.deleted_at &&
        !message.reply &&
        Number(message.created_at) - Number(previous.created_at) <= 300;

      element.classList.toggle("compact", Boolean(compact));
      desired.push(element);
      previous = message;
    }

    reconcileMessageChildren(box, desired);
    clearDeferredMediaObservers({ disconnectedOnly: true });

    const persisted = ordered.filter((message) => Number(message.id) > 0);
    state.firstMessageId = persisted[0]?.id || 0;
    state.lastMessageId = persisted[persisted.length - 1]?.id || 0;
    state.syncAfterId = Math.max(state.syncAfterId || 0, Number(state.lastMessageId || 0));
    $("#olderBtn").classList.toggle("hidden", !state.hasOlder);
    scheduleLocalMessageExpiry();
    updateScrollNewestButton();
  }

  function updateCursorFromMessage(message) {
    const changedAt = Number(message.updated_at || 0);

    if (
      changedAt > state.syncCursor ||
      (changedAt === state.syncCursor && message.id > state.syncCursorId)
    ) {
      state.syncCursor = changedAt;
      state.syncCursorId = message.id;
    }
  }

  function chatIsActuallyVisible() {
    return (
      document.visibilityState === "visible" &&
      (typeof document.hasFocus !== "function" || document.hasFocus())
    );
  }

  async function acknowledgeRead(conversationId, messageId) {
    conversationId = Number(conversationId || 0);
    messageId = Number(messageId || 0);

    if (
      !state.me ||
      Date.now() < state.readAckRetryAt ||
      !conversationId ||
      !messageId ||
      state.activeId !== conversationId ||
      !chatIsActuallyVisible() ||
      messageId <= state.lastReadAckId
    ) {
      return;
    }

    if (state.readAckInFlightId > 0) {
      return;
    }

    const targetId = messageId;
    const session = state.me, view = state.openConversationController;
    const request = {};
    state.readAckRequest = request;
    let succeeded = false;
    state.readAckInFlightId = targetId;

    try {
      const data = await api("read_receipt", {
        method: "POST",
        body: {
          conversation_id: conversationId,
          message_id: targetId,
        },
      });

      if (state.activeId !== conversationId || state.me !== session || state.openConversationController !== view) return;
      succeeded = true;
      state.readAckFailures = 0;
      state.readAckRetryAt = 0;

      state.lastReadAckId = Math.max(
        state.lastReadAckId,
        Number(data.message_id || targetId)
      );
      state.deliveryAckByConversation.set(
        conversationId,
        Math.max(
          state.deliveryAckByConversation.get(conversationId) || 0,
          targetId
        )
      );
      state.changeSeq = Math.max(
        state.changeSeq,
        Number(data.change_seq || 0)
      );

      if (data.signature) {
        state.inboxSignature = String(data.signature);
      }

      const conversation = state.conversations.find(
        (item) => item.id === conversationId
      );

      if (conversation && Number(conversation.unread_count || 0) > 0) {
        conversation.unread_count = 0;
        state.conversationFingerprint = JSON.stringify(state.conversations);
        renderConversations();
      }
    } catch {
      if (state.readAckRequest === request) {
        state.readAckFailures = Math.min(5, state.readAckFailures + 1);
        state.readAckRetryAt = Date.now() + Math.min(30000, 1000 * 2 ** state.readAckFailures);
      }
    } finally {
      if (state.readAckRequest !== request) return;
      state.readAckRequest = null;
      if (state.readAckInFlightId === targetId) {
        state.readAckInFlightId = 0;
      }

      // If messages arrived while this acknowledgement was in flight, catch
      // up immediately instead of waiting for another long-poll cycle.
      if (
        state.activeId === conversationId && state.me === session && state.openConversationController === view &&
        chatIsActuallyVisible() &&
        state.lastMessageId > state.lastReadAckId &&
        (!succeeded || state.lastMessageId > targetId)
      ) {
        clearTimeout(state.readAckRetryTimer);
        state.readAckRetryTimer = setTimeout(() => {
          state.readAckRetryTimer = null;
          if (state.me !== session || state.openConversationController !== view) return;
          acknowledgeRead(conversationId, state.lastMessageId).catch(() => {});
        }, Math.max(0, state.readAckRetryAt - Date.now()));
      }
    }
  }

  async function loadMessages({
    initial = false,
    latest = false,
    older = false,
    signal = null,
  } = {}) {
    if (!state.activeId) return;

    const conversationId = state.activeId;
    const session = state.me, view = state.openConversationController;
    const requestId = ++state.historyRequestId;
    const deviceMemory = Number(navigator.deviceMemory || 0);
    const tightMessageWindow =
      navigator.connection?.saveData === true ||
      document.documentElement.dataset.performance === "efficient" ||
      (deviceMemory > 0 && deviceMemory <= 4);
    const params = {
      conversation_id: conversationId,
      // v61: smaller history windows reduce JSON, decrypted-message, DOM and
      // decoded-media retention. Older history is still available on demand.
      limit: tightMessageWindow ? 36 : 48,
    };

    if (older && state.firstMessageId) {
      params.before = state.firstMessageId;
    }

    const data = await api("messages", { signal }, params);
    if (state.activeId !== conversationId || state.me !== session || state.openConversationController !== view || requestId !== state.historyRequestId) return;

    const box = $("#messages");
    const oldHeight = box.scrollHeight;
    const oldScrollTop = box.scrollTop;
    const anchor = box.querySelector(".message[data-message-id]");
    const anchorTop = anchor?.getBoundingClientRect().top;

    const decryptedMessages = await decryptIncomingMessages(data.messages || []);
    if (state.activeId !== conversationId || state.me !== session || state.openConversationController !== view || requestId !== state.historyRequestId) return;

    if (latest) {
      for (const [id, message] of state.messages) if (!message.pending) {
        state.messages.delete(id);
        window.SilknexE2EE?.releaseMediaUrl?.(id);
      }
      state.hasNewerHistory = false;
    }
    for (const message of decryptedMessages) {
      state.syncAfterId = Math.max(state.syncAfterId || 0, Number(message.id || 0));
      state.messages.set(message.id, message);
      updateCursorFromMessage(message);
    }

    state.typingUsers = Array.isArray(data.typing) ? data.typing : [];
    renderTypingIndicator();
    if (data.receipt) state.receipt = data.receipt;
    state.changeSeq = Math.max(
      state.changeSeq,
      Number(data.change_seq || 0)
    );
    state.hasOlder = Boolean(data.has_more);

    rebuildMessages({ preferOlder: older || state.hasNewerHistory });

    if (initial || latest) {
      box.scrollTop = box.scrollHeight;
    } else if (older) {
      box.scrollTop = anchor?.isConnected && Number.isFinite(anchorTop)
        ? oldScrollTop + anchor.getBoundingClientRect().top - anchorTop
        : Math.max(0, oldScrollTop + box.scrollHeight - oldHeight);
    }

    updateScrollNewestButton();
    $("#olderBtn").classList.toggle("hidden", !state.hasOlder);

    if (state.lastMessageId > 0) {
      if (chatIsActuallyVisible()) {
        acknowledgeRead(conversationId, state.lastMessageId).catch(() => {});
      } else {
        const latest = state.messages.get(state.lastMessageId);

        if (latest?.sender_id !== state.me?.id) {
          acknowledgeDeliveryItems([{
            conversation_id: conversationId,
            message_id: state.lastMessageId,
          }]).catch(() => {});
        }
      }
    }
  }

  function broadcastSilkNex(message) {
    try {
      state.crossTabChannel?.postMessage?.({
        ...message,
        user_id: Number(state.me?.id || 0),
        at: Date.now(),
      });
    } catch {}
  }

  function setupCrossTabChannel() {
    try {
      state.crossTabChannel?.close?.();
    } catch {}
    state.crossTabChannel = null;

    if (!("BroadcastChannel" in window)) return;

    try {
      const channel = new BroadcastChannel("neochat-live-v25");
      state.crossTabChannel = channel;
      channel.addEventListener("message", (event) => {
        const data = event.data || {};
        if (!state.me || Number(data.user_id || 0) !== Number(state.me.id || 0)) return;

        if (data.type === "logout") {
          showAuth("Signed out in another SilkNex tab.");
          return;
        }

        if (data.type === "notified" && Number(data.message_id || 0) > 0) {
          state.notifiedIds.add(Number(data.message_id));
          return;
        }

        if (data.type === "conversation-changed") {
          const conversationId = Number(data.conversation_id || 0);
          if (conversationId && conversationId === Number(state.activeId || 0)) {
            // Coalesce a burst of local-tab sends/edits into one immediate sync.
            const now = Date.now();
            if (now - state.lastCrossTabSyncAt > 100) {
              state.lastCrossTabSyncAt = now;
              state.syncController?.abort?.();
              state.syncController = null;
              state.syncBusy = false;
              schedulePoll();
            }
          }
          loadConversations().catch(() => {});
        }
      });
    } catch {}
  }

  function maybeNotifyMessage(message) {
    if (!message || message.sender_id === state.me?.id) return;
    if (state.notifiedIds.has(message.id)) return;

    state.notifiedIds.add(message.id);
    broadcastSilkNex({ type: "notified", message_id: Number(message.id) });

    if (state.notifiedIds.size > 400) {
      state.notifiedIds = new Set([...state.notifiedIds].slice(-250));
    }

    if (document.visibilityState === "visible" && state.activeId === message.conversation_id) {
      return;
    }

    const conversation = state.conversations.find(
      (item) => Number(item.id) === Number(message.conversation_id)
    );
    const mutedUntil = Number(conversation?.muted_until || 0);
    if (conversation?.muted && mutedUntil > Math.floor(Date.now() / 1000)) {
      return;
    }

    const isGroup = conversation?.kind === "group";
    const senderName = message.sender_display_name || "SilkNex";
    const preview =
      message.body ||
      (message.message_type === "image" ? "Photo" :
        message.message_type === "gif" ? "GIF" :
        message.message_type === "sticker" ? "Sticker" :
        message.message_type === "video" ? "Video" :
        message.message_type === "audio" ? "Voice message" :
        message.message_type === "video_note" ? "Video message" : "New message");

    showBrowserNotification(
      isGroup ? (conversation?.name || "Group chat") : senderName,
      isGroup ? `${senderName}: ${preview}` : preview,
      `message-${message.id}`,
      {
        conversation_id: message.conversation_id,
        conversation_kind: isGroup ? "group" : "dm",
        avatar_url: isGroup
          ? (conversation?.avatar_url || "")
          : (message.sender_avatar_url || ""),
      }
    );
  }

  async function syncConversation() {
    if (!state.activeId || state.syncBusy) return;

    const conversationId = state.activeId;
    const session = state.me, view = state.openConversationController;
    const controller = createAbortController();

    state.syncBusy = true;
    state.syncController = controller;

    try {
      setSyncStatus("", navigator.onLine ? "Live" : "Offline");

      const box = $("#messages");
      const nearBottom =
        box.scrollHeight - box.scrollTop - box.clientHeight < 150;
      const oldReceipt = JSON.stringify(state.receipt);

      const data = await api("sync", { signal: controller.signal }, {
        conversation_id: conversationId,
        after: Math.max(state.syncAfterId || 0, state.lastMessageId),
        cursor: state.syncCursor,
        cursor_id: state.syncCursorId,
        known_seq: state.syncHasMore ? 0 : state.changeSeq,
        limit: messageWindowLimit() === 120 ? 48 : 80,
        // v33 uses one lightweight heartbeat for inbox/call/chat change
        // detection. Message sync only runs when that heartbeat reports a
        // changed active conversation, so it must not occupy a PHP worker
        // waiting for future changes.
        wait_ms: 0,
      });

      if (state.activeId !== conversationId || state.me !== session || state.openConversationController !== view || state.syncController !== controller) return;

      let changed = false;
      const decryptedMessages = await decryptIncomingMessages(data.messages || []);
      if (state.activeId !== conversationId || state.me !== session || state.openConversationController !== view || state.syncController !== controller) return;
      state.typingUsers = Array.isArray(data.typing) ? data.typing : [];
      renderTypingIndicator();

      for (const message of decryptedMessages) {
        const previous = state.messages.get(message.id);
        state.syncAfterId = Math.max(state.syncAfterId || 0, Number(message.id || 0));
        if (!previous && state.hasNewerHistory && message.id > state.lastMessageId) {
          if (!message.expired) maybeNotifyMessage(message);
          changed = true;
          continue;
        }

        if (message.expired) {
          if (previous) {
            state.messages.delete(message.id);
            changed = true;
          }
          continue;
        }

        const outsideLoadedHistory =
          !previous &&
          state.firstMessageId > 0 &&
          message.id < state.firstMessageId;

        if (outsideLoadedHistory) continue;

        if (
          !previous ||
          previous.body !== message.body ||
          previous.edited_at !== message.edited_at ||
          previous.deleted_at !== message.deleted_at ||
          previous.message_type !== message.message_type ||
          previous.attachment_url !== message.attachment_url ||
          previous.attachment_name !== message.attachment_name ||
          Number(previous.duration_ms || 0) !== Number(message.duration_ms || 0) ||
          JSON.stringify(previous.reply) !== JSON.stringify(message.reply) ||
          JSON.stringify(previous.reactions || []) !== JSON.stringify(message.reactions || [])
        ) {
          changed = true;
        }

        if (!previous) maybeNotifyMessage(message);
        state.messages.set(message.id, message);
      }

      state.syncCursor = Number(data.cursor || state.syncCursor);
      state.syncCursorId = Number(data.cursor_id || 0);
      state.changeSeq = Math.max(
        state.changeSeq,
        Number(data.change_seq || 0)
      );
      state.syncHasMore = Boolean(data.has_more);

      if (data.receipt) state.receipt = data.receipt;

      const receiptChanged = oldReceipt !== JSON.stringify(state.receipt);

      if (changed) {
        rebuildMessages();

        if (nearBottom) {
          box.scrollTop = box.scrollHeight;
          updateScrollNewestButton();
        }
      } else if (receiptChanged) {
        refreshReceiptIndicators();
      }

      state.pollTick += 1;
      state.syncFailures = 0;

      if (changed) {
        loadConversations().catch(() => {});
      }

      if (state.lastMessageId > 0) {
        // Receipts must never block the next long-poll. Sending them in the
        // background makes incoming messages feel immediate on mobile while
        // still keeping read/delivery state accurate.
        if (chatIsActuallyVisible()) {
          if (state.lastMessageId > state.lastReadAckId) {
            acknowledgeRead(conversationId, state.lastMessageId).catch(() => {});
          }
        } else {
          const latest = state.messages.get(state.lastMessageId);

          if (latest?.sender_id !== state.me?.id) {
            acknowledgeDeliveryItems([{
              conversation_id: conversationId,
              message_id: state.lastMessageId,
            }]).catch(() => {});
          }
        }
      }

      // Presence/profile data changes do not need to wake the message stream,
      // so refresh them periodically without slowing message delivery.
      if (state.pollTick % 8 === 0 && state.activeId === conversationId) {
        api("conversation", {}, { id: conversationId })
          .then((conversationData) => {
            if (state.activeId !== conversationId || state.me !== session || state.openConversationController !== view) return;

            state.activeConversation = conversationData.conversation;
            state.changeSeq = Math.max(
              state.changeSeq,
              Number(conversationData.conversation.change_seq || 0)
            );
            renderChatHeader();
            applyChatWallpaper(state.activeConversation.preferences);
          })
          .catch(() => {});
      }

      setSyncStatus("", state.syncHasMore ? "Catching up…" : "Live");
    } catch (error) {
      if (state.me !== session || state.openConversationController !== view || state.syncController !== controller) return;
      if (error?.name !== "AbortError") {
        state.syncFailures += 1;
        setSyncStatus("error", navigator.onLine ? "Reconnecting…" : "Offline");
      }
    } finally {
      if (state.syncController === controller) {
        state.syncController = null;
        state.syncBusy = false;
      }
    }

  }

  function schedulePoll(delayOverride = 0) {
    clearTimeout(state.pollTimer);
    if (!state.me || !state.activeId) return;

    const conversationId = state.activeId;
    const offline = navigator.onLine === false;
    const failureDelay = state.syncFailures > 0
      ? Math.min(30000, 1000 * 2 ** Math.min(5, state.syncFailures))
      : 0;
    const delay = offline
      ? 12000
      : Math.max(failureDelay, Number(delayOverride) || 0);

    state.pollTimer = setTimeout(async () => {
      if (state.activeId !== conversationId) return;

      if (navigator.onLine === false) {
        setSyncStatus("error", "Offline");
        return;
      }

      await syncConversation();

      // A single response is intentionally capped server-side. Drain a burst
      // quickly, but do not create an idle request loop; the shared heartbeat
      // below wakes the next sync when change_seq advances.
      if (
        state.activeId === conversationId &&
        state.syncHasMore
      ) {
        schedulePoll(40);
      }
    }, jitteredDelay(delay, delay > 0 ? 0.12 : 0));
  }

  function scheduleGlobalPoll() {
    clearTimeout(state.globalPollTimer);
    if (!state.me || state.globalPollController) return;

    const hidden = document.visibilityState === "hidden";
    const unfocused =
      !hidden &&
      typeof document.hasFocus === "function" &&
      !document.hasFocus();
    const offline = navigator.onLine === false;
    const idleFor = Math.max(
      0,
      Date.now() - Number(state.lastRealtimeActivityAt || 0)
    );

    // One heartbeat replaces separate inbox, call, and continuous active-chat
    // polling streams. It is intentionally adaptive: newly active chats poll
    // quickly, then progressively back off while idle. Web Push wakes visible
    // clients immediately, so subscribed users do not need to hammer MySQL
    // just to discover that nothing changed.
    let baseDelay;
    if (offline) {
      baseDelay = 30000;
    } else if (hidden) {
      // Hidden tabs should be nearly free. Push wakes subscribed clients;
      // non-push clients retain a conservative heartbeat for calls/messages.
      baseDelay = state.pushSubscribed ? 120000 : 30000;
    } else if (unfocused) {
      baseDelay = state.pushSubscribed ? 30000 : 15000;
    } else if (state.call) {
      baseDelay = 7000;
    } else if (idleFor < 15000) {
      baseDelay = state.activeId ? 3200 : 4800;
    } else if (idleFor < 60000) {
      baseDelay = state.activeId ? 5200 : 7600;
    } else if (state.pushSubscribed) {
      baseDelay = state.activeId ? 12000 : 18000;
    } else {
      baseDelay = state.activeId ? 8200 : 11000;
    }

    if (!offline && state.globalPollFailures > 0) {
      baseDelay = Math.max(baseDelay, Math.min(60000, 4000 * 2 ** Math.min(4, state.globalPollFailures)));
    }

    // Jitter prevents thousands of tabs that reconnect at once from striking
    // PHP/MySQL on the exact same millisecond.
    const delay = jitteredDelay(baseDelay, 0.22);

    state.globalPollTimer = setTimeout(async () => {
      if (!state.me) return;
      if (navigator.onLine === false) {
        scheduleGlobalPoll();
        return;
      }

      if (state.globalPollController) return;
      const session = state.me;
      const controller = createAbortController();
      state.globalPollController = controller;
      try {
        const previousSignature = String(state.inboxSignature || "");
        const previousFriendSignature = String(state.friendSignature || "");
        const data = await api("inbox_state", { signal: controller.signal, timeoutMs: 15000 }, {
          conversation_id: Number(state.activeId || 0),
        });
        if (state.me !== session || controller.signal?.aborted) return;
        state.globalPollFailures = 0;
        window.dispatchEvent(new Event("silknex:connection"));
        const signature = String(data.signature || "");
        const friendSignature = String(data.friend_signature || "");
        const activeChangeSeq = Number(data.active_change_seq || 0);
        const incomingCallId = Number(data.incoming_call_id || 0);
        let realtimeChanged = false;

        if (
          state.activeId &&
          activeChangeSeq > Number(state.changeSeq || 0)
        ) {
          realtimeChanged = true;
          schedulePoll(0);
        }

        if (!state.call) {
          const visibleIncomingId = Number(state.incomingCall?.id || 0);
          if (
            incomingCallId > 0 &&
            incomingCallId !== visibleIncomingId
          ) {
            realtimeChanged = true;
            pollIncomingCall().catch(() => {});
          } else if (
            incomingCallId === 0 &&
            visibleIncomingId > 0
          ) {
            realtimeChanged = true;
            pollIncomingCall().catch(() => {});
          }
        }

        if (
          (previousSignature && signature && signature !== previousSignature) ||
          (
            previousFriendSignature &&
            friendSignature &&
            friendSignature !== previousFriendSignature
          )
        ) {
          realtimeChanged = true;
        }

        if (realtimeChanged) {
          state.lastRealtimeActivityAt = Date.now();
        }

        const staleAfter = state.activeId ? 180000 : 120000;
        const stale =
          Date.now() - Number(state.lastConversationRefreshAt || 0) > staleAfter;

        const tasks = [];
        if (
          !state.conversationsLoaded ||
          !state.inboxSignature ||
          signature !== state.inboxSignature ||
          stale
        ) {
          tasks.push(loadConversations());
        }

        if (
          !state.friendsLoaded ||
          (friendSignature && friendSignature !== state.friendSignature)
        ) {
          tasks.push(loadFriends({ notify: true }));
        }

        if (tasks.length) await Promise.allSettled(tasks);

        const storyInterval = state.activeId ? 120000 : 90000;
        if (
          document.visibilityState !== "hidden" &&
          state.me === session &&
          Date.now() - Number(state.lastStoryRefreshAt || 0) > storyInterval
        ) {
          loadStories().catch(() => {});
        }
      } catch (error) {
        if (state.me === session && !controller.signal?.aborted) {
          state.globalPollFailures = Math.min(5, state.globalPollFailures + 1);
          window.dispatchEvent(new Event("silknex:connection"));
        }
      } finally {
        if (state.globalPollController === controller) {
          state.globalPollController = null;
          scheduleGlobalPoll();
        }
      }
    }, delay);
  }

  function appIsForeground() {
    if (!state.me || navigator.onLine === false) return false;
    if (document.visibilityState !== "visible") return false;
    if (typeof document.hasFocus === "function" && !document.hasFocus()) return false;
    return true;
  }

  async function sendPresenceState(active, { keepalive = false, force = false } = {}) {
    if (!state.me) return;
    const shouldBeActive = Boolean(active && appIsForeground());
    const now = Date.now();
    const session = state.me;

    // Serialize renewals and retain the latest desired state. Forced blur/focus
    // events must not race each other and leave an old "online" write last.
    if (state.presenceInFlight) {
      state.presencePending = { active: shouldBeActive, keepalive, session };
      return state.presenceInFlight;
    }

    if (
      !force &&
      state.presenceActive === shouldBeActive &&
      now - Number(state.presenceLastSentAt || 0) < (shouldBeActive ? 6500 : 15000)
    ) {
      return;
    }

    const request = api("presence", {
      method: "POST",
      body: { active: shouldBeActive },
      keepalive,
      timeoutMs: keepalive ? 2500 : 5000,
      showLoader: false,
    }).then(() => {
      if (state.me !== session) return;
      state.presenceActive = shouldBeActive;
      state.presenceLastSentAt = Date.now();
    }).catch(() => {}).finally(() => {
      if (state.presenceInFlight !== request) return;
      state.presenceInFlight = null;
      const next = state.presencePending;
      state.presencePending = null;
      if (next && next.session === state.me) {
        sendPresenceState(next.active, { keepalive: next.keepalive }).catch(() => {});
      }
    });

    state.presenceInFlight = request;
    return request;
  }

  function schedulePresenceHeartbeat({ immediate = false } = {}) {
    clearTimeout(state.presenceTimer);
    state.presenceTimer = null;
    if (!state.me) return;

    if (!appIsForeground()) {
      sendPresenceState(false, { keepalive: true }).catch(() => {});
      return;
    }

    if (
      immediate ||
      !state.presenceActive ||
      Date.now() - Number(state.presenceLastSentAt || 0) >= 6500
    ) {
      sendPresenceState(true, { force: immediate }).catch(() => {});
    }

    // The server lease lasts 18 seconds. Renew comfortably before expiration
    // while the app is visible/focused, then stop completely in background.
    state.presenceTimer = setTimeout(() => {
      schedulePresenceHeartbeat();
    }, 8000);
  }

  function renderTypingIndicator() {
    const indicator = $("#typingIndicator");
    const label = $("#typingLabel");
    if (!indicator || !label) return;

    const users = Array.isArray(state.typingUsers) ? state.typingUsers : [];
    if (!state.activeId || !users.length) {
      indicator.classList.add("hidden");
      label.textContent = "";
      return;
    }

    const names = users.slice(0, 2).map((user) => user.display_name || user.username || "Someone");
    label.textContent = users.length === 1
      ? `${names[0]} is typing`
      : users.length === 2
        ? `${names[0]} and ${names[1]} are typing`
        : `${names[0]}, ${names[1]} and others are typing`;
    indicator.classList.remove("hidden");
  }

  async function sendTypingState(isTyping, conversationId = state.activeId) {
    const cid = Number(conversationId || 0);
    if (!state.me || !cid) return;
    if (isTyping && (
      document.visibilityState !== "visible" ||
      (typeof document.hasFocus === "function" && !document.hasFocus())
    )) return;
    if (isTyping && Date.now() - state.typingLastSentAt < 1800 && state.typingConversationId === cid) {
      return;
    }

    if (isTyping) {
      state.typingLastSentAt = Date.now();
      state.typingConversationId = cid;
    } else if (state.typingConversationId === cid) {
      state.typingConversationId = 0;
      state.typingLastSentAt = 0;
    }

    try {
      await api("typing", {
        method: "POST",
        body: { conversation_id: cid, typing: Boolean(isTyping) },
        keepalive: !isTyping,
        timeoutMs: 8000,
      });
    } catch {}
  }

  function scheduleTypingFromComposer() {
    clearTimeout(state.typingStopTimer);
    const input = $("#messageInput");
    const cid = Number(state.activeId || 0);
    const active = Boolean(
      cid &&
      state.activeConversation?.can_message !== false &&
      input?.value?.trim()
    );

    if (!active) {
      if (state.typingConversationId) {
        sendTypingState(false, state.typingConversationId);
      }
      return;
    }

    sendTypingState(true, cid);
    state.typingStopTimer = setTimeout(() => {
      state.typingStopTimer = null;
      sendTypingState(false, cid);
    }, 2600);
  }

  function updateComposer() {
    const input = $("#messageInput");
    if (!input) return;

    input.rows = 1;
    input.style.height = "auto";

    const styles = getComputedStyle(input);
    const lineHeight = Number.parseFloat(styles.lineHeight) || 22;
    const padding =
      (Number.parseFloat(styles.paddingTop) || 0) +
      (Number.parseFloat(styles.paddingBottom) || 0);
    const border =
      (Number.parseFloat(styles.borderTopWidth) || 0) +
      (Number.parseFloat(styles.borderBottomWidth) || 0);
    const maxHeight = Math.ceil((lineHeight * 6) + padding + border);
    const nextHeight = Math.min(maxHeight, Math.max(lineHeight + padding + border, input.scrollHeight));

    input.style.height = `${nextHeight}px`;
    input.style.overflowY = input.scrollHeight > maxHeight ? "auto" : "hidden";

    const composer = $("#messageForm");
    const hasText = input.value.trim().length > 0;
    const hasAttachment = Boolean(state.pendingAttachment);
    composer?.classList.toggle("has-message-text", hasText);
    composer?.classList.toggle("has-attachment", hasAttachment);
    composer?.classList.toggle("has-sendable", hasText || hasAttachment);

    const sendButton = $("#sendBtn");
    if (sendButton) {
      const conversationLocked =
        Boolean(state.activeConversation) &&
        state.activeConversation.can_message === false;
      sendButton.disabled =
        state.attachmentSendBusy ||
        !state.activeId ||
        conversationLocked ||
        (!hasText && !hasAttachment);
    }
  }

  function draftStorageKey(conversationId = state.activeId) {
    const userId = Number(state.me?.id || 0);
    const chatId = Number(conversationId || 0);
    return userId && chatId ? `silknex:draft:${userId}:${chatId}` : "";
  }

  function legacyDraftStorageKey(conversationId = state.activeId) {
    const userId = Number(state.me?.id || 0);
    const chatId = Number(conversationId || 0);
    return userId && chatId ? `neochat:draft:${userId}:${chatId}` : "";
  }

  function storeDraftValue(conversationId, value) {
    const key = draftStorageKey(conversationId);
    const legacyKey = legacyDraftStorageKey(conversationId);
    if (!key) return;

    const next = String(value || "").slice(0, 4000);

    try {
      if (next.trim()) window.SilknexStorage.setItem(key, next);
      else window.SilknexStorage.removeItem(key);

      // v51 and older used a legacy session-scoped NeoChat key. Remove both
      // legacy locations only after the new SilkNex key has been handled.
      if (legacyKey) {
        window.SilknexStorage.removeItem(legacyKey);
        sessionStorage.removeItem(legacyKey);
      }
      sessionStorage.removeItem(key);
      return;
    } catch {}

    // Privacy/storage-restricted browsers may deny persistent storage. Keeping
    // a session fallback is better than losing a draft entirely.
    try {
      if (next.trim()) sessionStorage.setItem(key, next);
      else sessionStorage.removeItem(key);
    } catch {}
  }

  function readDraftValue(conversationId) {
    const key = draftStorageKey(conversationId);
    const legacyKey = legacyDraftStorageKey(conversationId);
    if (!key) return "";

    try {
      const persistent = window.SilknexStorage.getItem(key);
      if (persistent !== null) return persistent;

      const legacy =
        (legacyKey ? window.SilknexStorage.getItem(legacyKey) : "") ||
        sessionStorage.getItem(key) ||
        (legacyKey ? sessionStorage.getItem(legacyKey) : "") ||
        "";

      if (legacy) {
        try {
          window.SilknexStorage.setItem(key, legacy);
          sessionStorage.removeItem(key);
          if (legacyKey) {
            window.SilknexStorage.removeItem(legacyKey);
            sessionStorage.removeItem(legacyKey);
          }
        } catch {}
      }
      return legacy;
    } catch {
      try {
        return (
          sessionStorage.getItem(key) ||
          (legacyKey ? sessionStorage.getItem(legacyKey) : "") ||
          ""
        );
      } catch {
        return "";
      }
    }
  }

  function persistDraft(conversationId = state.activeId) {
    const input = $("#messageInput");
    if (!input) return;
    storeDraftValue(conversationId, input.value);
  }

  function scheduleDraftSave() {
    clearTimeout(state.draftSaveTimer);
    state.draftSaveTimer = setTimeout(() => {
      state.draftSaveTimer = null;
      persistDraft();
    }, 180);
  }

  function restoreDraft(conversationId = state.activeId) {
    const key = draftStorageKey(conversationId);
    const input = $("#messageInput");
    if (!key || !input) return;

    input.value = readDraftValue(conversationId);
    updateComposer();
  }

  function clearDraft(conversationId = state.activeId) {
    storeDraftValue(conversationId, "");
  }

  async function sendPreparedMessage({
    conversationId = state.activeId,
    body = "",
    uploadToken = "",
    stickerId = 0,
    externalGif = null,
    optimisticMedia = null,
    durationMs = 0,
    replyToId = null,
  } = {}) {
    conversationId = Number(conversationId || 0);
    if (!conversationId || !state.me) return false;
    const senderId = Number(state.me.id);
    const sessionEpoch = Number(state.sessionEpoch || 0);
    const sameSession = () => Number(state.me?.id) === senderId && Number(state.sessionEpoch || 0) === sessionEpoch;
    if (state.activeId === conversationId && state.hasNewerHistory) {
      try { await loadMessages({ latest: true }); }
      catch (error) { if (sameSession()) toast(error.message); return false; }
      if (state.activeId !== conversationId || !sameSession()) return false;
    }
    const externalGifUrl = String(externalGif?.url || "");
    const key = [
      conversationId,
      replyToId || 0,
      body,
      uploadToken || "",
      stickerId || 0,
      externalGifUrl,
      durationMs || 0,
    ].join("|");

    // Failed sends keep their nonce so an uncertain network response can be
    // retried idempotently. Store a queue per payload rather than one nonce:
    // two intentionally identical rapid messages must never collapse into one.
    const retryQueue = state.retryNonces.get(key);
    let nonce = Array.isArray(retryQueue) && retryQueue.length
      ? String(retryQueue.shift() || "")
      : "";
    if (Array.isArray(retryQueue) && retryQueue.length) {
      state.retryNonces.set(key, retryQueue);
    } else {
      state.retryNonces.delete(key);
    }
    if (!nonce) nonce = makeClientNonce();

    let optimisticId = 0;
    const shouldOptimisticallyRender = Boolean(
      state.me &&
      state.activeId === conversationId &&
      (body || optimisticMedia)
    );

    if (shouldOptimisticallyRender) {
      optimisticId = -Math.abs(
        (Date.now() * 1000) + Math.floor(Math.random() * 1000)
      );

      const replySource =
        replyToId && state.replyTo?.id === replyToId
          ? state.replyTo
          : null;

      state.messages.set(optimisticId, {
        id: optimisticId,
        conversation_id: conversationId,
        sender_id: state.me.id,
        sender_username: state.me.username,
        sender_display_name: state.me.display_name,
        sender_accent: state.me.accent,
        sender_avatar_url: state.me.avatar_url || "",
        sender_avatar_style: state.me.avatar_style || {},
        sender_role: state.me.role || "member",
        body: localKidFilter(body),
        e2ee_meta: { text: body, media: optimisticMedia?.e2ee_media || null },
        message_type: optimisticMedia?.message_type || "text",
        attachment_url: optimisticMedia?.attachment_url || "",
        attachment_mime: optimisticMedia?.attachment_mime || "",
        attachment_name: optimisticMedia?.attachment_name || "",
        attachment_size: Number(optimisticMedia?.attachment_size || 0),
        duration_ms: Number(durationMs || optimisticMedia?.duration_ms || 0),
        created_at: Math.floor(Date.now() / 1000),
        updated_at: Date.now(),
        edited_at: null,
        deleted_at: null,
        expires_at: null,
        pending: true,
        reactions: [],
        reply: replySource
          ? {
              id: replySource.id,
              sender_display_name: replySource.sender_display_name,
              body: replySource.body || (
                replySource.message_type === "sticker" ? "Sticker" : "Attachment"
              ),
            }
          : null,
      });

      rebuildMessages();
      const optimisticBox = $("#messages");
      optimisticBox.scrollTop = optimisticBox.scrollHeight;
      updateScrollNewestButton();
    }

    const releaseOptimisticUrl = () => {
      const url = String(optimisticMedia?.revoke_url || "");
      if (!url) return;
      try { URL.revokeObjectURL(url); } catch {}
    };

    // Keep network commits ordered per conversation while still rendering
    // every message optimistically right away. Without this, two very fast
    // taps can reach PHP in the opposite order on HTTP/2/mobile networks and
    // appear swapped after the server assigns message IDs.
    const previousTail =
      state.sendQueueTails.get(conversationId) || Promise.resolve();
    let releaseQueue = () => {};
    const queueDone = new Promise((resolve) => {
      releaseQueue = resolve;
    });
    const queueTail = previousTail.catch(() => {}).then(() => queueDone);
    state.sendQueueTails.set(conversationId, queueTail);

    setSyncStatus("", "Sending…");
    await previousTail.catch(() => {});

    try {
      if (!sameSession()) { releaseOptimisticUrl(); return false; }
      const securePayload = {
        text: String(body || ""),
        media: optimisticMedia?.e2ee_media || null,
      };
      if (uploadToken && !securePayload.media?.key) {
        throw new Error("Attachment encryption key is missing. Attach or record the file again before sending.");
      }
      const sendEncrypted = async () => {
        const schoolFlags = await window.SilknexCommunity?.prepareText?.(body) || [];
        if (!sameSession()) throw new Error("Sign-in session changed.");
        // Text is protected by server-side AES-GCM at rest. Keep the existing
        // device envelope for encrypted media and legacy message compatibility.
        const mediaMessage = Boolean(uploadToken || stickerId || externalGif);
        const e2eePayload = mediaMessage
          ? await encryptMessagePayload(conversationId, nonce, securePayload)
          : "";
        if (!sameSession()) throw new Error("Sign-in session changed.");
        return api("send", {
          method: "POST",
          body: {
            conversation_id: conversationId,
            body: mediaMessage ? "" : body,
            e2ee_payload: e2eePayload,
            school_flags: schoolFlags,
            reply_to_id: replyToId,
            client_nonce: nonce,
            upload_token: uploadToken || undefined,
            sticker_id: Number(stickerId || 0) || undefined,
            external_gif: externalGif || undefined,
            duration_ms: durationMs || 0,
          },
        });
      };

      let data;
      try {
        data = await sendEncrypted();
      } catch (sendError) {
        if (!sameSession()) throw sendError;
        const secureStateChanged =
          Number(sendError?.status || 0) === 409 &&
          /(?:register this device|encryption key changed|missing a participant device|non-participant device)/i
            .test(String(sendError?.message || ""));

        if (!secureStateChanged) throw sendError;

        // Device lists can change between encryption and commit (new login,
        // revoked device, or a refreshed local identity). Re-register this
        // browser, discard only key/device caches, rebuild the envelope, and
        // retry once with the same idempotency nonce. Media object URLs stay
        // intact, and the nonce prevents duplicate messages.
        state.e2eeRegisterPromise = null;
        window.SilknexE2EE?.clearDeviceKeyCache?.();
        await ensureE2EERegistration();
        data = await sendEncrypted();
      }
      if (!sameSession()) { releaseOptimisticUrl(); return false; }
      data.message = await decryptIncomingMessage(data.message);
      if (!sameSession()) { releaseOptimisticUrl(); return false; }

      // A successful request consumes its retry nonce. Nothing is added back
      // to the retry queue here.

      if (optimisticId && state.activeId === conversationId) {
        state.messages.delete(optimisticId);
      }

      if (state.activeId === conversationId) {
        state.messages.set(data.message.id, data.message);
        updateCursorFromMessage(data.message);
        state.changeSeq = Math.max(
          state.changeSeq,
          Number(data.change_seq || 0)
        );
        state.lastReadAckId = Math.max(
          state.lastReadAckId,
          Number(data.message.id || 0)
        );
        state.deliveryAckByConversation.set(
          conversationId,
          Math.max(
            state.deliveryAckByConversation.get(conversationId) || 0,
            Number(data.message.id || 0)
          )
        );
        if (data.receipt) state.receipt = data.receipt;
        rebuildMessages();

        const box = $("#messages");
        box.scrollTop = box.scrollHeight;
        updateScrollNewestButton();
      }

      releaseOptimisticUrl();
      state.lastRealtimeActivityAt = Date.now();
      broadcastSilkNex({
        type: "conversation-changed",
        conversation_id: conversationId,
      });
      loadConversations().catch(() => {});
      flushPushQueue();

      if (state.activeId === conversationId) {
        // Multiple text sends may be in flight at once. Do not flash "Sent"
        // while an earlier/later message is still waiting for the network.
        const otherTextSends = Math.max(
          0,
          Number(state.textSendsInFlightByConversation.get(conversationId) || 0) - 1
        );
        setSyncStatus(
          "",
          otherTextSends > 0
            ? "Sending…"
            : (data.created === false ? "Delivered" : "Sent")
        );
      }
      return true;
    } catch (error) {
      // Keep this exact nonce for a later retry. Queuing avoids collisions
      // when several identical messages fail independently.
      if (!sameSession()) { releaseOptimisticUrl(); return false; }
      const failedQueue = state.retryNonces.get(key);
      const nextRetryQueue = Array.isArray(failedQueue) ? failedQueue : [];
      if (!nextRetryQueue.includes(nonce)) nextRetryQueue.push(nonce);
      state.retryNonces.set(key, nextRetryQueue.slice(-6));
      if (state.retryNonces.size > 48) {
        const oldestKey = state.retryNonces.keys().next().value;
        if (oldestKey && oldestKey !== key) state.retryNonces.delete(oldestKey);
      }

      if (optimisticId && state.activeId === conversationId) {
        state.messages.delete(optimisticId);
        rebuildMessages();
      }

      releaseOptimisticUrl();
      toast(error.message);
      if (state.activeId === conversationId) {
        setSyncStatus("error", navigator.onLine ? "Send failed" : "Offline");
      }
      return false;
    } finally {
      releaseQueue();
      if (state.sendQueueTails.get(conversationId) === queueTail) {
        queueTail.then(() => {
          if (state.sendQueueTails.get(conversationId) === queueTail) {
            state.sendQueueTails.delete(conversationId);
          }
        });
      }
    }
  }

  function localDateTimeValue(date) {
    const pad = (value) => String(value).padStart(2, "0");
    return [
      date.getFullYear(),
      "-",
      pad(date.getMonth() + 1),
      "-",
      pad(date.getDate()),
      "T",
      pad(date.getHours()),
      ":",
      pad(date.getMinutes()),
    ].join("");
  }

  function openScheduleMessage() {
    if (!state.activeId || !state.activeConversation?.can_message) return;

    const body = $("#messageInput").value.trim();
    if (!body) {
      toast("Type a message first, then choose Send later.");
      return;
    }
    if (state.pendingAttachment) {
      toast("Send-later currently supports text messages.");
      return;
    }

    const now = new Date();
    const earliest = new Date(now.getTime() + 60 * 1000);
    const suggested = new Date(now.getTime() + 60 * 60 * 1000);
    suggested.setSeconds(0, 0);

    const input = $("#scheduleMessageAt");
    input.min = localDateTimeValue(earliest);
    input.value = localDateTimeValue(suggested);
    $("#scheduleMessagePreview").textContent =
      body.length > 180 ? `${body.slice(0, 180)}…` : body;
    $("#scheduledMessageList").classList.add("hidden");
    openModal("#scheduleMessageModal");
  }

  async function confirmScheduleMessage() {
    if (!state.activeId) return;
    const body = $("#messageInput").value.trim();
    const scheduledAtMs = new Date($("#scheduleMessageAt").value).getTime();

    if (!body || !Number.isFinite(scheduledAtMs)) {
      toast("Choose a message and time.");
      return;
    }

    const button = $("#confirmScheduleBtn");
    if (button.disabled) return;
    const conversationId = state.activeId;
    const replyId = state.replyTo?.id;
    const userId = Number(state.me?.id);
    const epoch = Number(state.sessionEpoch || 0);
    const sameSession = () => Number(state.me?.id) === userId && Number(state.sessionEpoch || 0) === epoch;
    button.disabled = true;
    try {
      const nonce = makeClientNonce();
      const e2eePayload = await encryptMessagePayload(
        conversationId,
        nonce,
        { text: body, media: null }
      );
      if (!sameSession()) return;
      await api("schedule_message", {
        method: "POST",
        body: {
          conversation_id: conversationId,
          body: "",
          e2ee_payload: e2eePayload,
          reply_to_id: replyId || undefined,
          scheduled_at: Math.floor(scheduledAtMs / 1000),
        },
      });

      if (!sameSession() || state.activeId !== conversationId) return;
      if ($("#messageInput").value.trim() === body) $("#messageInput").value = "";
      updateComposer();
      cancelReply();
      closeModal();
      toast("Message scheduled.");
    } catch (error) {
      if (sameSession()) toast(error.message);
    } finally {
      button.disabled = false;
    }
  }

  async function loadScheduledMessages() {
    if (!state.activeId) return;
    const conversationId = state.activeId;
    const userId = Number(state.me?.id);
    const epoch = Number(state.sessionEpoch || 0);
    const request = state.scheduledRequestId = Number(state.scheduledRequestId || 0) + 1;
    const isCurrent = () => state.activeId === conversationId && Number(state.me?.id) === userId &&
      Number(state.sessionEpoch || 0) === epoch && state.scheduledRequestId === request;
    const list = $("#scheduledMessageList");
    list.classList.remove("hidden");
    list.replaceChildren();

    const loading = document.createElement("div");
    loading.className = "proposal-empty";
    loading.textContent = "Loading scheduled messages…";
    list.appendChild(loading);

    try {
      const data = await api("scheduled_messages", {}, {
        conversation_id: conversationId,
      });
      if (!isCurrent()) return;
      const scheduled = await mapWithConcurrency(
        data.scheduled || [], async (item) => {
          if (!item.e2ee_payload) return item;
          try {
            const payload = await window.SilknexE2EE.decryptEnvelope(
              item.e2ee_payload,
              item.conversation_id
            );
            return { ...item, body: localKidFilter(String(payload?.text || "")) };
          } catch {
            return { ...item, body: "🔒 Encrypted on another device" };
          }
        }
      );
      if (!isCurrent()) return;
      state.scheduledMessages = scheduled;
      list.replaceChildren();

      if (!state.scheduledMessages.length) {
        const empty = document.createElement("div");
        empty.className = "proposal-empty";
        empty.textContent = "No scheduled messages in this chat.";
        list.appendChild(empty);
        return;
      }

      for (const item of state.scheduledMessages) {
        const row = document.createElement("div");
        row.className = "scheduled-row";

        const copy = document.createElement("div");
        const body = document.createElement("strong");
        body.textContent = item.body;
        const when = document.createElement("small");
        when.textContent = new Date(item.scheduled_at * 1000).toLocaleString();
        copy.append(body, when);

        const cancel = document.createElement("button");
        cancel.type = "button";
        cancel.className = "danger-btn";
        cancel.textContent = "Cancel";
        cancel.addEventListener("click", async () => {
          if (!isCurrent()) return;
          cancel.disabled = true;
          try {
            await api("cancel_scheduled_message", {
              method: "POST",
              body: { scheduled_id: item.id },
            });
            if (!isCurrent()) return;
            await loadScheduledMessages();
            toast("Scheduled message cancelled.");
          } catch (error) {
            toast(error.message);
            cancel.disabled = false;
          }
        });

        row.append(copy, cancel);
        list.appendChild(row);
      }
    } catch (error) {
      if (!isCurrent()) return;
      list.replaceChildren();
      const failed = document.createElement("div");
      failed.className = "proposal-empty";
      failed.textContent = error.message;
      list.appendChild(failed);
    }
  }

  async function sendMessage(event) {
    event.preventDefault();

    const input = $("#messageInput");
    const body = input.value.trim();
    const attachment = state.pendingAttachment;

    if (!body && !attachment) return;
    if (!state.activeId || !state.activeConversation?.can_message) return;
    if (attachment && state.attachmentSendBusy) return;

    const conversationId = state.activeId;
    const senderId = Number(state.me?.id);
    const sessionEpoch = Number(state.sessionEpoch || 0);
    const sameSession = () => Number(state.me?.id) === senderId && Number(state.sessionEpoch || 0) === sessionEpoch;
    const reply = state.replyTo;
    const replyId = reply?.id || null;
    const textOnly = Boolean(body && !attachment);

    const optimisticMedia = attachment
      ? {
          message_type: attachment.media_type || "image",
          attachment_url:
            state.attachmentObjectUrl ||
            attachment.preview_url ||
            attachment.url ||
            "",
          attachment_mime: attachment.mime || "",
          attachment_name: attachment.name || "",
          attachment_size: Number(attachment.size || 0),
          duration_ms: Number(attachment.duration_ms || 0),
          e2ee_media: attachment.e2ee_media || null,
        }
      : null;

    // Text is the hot path. Clear the composer immediately and let the
    // idempotent request finish in the background so users can send another
    // message without waiting for network latency. Each send owns its nonce,
    // so fast consecutive sends cannot steal each other's retry identity.
    if (textOnly) {
      input.value = "";
      clearDraft(conversationId);
      updateComposer();
      state.textSendsInFlightByConversation.set(
        conversationId,
        Number(state.textSendsInFlightByConversation.get(conversationId) || 0) + 1
      );

      try { navigator.vibrate?.(8); } catch {}

      const sendPromise = sendPreparedMessage({
        conversationId,
        body,
        replyToId: replyId,
      });
      cancelReply();

      sendPromise.then((success) => {
        if (success || !sameSession()) return;

        // Never silently lose text after a network/server failure. If the user
        // switched chats while the request was in flight, restore it directly
        // into that chat's saved draft instead of touching the new composer.
        if (state.activeId !== conversationId) {
          const saved = readDraftValue(conversationId);
          const merged = !saved.trim()
            ? body
            : (saved.trim() === body ? saved : `${body}\n${saved}`);
          storeDraftValue(conversationId, merged);
          return;
        }

        const current = input.value;
        if (!current.trim()) {
          input.value = body;
        } else if (current.trim() !== body) {
          input.value = `${body}\n${current}`;
        }
        persistDraft(conversationId);
        updateComposer();
      }).finally(() => {
        if (!sameSession()) return;
        const remaining = Math.max(
          0,
          Number(state.textSendsInFlightByConversation.get(conversationId) || 0) - 1
        );
        if (remaining > 0) {
          state.textSendsInFlightByConversation.set(conversationId, remaining);
        } else {
          state.textSendsInFlightByConversation.delete(conversationId);
        }
      });

      sendTypingState(false, conversationId);
      input.focus({ preventScroll: true });
      return;
    }

    // Attachment upload tokens are single-use, so keep only this path locked
    // until the server confirms the message.
    const sendButton = $("#sendBtn");
    state.attachmentSendBusy = true;
    sendButton.disabled = true;

    const success = await sendPreparedMessage({
      conversationId,
      body,
      uploadToken: attachment?.token || "",
      durationMs: attachment?.duration_ms || 0,
      replyToId: replyId,
      optimisticMedia,
    });

    if (!sameSession()) return;
    if (success && state.activeId === conversationId) {
      sendTypingState(false, conversationId);
      if (input.value.trim() === body) {
        input.value = "";
        clearDraft(conversationId);
      }
      if (state.replyTo === reply) cancelReply();
      if (state.pendingAttachment === attachment) clearPendingAttachment();
      updateComposer();
    }

    state.attachmentSendBusy = false;
    // The user may have switched conversations while the upload-backed send
    // was being confirmed. Recompute the current composer's real state rather
    // than blindly enabling Send for whichever chat is now on screen.
    updateComposer();
    if (state.activeId === conversationId) {
      input.focus({ preventScroll: true });
    }
  }

  async function uploadFile(file, purpose, mediaHint = "", originalName = "") {
    const form = new FormData();
    form.append("purpose", purpose);

    if (mediaHint) {
      form.append("media_hint", mediaHint);
    }
    if (originalName) form.append("original_name", originalName);

    form.append("file", file, file.name || "upload");

    return api("upload", {
      method: "POST",
      body: form,
    });
  }

  function uploadFileWithProgress(file, purpose, mediaHint = "", onProgress = null, originalName = "") {
    const form = new FormData();
    form.append("purpose", purpose);
    if (mediaHint) form.append("media_hint", mediaHint);
    if (originalName) form.append("original_name", originalName);
    form.append("file", file, file.name || "upload");

    let request = null;
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      request = xhr;
      if (purpose === "message" || purpose === "message_e2ee") state.attachmentUploadXhr = xhr;

      xhr.open("POST", apiUrl("upload"), true);
      xhr.withCredentials = true;
      xhr.timeout = 300000;
      xhr.setRequestHeader("Accept", "application/json");
      if (state.csrf) xhr.setRequestHeader("X-CSRF-Token", state.csrf);

      xhr.upload.addEventListener("progress", (event) => {
        if (!event.lengthComputable || typeof onProgress !== "function") return;
        onProgress(Math.max(0, Math.min(1, event.loaded / Math.max(1, event.total))));
      });

      const finishWithError = (message, status = 0, code = "") => {
        const error = new Error(message);
        error.status = status;
        if (code) error.code = code;
        reject(error);
      };

      xhr.addEventListener("load", () => {
        let data = null;
        try {
          data = JSON.parse(xhr.responseText || "{}");
        } catch {
          finishWithError("SilkNex received an invalid server response.", xhr.status);
          return;
        }

        if (xhr.status < 200 || xhr.status >= 300 || data?.ok === false) {
          if (xhr.status === 401 && state.me) {
            showAuth("Your login ended. Sign in again.");
          }
          finishWithError(data?.error || "The upload failed.", xhr.status);
          return;
        }

        if (typeof onProgress === "function") onProgress(1);
        resolve(data);
      });

      xhr.addEventListener("error", () => {
        finishWithError(
          navigator.onLine
            ? "The upload lost its connection. Try again."
            : "You are offline.",
          0,
          "network"
        );
      });
      xhr.addEventListener("timeout", () => {
        finishWithError("The upload took too long. Try again.", 0, "timeout");
      });
      xhr.addEventListener("abort", () => {
        finishWithError("Upload cancelled.", 0, "aborted");
      });

      xhr.send(form);
    }).finally(() => {
      if ((purpose === "message" || purpose === "message_e2ee") && state.attachmentUploadXhr === request) {
        state.attachmentUploadXhr = null;
      }
    });
  }

  function messageMediaHint(file, preferred = "") {
    if (preferred) return preferred;
    const type = String(file?.type || "").toLowerCase();
    if (type === "image/gif") return "gif";
    if (type.startsWith("image/")) return "image";
    if (type.startsWith("video/")) return "video";
    if (type.startsWith("audio/")) return "audio";
    return "image";
  }

  async function secureUploadMessageFile(file, preferred = "", onProgress = null, isCurrent = () => true) {
    const userId = Number(state.me?.id);
    const epoch = Number(state.sessionEpoch || 0);
    const assertCurrent = () => {
      if (!userId || Number(state.me?.id) !== userId || Number(state.sessionEpoch || 0) !== epoch || !isCurrent()) {
        const error = new Error("Upload cancelled."); error.code = "aborted"; throw error;
      }
    };
    assertCurrent();
    await ensureE2EERegistration();
    assertCurrent();
    const mediaType = messageMediaHint(file, preferred);
    const encrypted = await window.SilknexE2EE.encryptFile(file);
    assertCurrent();
    const encryptedFile = fileFromBlob(
      encrypted.blob,
      `silknex-e2ee-${Date.now()}.bin`,
      { type: "application/octet-stream", lastModified: Date.now() }
    );

    const uploaded = typeof onProgress === "function"
      ? await uploadFileWithProgress(
          encryptedFile,
          "message_e2ee",
          mediaType,
          onProgress,
          "Encrypted attachment"
        )
      : await uploadFile(
          encryptedFile,
          "message_e2ee",
          mediaType,
          "Encrypted attachment"
        );

    return {
      uploaded,
      media: {
        ...encrypted.meta,
        type: mediaType,
      },
    };
  }

  async function optimizeVideoMedia(file) {
    if (!isFileLike(file) || !/^video\//i.test(file.type || "") || file.size < 10 * 1024 * 1024) {
      return file;
    }
    if (!window.MediaRecorder || typeof document.createElement("video").captureStream !== "function") {
      return file;
    }

    const sourceUrl = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.src = sourceUrl;
    video.preload = "metadata";
    video.playsInline = true;
    video.muted = true;

    try {
      await new Promise((resolve, reject) => {
        const onLoaded = () => resolve();
        const onError = () => reject(new Error("Could not prepare that video."));
        video.addEventListener("loadedmetadata", onLoaded, { once: true });
        video.addEventListener("error", onError, { once: true });
      });

      const duration = Number(video.duration || 0);
      if (!duration || !Number.isFinite(duration) || duration > 90) return file;

      const candidates = [
        "video/webm;codecs=vp9,opus",
        "video/webm;codecs=vp8,opus",
        "video/webm",
      ];
      const mimeType = candidates.find((item) => MediaRecorder.isTypeSupported?.(item));
      if (!mimeType) return file;

      // Preserve the source dimensions and lower only the bitrate. This avoids
      // the soft/blurred look of aggressive resolution downscaling.
      const pixels = Math.max(1, Number(video.videoWidth || 1280) * Number(video.videoHeight || 720));
      const bitrate = pixels >= 1920 * 1080 ? 5_000_000 : pixels >= 1280 * 720 ? 3_500_000 : 2_200_000;
      const stream = video.captureStream();
      const recorder = new MediaRecorder(stream, {
        mimeType,
        videoBitsPerSecond: bitrate,
        audioBitsPerSecond: 128_000,
      });
      const chunks = [];
      recorder.addEventListener("dataavailable", (event) => {
        if (event.data?.size) chunks.push(event.data);
      });

      const stopped = new Promise((resolve) => recorder.addEventListener("stop", resolve, { once: true }));
      video.currentTime = 0;
      recorder.start(1000);
      await video.play();

      await new Promise((resolve, reject) => {
        video.addEventListener("ended", resolve, { once: true });
        video.addEventListener("error", reject, { once: true });
      });
      if (recorder.state !== "inactive") recorder.stop();
      await stopped;
      stream.getTracks().forEach((track) => track.stop());

      const blob = new Blob(chunks, { type: mimeType });
      if (!blob.size || blob.size >= file.size * 0.88) return file;
      const baseName = String(file.name || "video").replace(/\.[^.]+$/, "").slice(0, 140) || "video";
      return fileFromBlob(blob, `${baseName}.webm`, {
        type: mimeType.split(";")[0],
        lastModified: file.lastModified || Date.now(),
      });
    } catch {
      return file;
    } finally {
      try { video.pause(); } catch {}
      video.removeAttribute("src");
      video.load?.();
      URL.revokeObjectURL(sourceUrl);
    }
  }


  async function optimizeMessageMedia(file) {
    if (!isFileLike(file)) return file;

    const type = String(file.type || "").toLowerCase();
    if (type.startsWith("video/")) return optimizeVideoMedia(file);

    // PNG/WebP can carry alpha. Never flatten those formats onto an opaque
    // canvas: transparent stickers/screenshots must remain truly transparent
    // after client-side size optimization.
    const compressibleImage = ["image/jpeg", "image/png", "image/webp"].includes(type);
    let mediaQuality = "balanced";
    try {
      const storedQuality = window.SilknexStorage.getItem("silknex:v62:media-quality");
      if (["saver", "balanced", "detail"].includes(storedQuality || "")) {
        mediaQuality = storedQuality;
      }
    } catch {}
    const compressionThreshold = mediaQuality === "saver"
      ? 420 * 1024
      : mediaQuality === "detail"
        ? 1400 * 1024
        : 900 * 1024;
    if (!compressibleImage || file.size < compressionThreshold) return file;

    let source = null;
    let decoded = null;
    let canvas = null;
    try {
      decoded = await window.SilknexMedia.decodeImage(file);
      source = decoded.source;
      const width = Number(source.width || source.naturalWidth || 0);
      const height = Number(source.height || source.naturalHeight || 0);
      if (!width || !height) return file;

      const info = callNetworkInfo();
      const cellular = info.type === "cellular";
      const deviceMemory = Number(navigator.deviceMemory || 0);
      const lowMemory = deviceMemory > 0 && deviceMemory <= 4;
      const maxDimension = mediaQuality === "saver"
        ? (cellular ? 1440 : 1920)
        : mediaQuality === "detail"
          ? (lowMemory ? 2560 : (cellular ? 3200 : 4096))
          : lowMemory
            ? (cellular ? 1600 : 2240)
            : (cellular ? 2240 : 3200);
      const scale = Math.min(1, maxDimension / Math.max(width, height));
      const targetWidth = Math.max(1, Math.round(width * scale));
      const targetHeight = Math.max(1, Math.round(height * scale));
      const outputType = "image/webp";
      const keepsAlpha = outputType === "image/webp";

      canvas = document.createElement("canvas");
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      const context = canvas.getContext("2d", { alpha: keepsAlpha });
      if (!context) return file;

      if (!keepsAlpha) {
        context.fillStyle = "#000";
        context.fillRect(0, 0, targetWidth, targetHeight);
      }
      context.drawImage(source, 0, 0, targetWidth, targetHeight);
      const quality = mediaQuality === "saver"
        ? (cellular ? 0.80 : 0.84)
        : mediaQuality === "detail"
          ? (cellular ? 0.92 : 0.94)
          : lowMemory
            ? (cellular ? 0.84 : 0.88)
            : (cellular ? 0.87 : 0.91);
      const blob = await window.SilknexMedia.encodeCanvas(canvas, outputType, quality);

      const requiredSavings = mediaQuality === "detail" ? 0.97 : mediaQuality === "saver" ? 0.98 : 0.90;
      if (!blob || blob.size >= file.size * requiredSavings) return file;

      const baseName = String(file.name || "photo")
        .replace(/\.[^.]+$/, "")
        .slice(0, 140) || "photo";
      const extension = window.SilknexMedia.extension(blob.type);
      return fileFromBlob(blob, `${baseName}.${extension}`, {
        type: blob.type,
        lastModified: file.lastModified || Date.now(),
      });
    } catch {
      return file;
    } finally {
      try { decoded?.dispose(); } catch {}
      if (canvas) { canvas.width = 1; canvas.height = 1; }
    }
  }

  function clearPendingAttachment() {
    state.attachmentGeneration = Number(state.attachmentGeneration || 0) + 1;
    if (state.attachmentUploadXhr) {
      try { state.attachmentUploadXhr.abort(); } catch {}
      state.attachmentUploadXhr = null;
    }
    state.attachmentUploadBusy = false;
    state.pendingAttachment = null;

    if (state.attachmentObjectUrl) {
      URL.revokeObjectURL(state.attachmentObjectUrl);
      state.attachmentObjectUrl = "";
    }

    $("#attachmentPreview").classList.add("hidden");
    $("#attachmentPreview").removeAttribute("data-uploading");
    $("#attachmentThumb").replaceChildren();
    $("#attachmentName").textContent = "Attachment";
    $("#attachmentMeta").textContent = "Ready to send";
    $("#attachBtn").disabled = false;
    updateComposer();
  }

  function renderAttachmentUploadProgress(file, fraction = 0) {
    const preview = $("#attachmentPreview");
    const thumb = $("#attachmentThumb");
    const name = $("#attachmentName");
    const meta = $("#attachmentMeta");

    if (!state.attachmentObjectUrl) {
      try { state.attachmentObjectUrl = URL.createObjectURL(file); } catch {}
    }

    name.textContent = file.name || "Media";
    const percent = Math.max(0, Math.min(100, Math.round(Number(fraction || 0) * 100)));
    meta.textContent = fraction > 0
      ? `Uploading · ${percent}% · ${formatFileSize(file.size)}`
      : `Preparing · ${formatFileSize(file.size)}`;

    if (!thumb.childNodes.length && state.attachmentObjectUrl) {
      if (/^image\//i.test(file.type || "")) {
        const image = document.createElement("img");
        image.src = state.attachmentObjectUrl;
        image.alt = "";
        thumb.appendChild(image);
      } else if (/^video\//i.test(file.type || "")) {
        const video = document.createElement("video");
        video.src = state.attachmentObjectUrl;
        video.muted = true;
        video.playsInline = true;
        thumb.appendChild(video);
      }
    }

    preview.dataset.uploading = "true";
    preview.classList.remove("hidden");
  }

  function renderPendingAttachment(file, uploaded) {
    // A completed XHR is no longer cancellable. Preserve the preview object URL
    // when it already points at the optimized upload file to avoid a visible flash.
    state.attachmentUploadXhr = null;
    state.attachmentUploadBusy = false;
    state.pendingAttachment = {
      ...uploaded,
      duration_ms: 0,
    };

    const preview = $("#attachmentPreview");
    const thumb = $("#attachmentThumb");
    const name = $("#attachmentName");
    const meta = $("#attachmentMeta");

    name.textContent = uploaded.name || file.name || "Attachment";
    meta.textContent = `${uploaded.media_type.toUpperCase()} · ${formatFileSize(uploaded.size)}`;

    if (!state.attachmentObjectUrl) {
      state.attachmentObjectUrl = URL.createObjectURL(file);
    }

    thumb.replaceChildren();
    if (uploaded.media_type === "image" || uploaded.media_type === "gif") {
      const image = document.createElement("img");
      image.src = state.attachmentObjectUrl;
      image.alt = "";
      thumb.appendChild(image);
    } else if (
      uploaded.media_type === "video" ||
      uploaded.media_type === "video_note"
    ) {
      const video = document.createElement("video");
      video.src = state.attachmentObjectUrl;
      video.muted = true;
      video.playsInline = true;
      thumb.appendChild(video);
    } else {
      thumb.replaceChildren(iconNode("mic", "neo-icon media-thumb-icon"));
    }

    preview.removeAttribute("data-uploading");
    preview.classList.remove("hidden");
    $("#attachBtn").disabled = false;
    updateComposer();
  }

  async function handleAttachmentFile(file) {
    if (!file || state.attachmentUploadBusy || state.attachmentSendBusy) return;

    $("#attachmentMenu").classList.add("hidden");
    clearPendingAttachment();
    const generation = state.attachmentGeneration;
    const conversationId = state.activeId;
    const isCurrent = () => state.attachmentGeneration === generation && state.activeId === conversationId;

    const isVideo =
      /^video\//i.test(file.type || "") ||
      /\.mov$/i.test(file.name || "");
    if (isVideo && file.size > 40 * 1024 * 1024) {
      toast("That video is over 40 MB. Choose a shorter clip.");
      return;
    }

    state.attachmentUploadBusy = true;
    $("#attachBtn").disabled = true;

    let preparedFile = file;
    try {
      renderAttachmentUploadProgress(file, 0);
      preparedFile = await optimizeMessageMedia(file);
      if (!isCurrent()) return;

      if (preparedFile !== file) {
        if (state.attachmentObjectUrl) {
          URL.revokeObjectURL(state.attachmentObjectUrl);
          state.attachmentObjectUrl = "";
        }
        $("#attachmentThumb").replaceChildren();
        renderAttachmentUploadProgress(preparedFile, 0);
      }

      const secureUpload = await secureUploadMessageFile(
        preparedFile,
        "",
        (progress) => { if (isCurrent()) renderAttachmentUploadProgress(preparedFile, progress); },
        isCurrent
      );
      if (!isCurrent()) return;
      const uploaded = secureUpload.uploaded;

      renderPendingAttachment(preparedFile, uploaded);
      if (state.pendingAttachment) {
        state.pendingAttachment.e2ee_media = secureUpload.media;
      }
      toast(preparedFile !== file ? "Media compressed and ready." : "Media ready.");
      $("#messageInput").focus({ preventScroll: true });
    } catch (error) {
      if (!isCurrent()) return;
      const cancelled = error?.code === "aborted";
      clearPendingAttachment();
      if (!cancelled) toast(error?.message || "The upload failed.");
    } finally {
      if (isCurrent()) {
        state.attachmentUploadBusy = false;
        $("#attachBtn").disabled = false;
        updateComposer();
      }
    }
  }

  function setRecordingUi(mode, stream = null) {
    const active = Boolean(mode);
    const bar = $("#recordingBar");
    const preview = $("#videoNotePreview");

    bar.classList.toggle("hidden", !active);
    $("#voiceBtn").classList.toggle("recording", active);
    $("#voiceBtn").classList.toggle("video-recording", mode === "video_note");
    $("#voiceBtn").setAttribute("aria-pressed", active ? "true" : "false");

    if (!active) {
      preview.classList.add("hidden");
      preview.srcObject = null;
      $("#recordingTimer").textContent = "0:00";
      return;
    }

    $("#recordingLabel").textContent =
      mode === "video_note"
        ? "Recording video message…"
        : state.mobileRecordingTap
          ? "Recording voice… tap mic to send"
          : "Recording voice…";

    if (mode === "video_note" && stream) {
      preview.srcObject = stream;
      preview.classList.remove("hidden");
      preview.play().catch(() => {});
    } else {
      preview.classList.add("hidden");
      preview.srcObject = null;
    }
  }

  function updateRecordingTimer() {
    if (!state.voiceStartedAt || !state.recordingMode) return;

    const elapsed = Math.max(0, Date.now() - state.voiceStartedAt);
    const totalSeconds = Math.floor(elapsed / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = String(totalSeconds % 60).padStart(2, "0");
    $("#recordingTimer").textContent = `${minutes}:${seconds}`;

    if (state.recordingMode === "video_note" && elapsed >= 60000) {
      stopActiveRecording(false);
    }

    if (state.recordingMode === "audio" && elapsed >= 600000) {
      stopActiveRecording(false);
    }
  }

  function stopActiveRecording(cancel = false) {
    clearTimeout(state.recordTapTimer);
    clearTimeout(state.recordPressTimer);
    state.recordPressTimer = null;
    state.recordPointerDown = false;

    clearTimeout(state.recordStopTimer);
    state.recordStopTimer = null;

    if (!state.voiceRecorder || state.voiceRecorder.state !== "recording") {
      if (cancel) {
        state.cancelCurrentRecording = true;

        if (state.recordingStarting) {
          state.recordingGeneration += 1;
          state.recordingStarting = false;
          state.recordHoldStarted = false;
          state.mobileRecordingTap = false;
          setRecordingUi("");
        }
      }

      return;
    }

    state.cancelCurrentRecording = cancel;
    const recorder = state.voiceRecorder;

    const finish = () => {
      if (!state.voiceRecorder || recorder !== state.voiceRecorder) return;
      if (recorder.state !== "recording") return;

      // requestData() helps Chromium flush an in-progress chunk. The normal
      // stop event still produces the final chunk on Safari/iOS.
      if (!/mp4/i.test(recorder.mimeType || "")) {
        try { recorder.requestData?.(); } catch {}
      }

      // Give requestData a moment before stop; some mobile WebKit builds
      // otherwise dispatch stop before a useful blob reaches dataavailable.
      state.recordStopTimer = setTimeout(() => {
        state.recordStopTimer = null;
        if (recorder.state === "recording") {
          try { recorder.stop(); } catch {}
        }
      }, cancel ? 0 : 90);
    };

    if (cancel) {
      finish();
      return;
    }

    // Very fast taps used to create a zero-byte recording and report
    // "too short". Keep capture alive long enough for mobile encoders to
    // initialize and emit their first chunk.
    const elapsed = Math.max(0, Date.now() - Number(state.voiceStartedAt || 0));
    const minimumCaptureMs = 700;

    if (elapsed < minimumCaptureMs) {
      state.recordStopTimer = setTimeout(finish, minimumCaptureMs - elapsed);
      return;
    }

    finish();
  }

  function cancelActiveRecording() {
    stopActiveRecording(true);
  }

  async function startMediaRecording(mode) {
    if (
      state.voiceRecorder?.state === "recording" ||
      state.recordingStarting
    ) {
      return false;
    }

    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
      toast("Recording is not supported in this browser.");
      return false;
    }

    const isVideo = mode === "video_note";
    const conversationId = state.activeId;
    const replyToId = state.replyTo?.id || null;
    const generation = ++state.recordingGeneration;
    const recordingSession = state.me;
    let acquiredStream = null;
    state.recordingStarting = true;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: isVideo
          ? {
              facingMode: "user",
              width: { ideal: 640 },
              height: { ideal: 640 },
            }
          : false,
      });
      acquiredStream = stream;

      if (
        generation !== state.recordingGeneration ||
        state.activeId !== conversationId ||
        state.me !== recordingSession
      ) {
        stream.getTracks().forEach((track) => track.stop());

        if (generation === state.recordingGeneration) {
          state.recordingStarting = false;
        }

        return false;
      }

      const candidates = isVideo
        ? [
            "video/webm;codecs=vp9,opus",
            "video/webm;codecs=vp8,opus",
            "video/mp4",
            "video/webm",
          ]
        : [
            "audio/mp4;codecs=mp4a.40.2",
            "audio/mp4",
            "audio/webm;codecs=opus",
            "audio/ogg;codecs=opus",
            "audio/webm",
          ];

      const supportsType = (type) => {
        try {
          return Boolean(MediaRecorder.isTypeSupported?.(type));
        } catch {
          return false;
        }
      };

      const mimeType = candidates.find(supportsType) || "";
      let recorder;

      try {
        recorder = mimeType
          ? new MediaRecorder(stream, {
              mimeType,
              ...(isVideo
                ? { videoBitsPerSecond: 900000, audioBitsPerSecond: 64000 }
                : { audioBitsPerSecond: 48000 }),
            })
          : new MediaRecorder(stream);
      } catch {
        try {
          recorder = mimeType
            ? new MediaRecorder(stream, { mimeType })
            : new MediaRecorder(stream);
        } catch {
          recorder = new MediaRecorder(stream);
        }
      }

      state.recordingStarting = false;
      state.voiceStream = stream;
      state.voiceRecorder = recorder;
      state.voiceChunks = [];
      state.voiceStartedAt = Date.now();
      state.recordingMode = mode;
      state.cancelCurrentRecording = false;
      const recordingChunks = [];
      const recordingStartedAt = Date.now();
      let recordingFailed = false;

      recorder.addEventListener("dataavailable", (event) => {
        if (event.data?.size) recordingChunks.push(event.data);
      });

      recorder.addEventListener("error", () => {
        recordingFailed = true;
        if (recorder.state === "recording") {
          try { recorder.stop(); } catch {}
        }
      });

      recorder.addEventListener("stop", async () => {
        stream.getTracks().forEach((track) => track.stop());
        if (state.voiceRecorder !== recorder) return;
        clearInterval(state.recordingTimer);
        state.recordingTimer = null;
        clearTimeout(state.recordStopTimer);
        state.recordStopTimer = null;

        const duration = Math.max(250, Date.now() - recordingStartedAt);
        const type =
          recorder.mimeType ||
          recordingChunks.find((chunk) => chunk.type)?.type ||
          mimeType ||
          (isVideo ? "video/webm" : "audio/webm");
        const extension = type.includes("mp4")
          ? (isVideo ? "mp4" : "m4a")
          : type.includes("ogg") ? "ogg" : "webm";

        const chunks = recordingChunks;
        const cancelled = state.cancelCurrentRecording || state.me !== recordingSession;

        stream.getTracks().forEach((track) => track.stop());

        state.voiceStream = null;
        state.voiceRecorder = null;
        state.voiceChunks = [];
        state.voiceStartedAt = 0;
        state.recordingMode = "";
        state.cancelCurrentRecording = false;
        state.recordHoldStarted = false;
        state.mobileRecordingTap = false;
        setRecordingUi("");

        if (cancelled || recordingFailed) {
          toast(recordingFailed ? "Microphone recording failed. Please try again." : "Recording cancelled.");
          return;
        }

        const blob = new Blob(chunks, { type });

        if (blob.size === 0) {
          toast(
            isVideo
              ? "No video data was captured. Try again."
              : "No audio data was captured. Check microphone permission and try again."
          );
          return;
        }

        // A valid mobile voice note can be very small (especially AAC/Opus).
        // Do not reject it based on an arbitrary byte threshold.
        if (!isVideo && duration < 500) {
          toast("Keep recording for a moment, then tap the mic again to send.");
          return;
        }

        const file = fileFromBlob(
          blob,
          `${isVideo ? "video-note" : "voice"}-${Date.now()}.${extension}`,
          { type }
        );

        toast(isVideo ? "Sending video message…" : "Sending voice message…");

        const submitRecording = async () => {
        if (state.me !== recordingSession || state.activeId !== conversationId) return;
        const retryBar = document.getElementById("voiceRecordingRetry");
        retryBar?.remove();
        try {
          const secureUpload = await secureUploadMessageFile(
            file,
            isVideo ? "video_note" : "audio"
          );
          const uploaded = secureUpload.uploaded;
          if (state.me !== recordingSession) return;

          const optimisticUrl = URL.createObjectURL(blob);
          const sent = await sendPreparedMessage({
            conversationId,
            body: "",
            uploadToken: uploaded.token,
            durationMs: duration,
            replyToId,
            optimisticMedia: {
              message_type: isVideo ? "video_note" : "audio",
              attachment_url: optimisticUrl,
              attachment_name: file.name,
              e2ee_media: secureUpload.media,
              revoke_url: optimisticUrl,
            },
          });

          if (state.me !== recordingSession) return;
          if (sent) {
            if (
              state.activeId === conversationId &&
              Number(state.replyTo?.id || 0) === Number(replyToId || 0)
            ) {
              cancelReply();
            }
          } else if (state.activeId === conversationId) {
            renderPendingAttachment(file, uploaded);
            state.pendingAttachment.duration_ms = duration;
            state.pendingAttachment.e2ee_media = secureUpload.media;
            toast(
              isVideo
                ? "Video message is ready to retry."
                : "Voice message is ready to retry."
            );
          } else {
            // Never place media captured for one conversation into another
            // conversation's composer after a slow upload/network handoff.
            toast(
              isVideo
                ? "Video message could not send. Return to the chat and try again."
                : "Voice message could not send. Return to the chat and try again."
            );
          }
        } catch (error) {
          toast(error.message);
          if (state.me === recordingSession && state.activeId === conversationId) {
            const bar = document.createElement("div");
            bar.id = "voiceRecordingRetry";
            bar.className = "voice-recording-retry";
            const label = document.createElement("span");
            label.textContent = "Recording kept on this device. Upload failed.";
            const retry = document.createElement("button");
            retry.type = "button";
            retry.className = "secondary-btn";
            retry.textContent = "Retry upload";
            retry.addEventListener("click", submitRecording, { once: true });
            const discard = document.createElement("button");
            discard.type = "button";
            discard.className = "secondary-btn";
            discard.textContent = "Discard";
            discard.addEventListener("click", () => bar.remove(), { once: true });
            bar.append(label, retry, discard);
            $("#messageForm").before(bar);
          }
        }
        };
        await submitRecording();
      });

      // Use periodic chunks where browsers handle them well so a recorder
      // always has recoverable audio before stop. Safari/iOS gets the simpler
      // no-timeslice path because its MediaRecorder implementation is more
      // reliable when it owns the final flush.
      const isAppleWebKit =
        /iPad|iPhone|iPod/i.test(navigator.userAgent) ||
        (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1) ||
        (/AppleWebKit/i.test(navigator.userAgent) &&
        !/(Chrome|Edg|OPR|Firefox)/i.test(navigator.userAgent));

      if (isAppleWebKit || /mp4/i.test(recorder.mimeType || mimeType)) recorder.start();
      else recorder.start(isVideo ? 1000 : 500);

      setRecordingUi(mode, stream);

      clearInterval(state.recordingTimer);
      state.recordingTimer = setInterval(updateRecordingTimer, 250);
      updateRecordingTimer();

      // If the user released while the permission prompt was still open,
      // finish the hold-to-record voice as soon as capture actually starts.
      if (!isVideo && !state.recordPointerDown && !state.mobileRecordingTap) {
        setTimeout(() => stopActiveRecording(false), 0);
      }

      return true;
    } catch (error) {
      acquiredStream?.getTracks().forEach((track) => track.stop());
      if (generation === state.recordingGeneration) {
        state.voiceRecorder = null;
        state.voiceStream = null;
        state.recordingMode = "";
        state.recordingStarting = false;
        state.recordHoldStarted = false;
        state.mobileRecordingTap = false;
        setRecordingUi("");
      }

      toast(
        error?.name === "NotAllowedError"
          ? (isVideo
              ? "Camera or microphone permission was not granted."
              : "Microphone permission was not granted.")
          : "SilkNex could not start recording."
      );

      return false;
    }
  }

  function usesTapToRecord(event) {
    if (event?.pointerType && event.pointerType !== "mouse") return true;
    return Boolean(window.matchMedia?.("(pointer: coarse)")?.matches);
  }

  function onRecordPointerDown(event) {
    if (!state.me || !state.activeId || state.recordingStarting) return;

    event.preventDefault();
    if (state.mobileRecordingTap && state.voiceRecorder?.state === "recording") {
      state.mobileRecordingTap = false;
      stopActiveRecording(false);
      return;
    }

    // Phones/tablets use tap-to-start, tap-to-send. This avoids the common
    // iOS permission-prompt bug where a held pointer is released before
    // getUserMedia resolves, producing a zero-length voice note.
    if (usesTapToRecord(event)) {
      if (state.voiceRecorder?.state === "recording") {
        state.mobileRecordingTap = false;
        stopActiveRecording(false);
      } else {
        state.mobileRecordingTap = true;
        startMediaRecording("audio");
      }
      return;
    }

    if (
      state.recordingMode === "video_note" &&
      state.voiceRecorder?.state === "recording"
    ) {
      stopActiveRecording(false);
      return;
    }

    if (state.voiceRecorder?.state === "recording") return;

    state.recordPointerDown = true;
    state.recordHoldStarted = false;

    try {
      event.currentTarget.setPointerCapture(event.pointerId);
    } catch {}

    clearTimeout(state.recordPressTimer);
    state.recordPressTimer = setTimeout(async () => {
      state.recordPressTimer = null;

      if (!state.recordPointerDown) return;

      state.recordHoldStarted = true;
      await startMediaRecording("audio");
    }, 170);
  }

  function onRecordPointerUp(event) {
    event.preventDefault();

    if (state.mobileRecordingTap || usesTapToRecord(event)) {
      return;
    }

    const hadPendingHold = Boolean(state.recordPressTimer);

    clearTimeout(state.recordPressTimer);
    state.recordPressTimer = null;
    state.recordPointerDown = false;

    if (state.recordHoldStarted) {
      stopActiveRecording(false);
      return;
    }

    if (!hadPendingHold || state.voiceRecorder?.state === "recording") {
      return;
    }

    const now = Date.now();

    if (now - state.lastRecordTapAt <= 340) {
      clearTimeout(state.recordTapTimer);
      state.lastRecordTapAt = 0;
      startMediaRecording("video_note");
    } else {
      state.lastRecordTapAt = now;
      const session = state.me;
      const conversationId = state.activeId;
      state.recordTapTimer = setTimeout(() => {
        if (state.me !== session || state.activeId !== conversationId || state.voiceRecorder?.state === "recording") return;
        state.mobileRecordingTap = true;
        startMediaRecording("audio");
      }, 350);
    }
  }

  function onRecordPointerCancel(event) {
    clearTimeout(state.recordPressTimer);
    state.recordPressTimer = null;

    if (usesTapToRecord(event)) {
      return;
    }

    state.recordPointerDown = false;

    if (state.recordHoldStarted) {
      stopActiveRecording(false);
    }
  }

  function beginReply(message) {
    state.replyTo = message;
    $("#replyName").textContent = message.sender_display_name;
    $("#replyText").textContent =
      message.body ||
      (message.message_type === "image" ? "Photo" :
        message.message_type === "gif" ? "GIF" :
        message.message_type === "sticker" ? "Sticker" :
        message.message_type === "video" ? "Video" :
        message.message_type === "audio" ? "Voice message" :
        message.message_type === "video_note" ? "Video message" : "Attachment");
    $("#replyBar").classList.remove("hidden");
    $("#messageInput").focus();
  }

  function cancelReply() {
    state.replyTo = null;
    $("#replyBar").classList.add("hidden");
  }

  function editMessage(message) {
    state.editingMessage = message;
    $("#editMessageInput").value = message.body;
    openModal("#editMessageModal");
  }

  async function saveEditedMessage() {
    const message = state.editingMessage;
    if (!message) return;

    const body = $("#editMessageInput").value.trim();
    if (!body) {
      toast("Message cannot be empty.");
      return;
    }

    const editingSession = state.me;
    const editingEpoch = state.sessionEpoch;
    const sameEditingSession = () => state.me === editingSession && state.sessionEpoch === editingEpoch;
    $("#saveEditBtn").disabled = true;

    try {
      const schoolFlags = await window.SilknexCommunity?.prepareText?.(body) || [];
      if (!sameEditingSession()) return;
      const nonce = makeClientNonce();
      const e2eePayload = "";
      if (!sameEditingSession()) return;
      const data = await api("edit", {
        method: "POST",
        body: {
          message_id: message.id,
          school_flags: schoolFlags,
          edit_nonce: nonce,
          body,
          e2ee_payload: e2eePayload,
        },
      });

      if (!sameEditingSession()) return;
      const existing = state.messages.get(message.id);

      if (existing) {
        state.messages.set(message.id, {
          ...existing,
          body: localKidFilter(body),
          e2ee_payload: data.e2ee_payload || e2eePayload,
          e2ee_meta: { text: body, media: null },
          edited_at: data.edited_at,
          updated_at: data.updated_at,
        });
      }

      state.changeSeq = Math.max(
        state.changeSeq,
        Number(data.change_seq || 0)
      );

      for (const [id, item] of state.messages.entries()) {
        if (item.reply?.id === message.id) {
          state.messages.set(id, {
            ...item,
            reply: { ...item.reply, body: localKidFilter(body), e2ee_payload: data.e2ee_payload || e2eePayload },
          });
        }
      }

      rebuildMessages();
      closeModal();
      loadConversations().catch(() => {});
    } catch (error) {
      toast(error.message);
    } finally {
      $("#saveEditBtn").disabled = false;
    }
  }

  function deleteMessage(messageId) {
    state.deletingMessageId = Number(messageId);
    openModal("#deleteMessageModal");
  }

  async function confirmDeleteMessage() {
    const messageId = state.deletingMessageId;
    if (!messageId) return;

    $("#confirmDeleteBtn").disabled = true;

    try {
      const data = await api("delete", {
        method: "POST",
        body: { message_id: messageId },
      });

      const existing = state.messages.get(messageId);

      if (existing) {
        state.messages.set(messageId, {
          ...existing,
          body: "",
          attachment_url: "",
          deleted_at: data.deleted_at,
          updated_at: data.updated_at,
        });
      }

      state.changeSeq = Math.max(
        state.changeSeq,
        Number(data.change_seq || 0)
      );

      for (const [id, item] of state.messages.entries()) {
        if (item.reply?.id === messageId) {
          state.messages.set(id, {
            ...item,
            reply: { ...item.reply, body: "Message deleted" },
          });
        }
      }

      rebuildMessages();
      closeModal();
      loadConversations().catch(() => {});
    } catch (error) {
      toast(error.message);
    } finally {
      $("#confirmDeleteBtn").disabled = false;
    }
  }

  function openNewChat() {
    state.selectedPeople = [];
    state.peopleSearchRequestId += 1;
    $("#peopleSearch").value = "";
    $("#groupName").value = "";
    $("#peopleResults").replaceChildren();
    renderSelectedPeople();
    openModal("#newChatModal");
    setTimeout(() => $("#peopleSearch").focus(), 0);
  }

  let peopleSearchTimer = null;

  function schedulePeopleSearch() {
    clearTimeout(peopleSearchTimer);
    peopleSearchTimer = setTimeout(searchPeople, 220);
  }

  async function searchPeople() {
    const query = $("#peopleSearch").value.trim();
    const results = $("#peopleResults");
    const requestId = ++state.peopleSearchRequestId;

    results.replaceChildren();
    if (!query) {
      const hint = document.createElement("div");
      hint.className = "chat-empty-message";
      hint.textContent = "Search for a friend to start a chat.";
      results.appendChild(hint);
      return;
    }

    try {
      const data = await api("search_users", {}, { q: query });

      if (
        requestId !== state.peopleSearchRequestId ||
        $("#peopleSearch").value.trim() !== query
      ) return;

      const selected = new Set(state.selectedPeople.map((person) => person.id));

      for (const person of (data.users || []).filter((item) => !selected.has(item.id))) {
        const relation = person.friendship?.status || "none";

        if (relation === "accepted") {
          const row = personRow(person, true);
          const status = document.createElement("span");
          status.className = "person-status";
          status.textContent = "Friend";
          row.appendChild(status);
          row.addEventListener("click", () => {
            state.selectedPeople.push(person);
            state.peopleSearchRequestId += 1;
            $("#peopleSearch").value = "";
            results.replaceChildren();
            renderSelectedPeople();
            $("#peopleSearch").focus();
          });
          results.appendChild(row);
        } else {
          results.appendChild(friendActionRow(person));
        }
      }

      if (!results.children.length) {
        const empty = document.createElement("div");
        empty.className = "chat-empty-message";
        empty.textContent = "No users found.";
        results.appendChild(empty);
      }
    } catch (error) {
      if (requestId === state.peopleSearchRequestId) toast(error.message);
    }
  }

  function friendActionRow(person) {
    const row = personRow(person, false);
    row.classList.add("friend-action-row");

    const relation = person.friendship?.status || "none";
    const action = document.createElement("button");
    action.type = "button";
    action.className = "secondary-btn compact friend-action";

    if (relation === "outgoing") {
      action.textContent = "Requested";
      action.disabled = true;
    } else if (relation === "incoming") {
      action.textContent = "Accept";
      action.addEventListener("click", async () => {
        const accepted = await respondFriendRequest(
          person.friendship.request_id,
          true,
          { openChat: false }
        );
        if (!accepted || accepted.status !== "accepted") return;
        person.friendship = {
          status: "accepted",
          request_id: person.friendship.request_id,
        };
        schedulePeopleSearch();
        scheduleFriendSearch();
      });
    } else {
      action.textContent = "Add";
      action.addEventListener("click", async () => {
        action.disabled = true;
        try {
          const data = await api("friend_request", {
            method: "POST",
            body: { user_id: person.id },
          });
          person.friendship = {
            status: data.status || "outgoing",
            request_id: Number(data.request_id || 0),
          };
          toast(`Friend request sent to ${person.display_name}.`);
          await loadFriends({ notify: false });
          schedulePeopleSearch();
          scheduleFriendSearch();
        } catch (error) {
          toast(error.message);
          action.disabled = false;
        }
      });
    }

    row.appendChild(action);
    return row;
  }

  async function loadFriends({ notify = true } = {}) {
    if (!state.me) return;

    const userId = Number(state.me.id || 0);
    const previousIncoming = new Set(
      state.incomingFriends.map((item) => Number(item.id))
    );
    const data = await api("friends");
    if (Number(state.me?.id || 0) !== userId) return;

    const nextIncoming = data.incoming || [];

    if (notify && state.friendsLoaded) {
      for (const item of nextIncoming) {
        const notifyKey = `friend-request-${Number(item.id)}`;
        if (
          previousIncoming.has(Number(item.id)) ||
          state.notifiedIds.has(notifyKey)
        ) continue;
        state.notifiedIds.add(notifyKey);
        const person = item.person || {};
        showBrowserNotification(
          person.display_name || "SilkNex",
          "wants to be friends",
          notifyKey,
          {
            type: "friend_request",
            request_id: item.id,
            avatar_url: person.avatar_url || "",
          }
        );
      }
    }

    const previousSignature = state.friendSignature;
    state.friends = data.friends || [];
    state.incomingFriends = nextIncoming;
    state.outgoingFriends = data.outgoing || [];
    state.friendSignature = String(data.signature || "");
    state.friendsLoaded = true;
    renderFriendBadge();

    if (
      previousSignature &&
      state.friendSignature !== previousSignature &&
      state.activeConversation?.kind === "dm"
    ) {
      refreshActiveConversation().catch(() => {});
    }

    if (!$("#friendsModal").classList.contains("hidden")) {
      renderFriends();
    }
  }

  function renderFriendBadge() {
    const count = state.incomingFriends.length;
    const badge = $("#friendRequestBadge");
    if (!badge) return;
    badge.textContent = count > 99 ? "99+" : String(count);
    badge.classList.toggle("hidden", count < 1);
  }

  function friendListRow(item, type) {
    const person = item.person || {};
    const row = personRow(person, false);
    row.classList.add("friend-list-row");

    const actions = document.createElement("div");
    actions.className = "friend-row-actions";

    if (type === "incoming") {
      const decline = document.createElement("button");
      decline.type = "button";
      decline.className = "text-btn";
      decline.textContent = "Decline";
      decline.addEventListener("click", () => respondFriendRequest(item.id, false));

      const accept = document.createElement("button");
      accept.type = "button";
      accept.className = "primary compact";
      accept.textContent = "Accept";
      accept.addEventListener("click", () => respondFriendRequest(item.id, true, { openChat: true }));
      actions.append(decline, accept);
    } else if (type === "friend") {
      const chat = document.createElement("button");
      chat.type = "button";
      chat.className = "secondary-btn compact";
      chat.textContent = "Chat";
      chat.addEventListener("click", () => startChatWithFriend(person));

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "text-btn danger-text";
      remove.textContent = "Remove";
      remove.addEventListener("click", () => removeFriend(person));
      actions.append(chat, remove);
    } else {
      const sent = document.createElement("span");
      sent.className = "person-status";
      sent.textContent = "Requested";
      actions.appendChild(sent);
    }

    row.appendChild(actions);
    return row;
  }

  function renderFriends() {
    const incoming = $("#incomingFriendRequests");
    const friends = $("#friendsList");
    const outgoing = $("#outgoingFriendRequests");
    incoming.replaceChildren();
    friends.replaceChildren();
    outgoing.replaceChildren();

    $("#incomingFriendsSection").classList.toggle("hidden", !state.incomingFriends.length);
    $("#outgoingFriendsSection").classList.toggle("hidden", !state.outgoingFriends.length);

    for (const item of state.incomingFriends) incoming.appendChild(friendListRow(item, "incoming"));
    for (const item of state.friends) friends.appendChild(friendListRow(item, "friend"));
    for (const item of state.outgoingFriends) outgoing.appendChild(friendListRow(item, "outgoing"));

    if (!state.friends.length) {
      const empty = document.createElement("div");
      empty.className = "chat-empty-message";
      empty.textContent = "No friends yet. Search above to add someone.";
      friends.appendChild(empty);
    }
  }

  async function openFriends() {
    $("#friendSearch").value = "";
    $("#friendSearchResults").replaceChildren();
    renderFriends();
    openModal("#friendsModal");
    try {
      await loadFriends({ notify: false });
    } catch (error) {
      toast(error.message);
    }
  }

  let friendSearchTimer = null;
  function scheduleFriendSearch() {
    clearTimeout(friendSearchTimer);
    friendSearchTimer = setTimeout(searchFriends, 180);
  }

  async function searchFriends() {
    const query = $("#friendSearch").value.trim();
    const results = $("#friendSearchResults");
    const requestId = ++state.friendSearchRequestId;
    results.replaceChildren();
    if (!query) return;

    try {
      const data = await api("search_users", {}, { q: query });
      if (
        requestId !== state.friendSearchRequestId ||
        $("#friendSearch").value.trim() !== query
      ) return;

      for (const person of data.users || []) {
        const relation = person.friendship?.status || "none";
        if (relation === "accepted") {
          const item = state.friends.find((entry) => entry.person?.id === person.id);
          if (item) results.appendChild(friendListRow(item, "friend"));
          else {
            const row = personRow(person, false);
            const status = document.createElement("span");
            status.className = "person-status";
            status.textContent = "Friend";
            row.appendChild(status);
            results.appendChild(row);
          }
        } else {
          results.appendChild(friendActionRow(person));
        }
      }

      if (!results.children.length) {
        const empty = document.createElement("div");
        empty.className = "chat-empty-message";
        empty.textContent = "No users found.";
        results.appendChild(empty);
      }
    } catch (error) {
      if (requestId === state.friendSearchRequestId) toast(error.message);
    }
  }

  async function respondFriendRequest(requestId, accept, { openChat = false } = {}) {
    try {
      const data = await api("friend_respond", {
        method: "POST",
        body: { request_id: Number(requestId), accept: Boolean(accept) },
      });
      await Promise.all([
        loadFriends({ notify: false }),
        loadConversations(),
      ]);

      if (accept) {
        toast("Friend request accepted.");
        if (state.activeConversation?.friendship?.request_id === Number(requestId)) {
          await refreshActiveConversation();
        }
        if (openChat && Number(data.conversation_id || 0) > 0) {
          closeModal();
          await openConversation(Number(data.conversation_id));
        }
      } else {
        toast("Friend request declined.");
      }
      return data;
    } catch (error) {
      toast(error.message);
      return null;
    }
  }

  async function removeFriend(person) {
    if (!person?.id || !window.confirm(`Remove ${person.display_name} from friends?`)) return;
    try {
      await api("friend_remove", {
        method: "POST",
        body: { user_id: person.id },
      });
      await loadFriends({ notify: false });
      if (state.activeConversation?.other_user_id === person.id) {
        await refreshActiveConversation();
      }
      toast("Friend removed.");
    } catch (error) {
      toast(error.message);
    }
  }

  async function startChatWithFriend(person) {
    if (!person?.username) return;
    try {
      const data = await api("create_conversation", {
        method: "POST",
        body: { usernames: [person.username] },
      });
      closeModal();
      await loadConversations();
      await openConversation(Number(data.conversation_id));
    } catch (error) {
      toast(error.message);
    }
  }

  async function refreshActiveConversation() {
    if (!state.activeId) return;
    try {
      const data = await api("conversation", {}, { id: state.activeId });
      if (state.activeId !== Number(data.conversation?.id || state.activeId)) return;
      state.activeConversation = data.conversation;
      renderChatHeader();
    } catch {}
  }

  function openUserProfile(person) {
    if (!person) return;
    if (typeof window.SilkNexOpenPublicProfile === "function" && person.username) {
      window.SilkNexOpenPublicProfile(person.username, person);
      return;
    }
    const modal = $("#userProfileModal");
    const avatarButton = $("#userProfileAvatarBtn");
    if (!modal || !avatarButton) return;

    $("#userProfileName").textContent = person.nickname || person.display_name || "Profile";
    $("#userProfileUsername").textContent = person.username ? `@${person.username}` : "";
    $("#userProfileBio").textContent = String(person.about || "").trim() || "No bio yet.";

    const avatar = document.createElement("div");
    avatar.className = "avatar avatar-xl";
    setAvatar(
      avatar,
      person.display_name || person.username || "S",
      person.accent || "silver",
      person.avatar_url || "",
      person.avatar_style || null
    );
    avatar.classList.add("avatar-xl");
    avatarButton.replaceChildren(avatar);
    avatarButton.onclick = () => {
      const url = person.avatar_url || (
        person.avatar_style && Object.keys(person.avatar_style).length
          ? avatarStyleDataUrl(person.avatar_style)
          : ""
      );
      if (url) {
        openFullscreenMedia(url, "image", `${person.display_name || person.username || "User"} profile picture`);
      } else {
        toast("This profile does not have a full-size picture.");
      }
    };

    openModal("#userProfileModal");
  }

  function openActiveChatProfile() {
    const conversation = state.activeConversation;
    if (!conversation) return;
    if (conversation.kind !== "dm") {
      openChatSettings();
      return;
    }
    const other = conversation.members?.find((member) => Number(member.id) !== Number(state.me?.id));
    if (other) openUserProfile(other);
    else openChatSettings();
  }

  function personRow(person, clickable = false) {
    const row = document.createElement(clickable ? "button" : "div");
    if (clickable) row.type = "button";
    row.className = "person-row";

    const avatar = document.createElement("div");
    setAvatar(avatar, person.display_name, person.accent, person.avatar_url, person.avatar_style);
    if (person.online) avatar.classList.add("online-ring");
    avatar.classList.add("profile-avatar-button");
    avatar.setAttribute("role", "button");
    avatar.setAttribute("tabindex", "0");
    avatar.setAttribute("aria-label", `View ${person.display_name || person.username}'s profile`);
    const openProfile = (event) => {
      event?.preventDefault?.();
      event?.stopPropagation?.();
      openUserProfile(person);
    };
    avatar.addEventListener("click", openProfile);
    avatar.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") openProfile(event);
    });

    const copy = document.createElement("div");
    copy.className = "person-copy";

    const nameLine = document.createElement("div");
    nameLine.className = "person-name-line";

    const name = document.createElement("strong");
    name.textContent = person.nickname || person.display_name;
    nameLine.appendChild(name);
    if (isFounderRole(person.role)) nameLine.appendChild(founderBadgeNode(person.role));

    const username = document.createElement("small");
    username.textContent = `@${person.username}${person.online ? " · online" : ""}`;

    copy.append(nameLine, username);
    row.append(avatar, copy);
    return row;
  }

  function renderSelectedPeople() {
    const container = $("#selectedPeople");
    container.replaceChildren();

    for (const person of state.selectedPeople) {
      const chip = document.createElement("div");
      chip.className = "person-chip";

      const name = document.createElement("span");
      name.textContent = person.display_name;

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "selected-person-remove";
      remove.setAttribute("aria-label", "Remove");
      remove.appendChild(iconNode("close"));
      remove.addEventListener("click", () => {
        state.selectedPeople = state.selectedPeople.filter(
          (item) => item.id !== person.id
        );
        renderSelectedPeople();
      });

      chip.append(name, remove);
      container.appendChild(chip);
    }

    $("#groupNameWrap").classList.toggle(
      "hidden",
      state.selectedPeople.length < 2
    );

    $("#createChatBtn").textContent =
      state.selectedPeople.length > 1
        ? `Create group (${state.selectedPeople.length + 1})`
        : "Start chat";
  }

  async function createConversation() {
    if (!state.selectedPeople.length) {
      toast("Choose at least one person.");
      return;
    }

    const button = $("#createChatBtn");
    if (button.disabled) return;
    button.disabled = true;

    let data;

    try {
      data = await api("create_conversation", {
        method: "POST",
        body: {
          usernames: state.selectedPeople.map((person) => person.username),
          name:
            state.selectedPeople.length > 1
              ? $("#groupName").value.trim()
              : null,
        },
      });
    } catch (error) {
      toast(error.message);
      button.disabled = false;
      return;
    }

    button.disabled = false;
    closeModal();
    await loadConversations().catch(() => {});
    await openConversation(data.conversation_id);
  }

  function renderAccentPicker() {
    $$("#accentPicker [data-accent]").forEach((button) => {
      button.classList.toggle(
        "selected",
        button.dataset.accent === state.selectedAccent
      );
    });
  }

  const AVATAR_FIELD_IDS = {
    skin: "avatarSkin",
    face_shape: "avatarFaceShape",
    hair: "avatarHair",
    hair_color: "avatarHairColor",
    eyes: "avatarEyes",
    eye_color: "avatarEyeColor",
    brows: "avatarBrows",
    nose: "avatarNose",
    mouth: "avatarMouth",
    face_detail: "avatarFaceDetail",
    outfit: "avatarOutfit",
    outfit_color: "avatarOutfitColor",
    outfit_pattern: "avatarOutfitPattern",
    background: "avatarBackground",
    background_pattern: "avatarBackgroundPattern",
    accessory: "avatarAccessory",
    accessory_color: "avatarAccessoryColor",
    headwear: "avatarHeadwear",
    facial_hair: "avatarFacialHair",
    facial_hair_opacity: "avatarFacialHairOpacity",
    skin_hex: "avatarSkinHex",
    hair_hex: "avatarHairHex",
    outfit_hex: "avatarOutfitHex",
    background_hex: "avatarBackgroundHex",
    accessory_hex: "avatarAccessoryHex",
    face_width: "avatarFaceWidth",
    face_length: "avatarFaceLength",
    jaw_width: "avatarJawWidth",
    eye_scale: "avatarEyeScale",
    iris_size: "avatarIrisSize",
    lashes: "avatarLashes",
    eye_spacing: "avatarEyeSpacing",
    eye_height: "avatarEyeHeight",
    nose_scale: "avatarNoseScale",
    mouth_width: "avatarMouthWidth",
    brow_height: "avatarBrowHeight",
    ear_size: "avatarEarSize",
    neck_width: "avatarNeckWidth",
    eye_tilt: "avatarEyeTilt",
    brow_thickness: "avatarBrowThickness",
    nose_width: "avatarNoseWidth",
    lip_fullness: "avatarLipFullness",
    hair_volume: "avatarHairVolume",
    hair_highlight: "avatarHairHighlight",
    makeup: "avatarMakeup",
    face_decal: "avatarFaceDecal",
    hair_highlight_hex: "avatarHairHighlightHex",
    eye_hex: "avatarEyeHex",
    lip_hex: "avatarLipHex",
  };

  function readAvatarBuilder() {
    const style = {};
    for (const [key, id] of Object.entries(AVATAR_FIELD_IDS)) {
      const field = $(`#${id}`);
      style[key] = field?.value || AVATAR_DEFAULT[key];
    }
    return normalizedAvatarStyle(style);
  }

  function writeAvatarBuilder(style) {
    const normalized = normalizedAvatarStyle(style);
    for (const [key, id] of Object.entries(AVATAR_FIELD_IDS)) {
      const field = $(`#${id}`);
      if (field) {
        if (field.type === "color" && !normalized[key]) {
          const fallbacks = {
            skin_hex: AVATAR_PALETTE.skin[normalized.skin] || AVATAR_PALETTE.skin.warm,
            hair_hex: AVATAR_PALETTE.hair[normalized.hair_color] || AVATAR_PALETTE.hair.espresso,
            outfit_hex: AVATAR_PALETTE.outfit[normalized.outfit_color] || AVATAR_PALETTE.outfit.blue,
            background_hex: AVATAR_PALETTE.background[normalized.background] || AVATAR_PALETTE.background.neo,
            accessory_hex: AVATAR_PALETTE.accessory[normalized.accessory_color] || AVATAR_PALETTE.accessory.charcoal,
            hair_highlight_hex: AVATAR_PALETTE.hair[normalized.hair_color] || AVATAR_PALETTE.hair.espresso,
            eye_hex: AVATAR_PALETTE.eyes[normalized.eye_color] || AVATAR_PALETTE.eyes.brown,
            lip_hex: "#6d3538",
          };
          field.value = fallbacks[key] || "#777777";
        } else {
          field.value = normalized[key];
        }
      }
    }
    state.avatarStyleDraft = normalized;
    renderAvatarBuilderPreview();
  }

  function renderAvatarBuilderPreview() {
    const preview = $("#avatarBuilderPreview");
    if (!preview) return;
    const style = readAvatarBuilder();
    state.avatarStyleDraft = style;
    preview.replaceChildren(avatarSvgElement(style));
  }

  function setAvatarBuilderTab(tabName = "face") {
    const requested = String(tabName || "face");
    let found = false;

    $$(".avatar-builder-tab").forEach((button) => {
      const active = button.dataset.avatarTab === requested;
      found ||= active;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
      button.tabIndex = active ? 0 : -1;
    });

    const resolved = found ? requested : "face";
    $$(".avatar-builder-panel").forEach((panel) => {
      const active = panel.dataset.avatarPanel === resolved;
      panel.classList.toggle("active", active);
      panel.hidden = !active;
    });
  }

  function toggleAvatarBuilder(force) {
    const builder = $("#avatarBuilder");
    if (!builder) return;

    const open = force === undefined
      ? builder.classList.contains("hidden")
      : Boolean(force);

    builder.classList.toggle("hidden", !open);
    state.avatarBuilderOpen = open;
    $("#settingsModal")?.classList.toggle("avatar-studio-open", open);

    if (open) {
      setAvatarBuilderTab("face");
      writeAvatarBuilder(
        state.avatarStyleDraft ||
        state.me?.avatar_style ||
        AVATAR_DEFAULT
      );
      builder.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
  }

  function randomizeAvatar() {
    const options = {
      skin: ["porcelain","fair","warm","olive","tan","brown","deep","ebony"],
      face_shape: ["oval","round","soft_square","heart","long","diamond","square","triangle","pear"],
      hair: ["crop","textured_crop","french_crop","taper_fade","low_fade","mid_fade","high_fade","curly_fade","quiff","pompadour","comb_over","two_block","waves","curls","curtain","slick_back","undercut","bob","french_bob","long","layers","wolf_cut","bun","space_buns","messy_bun","low_bun","ponytail","high_ponytail","side_part","afro","taper_afro","locs","loc_bun","twists","box_braids","dutch_braids","cornrows","mohawk","buzz","bald","hijab","pixie","braids","shag","spiky"],
      hair_color: ["black","espresso","brown","auburn","blonde","platinum","blue","pink","teal","silver","red","purple","copper","green"],
      eyes: ["round","soft","bright","sleepy","wink","almond","wide","hooded","monolid","cat"],
      eye_color: ["brown","dark_brown","hazel","green","blue","gray","amber"],
      lashes: ["none","none","soft","full","cat"],
      brows: ["soft","straight","arched","bold","tapered","rounded","high_arch","feathered"],
      nose: ["soft","button","straight","wide","petite","aquiline","upturned"],
      mouth: ["smile","grin","soft","open","cool","neutral","smirk","kiss","laugh"],
      face_detail: ["none","blush","freckles","beauty_mark","sun_kiss","cheek_mark","freckles_dense","under_eye","scar_brow"],
      outfit: ["tee","hoodie","jacket","sweater","shirt","tank","turtleneck","blazer","vest","jersey","bomber","denim","varsity","dress","overalls"],
      outfit_color: ["charcoal","silver","blue","green","purple","orange","pink","red","teal","yellow","white"],
      outfit_pattern: ["solid","stripe","badge","split","checker","gradient"],
      background: ["neo","blue","mint","violet","sunset","mono","rose","ocean","forest","gold","coral","lavender"],
      background_pattern: ["clean","dots","rings","grid","halo","diagonal","stars","checker","aurora","sparkles"],
      accessory: ["none","glasses","round_glasses","square_glasses","aviator","heart_glasses","sunglasses","earrings","hoop_earrings","studs","nose_ring","septum","lip_ring","chain","pearl_chain","choker","monocle","brow_ring","hearing_aid","face_bandage"],
      accessory_color: ["charcoal","silver","gold","blue","pink","red","white"],
      headwear: ["none","beanie","bandana","durag","cap","snapback","sports_cap","headphones","crown","bucket","flower","beret","fedora","visor","cowboy","tiara","cat_ears","hood"],
      facial_hair: ["none","stubble","mustache","beard","goatee","boxed_beard","full_beard","soul_patch"],
      hair_highlight: ["none","none","soft","streaks","tips"],
      makeup: ["none","none","rosy","liner","bold"],
      face_decal: ["none","none","star","heart","bolt"],
    };

    const style = {};
    for (const [key, values] of Object.entries(options)) {
      style[key] = values[Math.floor(Math.random() * values.length)];
    }
    const proportion = (spread) => String(100 + Math.round((Math.random() * 2 - 1) * spread));
    Object.assign(style, {
      face_width: proportion(10),
      face_length: proportion(8),
      jaw_width: proportion(10),
      eye_scale: proportion(12),
      iris_size: proportion(18),
      eye_spacing: proportion(10),
      eye_height: proportion(7),
      nose_scale: proportion(11),
      mouth_width: proportion(11),
      brow_height: proportion(7),
      ear_size: proportion(8),
      neck_width: proportion(9),
      eye_tilt: proportion(10),
      brow_thickness: proportion(18),
      nose_width: proportion(12),
      lip_fullness: proportion(16),
      hair_volume: proportion(12),
      facial_hair_opacity: String(55 + Math.round(Math.random() * 45)),
    });
    writeAvatarBuilder(style);
  }

  function useAvatarBuilder() {
    state.avatarStyleDraft = readAvatarBuilder();
    state.avatarUsingStyle = true;
    state.avatarToken = "";
    state.avatarPreviewUrl = "";
    state.removeAvatar = true;
    updateProfilePreview();
    toggleAvatarBuilder(false);
    toast("Avatar ready. Save your profile to keep it.");
  }

  function updateProfilePreview() {
    const name = $("#displayName").value.trim() || state.me?.display_name || "SilkNex";
    const useStyle = state.avatarUsingStyle;
    const avatarUrl = useStyle
      ? ""
      : state.avatarPreviewUrl || (state.removeAvatar ? "" : state.me?.avatar_url);

    setAvatar(
      $("#profileAvatarPreview"),
      name,
      state.selectedAccent,
      avatarUrl,
      useStyle ? state.avatarStyleDraft : (avatarUrl ? null : state.me?.avatar_style)
    );
    $("#profileAvatarPreview").classList.add("avatar-xl");
  }

  async function openSettings() {
    if (!state.me) return;

    state.selectedAccent = state.me.accent || "silver";
    state.avatarToken = "";
    state.removeAvatar = false;
    state.avatarPreviewUrl = state.me.avatar_url || "";
    state.avatarStyleDraft = normalizedAvatarStyle(state.me.avatar_style || AVATAR_DEFAULT);
    state.avatarUsingStyle = Boolean(
      state.me.avatar_style &&
      Object.keys(state.me.avatar_style).length &&
      !state.me.avatar_url
    );
    state.avatarBuilderOpen = false;
    $("#avatarBuilder")?.classList.add("hidden");
    $("#settingsModal")?.classList.remove("avatar-studio-open");
    setAvatarBuilderTab("face");
    writeAvatarBuilder(state.avatarStyleDraft);
    state.themeChoice = state.me.theme || "dark";
    state.iconStyleChoice = state.me.app_icon_style || "auto";
    state.fontScaleChoice = state.me.font_scale || "normal";
    state.fontFamilyChoice = state.me.font_family || "system";
    state.uiAccentChoice = state.me.ui_accent || "silver";
    state.bubbleStyleChoice = state.me.bubble_style || "rounded";
    state.messageDensityChoice = state.me.message_density || "normal";
    state.chatWidthChoice = state.me.chat_width || "normal";
    state.reduceMotionChoice = Boolean(state.me.reduce_motion);
    state.easyModeChoice = Boolean(state.me.easy_mode);
    state.wallpaperChoice = state.me.wallpaper || "neo";
    state.wallpaperToken = "";
    state.wallpaperPreviewUrl = state.me.wallpaper_url || "";
    state.notificationsChoice = Boolean(state.me.notifications_enabled);

    $("#displayName").value = state.me.display_name;
    $("#about").value = state.me.about || "";
    $("#fontScale").value = state.fontScaleChoice;
    $("#fontFamily").value = state.fontFamilyChoice;
    $("#uiAccent").value = state.uiAccentChoice;
    $("#bubbleStyle").value = state.bubbleStyleChoice;
    $("#messageDensity").value = state.messageDensityChoice;
    $("#chatWidth").value = state.chatWidthChoice;
    $("#reduceMotionToggle").checked = state.reduceMotionChoice;
    $("#easyModeToggle").checked = state.easyModeChoice;
    $("#notificationsToggle").checked = state.notificationsChoice;

    renderAccentPicker();
    updateProfilePreview();
    renderThemeButtons();
    renderIconButtons();
    renderWallpaperPicker();
    openModal("#settingsModal");

    await Promise.allSettled([
      loadKidSettings(),
      loadPasskeys(),
      loadSecurityStatus(),
    ]);
  }


  function openChildModal(selector) {
    const modal = $(selector);
    if (!modal) return;
    $("#modalOverlay").classList.remove("hidden");
    modal.classList.remove("hidden");

    // Child sheets (currently the avatar cropper) sit above an existing modal.
    // Move keyboard focus into the top layer so screen-reader/keyboard users do
    // not keep interacting with the sheet underneath it.
    setTimeout(() => {
      const control = modal.querySelector(
        "[autofocus],button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex='-1'])"
      );
      try { control?.focus?.({ preventScroll: true }); }
      catch { control?.focus?.(); }
    }, 0);
  }

  function closeAvatarCrop() {
    const crop = state.avatarCrop;
    if (crop?.objectUrl) URL.revokeObjectURL(crop.objectUrl);
    state.avatarCrop = null;
    $("#avatarCropModal").classList.add("hidden");
    if ($$(".modal").every((modal) => modal.classList.contains("hidden"))) {
      $("#modalOverlay").classList.add("hidden");
    }
  }

  function renderAvatarCrop() {
    const crop = state.avatarCrop;
    const canvas = $("#avatarCropCanvas");
    if (!crop?.image || !canvas) return;

    const ctx = canvas.getContext("2d");
    const w = canvas.width;
    const h = canvas.height;
    const img = crop.image;
    const cropSize = w * 0.78;
    const base = Math.max(
      cropSize / img.naturalWidth,
      cropSize / img.naturalHeight
    );
    const scale = base * crop.zoom;
    const drawW = img.naturalWidth * scale;
    const drawH = img.naturalHeight * scale;
    const maxX = Math.max(0, (drawW - cropSize) / 2);
    const maxY = Math.max(0, (drawH - cropSize) / 2);
    crop.offsetX = Math.max(-maxX, Math.min(maxX, crop.offsetX));
    crop.offsetY = Math.max(-maxY, Math.min(maxY, crop.offsetY));

    // Keep source alpha intact. The crop stage can provide its own visual
    // backdrop in CSS without baking a black matte into the saved avatar.
    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(
      img,
      (w - drawW) / 2 + crop.offsetX,
      (h - drawH) / 2 + crop.offsetY,
      drawW,
      drawH
    );
  }

  async function openAvatarCrop(file) {
    if (!file || !String(file.type || "").startsWith("image/")) {
      toast("Choose an image for your profile photo.");
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    const image = new Image();
    image.decoding = "async";

    try {
      await new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = reject;
        image.src = objectUrl;
      });
    } catch {
      URL.revokeObjectURL(objectUrl);
      toast("SilkNex could not open that image.");
      return;
    }

    state.avatarCrop = {
      file,
      image,
      objectUrl,
      zoom: 1,
      offsetX: 0,
      offsetY: 0,
      drag: null,
    };
    $("#avatarCropZoom").value = "1";
    openChildModal("#avatarCropModal");
    renderAvatarCrop();
  }

  async function saveAvatarCrop() {
    const crop = state.avatarCrop;
    const preview = $("#avatarCropCanvas");
    if (!crop || !preview) return;

    $("#saveAvatarCropBtn").disabled = true;

    try {
      renderAvatarCrop();
      const out = document.createElement("canvas");
      out.width = 512;
      out.height = 512;
      const ctx = out.getContext("2d", { alpha: true });
      const cropSize = Math.round(preview.width * 0.78);
      const sourceX = Math.round((preview.width - cropSize) / 2);
      const sourceY = Math.round((preview.height - cropSize) / 2);
      ctx.drawImage(
        preview,
        sourceX, sourceY, cropSize, cropSize,
        0, 0, out.width, out.height
      );

      let blob;
      let extension = "webp";
      try {
        blob = await canvasToBlob(out, "image/webp", 0.92);
      } catch {
        blob = await canvasToBlob(out, "image/png");
        extension = "png";
      }

      const file = fileFromBlob(blob, `profile-${Date.now()}.${extension}`, {
        type: blob.type || (extension === "png" ? "image/png" : "image/webp"),
      });
      toast("Uploading profile photo…");
      const uploaded = await uploadFile(file, "avatar");
      state.avatarToken = uploaded.token;
      state.removeAvatar = false;
      state.avatarPreviewUrl = uploaded.url;
      state.avatarUsingStyle = false;
      closeAvatarCrop();
      updateProfilePreview();
      toast("Profile photo ready. Save your profile.");
    } catch (error) {
      toast(error.message || "Could not save the profile photo.");
    } finally {
      $("#saveAvatarCropBtn").disabled = false;
    }
  }


  function clearStoryComposer({ preserveCaption = false } = {}) {
    if (state.pendingStoryPreviewUrl) {
      try { URL.revokeObjectURL(state.pendingStoryPreviewUrl); } catch {}
    }

    state.pendingStoryFile = null;
    state.pendingStoryPreviewUrl = "";

    const preview = $("#storyComposerPreview");
    if (preview) {
      preview.replaceChildren();
      preview.classList.add("hidden");
    }

    const meta = $("#storyComposerMeta");
    if (meta) {
      meta.textContent = "";
      meta.classList.add("hidden");
    }

    if (!preserveCaption && $("#storyCaption")) {
      $("#storyCaption").value = "";
      if ($("#storyOverlayText")) $("#storyOverlayText").value = "";
      if ($("#storyTextX")) $("#storyTextX").value = "50";
      if ($("#storyTextY")) $("#storyTextY").value = "50";
      if ($("#storyRetention")) $("#storyRetention").value = "30";
    }

    for (const selector of ["#storyMediaInput", "#storyPhotoInput", "#storyVideoInput"]) {
      const input = $(selector);
      if (input) input.value = "";
    }

    const post = $("#postStoryBtn");
    if (post) {
      post.disabled = true;
      post.textContent = "Post story";
    }

    $("#changeStoryMediaBtn")?.classList.add("hidden");
  }

  function storyFileKind(file) {
    const type = String(file?.type || "").toLowerCase();
    if (type.startsWith("image/")) return "image";
    if (type.startsWith("video/")) return "video";

    const name = String(file?.name || "").toLowerCase();
    if (/\.(jpe?g|png|webp|gif|heic|heif|avif)$/i.test(name)) return "image";
    if (/\.(mp4|mov|m4v|webm)$/i.test(name)) return "video";
    return "";
  }

  function storyImageNeedsConversion(file) {
    const type = String(file?.type || "").toLowerCase();
    return (
      file.size > 4 * 1024 * 1024 ||
      ["image/heic", "image/heif"].includes(type) ||
      /\.(heic|heif)$/i.test(String(file?.name || ""))
    );
  }

  async function optimizeStoryImage(file) {
    if (storyFileKind(file) !== "image") return file;

    const sourceType = String(file.type || "").toLowerCase();
    if (sourceType === "image/gif" || /\.gif$/i.test(String(file.name || ""))) {
      return file;
    }

    if (!storyImageNeedsConversion(file)) return file;

    let source = null;
    let width = 0;
    let height = 0;
    let decoded = null;
    let canvas = null;

    try {
      decoded = await window.SilknexMedia.decodeImage(file);
      source = decoded.source;
      width = Number(source.naturalWidth || source.width || 0);
      height = Number(source.naturalHeight || source.height || 0);

      if (!width || !height) return file;

      const deviceMemory = Number(navigator.deviceMemory || 0);
      const lowMemory = deviceMemory > 0 && deviceMemory <= 4;
      const maxSide = lowMemory ? 1600 : 2160;
      const scale = Math.min(1, maxSide / Math.max(width, height));
      const outputWidth = Math.max(1, Math.round(width * scale));
      const outputHeight = Math.max(1, Math.round(height * scale));

      const forceJpeg =
        ["image/heic", "image/heif"].includes(sourceType) ||
        /\.(heic|heif)$/i.test(String(file.name || ""));
      const alphaCapable = !forceJpeg && [
        "image/png",
        "image/webp",
        "image/avif",
      ].includes(sourceType);
      const outputType = alphaCapable ? "image/webp" : "image/jpeg";

      canvas = document.createElement("canvas");
      canvas.width = outputWidth;
      canvas.height = outputHeight;

      const context = canvas.getContext("2d", { alpha: alphaCapable });
      if (!context) return file;

      if (!alphaCapable) {
        context.fillStyle = "#000";
        context.fillRect(0, 0, outputWidth, outputHeight);
      }
      context.drawImage(source, 0, 0, outputWidth, outputHeight);

      const blob = await window.SilknexMedia.encodeCanvas(canvas, outputType, lowMemory ? 0.82 : 0.88);

      if (!blob) return file;

      if (!forceJpeg && blob.size >= file.size * 0.97) {
        return file;
      }

      const baseName = String(file.name || "story")
        .replace(/\.[^.]+$/, "")
        .replace(/[^\w.-]+/g, "-")
        .slice(0, 80) || "story";
      const extension = window.SilknexMedia.extension(blob.type);

      return fileFromBlob(blob, `${baseName}.${extension}`, {
        type: blob.type,
        lastModified: Date.now(),
      });
    } catch {
      return file;
    } finally {
      try { decoded?.dispose(); } catch {}
      if (canvas) { canvas.width = 1; canvas.height = 1; }
    }
  }

  function formatStoryTime(timestamp) {
    const seconds = Math.max(0, Math.floor(Date.now() / 1000) - Number(timestamp || 0));
    if (seconds < 60) return "Just now";
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    return "1d";
  }

  function buildStoryGroups(items) {
    const groups = new Map();
    for (const story of items) {
      const key = Number(story.user_id || 0);
      if (!key) continue;
      if (!groups.has(key)) {
        groups.set(key, {
          user_id: key,
          username: story.username,
          display_name: story.display_name,
          accent: story.accent,
          avatar_url: story.avatar_url,
          avatar_style: story.avatar_style || null,
          role: story.role || "member",
          mine: Boolean(story.mine),
          stories: [],
        });
      }
      groups.get(key).stories.push(story);
    }

    return [...groups.values()].sort((a, b) => {
      if (a.mine !== b.mine) return a.mine ? -1 : 1;
      const aUnseen = a.stories.some((story) => !story.viewed);
      const bUnseen = b.stories.some((story) => !story.viewed);
      if (aUnseen !== bUnseen) return aUnseen ? -1 : 1;
      const aTime = Math.max(...a.stories.map((story) => Number(story.created_at || 0)));
      const bTime = Math.max(...b.stories.map((story) => Number(story.created_at || 0)));
      return bTime - aTime;
    });
  }

  function renderStoriesRail() {
    const rail = $("#storiesRail");
    if (!rail) return;
    rail.replaceChildren();

    // The add chip is always present, including on narrow phones where the
    // Stories heading is intentionally hidden. This fixes the old mobile dead
    // end where a user could view stories but had no way to create one.
    const add = document.createElement("button");
    add.type = "button";
    add.className = "story-chip story-add-chip";
    add.setAttribute("aria-label", "Add to your story");

    const addRing = document.createElement("span");
    addRing.className = "story-ring";
    const addAvatar = document.createElement("span");
    addAvatar.className = "avatar";
    setAvatar(
      addAvatar,
      state.me?.display_name || "You",
      state.me?.accent || "silver",
      state.me?.avatar_url || "",
      state.me?.avatar_style || null
    );
    const plus = document.createElement("span");
    plus.className = "story-add-mark";
    plus.appendChild(iconNode("compose"));
    addRing.append(addAvatar, plus);

    const addLabel = document.createElement("small");
    addLabel.textContent = "Add story";
    add.append(addRing, addLabel);
    add.addEventListener("click", openStoryComposer);
    rail.appendChild(add);

    state.storyGroups.forEach((group, groupIndex) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className =
        "story-chip" +
        (group.mine ? " mine" : "") +
        (group.stories.every((story) => story.viewed) ? " viewed" : "");
      button.setAttribute(
        "aria-label",
        `${group.display_name}'s story${isFounderRole(group.role) ? (group.role === "cofounder_ceo" ? ", Co-Founder and CEO" : ", Founder and CEO") : ""}`
      );

      const ring = document.createElement("span");
      ring.className = "story-ring";
      const avatar = document.createElement("span");
      avatar.className = "avatar";
      setAvatar(avatar, group.display_name, group.accent, group.avatar_url, group.avatar_style);
      ring.appendChild(avatar);
      const firstStory = group.stories?.[0];
      if (!group.mine && firstStory?.media_type === "image" && firstStory?.media_url) {
        const mini = document.createElement("span");
        mini.className = "story-first-preview";
        const miniImg = document.createElement("img");
        miniImg.src = firstStory.media_url;
        miniImg.alt = "";
        miniImg.loading = "lazy";
        miniImg.decoding = "async";
        mini.appendChild(miniImg);
        ring.appendChild(mini);
      }

      const label = document.createElement("small");
      label.textContent = group.mine ? "Your story" : group.display_name;

      button.append(ring, label);
      button.addEventListener("click", () => {
        let storyIndex = group.stories.findIndex((story) => !story.viewed);
        if (storyIndex < 0) storyIndex = 0;
        openStory(groupIndex, storyIndex);
      });
      rail.appendChild(button);
    });

    if (!state.storyGroups.length) {
      const empty = document.createElement("div");
      empty.className = "story-empty";
      empty.textContent = "Be the first to share an update.";
      rail.appendChild(empty);
    }
  }

  async function loadStories() {
    if (!state.me) return;
    if (state.storiesLoadPromise) return state.storiesLoadPromise;

    const userId = Number(state.me.id || 0);
    const request = (async () => {
      const data = await api("stories");
      if (Number(state.me?.id || 0) !== userId) return;

      state.stories = Array.isArray(data.stories) ? data.stories : [];
      state.storyGroups = buildStoryGroups(state.stories);
      state.lastStoryRefreshAt = Date.now();
      renderStoriesRail();
    })();

    state.storiesLoadPromise = request;
    try {
      await request;
    } finally {
      if (state.storiesLoadPromise === request) {
        state.storiesLoadPromise = null;
      }
    }
  }

  function openStoryComposer() {
    if (!state.me) return;
    clearStoryComposer();
    openModal("#storyComposerModal");
  }

  async function storyImageWithText(file, text, blank = false) {
    const canvas = document.createElement("canvas");
    canvas.width = 720;
    canvas.height = 1280;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Story editor is unavailable on this device.");
    if (blank) {
      const gradient = ctx.createLinearGradient(0, 0, 720, 1280);
      gradient.addColorStop(0, "#39366e");
      gradient.addColorStop(1, "#111827");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 720, 1280);
    } else {
      let image;
      let objectUrl = "";
      if (typeof createImageBitmap === "function") image = await createImageBitmap(file);
      else {
        objectUrl = URL.createObjectURL(file);
        image = new Image();
        image.src = objectUrl;
        await image.decode();
      }
      const scale = Math.max(720 / image.width, 1280 / image.height);
      ctx.drawImage(image, (720 - image.width * scale) / 2, (1280 - image.height * scale) / 2, image.width * scale, image.height * scale);
      image.close?.();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    }
    const x = 720 * Number($("#storyTextX")?.value || 50) / 100;
    const y = 1280 * Number($("#storyTextY")?.value || 50) / 100;
    ctx.font = "bold 54px system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const words = text.trim().split(/\s+/u);
    const lines = [];
    let line = "";
    for (const word of words) {
      const candidate = line ? `${line} ${word}` : word;
      if (line && ctx.measureText(candidate).width > 600) { lines.push(line); line = word; }
      else line = candidate;
    }
    if (line) lines.push(line);
    ctx.lineWidth = 8;
    ctx.strokeStyle = "rgba(0,0,0,.86)";
    ctx.fillStyle = "#fff";
    lines.slice(0, 14).forEach((row, index) => {
      const py = Math.max(42, Math.min(1230, y + (index - (lines.length - 1) / 2) * 68));
      ctx.strokeText(row, x, py, 620);
      ctx.fillText(row, x, py, 620);
    });
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", .82));
    if (!blob) throw new Error("Could not prepare story image.");
    return new File([blob], "story.webp", { type: "image/webp" });
  }

  function updateStoryOverlayPreview() {
    const preview = $("#storyComposerPreview");
    if (!preview || preview.classList.contains("hidden")) return;
    let overlay = $("#storyPreviewOverlay", preview);
    if (!overlay) {
      overlay = document.createElement("span");
      overlay.id = "storyPreviewOverlay";
      overlay.className = "story-preview-overlay";
      preview.appendChild(overlay);
    }
    overlay.textContent = $("#storyOverlayText")?.value || "";
    overlay.style.left = `${$("#storyTextX")?.value || 50}%`;
    overlay.style.top = `${$("#storyTextY")?.value || 50}%`;
    overlay.hidden = !overlay.textContent.trim() || state.pendingStoryFile?.type.startsWith("video/");
  }

  async function handleStoryFile(file) {
    if (!file) return;

    const originalKind = storyFileKind(file);
    if (!originalKind) {
      toast("Choose a photo or video for your story.");
      return;
    }

    const caption = $("#storyCaption")?.value || "";
    clearStoryComposer({ preserveCaption: true });
    if ($("#storyCaption")) $("#storyCaption").value = caption;

    const post = $("#postStoryBtn");
    if (post) {
      post.disabled = true;
      post.textContent = originalKind === "image" ? "Preparing photo…" : "Preparing video…";
    }

    let prepared = file;

    if (originalKind === "image") {
      if (file.size > 40 * 1024 * 1024) {
        toast("That photo is too large to prepare.");
        if (post) post.textContent = "Post story";
        return;
      }
      prepared = await optimizeStoryImage(file);
      if (prepared.size > 12 * 1024 * 1024) {
        toast("That photo is still too large. Choose a smaller photo.");
        if (post) post.textContent = "Post story";
        return;
      }
    } else if (file.size > 24 * 1024 * 1024) {
      toast("Story videos can be up to 24 MB.");
      if (post) post.textContent = "Post story";
      return;
    }

    state.pendingStoryFile = prepared;
    state.pendingStoryPreviewUrl = URL.createObjectURL(prepared);

    const preview = $("#storyComposerPreview");
    const kind = storyFileKind(prepared);
    const media = document.createElement(kind === "video" ? "video" : "img");
    media.src = state.pendingStoryPreviewUrl;

    if (media instanceof HTMLVideoElement) {
      media.controls = true;
      media.playsInline = true;
      media.preload = "metadata";
      media.muted = false;
    } else {
      media.alt = "Story preview";
      media.decoding = "async";
    }

    media.addEventListener("error", () => {
      toast("This media could not be previewed on this device.");
    }, { once: true });

    preview.replaceChildren(media);
    preview.classList.remove("hidden");
    updateStoryOverlayPreview();

    const meta = $("#storyComposerMeta");
    if (meta) {
      const optimized = prepared !== file && prepared.size < file.size;
      meta.textContent = `${kind === "video" ? "Video" : "Photo"} · ${formatFileSize(prepared.size)}${optimized ? " · optimized for faster upload" : ""}`;
      meta.classList.remove("hidden");
    }

    $("#changeStoryMediaBtn")?.classList.remove("hidden");

    if (post) {
      post.disabled = false;
      post.textContent = "Post story";
    }
  }

  async function postStory() {
    const file = state.pendingStoryFile;
    if (!file) return;

    const button = $("#postStoryBtn");
    button.disabled = true;
    button.textContent = "Posting…";

    try {
      const overlay = $("#storyOverlayText")?.value.trim() || "";
      if (file.type.startsWith("video/") && overlay) {
        toast("For video stories, add text in the caption.");
        button.disabled = false;
        button.textContent = "Post story";
        return;
      }
      const prepared = overlay ? await storyImageWithText(file, overlay) : file;
      const uploaded = await uploadFile(prepared, "story");
      await api("story_create", {
        method: "POST",
        body: {
          upload_token: uploaded.token,
          caption: $("#storyCaption").value.trim(),
          retention_days: Number($("#storyRetention")?.value || 30),
          visibility: $("#storyAudience")?.value || "friends",
          audience: Array.isArray(window.SilkNexV53?.storyAudienceIds)
            ? window.SilkNexV53.storyAudienceIds
            : [],
        },
      });

      clearStoryComposer();
      closeModal();
      await loadStories();
      try { navigator.vibrate?.([12, 24, 12]); } catch {}
      toast("Story posted.");
    } catch (error) {
      toast(error.message || "Could not post story.");
      button.disabled = false;
      button.textContent = "Post story";
    }
  }

  function activeStory() {
    const group = state.storyGroups[state.activeStoryGroupIndex];
    return group?.stories?.[state.activeStoryIndex] || null;
  }

  function clearStoryPlayback() {
    clearTimeout(state.storyTimer);
    state.storyTimer = null;
    state.storyTimerStartedAt = 0;
    state.storyTimerRemainingMs = 6000;
    state.storyPaused = false;
    $("#storyProgress")?.classList.remove("paused");

    const media = $("#storyViewerMedia");
    const video = media?.querySelector("video");
    if (video) {
      try { video.pause(); } catch {}
    }
  }

  function setStoryPaused(paused) {
    if (state.activeStoryGroupIndex < 0) return;
    const nextPaused = Boolean(paused);
    if (state.storyPaused === nextPaused) return;

    state.storyPaused = nextPaused;
    $("#storyProgress")?.classList.toggle("paused", nextPaused);

    const media = $("#storyViewerMedia")?.querySelector("video, img");
    if (media instanceof HTMLVideoElement) {
      if (nextPaused) {
        try { media.pause(); } catch {}
      } else {
        media.play().catch(() => {
          media.controls = true;
        });
      }
      return;
    }

    if (!(media instanceof HTMLImageElement)) return;

    if (nextPaused) {
      if (state.storyTimer) {
        const elapsed = Math.max(0, Date.now() - Number(state.storyTimerStartedAt || Date.now()));
        state.storyTimerRemainingMs = Math.max(
          250,
          Number(state.storyTimerRemainingMs || 6000) - elapsed
        );
        clearTimeout(state.storyTimer);
        state.storyTimer = null;
      }
      return;
    }

    clearTimeout(state.storyTimer);
    state.storyTimerStartedAt = Date.now();
    state.storyTimer = setTimeout(
      nextStory,
      Math.max(250, Number(state.storyTimerRemainingMs || 6000))
    );
  }

  function closeStoryViewer() {
    clearStoryPlayback();
    if (state.storyViewQueue.size) flushStoryViews().catch(() => {});
    state.activeStoryGroupIndex = -1;
    state.activeStoryIndex = -1;
  }

  async function flushStoryViews() {
    clearTimeout(state.storyViewFlushTimer);
    state.storyViewFlushTimer = null;
    if (!state.me || !state.storyViewQueue.size) return;

    const ids = [...state.storyViewQueue]
      .map((id) => Number(id))
      .filter((id) => Number.isInteger(id) && id > 0)
      .slice(0, 25);
    if (!ids.length) {
      state.storyViewQueue.clear();
      return;
    }

    ids.forEach((id) => state.storyViewQueue.delete(id));

    try {
      const data = await api("story_views", {
        method: "POST",
        body: { story_ids: ids },
        showLoader: false,
        keepalive: true,
        timeoutMs: 10000,
      });
      window.SilknexAds?.handleStoryAd?.(data);
    } catch {
      // A failed analytics/view acknowledgement must never interrupt story
      // playback. Requeue once; later swipes or visibility changes flush it.
      ids.forEach((id) => state.storyViewQueue.add(id));
    }

    if (state.storyViewQueue.size) {
      state.storyViewFlushTimer = setTimeout(flushStoryViews, 650);
    }
  }

  function markStoryViewed(story) {
    if (!story || story.viewed) return;
    story.viewed = true;
    renderStoriesRail();
    if (story.mine) return;

    state.storyViewQueue.add(Number(story.id));
    clearTimeout(state.storyViewFlushTimer);
    state.storyViewFlushTimer = setTimeout(flushStoryViews, 320);
  }

  function renderStoryProgress(group, index, isVideo) {
    const progress = $("#storyProgress");
    progress.replaceChildren();
    group.stories.forEach((_, itemIndex) => {
      const segment = document.createElement("span");
      if (itemIndex < index) segment.classList.add("done");
      if (itemIndex === index && !isVideo) segment.classList.add("active");
      progress.appendChild(segment);
    });
  }

  function renderActiveStory() {
    clearStoryPlayback();
    const group = state.storyGroups[state.activeStoryGroupIndex];
    const story = group?.stories?.[state.activeStoryIndex];
    if (!group || !story) {
      closeModal();
      return;
    }

    setAvatar(
      $("#storyViewerAvatar"),
      group.display_name,
      group.accent,
      group.avatar_url,
      group.avatar_style
    );
    $("#storyViewerName").textContent = group.mine ? "Your story" : group.display_name;
    $("#storyViewerTime").textContent =
      `${formatStoryTime(story.created_at)} · ${group.mine ? `${story.view_count || 0} views` : `@${group.username}`}${isFounderRole(group.role) ? " · " + founderBadgeNode(group.role).textContent : ""}`;
    $("#deleteStoryBtn").classList.toggle("hidden", !group.mine);

    const mediaWrap = $("#storyViewerMedia");
    const isVideo = story.media_type === "video";
    const media = document.createElement(isVideo ? "video" : "img");
    media.src = story.media_url;
    if (isVideo) {
      media.autoplay = true;
      media.playsInline = true;
      media.preload = "auto";
      media.controls = false;
      media.addEventListener("ended", nextStory, { once: true });
      media.addEventListener("loadeddata", () => {
        media.play().catch(() => {
          media.controls = true;
          toast("Tap play to view this story.");
        });
      }, { once: true });
    } else {
      media.alt = `${group.display_name}'s story`;
      media.decoding = "async";
      media.loading = "eager";
      try { media.fetchPriority = "high"; } catch {}
      state.storyTimerRemainingMs = 6000;
      state.storyTimerStartedAt = Date.now();
      state.storyTimer = setTimeout(nextStory, state.storyTimerRemainingMs);
    }
    mediaWrap.replaceChildren(media);
    const direction = state.storyTransitionDirection || "next";
    state.storyTransitionDirection = "";
    mediaWrap.dataset.storyDirection = direction;
    mediaWrap.classList.remove("story-snap-in");
    void mediaWrap.offsetWidth;
    mediaWrap.classList.add("story-snap-in");

    const caption = $("#storyViewerCaption");
    caption.textContent = story.caption || "";
    caption.classList.toggle("hidden", !story.caption);
    renderStoryProgress(group, state.activeStoryIndex, isVideo);

    // Warm the next story only. This keeps Snapchat-like forward taps instant
    // without decoding the whole story tray into memory.
    const nextInGroup = group.stories?.[state.activeStoryIndex + 1] || null;
    const nextGroup = state.storyGroups?.[state.activeStoryGroupIndex + 1];
    const upcoming = nextInGroup || nextGroup?.stories?.[0] || null;
    if (upcoming?.media_url) {
      if (upcoming.media_type === "video") {
        const preloader = document.createElement("video");
        preloader.preload = "metadata";
        preloader.src = upcoming.media_url;
      } else {
        const preloader = new Image();
        preloader.decoding = "async";
        preloader.src = upcoming.media_url;
      }
    }

    markStoryViewed(story);
  }

  function openStory(groupIndex, storyIndex = 0) {
    if (!state.storyGroups[groupIndex]) return;
    state.activeStoryGroupIndex = groupIndex;
    state.activeStoryIndex = Math.max(
      0,
      Math.min(storyIndex, state.storyGroups[groupIndex].stories.length - 1)
    );
    openModal("#storyViewerModal");
    renderActiveStory();
  }

  function nextStory() {
    state.storyTransitionDirection = "next";
    const group = state.storyGroups[state.activeStoryGroupIndex];
    if (!group) return;

    if (state.activeStoryIndex + 1 < group.stories.length) {
      state.activeStoryIndex += 1;
      renderActiveStory();
      return;
    }

    if (state.activeStoryGroupIndex + 1 < state.storyGroups.length) {
      state.activeStoryGroupIndex += 1;
      state.activeStoryIndex = 0;
      renderActiveStory();
      return;
    }

    closeModal();
  }

  function previousStory() {
    state.storyTransitionDirection = "previous";
    const group = state.storyGroups[state.activeStoryGroupIndex];
    if (!group) return;

    if (state.activeStoryIndex > 0) {
      state.activeStoryIndex -= 1;
      renderActiveStory();
      return;
    }

    if (state.activeStoryGroupIndex > 0) {
      state.activeStoryGroupIndex -= 1;
      const previous = state.storyGroups[state.activeStoryGroupIndex];
      state.activeStoryIndex = Math.max(0, previous.stories.length - 1);
      renderActiveStory();
    }
  }

  async function deleteActiveStory() {
    const story = activeStory();
    if (!story?.mine) return;

    $("#deleteStoryBtn").disabled = true;
    try {
      await api("story_delete", {
        method: "POST",
        body: { story_id: story.id },
      });
      closeModal();
      await loadStories();
      toast("Story deleted.");
    } catch (error) {
      toast(error.message || "Could not delete story.");
    } finally {
      $("#deleteStoryBtn").disabled = false;
    }
  }

  async function handleAvatarFile(file) {
    if (!file) return;
    await openAvatarCrop(file);
  }

  async function saveProfile(event) {
    event.preventDefault();
    const submit = $("#profileForm button[type='submit']");
    submit.disabled = true;

    try {
      const data = await api("profile", {
        method: "POST",
        body: {
          display_name: $("#displayName").value.trim(),
          about: $("#about").value.trim(),
          accent: state.selectedAccent,
          avatar_token: state.avatarToken || undefined,
          remove_avatar: state.removeAvatar,
          avatar_style: state.avatarUsingStyle ? state.avatarStyleDraft : null,
        },
      });

      state.me = data.user;
      state.avatarToken = "";
      state.removeAvatar = false;
      state.avatarPreviewUrl = state.me.avatar_url || "";
      state.avatarStyleDraft = normalizedAvatarStyle(state.me.avatar_style || AVATAR_DEFAULT);
      state.avatarUsingStyle = Boolean(
        state.me.avatar_style &&
        Object.keys(state.me.avatar_style).length &&
        !state.me.avatar_url
      );

      for (const [id, message] of state.messages.entries()) {
        if (message.sender_id === state.me.id) {
          state.messages.set(id, {
            ...message,
            sender_display_name: state.me.display_name,
            sender_accent: state.me.accent,
            sender_avatar_url: state.me.avatar_url,
            sender_avatar_style: state.me.avatar_style,
            sender_role: state.me.role || "member",
          });
        }
      }

      renderMe();
      rebuildMessages();
      updateProfilePreview();
      toast("Profile saved.");
      loadConversations().catch(() => {});
      loadFriends({ notify: true }).catch(() => {});
      loadStories().catch(() => {});
      pollIncomingCall().catch(() => {});

      if (state.activeId) {
        try {
          const conversation = await api("conversation", {}, { id: state.activeId });
          state.activeConversation = conversation.conversation;
          renderChatHeader();
          applyChatWallpaper(state.activeConversation.preferences);
        } catch {}
      }
    } catch (error) {
      toast(error.message);
    } finally {
      submit.disabled = false;
    }
  }

  function previewThemeAndIcon() {
    const theme = resolvedTheme(state.themeChoice);
    document.documentElement.dataset.themeChoice = state.themeChoice;
    document.documentElement.dataset.theme = theme;
    applyAppIcon(state.iconStyleChoice, state.themeChoice);

    const color = theme === "light"
      ? "#f3f5f8"
      : theme === "amoled"
        ? "#000000"
        : "#090a0d";
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", color);
  }

  function renderThemeButtons() {
    $$("[data-theme-choice]").forEach((button) => {
      const active = button.dataset.themeChoice === state.themeChoice;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });
  }

  function renderIconButtons() {
    $$("[data-icon-style-choice]").forEach((button) => {
      const active = button.dataset.iconStyleChoice === state.iconStyleChoice;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
    });
  }

  function renderWallpaperPicker() {
    $$("#wallpaperPicker [data-wallpaper]").forEach((button) => {
      button.classList.toggle(
        "selected",
        button.dataset.wallpaper === state.wallpaperChoice
      );
    });

    $("#customWallpaperBtn").classList.toggle(
      "selected",
      state.wallpaperChoice === "custom"
    );

    const preview = $("#wallpaperPreviewFrame");
    if (preview) {
      const choice = state.wallpaperChoice || "neo";
      preview.className =
        "wallpaper-preview-frame " +
        (choice === "custom" ? "custom-wallpaper" : `wallpaper-${choice}`);
      preview.style.backgroundImage =
        choice === "custom" && state.wallpaperPreviewUrl
          ? `linear-gradient(rgba(0,0,0,.08),rgba(0,0,0,.08)),url("${state.wallpaperPreviewUrl}")`
          : "";
    }
  }

  async function handleWallpaperUpload(file, forChat = false) {
    if (!file) return;
    toast("Uploading wallpaper…");

    try {
      const uploaded = await uploadFile(file, "wallpaper");

      if (forChat) {
        state.chatWallpaperChoice = "custom";
        state.chatWallpaperToken = uploaded.token;
        state.chatWallpaperPreviewUrl = uploaded.url;
        renderChatWallpaperPicker();

        applyChatWallpaper({
          ...(state.activeConversation?.preferences || {}),
          wallpaper: "custom",
          wallpaper_url: uploaded.url,
        });
      } else {
        state.wallpaperChoice = "custom";
        state.wallpaperToken = uploaded.token;
        state.wallpaperPreviewUrl = uploaded.url;
        renderWallpaperPicker();

        if (
          state.activeConversation &&
          (state.activeConversation.preferences?.wallpaper || "default") === "default"
        ) {
          applyChatWallpaper({
            ...(state.activeConversation.preferences || {}),
            wallpaper: "custom",
            wallpaper_url: uploaded.url,
          });
        }
      }

      toast("Custom wallpaper ready. Save to keep it.");
    } catch (error) {
      toast(error.message);
    }
  }

  async function savePreferences(event) {
    event.preventDefault();

    const submit = $("#preferencesForm button[type='submit']");
    submit.disabled = true;

    try {
      let notificationsEnabled = $("#notificationsToggle").checked;
      let backgroundPushReady = false;

      if (notificationsEnabled) {
        notificationsEnabled = await requestNotifications();
        $("#notificationsToggle").checked = notificationsEnabled;

        if (notificationsEnabled) {
          try {
            backgroundPushReady = await ensurePushSubscription();
          } catch {
            backgroundPushReady = false;
          }
        }
      } else {
        await removePushSubscription();
      }

      const data = await api("preferences", {
        method: "POST",
        body: {
          theme: state.themeChoice,
          app_icon_style: state.iconStyleChoice,
          wallpaper: state.wallpaperChoice,
          wallpaper_token: state.wallpaperToken || undefined,
          font_scale: $("#fontScale").value,
          font_family: $("#fontFamily").value,
          ui_accent: $("#uiAccent").value,
          bubble_style: $("#bubbleStyle").value,
          message_density: $("#messageDensity").value,
          chat_width: $("#chatWidth").value,
          reduce_motion: $("#reduceMotionToggle").checked,
          easy_mode: $("#easyModeToggle").checked,
          notifications_enabled: notificationsEnabled,
        },
      });

      state.me = data.user;
      state.themeChoice = state.me.theme;
      state.iconStyleChoice = state.me.app_icon_style || "auto";
      state.fontScaleChoice = state.me.font_scale;
      state.fontFamilyChoice = state.me.font_family || "system";
      state.uiAccentChoice = state.me.ui_accent || "silver";
      state.bubbleStyleChoice = state.me.bubble_style || "rounded";
      state.messageDensityChoice = state.me.message_density || "normal";
      state.chatWidthChoice = state.me.chat_width || "normal";
      state.reduceMotionChoice = Boolean(state.me.reduce_motion);
      state.easyModeChoice = Boolean(state.me.easy_mode);
      state.wallpaperChoice = state.me.wallpaper;
      state.wallpaperToken = "";
      state.wallpaperPreviewUrl = state.me.wallpaper_url || "";
      state.notificationsChoice = Boolean(state.me.notifications_enabled);

      applyAppearance(state.me);
      applyChatWallpaper(state.activeConversation?.preferences);
      renderThemeButtons();
      renderIconButtons();
      renderWallpaperPicker();

      if (notificationsEnabled && !backgroundPushReady) {
        toast("Saved. Notifications work while SilkNex is open; background Push is unavailable on this browser/server.");
      } else {
        toast("Appearance saved.");
      }
    } catch (error) {
      toast(error.message);
    } finally {
      submit.disabled = false;
    }
  }

  async function loadKidSettings() {
    try {
      const data = await api("kid_settings");
      $("#kidModeToggle").checked = Boolean(data.kid.enabled);
      $("#kidWords").value = data.kid.custom_words || "";
      $("#kidPassword").value = "";
    } catch {}
  }

  async function saveKidSettings(event) {
    event.preventDefault();

    const submit = $("#kidForm button[type='submit']");
    submit.disabled = true;

    try {
      const data = await api("kid_settings", {
        method: "POST",
        body: {
          enabled: $("#kidModeToggle").checked,
          kid_password: $("#kidPassword").value,
          custom_words: $("#kidWords").value,
        },
      });

      state.me = data.user;
      renderMe();
      $("#kidPassword").value = "";
      toast(state.me.kid_mode ? "Kid chat filter enabled." : "Kid chat filter disabled.");

      if (state.activeId) {
        state.messages.clear();
        state.firstMessageId = 0;
    state.syncAfterId = 0;
    state.hasNewerHistory = false;
    state.historyRequestId += 1;
        state.lastMessageId = 0;
        await loadMessages({ initial: true });
      }

      await loadConversations();
    } catch (error) {
      toast(error.message);
    } finally {
      submit.disabled = false;
    }
  }

  async function loadSecurityStatus() {
    try {
      const data = await api("security_status");
      const algorithm = String(data.password_algorithm || "secure hash");
      $("#securityHash").textContent =
        algorithm.toLowerCase().includes("argon") ? "Argon2id" : algorithm;
      $("#securityServerKey").textContent =
        data.password_server_keyed ? "Enabled" : "Standard";
      $("#securityLogins").textContent = `${Number(data.saved_logins || 0)} saved`;
      $("#securityBinding").textContent =
        data.login_binding === "browser-bound" ? "Browser-bound" : "Protected";
      $("#securityPasskeys").textContent = `${Number(data.passkeys || 0)} active`;
      $("#securityRotation").textContent =
        `${Number(data.session_rotation_minutes || 15)} min`;
      $("#securityEncryption").textContent =
        data.message_encryption || "AES-256-GCM";
    } catch {}
  }

  async function changePassword(event) {
    event.preventDefault();

    const currentPassword = $("#currentPassword").value;
    const newPassword = $("#newPassword").value;
    const confirm = $("#newPasswordConfirm").value;

    if (!passwordIsValid(newPassword)) {
      toast("New password needs 8+ characters, 1 number, and 1 symbol.");
      return;
    }

    if (newPassword !== confirm) {
      toast("The new passwords do not match.");
      return;
    }

    const submit = $("#passwordForm button[type='submit']");
    submit.disabled = true;

    try {
      const data = await api("change_password", {
        method: "POST",
        body: {
          current_password: currentPassword,
          new_password: newPassword,
          new_password_confirm: confirm,
        },
      });

      if (data.csrf) state.csrf = data.csrf;

      $("#currentPassword").value = "";
      $("#newPassword").value = "";
      $("#newPasswordConfirm").value = "";
      toast("Password changed. Other logins were revoked.");
      loadSecurityStatus();
    } catch (error) {
      toast(error.message);
    } finally {
      submit.disabled = false;
    }
  }

  async function logoutOtherDevices() {
    $("#logoutOtherDevicesBtn").disabled = true;

    try {
      const data = await api("logout_other_devices", {
        method: "POST",
        body: {},
      });

      if (data.csrf) state.csrf = data.csrf;
      toast("Other devices were signed out.");
      loadSecurityStatus();
    } catch (error) {
      toast(error.message);
    } finally {
      $("#logoutOtherDevicesBtn").disabled = false;
    }
  }

  async function addPasskey() {
    if (!window.PublicKeyCredential || !navigator.credentials || !window.isSecureContext) {
      toast("Passkeys require HTTPS and a compatible browser.");
      return;
    }

    $("#addPasskeyBtn").disabled = true;

    try {
      const optionsData = await api("passkey_register_options");
      const publicKey = optionsData.publicKey;

      publicKey.challenge = base64UrlToBytes(publicKey.challenge);
      publicKey.user.id = base64UrlToBytes(publicKey.user.id);

      publicKey.excludeCredentials = (publicKey.excludeCredentials || []).map(
        (credential) => ({
          ...credential,
          id: base64UrlToBytes(credential.id),
        })
      );

      const credential = await navigator.credentials.create({ publicKey });
      if (!credential) throw new Error("Passkey creation was canceled.");

      const transports =
        typeof credential.response.getTransports === "function"
          ? credential.response.getTransports()
          : [];

      await api("passkey_register_finish", {
        method: "POST",
        body: {
          rawId: bytesToBase64Url(credential.rawId),
          clientDataJSON: bytesToBase64Url(credential.response.clientDataJSON),
          attestationObject: bytesToBase64Url(credential.response.attestationObject),
          transports,
        },
      });

      toast("Passkey added.");
      await loadPasskeys();
    } catch (error) {
      toast(
        error?.name === "NotAllowedError"
          ? "Passkey creation was canceled."
          : error.message || "Could not add passkey."
      );
    } finally {
      $("#addPasskeyBtn").disabled = false;
    }
  }

  async function loadPasskeys() {
    const list = $("#passkeyList");
    list.replaceChildren();

    if (!window.PublicKeyCredential || !window.isSecureContext) {
      const item = document.createElement("div");
      item.className = "passkey-item";
      item.textContent = "Passkeys require HTTPS and a supported browser.";
      list.appendChild(item);
      return;
    }

    try {
      const data = await api("passkeys");

      if (!data.passkeys.length) {
        const item = document.createElement("div");
        item.className = "passkey-item";
        item.textContent = "No passkeys added yet.";
        list.appendChild(item);
        return;
      }

      for (const passkey of data.passkeys) {
        const item = document.createElement("div");
        item.className = "passkey-item";

        const icon = document.createElement("span");
        icon.className = "passkey-icon";
        icon.appendChild(iconNode("spark"));

        const copy = document.createElement("div");
        const title = document.createElement("b");
        title.textContent = "Passkey";
        const detail = document.createElement("small");
        detail.textContent = passkey.last_used_at
          ? `Last used ${new Date(passkey.last_used_at * 1000).toLocaleDateString()}`
          : `Added ${new Date(passkey.created_at * 1000).toLocaleDateString()}`;
        copy.append(title, detail);

        const remove = document.createElement("button");
        remove.type = "button";
        remove.className = "text-btn";
        remove.textContent = "Remove";
        remove.addEventListener("click", async () => {
          remove.disabled = true;
          try {
            await api("passkey_remove", {
              method: "POST",
              body: { passkey_id: passkey.id },
            });
            await loadPasskeys();
            toast("Passkey removed.");
          } catch (error) {
            toast(error.message);
            remove.disabled = false;
          }
        });

        item.append(icon, copy, remove);
        list.appendChild(item);
      }
    } catch (error) {
      const item = document.createElement("div");
      item.className = "passkey-item";
      item.textContent = error.message;
      list.appendChild(item);
    }
  }

  function renderChatWallpaperPicker() {
    $$("#chatWallpaperPicker [data-wallpaper]").forEach((button) => {
      button.classList.toggle(
        "selected",
        button.dataset.wallpaper === state.chatWallpaperChoice
      );
    });

    $("#chatCustomWallpaperBtn").classList.toggle(
      "selected",
      state.chatWallpaperChoice === "custom"
    );

    const preview = $("#chatWallpaperPreviewFrame");
    if (preview) {
      const choice = state.chatWallpaperChoice || "default";
      const fallbackChoice =
        choice === "default" ? (state.me?.wallpaper || "neo") : choice;
      preview.className =
        "wallpaper-preview-frame " +
        (fallbackChoice === "custom"
          ? "custom-wallpaper"
          : `wallpaper-${fallbackChoice}`);
      const customUrl =
        choice === "default"
          ? (state.me?.wallpaper_url || "")
          : state.chatWallpaperPreviewUrl;
      preview.style.backgroundImage =
        fallbackChoice === "custom" && customUrl
          ? `linear-gradient(rgba(0,0,0,.08),rgba(0,0,0,.08)),url("${customUrl}")`
          : "";
    }
  }

  function openChatSettings() {
    if (!state.activeConversation) return;

    const preferences =
      state.activeConversation.preferences ||
      { wallpaper: "default", wallpaper_url: "" };

    state.chatWallpaperChoice = preferences.wallpaper || "default";
    state.chatWallpaperToken = "";
    state.chatWallpaperPreviewUrl = preferences.wallpaper_url || "";
    state.chatRingtoneChoice = preferences.ringtone || "classic";
    state.chatBubbleStyleChoice = preferences.bubble_style || "default";
    state.chatDensityChoice = preferences.density || "default";
    state.chatFontScaleChoice = preferences.chat_font_scale || "default";
    state.chatDisappearingChoice = Number(preferences.disappearing_seconds || 0);

    $("#chatRingtone").value = state.chatRingtoneChoice;
    $("#callBannerText").value = preferences.call_banner_text || "";
    $("#callBannerStyle").value = preferences.call_banner_style || "glass";
    $("#callBannerSize").value = window.SilknexStorage.getItem(`silknex:banner-size:${state.me?.id}:${state.activeId}`) || "compact";
    $("#chatBubbleStyle").value = state.chatBubbleStyleChoice;
    $("#chatDensity").value = state.chatDensityChoice;
    $("#chatFontScale").value = state.chatFontScaleChoice;
    $("#chatDisappearing").value = String(state.chatDisappearingChoice);

    const direct = state.activeConversation.kind === "dm";
    $("#directIdentitySettings").classList.toggle("hidden", !direct);
    $("#callBannerSettings").classList.toggle("hidden", !direct);
    $("#groupVoteSettings").classList.toggle("hidden", direct);

    if (direct) {
      const other = state.activeConversation.members?.find(
        (member) => member.id !== state.me.id
      );
      $("#friendNicknameInput").value = other?.nickname || "";
    } else {
      $("#groupRenameInput").value = "";
      state.groupAvatarToken = "";
      if (state.groupAvatarPreviewUrl) URL.revokeObjectURL(state.groupAvatarPreviewUrl);
      state.groupAvatarPreviewUrl = "";
      $("#groupAvatarProposalPreview").classList.add("hidden");
      $("#proposeGroupAvatarBtn").classList.add("hidden");
      renderGroupProposals();
    }

    renderChatWallpaperPicker();
    openModal("#chatSettingsModal");
  }

  async function saveChatWallpaper() {
    if (!state.activeId) return;

    $("#saveChatWallpaperBtn").disabled = true;

    try {
      const data = await api("conversation_preferences", {
        method: "POST",
        body: {
          conversation_id: state.activeId,
          wallpaper: state.chatWallpaperChoice,
          wallpaper_token: state.chatWallpaperToken || undefined,
          ringtone: $("#chatRingtone").value,
          bubble_style: $("#chatBubbleStyle").value,
          density: $("#chatDensity").value,
          chat_font_scale: $("#chatFontScale").value,
          call_banner_text: $("#callBannerText").value.trim(),
          call_banner_style: $("#callBannerStyle").value,
          disappearing_seconds: Number($("#chatDisappearing").value || 0),
        },
      });

      state.activeConversation.preferences = data.preferences;
      window.SilknexStorage.setItem(`silknex:banner-size:${state.me?.id}:${state.activeId}`, $("#callBannerSize").value);
      state.chatWallpaperToken = "";
      state.chatWallpaperPreviewUrl = data.preferences.wallpaper_url || "";
      applyChatWallpaper(data.preferences);
      closeModal();
      toast("Conversation settings saved.");
    } catch (error) {
      toast(error.message);
    } finally {
      $("#saveChatWallpaperBtn").disabled = false;
    }
  }

  async function saveFriendNickname() {
    const conversation = state.activeConversation;
    if (!conversation || conversation.kind !== "dm") return;

    const other = conversation.members?.find((member) => member.id !== state.me.id);
    if (!other) return;

    const button = $("#saveNicknameBtn");
    button.disabled = true;
    try {
      const data = await api("set_nickname", {
        method: "POST",
        body: {
          friend_id: other.id,
          nickname: $("#friendNicknameInput").value.trim(),
        },
      });
      other.nickname = data.nickname || "";
      conversation.title = other.nickname || other.display_name;
      renderChatHeader();
      state.conversationFingerprint = "";
      loadConversations().catch(() => {});
      toast(other.nickname ? "Nickname saved." : "Nickname removed.");
    } catch (error) {
      toast(error.message);
    } finally {
      button.disabled = false;
    }
  }

  function renderGroupProposals() {
    const list = $("#groupProposalList");
    if (!list) return;
    list.replaceChildren();

    const proposals = state.activeConversation?.group_proposals || [];
    if (!proposals.length) {
      const empty = document.createElement("div");
      empty.className = "proposal-empty";
      empty.textContent = "No active group votes.";
      list.appendChild(empty);
      return;
    }

    for (const proposal of proposals) {
      const item = document.createElement("div");
      item.className = "proposal-card";

      const head = document.createElement("div");
      head.className = "proposal-head";
      const title = document.createElement("strong");
      title.textContent = proposal.change_type === "name"
        ? `Rename to “${proposal.proposed_name}”`
        : "Change the group photo";
      const meta = document.createElement("small");
      meta.textContent = `${proposal.proposer_name} · ${proposal.yes_count}/${proposal.member_count} yes`;
      head.append(title, meta);

      if (proposal.change_type === "avatar" && proposal.proposed_avatar_url) {
        const image = document.createElement("img");
        image.src = proposal.proposed_avatar_url;
        image.alt = "Proposed group photo";
        image.className = "proposal-avatar";
        item.appendChild(image);
      }

      const actions = document.createElement("div");
      actions.className = "proposal-actions";
      for (const vote of ["yes", "no"]) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "secondary-btn";
        button.textContent = vote === "yes" ? "Yes" : "No";
        button.classList.toggle("selected", proposal.viewer_vote === vote);
        button.addEventListener("click", () => voteOnGroupChange(proposal.id, vote, button));
        actions.appendChild(button);
      }

      item.append(head, actions);
      list.appendChild(item);
    }
  }

  async function proposeGroupName() {
    if (state.activeConversation?.kind !== "group") return;
    const name = $("#groupRenameInput").value.trim();
    if (!name) {
      toast("Enter a new group name.");
      return;
    }

    const button = $("#proposeGroupNameBtn");
    button.disabled = true;
    try {
      await api("group_change_propose", {
        method: "POST",
        body: {
          conversation_id: state.activeId,
          change_type: "name",
          name,
        },
      });
      $("#groupRenameInput").value = "";
      await refreshActiveConversation();
      renderGroupProposals();
      toast("Group name vote started.");
    } catch (error) {
      toast(error.message);
    } finally {
      button.disabled = false;
    }
  }

  async function handleGroupAvatarFile(file) {
    if (!file || state.activeConversation?.kind !== "group") return;
    const button = $("#chooseGroupAvatarBtn");
    button.disabled = true;
    try {
      const data = await uploadFile(file, "avatar", "image");
      state.groupAvatarToken = data.token || "";
      if (state.groupAvatarPreviewUrl) URL.revokeObjectURL(state.groupAvatarPreviewUrl);
      state.groupAvatarPreviewUrl = URL.createObjectURL(file);

      const preview = $("#groupAvatarProposalPreview");
      preview.replaceChildren();
      const image = document.createElement("img");
      image.src = state.groupAvatarPreviewUrl;
      image.alt = "New group photo preview";
      preview.appendChild(image);
      preview.classList.remove("hidden");
      $("#proposeGroupAvatarBtn").classList.remove("hidden");
    } catch (error) {
      toast(error.message);
    } finally {
      button.disabled = false;
    }
  }

  async function proposeGroupAvatar() {
    if (!state.groupAvatarToken || state.activeConversation?.kind !== "group") return;
    const button = $("#proposeGroupAvatarBtn");
    button.disabled = true;
    try {
      await api("group_change_propose", {
        method: "POST",
        body: {
          conversation_id: state.activeId,
          change_type: "avatar",
          upload_token: state.groupAvatarToken,
        },
      });
      state.groupAvatarToken = "";
      if (state.groupAvatarPreviewUrl) URL.revokeObjectURL(state.groupAvatarPreviewUrl);
      state.groupAvatarPreviewUrl = "";
      $("#groupAvatarProposalPreview").classList.add("hidden");
      button.classList.add("hidden");
      await refreshActiveConversation();
      renderGroupProposals();
      toast("Group photo vote started.");
    } catch (error) {
      toast(error.message);
    } finally {
      button.disabled = false;
    }
  }

  async function voteOnGroupChange(proposalId, vote, button) {
    button.disabled = true;
    try {
      const data = await api("group_change_vote", {
        method: "POST",
        body: { proposal_id: proposalId, vote },
      });

      await refreshActiveConversation();
      state.conversationFingerprint = "";
      loadConversations().catch(() => {});
      renderGroupProposals();

      if (data.status === "approved") {
        toast("Vote passed. Group updated.");
      } else if (data.status === "rejected") {
        toast("Vote did not pass.");
      } else {
        toast("Vote saved.");
      }
    } catch (error) {
      toast(error.message);
    } finally {
      button.disabled = false;
    }
  }

  function askDeleteChat() {
    if (!state.activeId) return;
    closeModal();
    setTimeout(() => openModal("#deleteChatModal"), 0);
  }

  async function confirmDeleteChat() {
    if (!state.activeId) return;

    const conversationId = state.activeId;
    $("#confirmDeleteChatBtn").disabled = true;

    try {
      await api("delete_conversation", {
        method: "POST",
        body: { conversation_id: conversationId },
      });

      closeModal();

      state.syncController?.abort();
      state.syncController = null;
      state.syncBusy = false;
      clearTimeout(state.pollTimer);

      clearCurrentMobileChatHistory(conversationId);
      state.activeId = 0;
      state.mobileHistoryChatId = 0;
      state.activeConversation = null;
      state.messages.clear();
      state.firstMessageId = 0;
    state.syncAfterId = 0;
    state.hasNewerHistory = false;
    state.historyRequestId += 1;
      state.lastMessageId = 0;
      state.replyTo = null;

      $("#appView").classList.remove("mobile-chat-open");
      $("#appView").classList.remove("desktop-chat-active");
      $("#chatView").classList.add("hidden");
      $("#emptyState").classList.remove("hidden");
      document.title = "SilkNex";

      await loadConversations();
      toast("Chat deleted for your account.");
    } catch (error) {
      toast(error.message);
    } finally {
      $("#confirmDeleteChatBtn").disabled = false;
    }
  }

  function openMembers() {
    const members = state.activeConversation?.members || [];
    const list = $("#membersList");
    list.replaceChildren();

    for (const member of members) {
      list.appendChild(personRow(member));
    }

    closeModal();
    setTimeout(() => openModal("#membersModal"), 0);
  }

  function setMobileNavActive(buttonId = "mobileChatsBtn") {
    $$("#mobileNav .mobile-nav-item").forEach((button) => {
      const active = button.id === buttonId;
      button.classList.toggle("active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
  }

  function openModal(selector) {
    if (document.documentElement.dataset.schoolAccount === "true" && /gif|sticker/i.test(selector)) {
      toast("GIF and sticker creation is unavailable for school accounts."); return;
    }
    const modal = $(selector);
    if (!modal) return;

    state.lastFocus = document.activeElement;
    $("#modalOverlay").classList.remove("hidden");
    modal.classList.remove("hidden");
    window.dispatchEvent(new CustomEvent("silknex:modal", {
      detail: { open: true, id: modal.id || "" }
    }));

    setTimeout(() => {
      const preferred = modal.querySelector("[autofocus]");
      const firstControl = modal.querySelector(
        "button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled])"
      );
      const mobile = usesMobileShell();

      // Avoid opening the software keyboard just because a bottom sheet opened.
      // Explicit autofocus still wins for flows where typing is the whole task.
      if (preferred) {
        preferred.focus({ preventScroll: true });
      } else if (mobile) {
        (modal.querySelector(".close-modal:not([disabled]),button:not([disabled])") || firstControl)
          ?.focus({ preventScroll: true });
      } else {
        firstControl?.focus({ preventScroll: true });
      }
    }, 0);
  }

  function closeModal() {
    const gifMakerWasOpen =
      !$("#gifMakerModal").classList.contains("hidden");
    if (gifMakerWasOpen && state.gifEncoderBusy) {
      toast("Finishing your GIF…");
      return;
    }

    const giphyWasOpen = !$("#giphyModal").classList.contains("hidden");
    const stickerMakerWasOpen =
      !$("#stickerMakerModal").classList.contains("hidden");
    const mediaHoldWasOpen =
      !$("#mediaHoldModal").classList.contains("hidden");
    const settingsWasOpen = !$("#settingsModal").classList.contains("hidden");
    const chatSettingsWasOpen =
      !$("#chatSettingsModal").classList.contains("hidden");
    const storyComposerWasOpen =
      !$("#storyComposerModal").classList.contains("hidden");
    const storyViewerWasOpen =
      !$("#storyViewerModal").classList.contains("hidden");
    const avatarCropWasOpen =
      !$("#avatarCropModal").classList.contains("hidden");
    const hadModal = $$(".modal").some((modal) => !modal.classList.contains("hidden"));

    $("#modalOverlay").classList.add("hidden");
    $$(".modal").forEach((modal) => modal.classList.add("hidden"));

    if (storyComposerWasOpen) clearStoryComposer();
    if (storyViewerWasOpen) closeStoryViewer();
    if (avatarCropWasOpen && state.avatarCrop?.objectUrl) {
      URL.revokeObjectURL(state.avatarCrop.objectUrl);
      state.avatarCrop = null;
    }

    if (giphyWasOpen) {
      clearTimeout(state.giphySearchTimer);
      state.giphySearchTimer = null;
      state.giphyRequestId += 1;
    }

    if (stickerMakerWasOpen) {
      state.stickerSourceImage = null;
      if (state.stickerSourceRevocable && state.stickerSourceUrl?.startsWith?.("blob:")) {
        try { URL.revokeObjectURL(state.stickerSourceUrl); } catch {}
      }
      state.stickerSourceUrl = "";
      state.stickerSourceRevocable = false;
      state.stickerEraseMask = null;
      state.stickerDrawHistory = [];
      state.stickerDrawPointer = null;
    }

    if (mediaHoldWasOpen || stickerMakerWasOpen || gifMakerWasOpen) {
      clearTimeout(state.mediaHoldTimer);
      state.mediaHoldTimer = null;
      state.mediaHoldMessage = null;
    }

    if (gifMakerWasOpen) {
      const editorVideo = $("#gifMakerVideo");
      try {
        editorVideo.pause();
        editorVideo.removeAttribute("src");
        editorVideo.load();
      } catch {}
      if (state.gifSourceMessage?.local_creator_source && state.gifSourceMessage?.revoke_url) {
        try { URL.revokeObjectURL(state.gifSourceMessage.revoke_url); } catch {}
      }
      state.gifSourceMessage = null;
    }

    state.editingMessage = null;
    state.deletingMessageId = 0;

    if (hadModal && state.lastFocus instanceof HTMLElement) {
      // Restoring focus to an editable control on phones immediately reopens
      // the software keyboard after closing a sheet/modal. That made GIF,
      // sticker, settings, and schedule flows feel like they were fighting the
      // user. Restore buttons/links normally, but leave mobile text controls
      // unfocused until the user explicitly taps them again.
      const mobile = usesMobileShell();
      const editable = state.lastFocus.matches?.(
        "input, textarea, select, [contenteditable='true']"
      );

      if (!mobile || !editable) {
        try {
          state.lastFocus.focus({ preventScroll: true });
        } catch {
          state.lastFocus.focus();
        }
      }
    }

    state.lastFocus = null;

    if (usesMobileShell()) {
      setMobileNavActive(
        storyViewerWasOpen || storyComposerWasOpen
          ? "mobileStoriesBtn"
          : "mobileChatsBtn"
      );
    }

    if (settingsWasOpen && state.me) {
      applyAppearance(state.me);
      applyChatWallpaper(state.activeConversation?.preferences);
      state.themeChoice = state.me.theme || "dark";
      state.iconStyleChoice = state.me.app_icon_style || "auto";
      state.fontScaleChoice = state.me.font_scale || "normal";
      state.fontFamilyChoice = state.me.font_family || "system";
      state.uiAccentChoice = state.me.ui_accent || "silver";
      state.bubbleStyleChoice = state.me.bubble_style || "rounded";
      state.messageDensityChoice = state.me.message_density || "normal";
      state.chatWidthChoice = state.me.chat_width || "normal";
      state.reduceMotionChoice = Boolean(state.me.reduce_motion);
    }

    if (chatSettingsWasOpen && state.activeConversation) {
      applyChatWallpaper(state.activeConversation.preferences);
      state.chatWallpaperToken = "";
      state.chatWallpaperPreviewUrl =
        state.activeConversation.preferences?.wallpaper_url || "";
    }

    if (hadModal) {
      window.dispatchEvent(new CustomEvent("silknex:modal", {
        detail: { open: false, id: storyViewerWasOpen ? "storyViewerModal" : "" }
      }));
    }
  }

  function trapModalFocus(event) {
    if (event.key !== "Tab") return;

    // Some workflows intentionally open a child modal on top of a parent
    // (profile-photo crop is one example). Trap focus in the top-most visible
    // dialog rather than the first dialog in DOM order.
    const visibleModals = $$(".modal").filter(
      (item) => !item.classList.contains("hidden") && item.getClientRects().length > 0
    );
    const modal = visibleModals.length ? visibleModals[visibleModals.length - 1] : null;
    if (!modal) return;

    const focusable = [...modal.querySelectorAll(
      "button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),a[href],[tabindex]:not([tabindex='-1'])"
    )].filter((element) => {
      if (!(element instanceof HTMLElement) || element.hidden) return false;
      if (element.getAttribute("aria-hidden") === "true") return false;
      if (element.closest(".hidden,[aria-hidden='true']")) return false;
      return element.getClientRects().length > 0;
    });

    if (!focusable.length) {
      event.preventDefault();
      return;
    }

    const first = focusable[0];
    const last = focusable[focusable.length - 1];

    if (!modal.contains(document.activeElement)) {
      event.preventDefault();
      (event.shiftKey ? last : first).focus();
      return;
    }

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  /* ---------------- Calls / WebRTC ---------------- */

  function unlockRingtoneAudio() {
    const AudioContextClass =
      window.AudioContext || window.webkitAudioContext;

    if (!AudioContextClass) return;

    try {
      if (!state.ringtoneContext) {
        state.ringtoneContext = new AudioContextClass({
          latencyHint: "interactive",
        });
      }

      const context = state.ringtoneContext;
      const markReady = () => {
        state.ringtonePrimed = context.state === "running";
      };

      if (context.state === "suspended") {
        context.resume().then(markReady).catch(() => {});
      } else {
        markReady();
      }

      // Prime the audio graph during a user gesture. A silent oscillator is
      // enough to satisfy stricter mobile autoplay policies for later calls.
      if (!state.ringtonePrimed && context.state === "running") {
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        gain.gain.value = 0.00001;
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start();
        oscillator.stop(context.currentTime + 0.025);
        state.ringtonePrimed = true;
      }
    } catch {}
  }

  function stopRingtone() {
    clearInterval(state.ringtoneTimer);
    state.ringtoneTimer = null;

    try {
      navigator.vibrate?.(0);
    } catch {}
  }

  function ringtonePattern(name) {
    return {
      classic: [
        [0, 740, 0.20],
        [280, 880, 0.20],
        [720, 740, 0.22],
        [1000, 880, 0.22],
      ],
      chime: [
        [0, 660, 0.16],
        [180, 880, 0.18],
        [390, 1100, 0.28],
      ],
      pulse: [
        [0, 520, 0.13],
        [210, 520, 0.13],
        [420, 650, 0.18],
      ],
      digital: [
        [0, 940, 0.10],
        [140, 720, 0.10],
        [280, 1040, 0.10],
        [420, 820, 0.12],
      ],
      soft: [
        [0, 523, 0.22],
        [320, 659, 0.22],
        [650, 784, 0.30],
      ],
      bell: [[0,784,.16],[190,988,.18],[420,1175,.28]],
      orbit: [[0,392,.12],[145,523,.12],[290,659,.12],[435,784,.22]],
      arcade: [[0,1047,.08],[110,1319,.08],[220,1568,.12],[390,1319,.14]],
      glass: [[0,880,.18],[260,1320,.24],[610,1760,.28]],
      bass: [[0,196,.16],[210,247,.16],[420,196,.22],[720,294,.22]],
      alert: [[0,880,.12],[170,880,.12],[340,988,.12],[510,1175,.18]],
    }[name] || [
      [0, 740, 0.20],
      [280, 880, 0.20],
    ];
  }

  function ringOnce(name) {
    if (name === "none") return;
    if (name === "custom" && window.SilknexCustomRingtones?.play) { window.SilknexCustomRingtones.play().catch?.(() => {}); return; }

    const AudioContextClass =
      window.AudioContext || window.webkitAudioContext;

    if (!AudioContextClass) return;

    try {
      unlockRingtoneAudio();
      const context = state.ringtoneContext;
      if (!context) return;

      const base = context.currentTime + 0.02;

      for (const [delayMs, frequency, duration] of ringtonePattern(name)) {
        const oscillator = context.createOscillator();
        const gain = context.createGain();

        oscillator.type = "sine";
        oscillator.frequency.value = frequency;

        const start = base + (delayMs / 1000);
        const stop = start + duration;

        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.22, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, stop);

        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start(start);
        oscillator.stop(stop + 0.03);
      }
    } catch {}
  }

  function startRingtone(name = "classic") {
    stopRingtone();

    if (name === "none") return;

    ringOnce(name);
    state.ringtoneTimer = setInterval(() => ringOnce(name), 1650);

    try {
      navigator.vibrate?.([300, 150, 300, 650]);
    } catch {}
  }

  async function requestCallWakeLock() {
    const callId = Number(state.call?.id || 0);
    if (!callId || !navigator.wakeLock?.request || document.visibilityState !== "visible") return;

    try {
      const lock = await navigator.wakeLock.request("screen");

      // The permission/request can resolve after a call ended or another call
      // started. Never leave an orphaned screen wake lock behind.
      if (Number(state.call?.id || 0) !== callId) {
        await lock.release().catch(() => {});
        return;
      }

      const previous = state.callWakeLock;
      state.callWakeLock = lock;
      lock.addEventListener("release", () => {
        if (state.callWakeLock === lock) state.callWakeLock = null;
      }, { once: true });

      if (previous && previous !== lock) {
        previous.release().catch(() => {});
      }
    } catch {}
  }

  function releaseCallWakeLock() {
    const lock = state.callWakeLock;
    state.callWakeLock = null;
    try {
      lock?.release?.().catch?.(() => {});
    } catch {}
  }

  function updateCallMediaSession() {
    if (!("mediaSession" in navigator)) return;

    try {
      if (!state.call) {
        navigator.mediaSession.metadata = null;
        navigator.mediaSession.playbackState = "none";
        for (const action of [
          "hangup",
          "stop",
          "togglemicrophone",
          "togglecamera",
          "enterpictureinpicture",
          "leavepictureinpicture",
        ]) {
          try { navigator.mediaSession.setActionHandler(action, null); } catch {}
        }
        return;
      }

      const other = state.call.other || {};
      navigator.mediaSession.metadata = new MediaMetadata({
        title: other.nickname || other.display_name || "SilkNex call",
        artist: state.call.type === "video" ? "SilkNex video call" : "SilkNex voice call",
        album: "SilkNex",
        artwork: other.avatar_url
          ? [{ src: other.avatar_url, sizes: "512x512" }]
          : [],
      });
      navigator.mediaSession.playbackState = "playing";

      const setAction = (name, handler) => {
        try { navigator.mediaSession.setActionHandler(name, handler); } catch {}
      };
      setAction("hangup", () => endCall());
      setAction("stop", () => endCall());
      setAction("togglemicrophone", () => toggleCallMute());
      setAction("togglecamera", () => toggleCallCamera());
      setAction("enterpictureinpicture", () => {
        enterCallPictureInPicture().catch(() => {});
      });
      setAction("leavepictureinpicture", () => {
        leaveCallPictureInPicture().catch(() => {});
      });
    } catch {}
  }

  async function showActiveCallNotification() {
    if (!state.call || !("Notification" in window) || Notification.permission !== "granted") return;
    if (!navigator.serviceWorker?.ready) return;

    try {
      const registration = await navigator.serviceWorker.ready;
      const other = state.call.other || {};
      const title = other.nickname || other.display_name || "SilkNex call";

      await registration.showNotification(title, {
        body: `${state.call.type === "video" ? "Video" : "Voice"} call in progress · Tap to return`,
        icon: await notificationSafeIcon(other.avatar_url || ""),
        badge: notificationBadge(),
        tag: `active-call-${state.call.id}`,
        renotify: false,
        silent: true,
        requireInteraction: true,
        data: {
          type: "call",
          active_call: true,
          call_id: state.call.id,
          conversation_id: state.call.conversationId,
        },
      });
    } catch {}
  }

  async function closeActiveCallNotification(callId = state.call?.id || 0) {
    if (!callId || !navigator.serviceWorker?.ready) return;

    try {
      const registration = await navigator.serviceWorker.ready;
      const notifications = await registration.getNotifications({
        tag: `active-call-${callId}`,
      });
      notifications.forEach((notification) => notification.close());
    } catch {}
  }

  async function enterCallPictureInPicture() {
    if (!state.call || !state.call.remoteStream?.getVideoTracks?.().length) return false;

    const remote = $("#remoteVideo");
    if (!remote) return false;

    remote.disablePictureInPicture = false;
    remote.setAttribute("autopictureinpicture", "");
    try { await remote.play?.(); } catch {}

    // A newly connected remote stream can exist before video metadata is ready.
    // Give it a brief chance to become PiP-eligible instead of making the Float
    // button look broken on slower cellular connections.
    if (remote.readyState < 2) {
      await new Promise((resolve) => {
        let settled = false;
        const done = () => {
          if (settled) return;
          settled = true;
          remote.removeEventListener("loadedmetadata", done);
          resolve();
        };
        remote.addEventListener("loadedmetadata", done, { once: true });
        setTimeout(done, 1200);
      });
    }
    if (remote.readyState < 2) return false;

    try {
      if (document.pictureInPictureElement === remote) {
        state.call.pipPrimed = true;
        return true;
      }

      if (typeof remote.requestPictureInPicture === "function" && document.pictureInPictureEnabled) {
        await remote.requestPictureInPicture();
        if (state.call) state.call.pipPrimed = true;
        return true;
      }

      if (
        typeof remote.webkitSupportsPresentationMode === "function" &&
        remote.webkitSupportsPresentationMode("picture-in-picture") &&
        typeof remote.webkitSetPresentationMode === "function"
      ) {
        remote.webkitSetPresentationMode("picture-in-picture");
        return true;
      }
    } catch {}

    return false;
  }

  async function leaveCallPictureInPicture() {
    const remote = $("#remoteVideo");

    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (
        remote &&
        typeof remote.webkitPresentationMode === "string" &&
        remote.webkitPresentationMode === "picture-in-picture" &&
        typeof remote.webkitSetPresentationMode === "function"
      ) {
        remote.webkitSetPresentationMode("inline");
      }
    } catch {}
  }


  function ringbackOnce() {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;

    try {
      unlockRingtoneAudio();
      const context = state.ringtoneContext;
      if (!context) return;
      const base = context.currentTime + 0.02;

      for (const [offset, frequency, duration] of [
        [0, 440, 0.32],
        [410, 480, 0.32],
      ]) {
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.type = "sine";
        oscillator.frequency.value = frequency;
        const start = base + offset / 1000;
        const stop = start + duration;
        gain.gain.setValueAtTime(0.0001, start);
        gain.gain.exponentialRampToValueAtTime(0.075, start + 0.025);
        gain.gain.exponentialRampToValueAtTime(0.0001, stop);
        oscillator.connect(gain);
        gain.connect(context.destination);
        oscillator.start(start);
        oscillator.stop(stop + 0.03);
      }
    } catch {}
  }

  function startRingback() {
    stopRingback();
    ringbackOnce();
    state.ringbackTimer = setInterval(ringbackOnce, 2450);
  }

  function stopRingback() {
    clearInterval(state.ringbackTimer);
    state.ringbackTimer = null;
  }

  function scheduleIncomingCallPoll() {
    clearTimeout(state.incomingCallTimer);
    if (!state.me) return;

    const hidden = document.visibilityState === "hidden";
    const hasPushWakeup = Boolean(state.pushSubscribed);

    // Primary incoming-call detection now rides on inbox_state. Keep this as a
    // slow safety net for older browsers/push failures instead of issuing a
    // dedicated request every second for every signed-in user.
    const baseDelay = state.call
      ? 20000
      : hasPushWakeup
        ? (hidden ? 60000 : 30000)
        : (hidden ? 20000 : 10000);
    const delay = jitteredDelay(baseDelay, 0.22);

    state.incomingCallTimer = setTimeout(async () => {
      try {
        if (!state.call) await pollIncomingCall();
      } catch {}
      scheduleIncomingCallPoll();
    }, delay);
  }

  async function pollIncomingCall() {
    if (state.incomingCallPollBusy || !state.me || state.call) return;
    state.incomingCallPollBusy = true;

    try {
      const data = await api("call_poll");

      if (!data.incoming) {
        if (state.incomingCall) {
          state.incomingCall = null;
          $("#incomingCall").classList.add("hidden");
          stopRingtone();
        }
        return;
      }

      if (state.incomingCall?.id === data.incoming.id) return;

      state.incomingCall = data.incoming;
      setAvatar(
        $("#incomingCallAvatar"),
        data.incoming.other?.display_name || "SilkNex",
        data.incoming.other?.accent,
        data.incoming.other?.avatar_url,
        data.incoming.other?.avatar_style
      );
      const callerName =
        data.incoming.other?.nickname ||
        data.incoming.other?.display_name ||
        "Incoming call";
      const customBanner = String(data.incoming.call_banner_text || "").trim();
      $("#incomingCallName").textContent = customBanner || callerName;
      $("#incomingCallType").textContent = customBanner
        ? `${callerName} · ${data.incoming.call_type === "video" ? "Video call" : "Voice call"}`
        : (data.incoming.call_type === "video" ? "Incoming video call" : "Incoming audio call");
      $("#incomingCall").dataset.bannerStyle = data.incoming.call_banner_style || "glass";
      $("#incomingCall").classList.toggle("fullscreen", window.SilknexStorage.getItem(`silknex:banner-size:${state.me?.id}:${data.incoming.conversation_id}`) === "fullscreen");
      $("#incomingCall").classList.remove("hidden");
      startRingtone(data.incoming.ringtone || "classic");

      showBrowserNotification(
        data.incoming.other?.nickname || data.incoming.other?.display_name || "SilkNex",
        data.incoming.call_type === "video"
          ? "Incoming video call"
          : "Incoming audio call",
        `call-${data.incoming.id}`,
        {
          type: "call",
          call_id: data.incoming.id,
          conversation_id: data.incoming.conversation_id,
          avatar_url: data.incoming.other?.avatar_url || "",
        }
      );
    } finally {
      state.incomingCallPollBusy = false;
    }
  }

  const DEFAULT_CALL_ICE_SERVERS = Object.freeze([
    {
      urls: [
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
        "stun:stun2.l.google.com:19302",
        "stun:stun.cloudflare.com:3478",
      ],
    },
  ]);

  function hasTurnIceServer(servers) {
    return (Array.isArray(servers) ? servers : []).some((server) => {
      const urls = Array.isArray(server?.urls) ? server.urls : [server?.urls];
      return urls.some((url) => /^turns?:/i.test(String(url || "")));
    });
  }

  async function getCallIceServers({ force = false } = {}) {
    const cached =
      Array.isArray(state.callIceServers) && state.callIceServers.length > 0
        ? state.callIceServers
        : null;
    const fresh =
      Boolean(cached) &&
      Date.now() - Number(state.callIceConfigLoadedAt || 0) < 45 * 60 * 1000;

    if (!force && fresh) return cached;

    try {
      const data = await api("call_config");
      const servers = Array.isArray(data.ice_servers)
        ? data.ice_servers.filter((item) => {
            const urls = item?.urls;
            return typeof urls === "string" || (Array.isArray(urls) && urls.length > 0);
          })
        : [];

      if (servers.length) {
        state.callIceServers = servers;
        state.callIceConfigLoadedAt = Date.now();
        return servers;
      }
    } catch {}

    // A temporary API failure during a Wi-Fi/cellular handoff must not throw
    // away working TURN credentials that are already loaded into the call.
    if (cached) return cached;

    state.callIceServers = DEFAULT_CALL_ICE_SERVERS;
    state.callIceConfigLoadedAt = Date.now();
    return state.callIceServers;
  }

  function callIsHandheld() {
    return (
      Boolean(window.matchMedia?.("(pointer: coarse)")?.matches) &&
      Math.min(window.innerWidth || 9999, window.innerHeight || 9999) <= 1000
    );
  }

  function callNetworkInfo() {
    const connection =
      navigator.connection ||
      navigator.mozConnection ||
      navigator.webkitConnection ||
      null;

    const type = String(connection?.type || "").toLowerCase();
    const effectiveType = String(connection?.effectiveType || "").toLowerCase();
    const saveData = Boolean(connection?.saveData);
    const downlink = Number(connection?.downlink || 0);
    const rtt = Number(connection?.rtt || 0);

    let label = "Internet";
    if (type === "wifi") label = "Wi-Fi";
    else if (type === "cellular") label = "Cellular";
    else if (effectiveType) label = effectiveType.toUpperCase();

    return { connection, type, effectiveType, saveData, downlink, rtt, label };
  }

  async function applyCallNetworkProfile() {
    if (!state.call?.pc) return;

    const { type, effectiveType, saveData, downlink, rtt, label } = callNetworkInfo();
    const handheld = callIsHandheld();
    const cellular = type === "cellular";
    const constrained =
      saveData ||
      ["slow-2g", "2g"].includes(effectiveType) ||
      (downlink > 0 && downlink < 1.1) ||
      (rtt > 0 && rtt >= 700);
    const medium =
      !constrained &&
      (effectiveType === "3g" ||
        (downlink > 0 && downlink < 3.5) ||
        (rtt > 0 && rtt >= 280));

    const profile = constrained
      ? {
          key: "low",
          videoBitrate: 700_000,
          audioBitrate: 48_000,
          width: 640,
          height: 360,
          frameRate: 20,
          scale: 2,
        }
      : medium
        ? {
            key: "medium",
          videoBitrate: 1_200_000,
            audioBitrate: 64_000,
            width: 960,
            height: 540,
          frameRate: 20,
            scale: 1.25,
          }
        : (cellular || handheld)
          ? {
              key: cellular ? "cellular" : "mobile",
              videoBitrate: 1_600_000,
              audioBitrate: 64_000,
              width: 960,
              height: 540,
              frameRate: 24,
              scale: 1,
            }
          : {
              key: "high",
              videoBitrate: 2_400_000,
              audioBitrate: 80_000,
              width: 1280,
              height: 720,
              frameRate: 24,
              scale: 1,
            };

    const profileChanged = state.call.networkProfile !== profile.key;
    state.call.networkProfile = profile.key;

    for (const sender of state.call.pc.getSenders()) {
      if (!sender.track || !sender.getParameters || !sender.setParameters) continue;

      try {
        const params = sender.getParameters();
        if (!Array.isArray(params.encodings) || !params.encodings.length) {
          params.encodings = [{}];
        }

        if (sender.track.kind === "video") {
          const screenSharing = Boolean(state.call.screenStream);
          params.encodings[0].maxBitrate = screenSharing
            ? Math.max(profile.videoBitrate, constrained ? 1_200_000 : 4_500_000)
            : profile.videoBitrate;
          params.encodings[0].maxFramerate = screenSharing
            ? Math.min(30, Math.max(20, profile.frameRate))
            : profile.frameRate;
          params.encodings[0].scaleResolutionDownBy = screenSharing ? 1 : profile.scale;
          params.degradationPreference = screenSharing ? "maintain-resolution" : "balanced";
          sender.track.contentHint = screenSharing ? "detail" : "motion";
        } else if (sender.track.kind === "audio") {
          params.encodings[0].maxBitrate = profile.audioBitrate;
          sender.track.contentHint = "speech";
        }

        await sender.setParameters(params);
      } catch {}
    }

    // Lower camera capture cost as well as encoder bitrate on constrained and
    // phone-class links. Screen sharing keeps native detail and is controlled
    // by sender bitrate so text stays readable.
    if (profileChanged && !state.call.screenStream) {
      const cameraTrack = state.call.localStream?.getVideoTracks?.()[0];
      if (cameraTrack?.applyConstraints) {
        cameraTrack.applyConstraints({
          width: { ideal: profile.width, max: profile.width },
          height: { ideal: profile.height, max: profile.height },
          frameRate: { ideal: profile.frameRate, max: profile.frameRate },
        }).catch(() => {});
      }
    }

    const network = $("#callNetwork");
    if (network) network.textContent = label;
  }

  async function applyCallCongestionRelief() {
    const call = state.call;
    if (!call?.pc || call.qualityDegraded) return;

    call.qualityDegraded = true;
    for (const sender of call.pc.getSenders()) {
      if (!sender.track || !sender.getParameters || !sender.setParameters) continue;

      try {
        const params = sender.getParameters();
        if (!Array.isArray(params.encodings) || !params.encodings.length) {
          params.encodings = [{}];
        }

        if (sender.track.kind === "video") {
          params.encodings[0].maxBitrate = 560_000;
          params.encodings[0].maxFramerate = 20;
          params.encodings[0].scaleResolutionDownBy = 2;
          params.degradationPreference = "balanced";
        } else if (sender.track.kind === "audio") {
          params.encodings[0].maxBitrate = 48_000;
        }

        await sender.setParameters(params);
      } catch {}
    }

    if (!call.screenStream) {
      const cameraTrack = call.localStream?.getVideoTracks?.()[0];
      cameraTrack?.applyConstraints?.({
        width: { ideal: 640, max: 640 },
        height: { ideal: 360, max: 360 },
        frameRate: { ideal: 20, max: 20 },
      }).catch(() => {});
    }
  }

  async function restoreCallQualityProfile() {
    const call = state.call;
    if (!call?.qualityDegraded) return;
    call.qualityDegraded = false;
    call.poorQualityStreak = 0;
    call.goodQualityStreak = 0;
    call.networkProfile = "";
    await applyCallNetworkProfile();
  }

  async function forceCallRelay(reason = "network-quality") {
    const call = state.call;
    if (!call?.pc || call.relayForced || call.relaySwitching) return false;

    call.relaySwitching = true;
    try {
      const iceServers = await getCallIceServers({ force: true });
      if (!hasTurnIceServer(iceServers) || state.call?.id !== call.id) return false;

      const configuration = {
        ...call.pc.getConfiguration(),
        iceServers,
        iceTransportPolicy: "relay",
      };
      call.pc.setConfiguration(configuration);
      call.relayForced = true;
      call.hasRelay = true;
      $("#callStatus").textContent = "Optimizing connection…";

      // Switching transport policy is a deliberate route change, so it must
      // gather a fresh relay candidate even if another recovery attempt ran a
      // moment ago.
      call.lastIceRestartAt = 0;
      await restartCallIce(reason);
      return true;
    } catch {
      if (state.call?.id === call.id) call.relayForced = false;
      return false;
    } finally {
      if (state.call?.id === call.id) call.relaySwitching = false;
    }
  }

  async function restartCallIce(reason = "network") {
    const call = state.call;
    if (!call?.pc) return;

    const now = Date.now();
    if (now - Number(call.lastIceRestartAt || 0) < 3500) return;
    call.lastIceRestartAt = now;

    if (!call.isCaller) {
      await sendCallSignal("restart", { reason }).catch(() => {});
      return;
    }

    $("#callStatus").textContent = "Reconnecting…";
    try {
      if (typeof call.pc.restartIce === "function") call.pc.restartIce();
      await createAndSendOffer({ iceRestart: true });
    } catch {
      // Keep the restart request pending. signalingstatechange or the next
      // network event will flush it once the peer connection becomes stable.
      if (state.call?.id === call.id) {
        call.negotiationPending = true;
        call.iceRestartPending = true;
      }
    }
  }

  function scheduleCallStats() {
    clearTimeout(state.callStatsTimer);
    state.callStatsTimer = null;
    if (!state.call?.pc) return;

    const callId = state.call.id;
    const delay = document.visibilityState === "hidden" ? 7000 : 3000;

    state.callStatsTimer = setTimeout(async () => {
      if (!state.call || state.call.id !== callId) return;

      let quality = "Connecting";
      let route = "";
      try {
        const stats = await state.call.pc.getStats();
        let selectedPair = null;
        let inbound = null;

        stats.forEach((report) => {
          if (
            report.type === "candidate-pair" &&
            report.state === "succeeded" &&
            (report.nominated || report.selected)
          ) {
            selectedPair = report;
          }
          if (
            report.type === "inbound-rtp" &&
            !report.isRemote &&
            report.kind === (state.call.type === "video" ? "video" : "audio")
          ) {
            inbound = report;
          }
        });

        if (selectedPair && typeof stats.get === "function") {
          const localCandidate = stats.get(selectedPair.localCandidateId);
          const remoteCandidate = stats.get(selectedPair.remoteCandidateId);
          route =
            localCandidate?.candidateType === "relay" ||
            remoteCandidate?.candidateType === "relay"
              ? "Relay"
              : "Direct";
        }

        const rtt = Number(selectedPair?.currentRoundTripTime || 0);
        const lost = Math.max(0, Number(inbound?.packetsLost || 0));
        const received = Math.max(0, Number(inbound?.packetsReceived || 0));
        const jitter = Math.max(0, Number(inbound?.jitter || 0));

        const previousReceived = Math.max(0, Number(state.call.statsPacketsReceived || 0));
        const previousLost = Math.max(0, Number(state.call.statsPacketsLost || 0));
        const deltaReceived = Math.max(0, received - previousReceived);
        const deltaLost = Math.max(0, lost - previousLost);
        const samplePackets = deltaReceived + deltaLost;
        const loss = samplePackets > 0
          ? deltaLost / samplePackets
          : (received + lost > 0 ? lost / (received + lost) : 0);

        state.call.statsPacketsReceived = received;
        state.call.statsPacketsLost = lost;
        state.call.statsSampleAt = Date.now();

        if (state.call.pc.connectionState !== "connected") {
          quality = "Reconnecting";
        } else if ((rtt && rtt > 0.48) || loss > 0.09 || jitter > 0.065) {
          quality = "Weak";
        } else if ((rtt && rtt > 0.24) || loss > 0.04 || jitter > 0.035) {
          quality = "Fair";
        } else if (rtt || received) {
          quality = "Great";
        } else {
          quality = "Connected";
        }
      } catch {
        quality = state.call.pc.connectionState === "connected" ? "Connected" : "Reconnecting";
      }

      if (state.call?.id === callId) {
        const call = state.call;
        const qualityNode = $("#callQuality");
        if (qualityNode) qualityNode.textContent = quality;

        const networkNode = $("#callNetwork");
        if (networkNode) {
          const label = callNetworkInfo().label;
          networkNode.textContent = route ? `${label} · ${route}` : label;
        }

        if (quality === "Weak" && route === "Direct") {
          call.weakQualityStreak = Number(call.weakQualityStreak || 0) + 1;
        } else if (quality === "Great" || quality === "Connected" || route === "Relay") {
          call.weakQualityStreak = 0;
        } else {
          call.weakQualityStreak = Math.max(0, Number(call.weakQualityStreak || 0) - 1);
        }

        // A direct route that stays weak across multiple samples is usually a
        // poor NAT/carrier path. If TURN exists, move the call once instead of
        // forcing the user to hang up and call again.
        if (
          call.weakQualityStreak >= 2 &&
          call.hasRelay &&
          !call.relayForced &&
          !call.relaySwitching
        ) {
          forceCallRelay("poor-quality").catch(() => {});
        }

        if (quality === "Weak") {
          call.poorQualityStreak = Number(call.poorQualityStreak || 0) + 1;
          call.goodQualityStreak = 0;
        } else if (quality === "Great") {
          call.goodQualityStreak = Number(call.goodQualityStreak || 0) + 1;
          call.poorQualityStreak = Math.max(0, Number(call.poorQualityStreak || 0) - 1);
        } else {
          call.goodQualityStreak = 0;
          call.poorQualityStreak = Math.max(0, Number(call.poorQualityStreak || 0) - 1);
        }

        if (call.poorQualityStreak >= 2 && !call.qualityDegraded) {
          applyCallCongestionRelief().catch(() => {});
        } else if (call.qualityDegraded && call.goodQualityStreak >= 3) {
          restoreCallQualityProfile().catch(() => {});
        }

        scheduleCallStats();
      }
    }, delay);
  }

  function preferredCallVideoConstraints(facingMode = "user") {
    const network = callNetworkInfo();
    const constrained =
      network.saveData ||
      ["slow-2g", "2g", "3g"].includes(network.effectiveType) ||
      (network.downlink > 0 && network.downlink < 2);

    // Avoid hard maximums on modern phone cameras. "ideal" lets the browser
    // choose the best native mode without digitally cropping to a narrow preset.
    return {
      facingMode: { ideal: facingMode },
      width: { ideal: constrained ? 640 : 1280, max: constrained ? 960 : 1280 },
      height: { ideal: constrained ? 360 : 720, max: constrained ? 540 : 720 },
      frameRate: { ideal: constrained ? 20 : 24, max: 24 },
      aspectRatio: { ideal: 16 / 9 },
      resizeMode: "none",
    };
  }

  async function getCallMedia(type, facingMode = "user") {
    const localHost = ["localhost", "127.0.0.1", "::1"].includes(location.hostname);
    if (!window.isSecureContext && !localHost) {
      throw new Error("Calls need a secure HTTPS connection. Open SilkNex over HTTPS and try again.");
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error("This browser does not support camera or microphone calls.");
    }

    const supported = navigator.mediaDevices.getSupportedConstraints?.() || {};
    const audio = {
      echoCancellation: { ideal: true },
      noiseSuppression: { ideal: true },
      autoGainControl: { ideal: true },
      channelCount: { ideal: 1 },
      sampleRate: { ideal: 48000 },
      sampleSize: { ideal: 16 },
      latency: { ideal: 0.02 },
    };
    if (supported.voiceIsolation) audio.voiceIsolation = { ideal: true };

    const stream = await navigator.mediaDevices.getUserMedia({
      audio,
      video: type === "video" ? preferredCallVideoConstraints(facingMode) : false,
    });
    const track = stream.getVideoTracks()[0];
    if (track?.getCapabilities && track.applyConstraints) {
      try {
        const caps = track.getCapabilities();
        const advanced = {};
        if (Array.isArray(caps.focusMode) && caps.focusMode.includes("continuous")) {
          advanced.focusMode = "continuous";
        }
        if (Array.isArray(caps.exposureMode) && caps.exposureMode.includes("continuous")) {
          advanced.exposureMode = "continuous";
        }
        if (Object.keys(advanced).length) await track.applyConstraints({advanced:[advanced]});
      } catch { /* Cameras without these controls retain their native autofocus. */ }
    }
    return stream;
  }

  function callOtherFromConversation() {
    return state.activeConversation?.members?.find(
      (member) => member.id !== state.me.id
    ) || null;
  }

  async function startCall(type) {
    if (window.SilknexCommunity?.inCall) { toast("Leave the group call before starting another call."); return; }
    if (!state.activeConversation?.can_call || !state.activeId) {
      toast("Add this person as a friend before calling.");
      return;
    }

    if (state.call || state.callStarting) {
      toast("You are already starting or in a call.");
      return;
    }

    const conversationId = Number(state.activeId);
    const callButtons = [$("#audioCallBtn"), $("#videoCallBtn")].filter(Boolean);
    let stream = null;
    let startedCallId = 0;

    state.callStarting = true;
    for (const button of callButtons) button.disabled = true;

    try {
      const iceWarmup = getCallIceServers().catch(() => DEFAULT_CALL_ICE_SERVERS);
      stream = await getCallMedia(type);
      await iceWarmup;

      // Permission prompts can stay open while the user navigates elsewhere.
      // Never turn a call meant for one person into a call to the newly opened
      // conversation.
      if (
        state.activeId !== conversationId ||
        !state.activeConversation?.can_call ||
        state.call
      ) {
        stream.getTracks().forEach((track) => track.stop());
        stream = null;
        return;
      }

      const data = await api("call_start", {
        method: "POST",
        body: {
          conversation_id: conversationId,
          call_type: type,
        },
      });

      startedCallId = Number(data.call?.id || 0);
      flushPushQueue({ immediate: true });
      await initializeCall(data.call, true, stream);
      stream = null; // initializeCall now owns the MediaStream lifecycle.
      await createAndSendOffer();
    } catch (error) {
      if (state.call) cleanupCall();
      else stream?.getTracks().forEach((track) => track.stop());

      if (startedCallId) {
        api("call_end", {
          method: "POST",
          body: { call_id: startedCallId },
        }).catch(() => {});
      }

      toast(
        error?.name === "NotAllowedError"
          ? "Camera or microphone permission was not granted."
          : (error?.message || "The call could not start.")
      );
    } finally {
      state.callStarting = false;
      for (const button of callButtons) button.disabled = false;
    }
  }

  async function processPendingCallAnswer(attempt = 0) {
    const callId = Number(state.pendingAnswerCallId || 0);
    if (!callId || !state.me || state.call) return;

    await pollIncomingCall().catch(() => {});

    if (
      state.incomingCall &&
      Number(state.incomingCall.id) === callId &&
      !state.call
    ) {
      state.pendingAnswerCallId = 0;
      await acceptIncomingCall();
      return;
    }

    if (attempt < 3 && state.pendingAnswerCallId === callId) {
      setTimeout(() => processPendingCallAnswer(attempt + 1), 450 * (attempt + 1));
      return;
    }

    if (state.pendingAnswerCallId === callId) {
      state.pendingAnswerCallId = 0;
    }
  }

  async function acceptIncomingCall() {
    const incoming = state.incomingCall;
    if (!incoming || state.call) return;

    $("#acceptCallBtn").disabled = true;

    let stream;
    let acceptedCallId = 0;

    try {
      const iceWarmup = getCallIceServers().catch(() => DEFAULT_CALL_ICE_SERVERS);
      stream = await getCallMedia(incoming.call_type);
      await iceWarmup;

      if (
        state.call ||
        !state.incomingCall ||
        Number(state.incomingCall.id) !== Number(incoming.id)
      ) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }

      await api("call_answer", {
        method: "POST",
        body: { call_id: incoming.id, accept: true },
      });
      acceptedCallId = Number(incoming.id || 0);

      $("#incomingCall").classList.add("hidden");
      state.incomingCall = null;
      stopRingtone();
      await initializeCall(
        {
          ...incoming,
          status: "active",
        },
        false,
        stream
      );
    } catch (error) {
      if (state.call) {
        cleanupCall();
      } else {
        stream?.getTracks().forEach((track) => track.stop());
      }

      if (acceptedCallId) {
        api("call_end", {
          method: "POST",
          body: { call_id: acceptedCallId },
        }).catch(() => {});
      }

      if (
        state.incomingCall &&
        Number(state.incomingCall.id) === Number(incoming.id)
      ) {
        state.incomingCall = null;
      }
      $("#incomingCall").classList.add("hidden");
      stopRingtone();
      toast(error?.message || "The call could not connect.");
    } finally {
      $("#acceptCallBtn").disabled = false;
    }
  }

  async function declineIncomingCall() {
    const incoming = state.incomingCall;
    if (!incoming) return;

    $("#declineCallBtn").disabled = true;

    try {
      await api("call_answer", {
        method: "POST",
        body: { call_id: incoming.id, accept: false },
      });
    } catch {}

    state.incomingCall = null;
    $("#incomingCall").classList.add("hidden");
    stopRingtone();
    $("#declineCallBtn").disabled = false;
  }

  function scheduleCallConnectRecovery(callId, delay = 9000) {
    const call = state.call;
    if (!call || call.id !== Number(callId)) return;

    clearTimeout(call.connectWatchdog);
    call.connectWatchdog = setTimeout(async () => {
      const active = state.call;
      if (!active || active.id !== Number(callId)) return;

      if (active.pc?.connectionState === "connected") return;

      // Do not churn ICE while the other phone is still ringing. Once the call
      // is answered, the next watchdog pass repairs a blocked NAT path quickly.
      if (active.status === "ringing" && active.isCaller) {
        scheduleCallConnectRecovery(callId, 7000);
        return;
      }

      const relayed = active.hasRelay && !active.relayForced
        ? await forceCallRelay("connect-timeout")
        : false;

      if (!relayed && state.call?.id === Number(callId)) {
        await restartCallIce("connect-timeout").catch(() => {});
      }

      if (
        state.call?.id === Number(callId) &&
        state.call.pc?.connectionState !== "connected"
      ) {
        scheduleCallConnectRecovery(callId, 9000);
      }
    }, Math.max(3000, Number(delay) || 9000));
  }

  function configurePreferredCallCodecs(pc) {
    if (!pc?.getTransceivers || !window.RTCRtpSender?.getCapabilities) return;

    const handheld = callIsHandheld();
    for (const transceiver of pc.getTransceivers()) {
      if (typeof transceiver.setCodecPreferences !== "function") continue;

      const kind = transceiver.receiver?.track?.kind || transceiver.sender?.track?.kind;
      if (!["audio", "video"].includes(kind)) continue;

      const codecs = RTCRtpSender.getCapabilities(kind)?.codecs;
      if (!Array.isArray(codecs) || codecs.length < 2) continue;

      const rank = (codec) => {
        const mime = String(codec?.mimeType || "").toLowerCase();
        if (kind === "audio") {
          if (mime === "audio/opus") return 0;
          if (mime === "audio/red") return 1;
          return 5;
        }

        // H.264 is broadly hardware-accelerated on phones and usually uses less
        // CPU/battery than software-heavy codecs. Desktop keeps the browser's
        // native ordering unless it also supports the same mobile preference.
        if (handheld && mime === "video/h264") return 0;
        if (mime === "video/vp8") return handheld ? 1 : 0;
        if (mime === "video/h264") return 1;
        if (mime === "video/vp9") return 2;
        if (mime === "video/av1") return 3;
        return 8; // RTX/RED/FEC stay available after the primary codecs.
      };

      try {
        transceiver.setCodecPreferences(
          codecs.map((codec, index) => ({ codec, index }))
            .sort((a, b) => rank(a.codec) - rank(b.codec) || a.index - b.index)
            .map((item) => item.codec)
        );
      } catch {}
    }
  }

  async function initializeCall(call, isCaller, localStream) {
    try {
      if (navigator.audioSession) {
        navigator.audioSession.type = "play-and-record";
      }
    } catch {}

    const iceServers = await getCallIceServers();
    const pc = new RTCPeerConnection({
      iceServers,
      iceCandidatePoolSize: 4,
      bundlePolicy: "max-bundle",
      rtcpMuxPolicy: "require",
      iceTransportPolicy: "all",
    });

    const fallbackOther =
      Number(state.activeId) === Number(call.conversation_id)
        ? callOtherFromConversation()
        : null;

    state.call = {
      id: Number(call.id),
      conversationId: Number(call.conversation_id),
      type: call.call_type,
      status: call.status || "ringing",
      other: {
        ...(call.other || fallbackOther || {}),
        nickname: call.other?.nickname || fallbackOther?.nickname || "",
      },
      isCaller,
      pc,
      localStream,
      remoteStream: new MediaStream(),
      lastSignalId: 0,
      pendingIce: [],
      pollTimer: null,
      screenStream: null,
      screenSender: null,
      facingMode: "user",
      audioOutputId: "",
      originalVideoTrack: localStream.getVideoTracks()[0] || null,
      minimized: false,
      lastIceRestartAt: 0,
      disconnectedAt: 0,
      pollFailures: 0,
      networkProfile: "",
      makingOffer: false,
      ignoreOffer: false,
      isSettingRemoteAnswerPending: false,
      negotiationPending: false,
      iceRestartPending: false,
      negotiationRunning: false,
      screenShareBusy: false,
      cameraBusy: false,
      cameraZoom: 1,
      cameraZoomMin: 1,
      cameraZoomMax: 1,
      cameraZoomStep: 0.1,
      hasRelay: hasTurnIceServer(iceServers),
      relayForced: false,
      relaySwitching: false,
      weakQualityStreak: 0,
      poorQualityStreak: 0,
      goodQualityStreak: 0,
      qualityDegraded: false,
      statsPacketsReceived: 0,
      statsPacketsLost: 0,
      statsSampleAt: 0,
      connectWatchdog: null,
    };

    document.documentElement.dataset.callActive = "true";

    for (const track of localStream.getTracks()) {
      pc.addTrack(track, localStream);
    }
    if (!localStream.getVideoTracks().length) {
      // Voice calls can be promoted to camera calls at any time. A negotiated
      // send/receive video m-line avoids tearing down the voice call when either
      // person enables their camera later.
      try {
        pc.addTransceiver("video", { direction: "sendrecv" });
      } catch {}
    }
    configurePreferredCallCodecs(pc);

    pc.addEventListener("icecandidate", (event) => {
      if (!event.candidate || !state.call || state.call.id !== Number(call.id)) return;
      sendCallSignal("ice", event.candidate.toJSON()).catch(() => {});
    });

    pc.addEventListener("icecandidateerror", (event) => {
      if (!state.call || state.call.id !== Number(call.id)) return;
      // STUN failures can be harmless when another route succeeds. If the peer
      // is not connected, refresh TURN credentials/config and retry once.
      if (state.call.pc?.connectionState === "connected") return;
      const now = Date.now();
      if (now - Number(state.call.lastIceCandidateErrorAt || 0) < 5000) return;
      state.call.lastIceCandidateErrorAt = now;
      getCallIceServers({ force: true })
        .then(async (servers) => {
          const active = state.call;
          if (!active?.pc || active.id !== Number(call.id)) return;
          active.hasRelay = hasTurnIceServer(servers);
          try {
            active.pc.setConfiguration({
              ...active.pc.getConfiguration(),
              iceServers: servers,
            });
          } catch {}
          if (active.hasRelay && !active.relayForced) {
            const switched = await forceCallRelay("candidate-error");
            if (switched) return;
          }
          return restartCallIce("candidate-error");
        })
        .catch(() => {});
    });

    pc.addEventListener("track", (event) => {
      if (!state.call || state.call.id !== Number(call.id)) return;

      for (const track of event.streams[0]?.getTracks?.() || [event.track]) {
        if (!state.call.remoteStream.getTracks().some((item) => item.id === track.id)) {
          state.call.remoteStream.addTrack(track);
        }
      }

      const remote = $("#remoteVideo");
      remote.srcObject = state.call.remoteStream;
      remote.play?.().catch(() => {});

      if (event.track.kind === "video") {
        $("#callBackdrop").classList.add("hidden");
      }
    });

    pc.addEventListener("connectionstatechange", () => {
      if (!state.call || state.call.id !== Number(call.id)) return;
      const value = pc.connectionState;

      if (value === "connected") {
        stopRingback();
        state.call.disconnectedAt = 0;
        clearTimeout(state.call.connectWatchdog);
        state.call.connectWatchdog = null;
        $("#callStatus").textContent = "Connected";
        applyCallNetworkProfile().catch(() => {});
        scheduleCallStats();
      } else if (value === "failed") {
        $("#callStatus").textContent = "Reconnecting…";
        const active = state.call;
        if (active.hasRelay && !active.relayForced) {
          forceCallRelay("failed").then((switched) => {
            if (!switched) restartCallIce("failed").catch(() => {});
          }).catch(() => restartCallIce("failed").catch(() => {}));
        } else {
          restartCallIce("failed").catch(() => {});
        }
        scheduleCallConnectRecovery(active.id, 7000);
      } else if (value === "disconnected") {
        $("#callStatus").textContent = "Reconnecting…";
        if (!state.call.disconnectedAt) state.call.disconnectedAt = Date.now();
        const expectedCallId = state.call.id;
        setTimeout(() => {
          const active = state.call;
          if (
            active?.id === expectedCallId &&
            active.pc?.connectionState === "disconnected"
          ) {
            if (active.hasRelay && !active.relayForced) {
              forceCallRelay("network-handoff").then((switched) => {
                if (!switched) restartCallIce("disconnected").catch(() => {});
              }).catch(() => restartCallIce("disconnected").catch(() => {}));
            } else {
              restartCallIce("disconnected").catch(() => {});
            }
          }
        }, 900);
        scheduleCallConnectRecovery(expectedCallId, 6500);
      }
    });

    pc.addEventListener("iceconnectionstatechange", () => {
      if (!state.call || state.call.id !== Number(call.id)) return;
      if (pc.iceConnectionState === "failed") {
        const active = state.call;
        if (active?.hasRelay && !active.relayForced) {
          forceCallRelay("ice-failed").then((switched) => {
            if (!switched) restartCallIce("ice-failed").catch(() => {});
          }).catch(() => restartCallIce("ice-failed").catch(() => {}));
        } else {
          restartCallIce("ice-failed").catch(() => {});
        }
      }
    });

    pc.addEventListener("signalingstatechange", () => {
      if (
        state.call?.id === Number(call.id) &&
        pc.signalingState === "stable" &&
        state.call.negotiationPending
      ) {
        flushCallNegotiation().catch(() => {});
      }
    });

    if (isCaller && state.call.status === "ringing") {
      startRingback();
    } else {
      stopRingback();
    }

    renderCallUI();
    updateCallMediaSession();
    requestCallWakeLock().catch(() => {});
    refreshAudioOutputs().catch(() => {});
    applyCallNetworkProfile().catch(() => {});
    scheduleCallStats();
    scheduleActiveCallPoll();
    scheduleCallConnectRecovery(state.call.id);
  }

  function renderCallUI() {
    if (!state.call) return;

    const other = state.call.other || {};
    $("#callView").classList.remove("hidden", "minimized");
    $("#restoreCallBtn").classList.add("hidden");
    state.call.minimized = false;
    const callDisplayName = other.nickname || other.display_name || "SilkNex call";
    $("#callName").textContent = callDisplayName;
    $("#restoreCallName").textContent = callDisplayName;
    $("#callStatus").textContent =
      state.call.status === "ringing" ? "Ringing…" : "Connecting…";
    const callNetwork = $("#callNetwork");
    if (callNetwork) callNetwork.textContent = callNetworkInfo().label;
    const callQuality = $("#callQuality");
    if (callQuality) callQuality.textContent = "Connecting";

    setAvatar(
      $("#callAvatar"),
      other.display_name || "SilkNex",
      other.accent,
      other.avatar_url,
      other.avatar_style
    );
    $("#callAvatar").classList.add("call-avatar");

    $("#localVideo").srcObject = state.call.localStream;
    const remoteVideo = $("#remoteVideo");
    remoteVideo.srcObject = state.call.remoteStream;
    remoteVideo.disablePictureInPicture = false;
    remoteVideo.setAttribute("autopictureinpicture", "");
    remoteVideo.play?.().catch(() => {});

    const hasLocalVideo = state.call.localStream.getVideoTracks().some((track) => track.readyState === "live");
    $("#cameraCallBtn").classList.remove("hidden");
    $("#cameraCallBtn").classList.toggle("active", hasLocalVideo);
    $("#cameraCallBtn small").textContent = hasLocalVideo ? "Camera off" : "Camera";
    $("#flipCameraBtn").classList.toggle("hidden", !hasLocalVideo);
    $("#snapshotCallBtn").classList.toggle("hidden", !hasLocalVideo);
    $("#localVideo").classList.toggle("hidden", !hasLocalVideo);
    $("#callBackdrop").classList.remove("hidden");
    updateCallZoomControl();

    $("#screenShareBtn").classList.toggle(
      "hidden",
      !navigator.mediaDevices?.getDisplayMedia
    );
    $("#audioRouteBtn").classList.remove("hidden");
    $("#callAudioPanel").classList.add("hidden");
  }

  async function switchCallCamera() {
    const call = state.call;
    if (!call || !call.localStream.getVideoTracks().length || call.screenStream) return;

    const callId = call.id;
    const nextFacing = call.facingMode === "user" ? "environment" : "user";
    const button = $("#flipCameraBtn");
    button.disabled = true;

    let cameraStream = null;
    try {
      cameraStream = await navigator.mediaDevices.getUserMedia({
        video: preferredCallVideoConstraints(nextFacing),
        audio: false,
      });
      const nextTrack = cameraStream.getVideoTracks()[0];
      if (!nextTrack) throw new Error("No camera was available.");

      if (state.call?.id !== callId || call.screenStream) {
        cameraStream.getTracks().forEach((track) => track.stop());
        return;
      }

      const sender = call.pc
        .getSenders()
        .find((item) => item.track?.kind === "video");
      if (!sender) {
        cameraStream.getTracks().forEach((track) => track.stop());
        throw new Error("The call video sender is unavailable.");
      }

      await sender.replaceTrack(nextTrack);
      if (state.call?.id !== callId) {
        nextTrack.stop();
        return;
      }

      const oldTracks = call.localStream.getVideoTracks();
      for (const track of oldTracks) {
        call.localStream.removeTrack(track);
        track.stop();
      }
      call.localStream.addTrack(nextTrack);
      call.originalVideoTrack = nextTrack;
      call.facingMode = nextFacing;
      $("#localVideo").srcObject = call.localStream;
      $("#localVideo").classList.remove("hidden");
      $("#localVideo").play?.().catch(() => {});
      updateCallZoomControl();
      applyCallNetworkProfile().catch(() => {});
      cameraStream = null; // nextTrack is now owned by call.localStream.
    } catch (error) {
      cameraStream?.getTracks().forEach((track) => track.stop());
      toast(error?.name === "NotAllowedError"
        ? "Camera access is needed to switch cameras."
        : (error?.message || "This device could not switch cameras."));
    } finally {
      button.disabled = false;
    }
  }

  function audioDeviceLabel(device, index) {
    const label = String(device.label || "").trim();
    if (label) return label;
    return index === 0 ? "Speaker / audio output" : `Audio device ${index + 1}`;
  }

  async function refreshAudioOutputs() {
    const select = $("#callAudioOutput");
    if (!select || !navigator.mediaDevices?.enumerateDevices) return;

    const current = select.value || state.call?.audioOutputId || "";
    let devices = [];
    try {
      devices = (await navigator.mediaDevices.enumerateDevices())
        .filter((device) => device.kind === "audiooutput");
    } catch {}

    select.replaceChildren();
    const defaultOption = document.createElement("option");
    defaultOption.value = "";
    defaultOption.textContent = "Phone / system default";
    select.appendChild(defaultOption);

    devices.forEach((device, index) => {
      if (!device.deviceId || device.deviceId === "default") return;
      const option = document.createElement("option");
      option.value = device.deviceId;
      option.textContent = audioDeviceLabel(device, index);
      select.appendChild(option);
    });

    if ([...select.options].some((option) => option.value === current)) {
      select.value = current;
    }

    $("#chooseAudioOutputBtn").classList.toggle(
      "hidden",
      typeof navigator.mediaDevices?.selectAudioOutput !== "function"
    );
  }

  async function setCallAudioOutput(deviceId) {
    if (!state.call) return;
    const remote = $("#remoteVideo");

    if (typeof remote?.setSinkId !== "function") {
      toast("This browser follows your phone's system call-audio route. Use the device audio controls for speaker, earpiece, Bluetooth, or headphones.");
      return;
    }

    try {
      await remote.setSinkId(deviceId || "");
      state.call.audioOutputId = deviceId || "";
      toast(deviceId ? "Call audio device changed." : "Using system-default call audio.");
    } catch (error) {
      toast("That audio output could not be selected.");
    }
  }

  async function chooseCallAudioOutput() {
    if (!state.call) return;

    if (typeof navigator.mediaDevices?.selectAudioOutput === "function") {
      try {
        const device = await navigator.mediaDevices.selectAudioOutput();
        await refreshAudioOutputs();
        if (device?.deviceId) {
          $("#callAudioOutput").value = device.deviceId;
          await setCallAudioOutput(device.deviceId);
        }
        return;
      } catch (error) {
        if (error?.name !== "NotAllowedError") {
          toast("Audio output selection was cancelled or unavailable.");
        }
        return;
      }
    }

    if (typeof $("#remoteVideo")?.setSinkId === "function") {
      await refreshAudioOutputs();
      $("#callAudioPanel").classList.toggle("hidden");
      if (!$("#callAudioPanel").classList.contains("hidden")) {
        $("#callAudioOutput").focus();
      }
      return;
    }

    toast("Your phone controls call audio for this browser. Use the phone's speaker/Bluetooth/headphone controls to change the route.");
  }

  async function sendCallSignal(type, payload) {
    if (!state.call) return;

    await api("call_signal", {
      method: "POST",
      body: {
        call_id: state.call.id,
        signal_type: type,
        payload,
      },
    });
  }

  async function flushPendingCallIce(call) {
    if (!call?.pc?.remoteDescription || !call.pendingIce.length) return;

    const candidates = call.pendingIce.splice(0);
    for (const candidate of candidates) {
      try {
        await call.pc.addIceCandidate(candidate);
      } catch {
        // Candidates from an intentionally ignored colliding offer are not
        // valid for the accepted description and should not poison signaling.
        if (!call.ignoreOffer) {
          call.pendingIce.unshift(candidate);
          break;
        }
      }
    }
  }

  async function flushCallNegotiation() {
    const call = state.call;
    if (!call?.pc || call.negotiationRunning || !call.negotiationPending) return;
    if (call.pc.signalingState !== "stable") return;

    const callId = call.id;
    const iceRestart = Boolean(call.iceRestartPending);
    call.negotiationPending = false;
    call.iceRestartPending = false;
    call.negotiationRunning = true;
    call.makingOffer = true;

    try {
      const offer = await call.pc.createOffer(iceRestart ? { iceRestart: true } : undefined);
      if (state.call?.id !== callId) return;

      await call.pc.setLocalDescription(offer);
      const local = call.pc.localDescription;
      if (!local) throw new Error("The browser could not create a call offer.");

      await sendCallSignal("offer", {
        type: local.type,
        sdp: local.sdp,
      });
    } catch (error) {
      if (state.call?.id === callId) {
        call.negotiationPending = true;
        if (iceRestart) call.iceRestartPending = true;
      }
      throw error;
    } finally {
      if (state.call?.id === callId) {
        call.makingOffer = false;
        call.negotiationRunning = false;
      }
    }
  }

  async function createAndSendOffer(options = {}) {
    const call = state.call;
    if (!call?.pc) return;

    call.negotiationPending = true;
    if (options.iceRestart) call.iceRestartPending = true;
    await flushCallNegotiation();
  }

  async function processCallSignal(signal) {
    const call = state.call;
    if (!call?.pc) return;

    const pc = call.pc;
    const payload = signal.payload;

    if (signal.signal_type === "offer" || signal.signal_type === "answer") {
      const isOffer = signal.signal_type === "offer";

      // An answer can legitimately arrive after a local offer was rolled back
      // because both peers negotiated at once. It is stale at that point and
      // must be acknowledged/ignored instead of retried forever.
      if (!isOffer && pc.signalingState !== "have-local-offer") {
        return;
      }

      const readyForOffer =
        !call.makingOffer &&
        (pc.signalingState === "stable" || call.isSettingRemoteAnswerPending);
      const offerCollision = isOffer && !readyForOffer;

      // Deterministic perfect-negotiation roles prevent simultaneous screen
      // share / reconnect offers from tearing down an otherwise healthy call.
      const polite = !call.isCaller;
      call.ignoreOffer = !polite && offerCollision;
      if (call.ignoreOffer) {
        // Candidates queued before the colliding offer was observed belong to
        // that ignored negotiation and must not be replayed onto the answer we
        // keep.
        call.pendingIce.length = 0;
        return;
      }

      if (offerCollision && polite) {
        // Rolling back our local offer also rolls back its negotiation result.
        // Keep local track/transceiver changes pending so they are offered
        // again after we answer the winning remote offer.
        call.negotiationPending = true;
      }

      call.isSettingRemoteAnswerPending = !isOffer;
      try {
        if (offerCollision && polite && pc.signalingState !== "stable") {
          try {
            await pc.setLocalDescription({ type: "rollback" });
          } catch {
            // Modern browsers can also perform implicit rollback when the
            // colliding remote offer is applied.
          }
        }

        await pc.setRemoteDescription(payload);
      } finally {
        call.isSettingRemoteAnswerPending = false;
      }

      await flushPendingCallIce(call);

      if (isOffer) {
        await pc.setLocalDescription(await pc.createAnswer());
        const local = pc.localDescription;
        if (!local) throw new Error("The browser could not create a call answer.");

        await sendCallSignal("answer", {
          type: local.type,
          sdp: local.sdp,
        });
      }

      call.ignoreOffer = false;
      await flushCallNegotiation();
      return;
    }

    if (signal.signal_type === "ice") {
      if (call.ignoreOffer) return;

      if (pc.remoteDescription) {
        try {
          await pc.addIceCandidate(payload);
        } catch {
          if (!call.ignoreOffer) throw new Error("Could not apply a call network candidate.");
        }
      } else {
        call.pendingIce.push(payload);
        if (call.pendingIce.length > 128) {
          call.pendingIce.splice(0, call.pendingIce.length - 128);
        }
      }
      return;
    }

    if (signal.signal_type === "restart") {
      if (call.isCaller) {
        await restartCallIce(payload?.reason || "peer-request");
      }
    }
  }

  function scheduleActiveCallPoll() {
    if (!state.call) return;
    clearTimeout(state.call.pollTimer);

    const hidden = document.visibilityState === "hidden";
    const connected = state.call.pc?.connectionState === "connected";
    // Signaling needs sub-second checks while WebRTC is connecting. Once the
    // peer connection is established, a slower heartbeat is enough and saves
    // a large amount of idle call-poll traffic without affecting the media.
    const baseDelay = connected
      ? (hidden ? 8000 : 3000)
      : (hidden ? 1800 : 650);
    const failures = Math.min(4, Math.max(0, Number(state.call.pollFailures || 0)));
    const computedDelay = failures
      ? Math.min(8000, Math.round(baseDelay * (1.65 ** failures)))
      : baseDelay;
    const delay = jitteredDelay(computedDelay, connected ? 0.12 : 0.06);

    state.call.pollTimer = setTimeout(async () => {
      await pollActiveCall();
      if (state.call) scheduleActiveCallPoll();
    }, delay);
  }

  async function pollActiveCall() {
    if (!state.call) return;

    const callId = state.call.id;

    try {
      const data = await api("call_poll", {}, {
        call_id: callId,
        after_signal: state.call.lastSignalId,
        include_other: state.call.other?.id ? 0 : 1,
      });

      if (!state.call || state.call.id !== callId) return;

      state.call.status = data.call.status;
      if (data.call.other) state.call.other = data.call.other;

      if (["ended", "declined"].includes(data.call.status)) {
        toast(data.call.status === "declined" ? "Call declined." : "Call ended.");
        cleanupCall();
        return;
      }

      if (data.call.status === "active") {
        stopRingback();
        $("#callStatus").textContent =
          state.call.pc?.connectionState === "connected"
            ? "Connected"
            : "Connecting…";
      } else if (data.call.status === "ringing" && state.call.isCaller) {
        if (!state.ringbackTimer) startRingback();
        $("#callStatus").textContent = "Ringing…";
      }

      for (const signal of data.signals || []) {
        // Only acknowledge a signal after it was successfully applied.
        // advanced the cursor first, so one transient setRemoteDescription()
        // failure could permanently skip the offer/answer needed for the call.
        await processCallSignal(signal);
        state.call.lastSignalId = Math.max(state.call.lastSignalId, signal.id);
      }

      state.call.pollFailures = 0;
    } catch {
      if (state.call) {
        state.call.pollFailures = Math.min(
          8,
          Number(state.call.pollFailures || 0) + 1
        );
        $("#callStatus").textContent = "Reconnecting…";
      }
    }
  }

  async function endCall() {
    if (!state.call) return;

    const callId = state.call.id;
    cleanupCall();

    try {
      await api("call_end", {
        method: "POST",
        body: { call_id: callId },
      });
    } catch {}
  }

  function cleanupCall() {
    const closingCallId = state.call?.id || 0;
    delete document.documentElement.dataset.callActive;
    stopRingback();
    stopRingtone();
    releaseCallWakeLock();
    clearTimeout(state.callStatsTimer);
    state.callStatsTimer = null;
    leaveCallPictureInPicture().catch(() => {});
    closeActiveCallNotification(closingCallId).catch(() => {});

    if (!state.call) {
      $("#callView").classList.add("hidden");
      updateCallMediaSession();
      return;
    }

    clearTimeout(state.call.pollTimer);
    clearTimeout(state.call.connectWatchdog);
    state.call.connectWatchdog = null;

    try {
      state.call.pc.close();
    } catch {}

    state.call.localStream?.getTracks().forEach((track) => track.stop());
    state.call.screenStream?.getTracks().forEach((track) => track.stop());

    state.call.remoteStream?.getTracks().forEach((track) => track.stop());

    $("#remoteVideo").srcObject = null;
    $("#localVideo").srcObject = null;
    $("#callView").classList.add("hidden");
    $("#callView").classList.remove("minimized");
    $("#restoreCallBtn").classList.add("hidden");
    $("#muteCallBtn").classList.remove("active");
    $("#cameraCallBtn").classList.remove("active");
    $("#screenShareBtn").classList.remove("active");
    $("#callZoomControl")?.classList.add("hidden");
    $("#callAudioPanel").classList.add("hidden");
    $("#callAudioOutput").value = "";

    state.call = null;
    try {
      if (navigator.audioSession) navigator.audioSession.type = "auto";
    } catch {}
    updateCallMediaSession();
  }

  async function minimizeCall() {
    if (!state.call) return;
    state.call.minimized = true;
    $("#callView").classList.add("minimized");
    $("#restoreCallBtn").classList.remove("hidden");
    showActiveCallNotification().catch(() => {});

    // On supported phones/browsers, video continues in an OS-level floating
    // Picture-in-Picture window even after the user switches away from SilkNex.
    const floated = await enterCallPictureInPicture();
    if (state.call?.remoteStream?.getVideoTracks?.().length && !floated) {
      toast("Call minimized. Your browser may require its system Picture-in-Picture control to float video outside SilkNex.");
    }
  }

  async function restoreCall() {
    if (!state.call) return;
    state.call.minimized = false;
    $("#callView").classList.remove("minimized");
    $("#restoreCallBtn").classList.add("hidden");
    closeActiveCallNotification().catch(() => {});
    await leaveCallPictureInPicture();
    requestCallWakeLock().catch(() => {});
  }

  async function takeCallPhoto() {
    if (!state.call || (!state.call.remoteStream?.getVideoTracks?.().length && !state.call.localStream?.getVideoTracks?.().length)) return;

    const remote = $("#remoteVideo");
    const local = $("#localVideo");
    const source =
      remote.videoWidth > 0 && remote.videoHeight > 0
        ? remote
        : local.videoWidth > 0 && local.videoHeight > 0
          ? local
          : null;

    if (!source) {
      toast("The video is not ready for a photo yet.");
      return;
    }

    const button = $("#snapshotCallBtn");
    button.disabled = true;

    try {
      const canvas = document.createElement("canvas");
      canvas.width = source.videoWidth;
      canvas.height = source.videoHeight;
      const context = canvas.getContext("2d", { alpha: false });
      if (!context) throw new Error("Photo capture is unavailable.");

      context.drawImage(source, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise((resolve) =>
        canvas.toBlob(resolve, "image/jpeg", 0.92)
      );
      if (!blob) throw new Error("Could not capture the call photo.");

      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      const file = fileFromBlob(blob, `SilkNex-call-${stamp}.jpg`, {
        type: "image/jpeg",
      });

      if (
        navigator.share &&
        navigator.canShare?.({ files: [file] })
      ) {
        await navigator.share({
          files: [file],
          title: "SilkNex call photo",
        });
      } else {
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
      }

      toast("Call photo captured.");
    } catch (error) {
      if (error?.name !== "AbortError") {
        toast(error.message || "Could not capture the call photo.");
      }
    } finally {
      button.disabled = false;
    }
  }

  function toggleCallMute() {
    if (!state.call) return;

    const tracks = state.call.localStream.getAudioTracks();
    const enabled = tracks.some((track) => track.enabled);

    for (const track of tracks) track.enabled = !enabled;
    $("#muteCallBtn").classList.toggle("active", enabled);
    $("#muteCallBtn small").textContent = enabled ? "Unmute" : "Mute";
  }

  function updateCallZoomControl() {
    const call = state.call;
    const wrap = $("#callZoomControl");
    const range = $("#callZoomRange");
    const value = $("#callZoomValue");
    if (!wrap || !range || !value || !call) return;

    const track = call.originalVideoTrack || call.localStream?.getVideoTracks?.()[0];
    let caps = {};
    let settings = {};
    try { caps = track?.getCapabilities?.() || {}; } catch {}
    try { settings = track?.getSettings?.() || {}; } catch {}
    const zoom = caps.zoom;
    const supported = Boolean(track && zoom && Number.isFinite(Number(zoom.min)) && Number(zoom.max) > Number(zoom.min));

    wrap.classList.toggle("hidden", !supported || Boolean(call.screenStream));
    if (!supported) return;

    call.cameraZoomMin = Number(zoom.min);
    call.cameraZoomMax = Number(zoom.max);
    call.cameraZoomStep = Number(zoom.step || 0.1);
    call.cameraZoom = Math.max(call.cameraZoomMin, Math.min(call.cameraZoomMax, Number(settings.zoom ?? call.cameraZoom ?? zoom.min)));

    range.min = String(call.cameraZoomMin);
    range.max = String(call.cameraZoomMax);
    range.step = String(call.cameraZoomStep);
    range.value = String(call.cameraZoom);
    value.textContent = `${call.cameraZoom.toFixed(call.cameraZoomStep < 0.1 ? 2 : 1)}×`;
  }

  async function setCallCameraZoom(value) {
    const call = state.call;
    const track = call?.originalVideoTrack || call?.localStream?.getVideoTracks?.()[0];
    if (!call || !track || call.screenStream || track.readyState === "ended") return;
    const min = Number(call.cameraZoomMin ?? 1), max = Number(call.cameraZoomMax ?? min);
    const step = Math.max(.001, Number(call.cameraZoomStep || .1));
    const requested = Number(value);
    if (!Number.isFinite(requested)) return;
    call.pendingZoom = Math.min(max, Math.max(min, min + Math.round((requested-min)/step)*step));
    if (call.zoomBusy) return;
    call.zoomBusy = true;
    try {
      while (call.pendingZoom !== null && call.pendingZoom !== undefined) {
        const target = call.pendingZoom; call.pendingZoom = null;
        if (state.call !== call || call.screenStream || (call.originalVideoTrack || call.localStream?.getVideoTracks?.()[0]) !== track) break;
        await track.applyConstraints({advanced:[{zoom:target}]});
        if (state.call !== call || (call.originalVideoTrack || call.localStream?.getVideoTracks?.()[0]) !== track) break;
        call.cameraZoom = target;
        if (call.pendingZoom === null) updateCallZoomControl();
      }
    } catch {
      if (state.call === call) {call.pendingZoom = null; updateCallZoomControl(); toast("This camera could not apply that zoom level.");}
    } finally {call.zoomBusy = false;}
  }

  async function toggleCallCamera() {
    const call = state.call;
    if (!call || call.cameraBusy || call.screenStream) return;

    call.cameraBusy = true;
    const button = $("#cameraCallBtn");
    if (button) button.disabled = true;

    try {
      let tracks = call.localStream.getVideoTracks().filter((track) => track.readyState === "live");
      if (!tracks.length) {
        const cameraStream = await navigator.mediaDevices.getUserMedia({
          video: preferredCallVideoConstraints(call.facingMode || "user"),
          audio: false,
        });
        const track = cameraStream.getVideoTracks()[0];
        if (!track) throw new Error("No camera was available.");
        track.contentHint = "motion";

        if (!state.call || state.call.id !== call.id) {
          cameraStream.getTracks().forEach((item) => item.stop());
          return;
        }

        let sender = call.pc.getSenders().find((item) => item.track?.kind === "video");
        if (!sender) {
          sender = call.pc.getTransceivers?.()
            .find((item) => item.receiver?.track?.kind === "video")?.sender || null;
        }

        if (sender) {
          await sender.replaceTrack(track);
          try {
            const transceiver = call.pc.getTransceivers?.().find((item) => item.sender === sender);
            if (transceiver && transceiver.direction !== "sendrecv") transceiver.direction = "sendrecv";
          } catch {}
        } else {
          call.pc.addTrack(track, call.localStream);
          await createAndSendOffer();
        }

        call.localStream.addTrack(track);
        call.originalVideoTrack = track;
        tracks = [track];
        cameraStream.getAudioTracks().forEach((item) => item.stop());
        $("#localVideo").srcObject = call.localStream;
        $("#localVideo").classList.remove("hidden");
        $("#localVideo").play?.().catch(() => {});
        $("#flipCameraBtn").classList.remove("hidden");
        $("#snapshotCallBtn").classList.remove("hidden");
        updateCallZoomControl();
        applyCallNetworkProfile().catch(() => {});
      } else {
        const enabled = tracks.some((track) => track.enabled);
        for (const track of tracks) track.enabled = !enabled;
      }

      const enabled = call.localStream.getVideoTracks().some((track) => track.readyState === "live" && track.enabled);
      $("#localVideo").classList.toggle("hidden", !enabled);
      $("#flipCameraBtn").classList.toggle("hidden", !enabled);
      $("#snapshotCallBtn").classList.toggle("hidden", !enabled);
      button?.classList.toggle("active", enabled);
      const small = button?.querySelector("small");
      if (small) small.textContent = enabled ? "Camera off" : "Camera";
      updateCallMediaSession();
    } catch (error) {
      toast(error?.name === "NotAllowedError"
        ? "Camera permission was not granted."
        : (error?.message || "Camera could not be started."));
    } finally {
      if (state.call?.id === call.id) call.cameraBusy = false;
      if (button) button.disabled = false;
    }
  }

  async function shareScreen() {
    const call = state.call;
    if (!call || !navigator.mediaDevices?.getDisplayMedia) {
      toast("Screen sharing is not supported on this device.");
      return;
    }

    if (call.screenShareBusy) return;

    if (call.screenStream) {
      await stopScreenShare();
      return;
    }

    const callId = call.id;
    call.screenShareBusy = true;
    const button = $("#screenShareBtn");
    if (button) button.disabled = true;

    try {
      const screenWidth = Math.max(1280, Number(screen?.width || 1920) * Number(devicePixelRatio || 1));
      const screenHeight = Math.max(720, Number(screen?.height || 1080) * Number(devicePixelRatio || 1));
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          width: { ideal: Math.min(3840, Math.round(screenWidth)) },
          height: { ideal: Math.min(2160, Math.round(screenHeight)) },
          frameRate: { ideal: 30, max: 60 },
          displaySurface: "monitor",
        },
        audio: false,
        selfBrowserSurface: "exclude",
        surfaceSwitching: "include",
      });

      if (state.call?.id !== callId) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }

      const screenTrack = stream.getVideoTracks()[0];
      if (screenTrack) screenTrack.contentHint = "detail";
      if (!screenTrack) {
        stream.getTracks().forEach((track) => track.stop());
        throw new Error("No screen video track was available.");
      }

      call.screenStream = stream;
      $("#localVideo").srcObject = stream;
      $("#localVideo").classList.remove("hidden");

      let sender = call.pc
        .getSenders()
        .find((item) => item.track?.kind === "video");
      if (!sender) {
        sender = call.pc.getTransceivers?.()
          .find((item) => item.receiver?.track?.kind === "video")?.sender || null;
      }

      if (sender) {
        // Reuse the video m-line that is negotiated even for voice-only calls.
        // This makes screen sharing available from a voice call without
        // creating duplicate video transceivers.
        await sender.replaceTrack(screenTrack);
        try {
          const transceiver = call.pc.getTransceivers?.().find((item) => item.sender === sender);
          if (transceiver && transceiver.direction !== "sendrecv") transceiver.direction = "sendrecv";
        } catch {}
      } else {
        sender = call.pc.addTrack(screenTrack, stream);
        await createAndSendOffer();
      }

      if (state.call?.id !== callId) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }

      call.screenSender = sender;
      try {
        const params = sender.getParameters?.() || {};
        if (params.encodings?.length) {
          params.encodings[0].maxBitrate = 8_000_000;
          params.encodings[0].maxFramerate = 30;
          await sender.setParameters(params);
        }
      } catch {}
      updateCallZoomControl();
      applyCallNetworkProfile().catch(() => {});
      $("#screenShareBtn").classList.add("active");
      $("#screenShareBtn small").textContent = "Stop share";

      screenTrack.addEventListener("ended", () => {
        if (state.call?.id === callId) stopScreenShare().catch(() => {});
      }, { once: true });
    } catch (error) {
      if (state.call?.id === callId && call.screenStream) {
        await stopScreenShare().catch(() => {});
      }
      if (error?.name !== "NotAllowedError") {
        toast(error?.message || "Screen sharing could not start.");
      }
    } finally {
      if (state.call?.id === callId) call.screenShareBusy = false;
      if (button) button.disabled = false;
    }
  }

  async function stopScreenShare() {
    const call = state.call;
    if (!call?.screenStream) return;

    const callId = call.id;
    const sender = call.screenSender;
    const originalTrack = call.originalVideoTrack;
    const stream = call.screenStream;

    call.screenStream = null;
    stream.getTracks().forEach((track) => track.stop());

    if (sender && state.call?.id === callId) {
      if (originalTrack && originalTrack.readyState === "live") {
        await sender.replaceTrack(originalTrack);
      } else {
        try {
          call.pc.removeTrack(sender);
          await createAndSendOffer();
        } catch {}
      }
    }

    if (state.call?.id !== callId) return;

    call.screenSender = null;
    updateCallZoomControl();
    applyCallNetworkProfile().catch(() => {});
    $("#localVideo").srcObject = call.localStream;
    $("#localVideo").classList.toggle(
      "hidden",
      !call.localStream.getVideoTracks().some((track) => track.readyState === "live" && track.enabled)
    );
    $("#screenShareBtn").classList.remove("active");
    $("#screenShareBtn small").textContent = "Share";
  }

  /* ---------------- Event wiring ---------------- */

  let mobileSwipeStart = null;
  let messageSwipeStart = null;
  let chatDragDepth = 0;

  async function refreshForegroundState({ force = false } = {}) {
    if (!state.me) return;

    if (state.foregroundRefreshPromise) {
      return state.foregroundRefreshPromise;
    }

    const now = Date.now();
    if (!force && now - Number(state.lastForegroundRefreshAt || 0) < 900) {
      return;
    }

    state.lastForegroundRefreshAt = now;

    const task = (async () => {
      const jobs = [
        loadConversations(),
        loadFriends({ notify: true }),
        pollIncomingCall(),
      ];

      if (state.activeId) {
        jobs.push(syncConversation());
        if (chatIsActuallyVisible() && state.lastMessageId > state.lastReadAckId) {
          jobs.push(acknowledgeRead(state.activeId, state.lastMessageId));
        }
      }

      await Promise.allSettled(jobs);
    })();

    state.foregroundRefreshPromise = task;

    try {
      await task;
    } finally {
      if (state.foregroundRefreshPromise === task) {
        state.foregroundRefreshPromise = null;
      }
    }
  }

  function scheduleMobileViewportUpdate(includeComposer = false) {
    state.mobileViewportNeedsComposer =
      state.mobileViewportNeedsComposer || Boolean(includeComposer);

    if (state.mobileViewportRaf) return;

    state.mobileViewportRaf = requestAnimationFrame(() => {
      state.mobileViewportRaf = 0;
      const needsComposer = state.mobileViewportNeedsComposer;
      state.mobileViewportNeedsComposer = false;
      updateMobileViewport();
      if (needsComposer) updateComposer();
    });
  }

  function updateMobileViewport() {
    const root = document.documentElement;
    const viewport = window.visualViewport;
    // Leave pinch zoom and panning to the browser, without resizing the shell.
    if (viewport && Number(viewport.scale || 1) > 1.05) return;
    const layoutHeight = Math.round(
      window.innerHeight || document.documentElement.clientHeight || 0
    );
    const rawVisualHeight = Math.round(viewport?.height || layoutHeight || 0);
    const top = Math.max(0, Math.round(viewport?.offsetTop || 0));
    const visualWidth = Math.round(viewport?.width || window.innerWidth || 0);
    const inputFocused = Boolean(document.activeElement?.matches(
      "input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=color]), textarea, [contenteditable=true]"
    ));
    let virtualKeyboardHeight = 0;
    try {
      virtualKeyboardHeight = Math.max(
        0,
        Math.round(Number(navigator.virtualKeyboard?.boundingRect?.height || 0))
      );
    } catch {}

    const orientationChanged =
      state.mobileViewportWidth > 0 &&
      Math.abs(visualWidth - state.mobileViewportWidth) > 80;

    if (!inputFocused || orientationChanged) {
      // Keep a stable pre-keyboard baseline. Android's VirtualKeyboard API can
      // overlay content while iOS instead shrinks VisualViewport; supporting
      // both avoids the composer jumping below the keyboard mid-animation.
      state.mobileViewportBaseline = Math.max(
        layoutHeight,
        rawVisualHeight + top,
        Number(state.mobileViewportBaseline || 0) && !orientationChanged
          ? Number(state.mobileViewportBaseline || 0)
          : 0
      );
    }
    if (visualWidth > 0) {
      state.mobileViewportWidth = visualWidth;
    }

    const baseline = Math.max(
      Number(state.mobileViewportBaseline || 0),
      layoutHeight,
      rawVisualHeight + top
    );
    const inferredKeyboardHeight = inputFocused
      ? Math.max(0, baseline - rawVisualHeight - top)
      : 0;
    const keyboardHeight = inputFocused
      ? Math.max(inferredKeyboardHeight, virtualKeyboardHeight)
      : 0;
    const keyboardOpen = inputFocused && (
      keyboardHeight > 80 ||
      (viewport && rawVisualHeight < baseline * 0.82)
    );

    // When VirtualKeyboard overlays content, VisualViewport can remain full
    // height. Subtract only in that case; if the layout/visual viewport already
    // shrank, using rawVisualHeight avoids double-subtracting the keyboard.
    const viewportAlreadyShrunk =
      keyboardOpen &&
      baseline > 0 &&
      rawVisualHeight < baseline - 80;
    const overlayUsableHeight =
      keyboardOpen &&
      virtualKeyboardHeight > 0 &&
      !viewportAlreadyShrunk
        ? Math.max(1, layoutHeight - top - virtualKeyboardHeight)
        : rawVisualHeight;
    const usableHeight = Math.max(
      1,
      Math.min(rawVisualHeight || overlayUsableHeight, overlayUsableHeight || rawVisualHeight)
    );

    if (usableHeight > 0) {
      root.style.setProperty("--app-height", `${usableHeight}px`);
      root.style.setProperty("--silknex-vv-height", `${usableHeight}px`);
    }
    root.style.setProperty("--silknex-vv-top", `${top}px`);
    root.style.setProperty("--viewport-top", `${top}px`);
    root.style.setProperty("--keyboard-height", `${keyboardHeight}px`);
    root.style.setProperty("--silknex-keyboard-height", `${keyboardHeight}px`);
    root.style.setProperty("--silknex-vv-width", `${visualWidth}px`);
    root.dataset.keyboardOpen = keyboardOpen ? "true" : "false";

    if (keyboardOpen && state.activeId) {
      requestAnimationFrame(() => {
        const box = $("#messages");
        const input = $("#messageInput");
        if (!box) return;

        // Keep both the caret and recent chat visible. Only the message pane is
        // adjusted; the document itself never scrolls behind the software
        // keyboard.
        const distanceFromBottom =
          box.scrollHeight - box.scrollTop - box.clientHeight;
        if (distanceFromBottom < 320) {
          box.scrollTop = Math.max(0, box.scrollHeight - box.clientHeight);
        }
        if (input) {
          input.style.scrollMarginBottom = "12px";
        }
      });
    }
  }

  function isEditableShortcutTarget(target) {
    return Boolean(
      target instanceof HTMLElement &&
      (target.matches("input, textarea, select") ||
        target.isContentEditable ||
        target.closest("[contenteditable='true']"))
    );
  }

  function openAdjacentConversation(direction) {
    if (!state.me || !state.conversations.length) return;

    const ids = state.conversations
      .map((conversation) => Number(conversation.id))
      .filter(Boolean);

    if (!ids.length) return;

    let index = ids.indexOf(Number(state.activeId));
    if (index < 0) index = direction > 0 ? -1 : 0;

    const nextIndex = (index + direction + ids.length) % ids.length;
    const nextId = ids[nextIndex];
    if (!nextId || nextId === Number(state.activeId)) return;

    openConversation(nextId).catch((error) => toast(error.message));
  }

  function openShortcutHelp() {
    if (!state.me) return;
    openModal("#shortcutsModal");
  }

  function focusMessageComposer() {
    if (!state.me || !state.activeId) return;
    const input = $("#messageInput");
    if (!input || input.disabled) return;
    input.focus({ preventScroll: true });
    const end = input.value.length;
    try { input.setSelectionRange(end, end); } catch {}
  }

  function bindEvents() {
    hydrateIcons();
    $("#loginTab").addEventListener("click", () => setAuthMode("login"));
    $("#signupTab").addEventListener("click", () => setAuthMode("signup"));
    $("#authForm").addEventListener("submit", submitAuth);
    $("#authPassword").addEventListener("input", updatePasswordRules);
    $$(".password-toggle").forEach((button) => {
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        const input = document.getElementById(button.dataset.passwordTarget || "");
        if (!input) return;
        const reveal = input.type === "password";
        input.type = reveal ? "text" : "password";
        button.setAttribute("aria-pressed", reveal ? "true" : "false");
        button.setAttribute("aria-label", reveal ? "Hide password" : "Show password");
        button.title = reveal ? "Hide password" : "Show password";
        setButtonContent(button, reveal ? "eyeOff" : "eye");
        try { input.focus({ preventScroll: true }); } catch { input.focus(); }
      });
    });
    $("#passkeyLoginBtn").addEventListener("click", usePasskey);

    $("#friendsBtn").addEventListener("click", openFriends);
    $("#newChatBtn").addEventListener("click", openNewChat);
    $("#emptyNewChat").addEventListener("click", openNewChat);
    $("#emptyFriendsBtn")?.addEventListener("click", openFriends);
    $("#settingsBtn").addEventListener("click", openSettings);
    $("#mobileChatsBtn")?.addEventListener("click", () => {
      closeModal();
      setMobileNavActive("mobileChatsBtn");
    });
    $("#mobileFriendsBtn")?.addEventListener("click", () => {
      setMobileNavActive("mobileFriendsBtn");
      openFriends();
    });
    $("#mobileNewChatBtn")?.addEventListener("click", () => {
      setMobileNavActive("mobileNewChatBtn");
      openNewChat();
    });
    $("#mobileSettingsBtn")?.addEventListener("click", () => {
      setMobileNavActive("mobileSettingsBtn");
      openSettings();
    });
    $("#addStoryBtn").addEventListener("click", openStoryComposer);
    $("#storyMediaPicker").addEventListener("click", () => $("#storyMediaInput").click());
    for (const selector of ["#storyOverlayText", "#storyTextX", "#storyTextY"]) $(selector)?.addEventListener("input", updateStoryOverlayPreview);
    $("#storyTextOnlyBtn")?.addEventListener("click", async () => {
      const text = $("#storyOverlayText")?.value.trim();
      if (!text) { $("#storyOverlayText")?.focus(); toast("Write your story text first."); return; }
      try { await handleStoryFile(await storyImageWithText(null, "", true)); }
      catch (error) { toast(error?.message || "Could not make the text story."); }
    });
    $("#storyTakePhotoBtn")?.addEventListener("click", () => $("#storyPhotoInput").click());
    $("#storyRecordVideoBtn")?.addEventListener("click", () => $("#storyVideoInput").click());
    $("#changeStoryMediaBtn")?.addEventListener("click", () => $("#storyMediaInput").click());

    for (const selector of ["#storyMediaInput", "#storyPhotoInput", "#storyVideoInput"]) {
      $(selector)?.addEventListener("change", (event) => {
        const file = event.target.files?.[0];
        event.target.value = "";
        handleStoryFile(file).catch((error) => {
          toast(error?.message || "Could not prepare that story.");
          const post = $("#postStoryBtn");
          if (post) {
            post.disabled = !state.pendingStoryFile;
            post.textContent = "Post story";
          }
        });
      });
    }

    $("#postStoryBtn").addEventListener("click", postStory);
    $("#storyPrevBtn").addEventListener("click", previousStory);
    $("#storyNextBtn").addEventListener("click", nextStory);
    $("#deleteStoryBtn").addEventListener("click", deleteActiveStory);

    const storySurface = $("#storyViewerMedia");
    const storyViewer = $("#storyViewerModal");

    const resetStoryGestureVisual = () => {
      storySurface?.style.removeProperty("--story-drag-y");
      storySurface?.classList.remove("story-dragging");
    };

    storySurface?.addEventListener("pointerdown", (event) => {
      if (
        state.activeStoryGroupIndex < 0 ||
        (event.pointerType === "mouse" && event.button !== 0)
      ) {
        return;
      }

      state.storyGestureStart = {
        x: event.clientX,
        y: event.clientY,
        at: performance.now(),
        pointerId: event.pointerId,
      };
      try { storySurface.setPointerCapture(event.pointerId); } catch {}
      storySurface.classList.add("story-dragging");
      storySurface.style.setProperty("--story-drag-y", "0px");
      setStoryPaused(true);
    });

    storySurface?.addEventListener("pointermove", (event) => {
      const start = state.storyGestureStart;
      if (!start || start.pointerId !== event.pointerId) return;

      const dx = event.clientX - start.x;
      const dy = event.clientY - start.y;
      if (Math.abs(dy) < Math.abs(dx) * 0.72) return;

      if (event.cancelable) event.preventDefault();
      const resistance = Math.sign(dy) * Math.min(Math.abs(dy), 180);
      storySurface.style.setProperty("--story-drag-y", `${resistance}px`);
    }, { passive: false });

    storySurface?.addEventListener("pointerup", (event) => {
      const start = state.storyGestureStart;
      state.storyGestureStart = null;
      setStoryPaused(false);

      if (!start || start.pointerId !== event.pointerId) {
        resetStoryGestureVisual();
        return;
      }

      const dx = event.clientX - start.x;
      const dy = event.clientY - start.y;
      const elapsed = Math.max(1, performance.now() - start.at);
      const verticalVelocity = Math.abs(dy) / elapsed;
      const verticalIntent = Math.abs(dy) > Math.abs(dx) * 0.82;
      const shouldAdvance =
        verticalIntent &&
        (Math.abs(dy) >= 54 || (Math.abs(dy) >= 30 && verticalVelocity > 0.48));

      if (shouldAdvance) {
        try { navigator.vibrate?.(7); } catch {}
        storySurface.style.setProperty(
          "--story-drag-y",
          `${dy < 0 ? "-110" : "110"}%`
        );
        storySurface.classList.remove("story-dragging");
        storySurface.classList.add("story-committing");
        setTimeout(() => {
          storySurface.classList.remove("story-committing");
          resetStoryGestureVisual();
          if (dy < 0) nextStory();
          else previousStory();
        }, 150);
        return;
      }

      // Keep horizontal swipe navigation for users already familiar with it.
      if (Math.abs(dx) > 64 && Math.abs(dx) > Math.abs(dy) * 1.18) {
        resetStoryGestureVisual();
        try { navigator.vibrate?.(7); } catch {}
        if (dx < 0) nextStory();
        else previousStory();
        return;
      }

      resetStoryGestureVisual();

      // A short center tap toggles video controls instead of advancing.
      if (elapsed < 240 && Math.abs(dx) < 12 && Math.abs(dy) < 12) {
        const video = storySurface.querySelector("video");
        if (video) video.controls = !video.controls;
      }
    });

    storySurface?.addEventListener("pointercancel", () => {
      state.storyGestureStart = null;
      resetStoryGestureVisual();
      setStoryPaused(false);
    });

    // Trackpad/mouse-wheel users get the same vertical reel behavior. One
    // deliberate scroll moves exactly one story so momentum cannot skip people.
    storyViewer?.addEventListener("wheel", (event) => {
      if (state.activeStoryGroupIndex < 0 || storyViewer.classList.contains("hidden")) return;
      if (Math.abs(event.deltaY) <= Math.abs(event.deltaX) || Math.abs(event.deltaY) < 18) return;
      if (event.cancelable) event.preventDefault();

      const now = performance.now();
      if (now < Number(state.storyWheelLockUntil || 0)) return;
      state.storyWheelLockUntil = now + 430;

      if (event.deltaY > 0) nextStory();
      else previousStory();
    }, { passive: false });

    $("#mobileBackBtn").addEventListener("click", closeMobileChat);

    $("#mainView").addEventListener("touchstart", (event) => {
      if (
        !usesMobileShell() ||
        !state.activeId ||
        event.touches.length !== 1 ||
        event.touches[0].clientX > 28
      ) {
        mobileSwipeStart = null;
        return;
      }

      mobileSwipeStart = {
        x: event.touches[0].clientX,
        y: event.touches[0].clientY,
      };
    }, { passive: true });

    $("#mainView").addEventListener("touchend", (event) => {
      if (!mobileSwipeStart || !event.changedTouches.length) return;

      const touch = event.changedTouches[0];
      const dx = touch.clientX - mobileSwipeStart.x;
      const dy = Math.abs(touch.clientY - mobileSwipeStart.y);
      mobileSwipeStart = null;

      if (dx > 72 && dy < 70) {
        closeMobileChat();
      }
    }, { passive: true });

    $("#chatSearch").addEventListener("input", renderConversations);
    $$("#chatFilters [data-filter]").forEach((button) => {
      button.setAttribute("aria-pressed", button.classList.contains("active") ? "true" : "false");
      button.addEventListener("click", () => {
        state.chatFilter = button.dataset.filter;
        $$("#chatFilters [data-filter]").forEach((item) => {
          const active = item === button;
          item.classList.toggle("active", active);
          item.setAttribute("aria-pressed", active ? "true" : "false");
        });
        renderConversations();
      });
    });
    const filterRail = $("#chatFilters");
    filterRail?.addEventListener("wheel", (event) => {
      if (filterRail.scrollWidth <= filterRail.clientWidth || Math.abs(event.deltaY) < Math.abs(event.deltaX)) return;
      filterRail.scrollLeft += event.deltaY;
      event.preventDefault();
    }, { passive: false });
    let railDrag = null;
    filterRail?.addEventListener("pointerdown", (event) => {
      if (event.pointerType !== "mouse" || event.button !== 0) return;
      railDrag = { x: event.clientX, left: filterRail.scrollLeft, moved: false };
    });
    filterRail?.addEventListener("pointermove", (event) => {
      if (!railDrag || !(event.buttons & 1)) return;
      if (Math.abs(event.clientX - railDrag.x) > 5) railDrag.moved = true;
      if (railDrag.moved) filterRail.scrollLeft = railDrag.left - event.clientX + railDrag.x;
    });
    filterRail?.addEventListener("pointerup", () => { if (railDrag?.moved) filterRail.dataset.dragged = "1"; railDrag = null; });
    filterRail?.addEventListener("click", (event) => {
      if (filterRail.dataset.dragged === "1") { event.preventDefault(); event.stopPropagation(); delete filterRail.dataset.dragged; }
    }, true);

    $("#messageForm").addEventListener("submit", sendMessage);
    $("#scheduleBtn").addEventListener("click", openScheduleMessage);
    $("#confirmScheduleBtn").addEventListener("click", confirmScheduleMessage);
    $("#openScheduledListBtn").addEventListener("click", loadScheduledMessages);
    $("#messageInput").addEventListener("input", () => {
      updateComposer();
      scheduleDraftSave();
      scheduleTypingFromComposer();
    });
    $("#messageInput").addEventListener("keydown", (event) => {
      if (
        event.key === "Enter" &&
        !event.shiftKey &&
        !event.isComposing
      ) {
        event.preventDefault();
        $("#messageForm").requestSubmit();
      }
    });

    $("#messages").addEventListener("scroll", updateScrollNewestButton);

    // A short right-swipe on a message starts a reply. Ignore controls/media
    // and the screen edge so normal scrolling, playback, reactions, and the
    // browser's back gesture keep priority.
    $("#messages").addEventListener("touchstart", (event) => {
      if (event.touches.length !== 1) {
        messageSwipeStart = null;
        return;
      }

      const touch = event.touches[0];
      const target = event.target instanceof Element ? event.target : null;
      const row = target?.closest?.(".message[data-message-id]");
      if (
        !row ||
        touch.clientX < 26 ||
        target?.closest?.("button,a,audio,video,input,textarea,.avatar-reaction-picker")
      ) {
        messageSwipeStart = null;
        return;
      }

      messageSwipeStart = {
        id: Number(row.dataset.messageId || 0),
        x: touch.clientX,
        y: touch.clientY,
      };
    }, { passive: true });

    $("#messages").addEventListener("touchend", (event) => {
      if (!messageSwipeStart || !event.changedTouches.length) return;
      const touch = event.changedTouches[0];
      const start = messageSwipeStart;
      messageSwipeStart = null;

      const dx = touch.clientX - start.x;
      const dy = Math.abs(touch.clientY - start.y);
      if (dx < 58 || dy > 42) return;

      const message = state.messages.get(start.id);
      if (!message || message.pending || message.deleted_at) return;
      beginReply(message);
      try { navigator.vibrate?.(10); } catch {}
    }, { passive: true });

    $("#messageInput").addEventListener("paste", (event) => {
      const files = [...(event.clipboardData?.files || [])];
      const media = files.find((file) =>
        /^image\//i.test(file.type) || /^video\//i.test(file.type)
      );
      if (!media || state.attachmentSendBusy) return;
      event.preventDefault();
      handleAttachmentFile(media);
    });

    const chatView = $("#chatView");
    chatView.addEventListener("dragenter", (event) => {
      if (![...(event.dataTransfer?.types || [])].includes("Files")) return;
      event.preventDefault();
      chatDragDepth += 1;
      chatView.classList.add("drag-over");
    });
    chatView.addEventListener("dragover", (event) => {
      if (![...(event.dataTransfer?.types || [])].includes("Files")) return;
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
    });
    chatView.addEventListener("dragleave", () => {
      chatDragDepth = Math.max(0, chatDragDepth - 1);
      if (!chatDragDepth) chatView.classList.remove("drag-over");
    });
    chatView.addEventListener("drop", (event) => {
      chatDragDepth = 0;
      chatView.classList.remove("drag-over");
      const file = event.dataTransfer?.files?.[0];
      if (!file) return;
      event.preventDefault();
      handleAttachmentFile(file);
    });

    $("#scrollNewestBtn").addEventListener("click", async () => {
      const button = $("#scrollNewestBtn");
      if (button.disabled) return;
      button.disabled = true;
      try {
        if (state.hasNewerHistory) await loadMessages({ latest: true });
        const box = $("#messages");
        box.scrollTo({ top: box.scrollHeight, behavior: "auto" });
        updateScrollNewestButton();
      } catch (error) { toast(error.message); }
      finally { button.disabled = false; }
    });

    $("#olderBtn").addEventListener("click", async () => {
      const button = $("#olderBtn");
      if (button.disabled) return;
      button.disabled = true;

      try {
        await loadMessages({ older: true });
      } catch (error) {
        toast(error.message);
      } finally {
        button.disabled = false;
      }
    });

    $("#cancelReply").addEventListener("click", cancelReply);

    $("#attachBtn").addEventListener("click", () => {
      $("#attachmentMenu").classList.toggle("hidden");
    });
    $("#pickMediaBtn").addEventListener("click", () => {
      $("#attachmentMenu").classList.add("hidden");
      $("#mediaInput").click();
    });
    $("#takeMediaBtn").addEventListener("click", () => {
      $("#attachmentMenu").classList.add("hidden");
      $("#cameraMediaInput").click();
    });
    $("#pickGifBtn").addEventListener("click", openGiphyPicker);
    $("#pickStickerBtn").addEventListener("click", openStickerLibrary);
    $("#scheduleMenuBtn")?.addEventListener("click", () => {
      $("#attachmentMenu").classList.add("hidden");
      openScheduleMessage();
    });
    document.addEventListener("pointerdown", (event) => {
      const menu = $("#attachmentMenu");
      if (!menu || menu.classList.contains("hidden")) return;
      const target = event.target;
      if (!(target instanceof Node)) return;
      if (menu.contains(target) || $("#attachBtn")?.contains(target)) return;
      menu.classList.add("hidden");
    }, { passive: true });
    for (const selector of ["#mediaInput", "#cameraMediaInput"]) {
      $(selector).addEventListener("change", (event) => {
        const file = event.target.files?.[0];
        event.target.value = "";
        handleAttachmentFile(file);
      });
    }
    $("#cancelAttachmentBtn").addEventListener("click", clearPendingAttachment);

    $("#giphySearch").addEventListener("input", scheduleGiphySearch);
    $("#giphySearch").addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      clearTimeout(state.giphySearchTimer);
      loadGiphy($("#giphySearch").value).catch(() => {});
    });

    $("#makeStickerFromMediaBtn").addEventListener(
      "click",
      () => openStickerMakerFromMessage().catch(() => toast("That image could not be opened."))
    );
    $("#makeGifFromMediaBtn").addEventListener(
      "click",
      () => openGifMakerFromMessage().catch(() => toast("That video could not be opened."))
    );

    for (const id of ["stickerFit", "stickerShape", "stickerOutline", "stickerShadow"]) {
      $(`#${id}`)?.addEventListener("change", renderStickerMaker);
    }
    for (const id of ["stickerPadding", "stickerZoom", "stickerRotate", "stickerOffsetX", "stickerOffsetY", "stickerOutlineWidth"]) {
      $(`#${id}`)?.addEventListener("input", renderStickerMaker);
    }
    $("#saveStickerBtn").addEventListener("click", saveSticker);
    $("#createBlankStickerBtn")?.addEventListener("click", () => openBlankStickerMaker().catch(() => toast("Sticker editor could not open.")));
    $("#createPhotoStickerBtn")?.addEventListener("click", () => $("#createPhotoStickerInput")?.click());
    $("#createPhotoStickerInput")?.addEventListener("change", (event) => {
      const file = event.currentTarget.files?.[0];
      event.currentTarget.value = "";
      openStickerMakerFromFile(file).catch(() => toast("Sticker editor could not open."));
    });
    $("#stickerDrawModeBtn")?.addEventListener("click", () => setStickerDrawMode("draw"));
    $("#stickerEraseModeBtn")?.addEventListener("click", () => setStickerDrawMode("erase"));
    $("#stickerRestoreModeBtn")?.addEventListener("click", () => setStickerDrawMode("restore"));
    $("#stickerAutoCutoutBtn")?.addEventListener("click", autoCutoutStickerBackground);
    $("#saveStickerFromMessageBtn")?.addEventListener("click", saveStickerFromMessage);
    $("#stickerFlipBtn")?.addEventListener("click", () => {
      state.stickerFlipX = !state.stickerFlipX;
      $("#stickerFlipBtn")?.classList.toggle("active", state.stickerFlipX);
      renderStickerMaker();
    });
    $("#stickerResetTransformBtn")?.addEventListener("click", resetStickerTransform);
    $("#stickerUndoBtn")?.addEventListener("click", undoStickerDrawing);
    $("#stickerClearDrawBtn")?.addEventListener("click", () => {
      snapshotStickerDrawing();
      $("#stickerDrawCanvas")?.getContext?.("2d")?.clearRect(0, 0, 512, 512);
      state.stickerEraseMask?.getContext?.("2d")?.clearRect(0, 0, 512, 512);
      renderStickerMaker();
    });
    $("#stickerAddTextBtn")?.addEventListener("click", addStickerText);
    $("#stickerTextInput")?.addEventListener("keydown", (event) => {
      if (event.key === "Enter") { event.preventDefault(); addStickerText(); }
    });
    const drawCanvas = $("#stickerDrawCanvas");
    drawCanvas?.addEventListener("pointerdown", beginStickerDraw);
    drawCanvas?.addEventListener("pointermove", continueStickerDraw);
    drawCanvas?.addEventListener("pointerup", endStickerDraw);
    drawCanvas?.addEventListener("pointercancel", endStickerDraw);

    $("#createOwnGifBtn")?.addEventListener("click", () => $("#createOwnGifInput")?.click());
    $("#createOwnGifInput")?.addEventListener("change", (event) => {
      const file = event.target.files?.[0];
      event.target.value = "";
      openGifMakerFromFile(file).catch((error) => toast(error.message));
    });

    $("#fullscreenMediaClose")?.addEventListener("click", closeFullscreenMedia);
    $("#fullscreenMediaModal")?.addEventListener("click", (event) => {
      if (event.target === $("#fullscreenMediaModal") || event.target === $("#fullscreenMediaStage")) {
        closeFullscreenMedia();
      }
    });

    $("#gifStart").addEventListener("input", updateGifRangeUi);
    $("#gifLength").addEventListener("input", updateGifRangeUi);
    $("#gifMakerVideo").addEventListener("loadedmetadata", updateGifRangeUi);
    $("#gifResetEditsBtn")?.addEventListener("click", resetGifEditorControls);
    $("#createGifBtn").addEventListener("click", createCustomGif);
    $("#voiceBtn").addEventListener("pointerdown", onRecordPointerDown);
    $("#voiceBtn").addEventListener("pointerup", onRecordPointerUp);
    $("#voiceBtn").addEventListener("pointercancel", onRecordPointerCancel);
    let lastVoiceTouchAt = 0;
    $("#voiceBtn").addEventListener("click", (event) => {
      if (event.detail === 0 || (!window.PointerEvent && Date.now() - lastVoiceTouchAt > 500)) {
        event.preventDefault();
        onRecordPointerDown({ preventDefault() {}, pointerType: "touch" });
      }
    });
    if (!window.PointerEvent) {
      $("#voiceBtn").addEventListener("touchend", (event) => {
        lastVoiceTouchAt = Date.now();
        event.preventDefault();
        onRecordPointerDown({
          preventDefault() {},
          pointerType: "touch",
        });
      }, { passive: false });
    }
    if (window.matchMedia?.("(pointer: coarse)")?.matches) {
      $("#voiceBtn").setAttribute(
        "aria-label",
        "Tap to record a voice message. Tap again to send."
      );
      $("#voiceBtn").title = "Tap to record · tap again to send";
    }
    $("#voiceBtn").addEventListener("contextmenu", (event) => event.preventDefault());
    $("#voiceBtn").addEventListener("keydown", (event) => {
      if (
        (event.key === " " || event.key === "Enter") &&
        !event.repeat
      ) {
        event.preventDefault();
        onRecordPointerDown({ preventDefault() {}, pointerType: "touch" });
      }
    });
    $("#voiceBtn").addEventListener("keyup", (event) => {
      if (event.key === " " || event.key === "Enter") {
        event.preventDefault();
      }
    });
    $("#cancelRecordingBtn").addEventListener("click", cancelActiveRecording);

    $("#peopleSearch").addEventListener("input", schedulePeopleSearch);
    $("#friendSearch").addEventListener("input", scheduleFriendSearch);
    $("#friendGateAction").addEventListener("click", handleFriendGateAction);
    $("#createChatBtn").addEventListener("click", createConversation);

    $("#profileForm").addEventListener("submit", saveProfile);
    $("#displayName").addEventListener("input", updateProfilePreview);
    $("#openAvatarBuilderBtn")?.addEventListener("click", () => toggleAvatarBuilder());
    $("#randomizeAvatarBtn")?.addEventListener("click", randomizeAvatar);
    $("#useAvatarBtn")?.addEventListener("click", useAvatarBuilder);
    $$(".avatar-builder-tab").forEach((button, index, tabs) => {
      button.addEventListener("click", () => setAvatarBuilderTab(button.dataset.avatarTab));
      button.addEventListener("keydown", (event) => {
        if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
        event.preventDefault();
        let nextIndex = index;
        if (event.key === "ArrowRight") nextIndex = (index + 1) % tabs.length;
        if (event.key === "ArrowLeft") nextIndex = (index - 1 + tabs.length) % tabs.length;
        if (event.key === "Home") nextIndex = 0;
        if (event.key === "End") nextIndex = tabs.length - 1;
        const next = tabs[nextIndex];
        setAvatarBuilderTab(next?.dataset.avatarTab || "face");
        next?.focus();
      });
    });
    for (const id of Object.values(AVATAR_FIELD_IDS)) {
      const field = $(`#${id}`);
      field?.addEventListener("change", renderAvatarBuilderPreview);
      if (field?.matches?.('input[type="range"], input[type="color"]')) {
        field.addEventListener("input", renderAvatarBuilderPreview);
      }
    }
    $$("#accentPicker [data-accent]").forEach((button) => {
      button.addEventListener("click", () => {
        state.selectedAccent = button.dataset.accent;
        renderAccentPicker();
        updateProfilePreview();
      });
    });
    $("#chooseAvatarBtn").addEventListener("click", () => $("#avatarInput").click());
    $("#avatarInput").addEventListener("change", (event) => {
      const file = event.target.files?.[0];
      event.target.value = "";
      handleAvatarFile(file);
    });
    $("#avatarCropZoom").addEventListener("input", () => {
      if (!state.avatarCrop) return;
      state.avatarCrop.zoom = Number($("#avatarCropZoom").value || 1);
      renderAvatarCrop();
    });
    $("#avatarCropStage").addEventListener("pointerdown", (event) => {
      if (!state.avatarCrop) return;
      event.preventDefault();
      const rect = $("#avatarCropStage").getBoundingClientRect();
      state.avatarCrop.drag = {
        x: event.clientX,
        y: event.clientY,
        offsetX: state.avatarCrop.offsetX,
        offsetY: state.avatarCrop.offsetY,
        scaleX: $("#avatarCropCanvas").width / Math.max(1, rect.width),
        scaleY: $("#avatarCropCanvas").height / Math.max(1, rect.height),
      };
      try { event.currentTarget.setPointerCapture(event.pointerId); } catch {}
    });
    $("#avatarCropStage").addEventListener("pointermove", (event) => {
      const drag = state.avatarCrop?.drag;
      if (!drag) return;
      event.preventDefault();
      state.avatarCrop.offsetX =
        drag.offsetX + (event.clientX - drag.x) * drag.scaleX;
      state.avatarCrop.offsetY =
        drag.offsetY + (event.clientY - drag.y) * drag.scaleY;
      renderAvatarCrop();
    });
    const endAvatarDrag = () => {
      if (state.avatarCrop) state.avatarCrop.drag = null;
    };
    $("#avatarCropStage").addEventListener("pointerup", endAvatarDrag);
    $("#avatarCropStage").addEventListener("pointercancel", endAvatarDrag);
    $("#saveAvatarCropBtn").addEventListener("click", saveAvatarCrop);
    $("#cancelAvatarCropBtn").addEventListener("click", closeAvatarCrop);
    $("#closeAvatarCropBtn").addEventListener("click", closeAvatarCrop);
    $("#removeAvatarBtn").addEventListener("click", () => {
      state.avatarToken = "";
      state.removeAvatar = true;
      state.avatarPreviewUrl = "";
      state.avatarUsingStyle = false;
      state.avatarStyleDraft = null;
      updateProfilePreview();
    });

    $$("[data-theme-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        state.themeChoice = button.dataset.themeChoice;
        previewThemeAndIcon();
        renderThemeButtons();
        renderIconButtons();
      });
    });

    $$("[data-icon-style-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        state.iconStyleChoice = button.dataset.iconStyleChoice;
        previewThemeAndIcon();
        renderIconButtons();
      });
    });

    $$("#wallpaperPicker [data-wallpaper]").forEach((button) => {
      button.addEventListener("click", () => {
        state.wallpaperChoice = button.dataset.wallpaper;
        state.wallpaperToken = "";
        renderWallpaperPicker();
      });
    });
    $("#customWallpaperBtn").addEventListener("click", () => $("#wallpaperInput").click());
    $("#wallpaperInput").addEventListener("change", (event) => {
      const file = event.target.files?.[0];
      event.target.value = "";
      handleWallpaperUpload(file, false);
    });
    $("#preferencesForm").addEventListener("submit", savePreferences);
    $("#fontScale").addEventListener("change", () => {
      document.documentElement.dataset.font = $("#fontScale").value;
      applyChatWallpaper(state.activeConversation?.preferences);
    });
    $("#fontFamily").addEventListener("change", () => {
      state.fontFamilyChoice = $("#fontFamily").value;
      document.documentElement.dataset.fontFamily = state.fontFamilyChoice;
    });
    $("#uiAccent").addEventListener("change", () => {
      state.uiAccentChoice = $("#uiAccent").value;
      document.documentElement.dataset.uiAccent = state.uiAccentChoice;
    });
    $("#bubbleStyle").addEventListener("change", () => {
      document.documentElement.dataset.bubbles = $("#bubbleStyle").value;
      if (state.activeConversation?.preferences?.bubble_style === "default") {
        $("#chatWallpaper").dataset.bubbles = $("#bubbleStyle").value;
      }
    });
    $("#messageDensity").addEventListener("change", () => {
      document.documentElement.dataset.density = $("#messageDensity").value;
      if (state.activeConversation?.preferences?.density === "default") {
        $("#chatWallpaper").dataset.density = $("#messageDensity").value;
      }
    });
    $("#chatWidth").addEventListener("change", () => {
      document.documentElement.dataset.chatWidth = $("#chatWidth").value;
      $("#chatWallpaper").dataset.chatWidth = $("#chatWidth").value;
    });
    $("#reduceMotionToggle").addEventListener("change", () => {
      document.documentElement.dataset.reduceMotion =
        $("#reduceMotionToggle").checked ? "true" : "false";
    });
    $("#easyModeToggle").addEventListener("change", () => {
      document.documentElement.dataset.easyMode =
        ($("#easyModeToggle").checked || Boolean(state.me?.kid_mode)) ? "true" : "false";
    });

    $("#kidForm").addEventListener("submit", saveKidSettings);
    $("#addPasskeyBtn").addEventListener("click", addPasskey);

    $("#passwordForm").addEventListener("submit", changePassword);
    $("#logoutOtherDevicesBtn").addEventListener("click", logoutOtherDevices);
    $("#logoutBtn").addEventListener("click", logout);

    $("#chatSettingsBtn").addEventListener("click", openChatSettings);
    $("#chatIdentityBtn").addEventListener("click", openActiveChatProfile);
    $$("#chatWallpaperPicker [data-wallpaper]").forEach((button) => {
      button.addEventListener("click", () => {
        state.chatWallpaperChoice = button.dataset.wallpaper;
        state.chatWallpaperToken = "";
        renderChatWallpaperPicker();
      });
    });
    $("#chatCustomWallpaperBtn").addEventListener("click", () => $("#chatWallpaperInput").click());
    $("#chatWallpaperInput").addEventListener("change", (event) => {
      const file = event.target.files?.[0];
      event.target.value = "";
      handleWallpaperUpload(file, true);
    });
    $("#chatRingtone").addEventListener("change", () => {
      unlockRingtoneAudio();
      ringOnce($("#chatRingtone").value);
    });
    $("#saveChatWallpaperBtn").addEventListener("click", saveChatWallpaper);
    $("#saveNicknameBtn").addEventListener("click", saveFriendNickname);
    $("#proposeGroupNameBtn").addEventListener("click", proposeGroupName);
    $("#chooseGroupAvatarBtn").addEventListener("click", () => $("#groupAvatarInput").click());
    $("#groupAvatarInput").addEventListener("change", (event) => {
      const file = event.target.files?.[0];
      event.target.value = "";
      handleGroupAvatarFile(file);
    });
    $("#proposeGroupAvatarBtn").addEventListener("click", proposeGroupAvatar);
    $("#membersBtn").addEventListener("click", openMembers);
    $("#deleteChatBtn").addEventListener("click", askDeleteChat);
    $("#confirmDeleteChatBtn").addEventListener("click", confirmDeleteChat);
    $("#cancelDeleteChatBtn").addEventListener("click", closeModal);

    $("#saveEditBtn").addEventListener("click", saveEditedMessage);
    $("#cancelEditBtn").addEventListener("click", closeModal);
    $("#confirmDeleteBtn").addEventListener("click", confirmDeleteMessage);
    $("#cancelDeleteBtn").addEventListener("click", closeModal);

    $("#modalOverlay").addEventListener("click", () => {
      if (!$("#avatarCropModal").classList.contains("hidden")) {
        closeAvatarCrop();
        return;
      }
      closeModal();
    });
    $$(".close-modal").forEach((button) => {
      button.addEventListener("click", closeModal);
    });

    $("#audioCallBtn").addEventListener("click", () => startCall("audio"));
    $("#videoCallBtn").addEventListener("click", () => startCall("video"));
    $("#acceptCallBtn").addEventListener("click", acceptIncomingCall);
    $("#declineCallBtn").addEventListener("click", declineIncomingCall);
    $("#endCallBtn").addEventListener("click", endCall);
    $("#minimizeCallBtn").addEventListener("click", () => minimizeCall().catch(() => {}));
    $("#restoreCallBtn").addEventListener("click", () => restoreCall().catch(() => {}));
    $("#snapshotCallBtn").addEventListener("click", takeCallPhoto);
    $("#muteCallBtn").addEventListener("click", toggleCallMute);
    $("#cameraCallBtn").addEventListener("click", toggleCallCamera);
    $("#flipCameraBtn").addEventListener("click", switchCallCamera);
    $("#audioRouteBtn").addEventListener("click", chooseCallAudioOutput);
    $("#chooseAudioOutputBtn").addEventListener("click", chooseCallAudioOutput);
    $("#callAudioOutput").addEventListener("change", (event) => {
      setCallAudioOutput(event.target.value);
    });
    $("#screenShareBtn").addEventListener("click", shareScreen);

    document.addEventListener("click", () => {
      document.querySelectorAll(".avatar-reaction-picker.open").forEach((picker) => {
        picker.classList.remove("open");
      });
    });

    document.addEventListener("pointerdown", unlockRingtoneAudio, {
      passive: true,
    });
    document.addEventListener("touchstart", unlockRingtoneAudio, {
      passive: true,
    });
    document.addEventListener("click", unlockRingtoneAudio, {
      passive: true,
      once: true,
    });

    document.addEventListener("keydown", (event) => {
      unlockRingtoneAudio();
      trapModalFocus(event);

      const key = event.key.toLowerCase();
      const modifier = event.ctrlKey || event.metaKey;
      const modalOpen = $$(".modal").some(
        (modal) => !modal.classList.contains("hidden")
      );

      if (event.key === "Escape") {
        if (!$("#avatarCropModal").classList.contains("hidden")) {
          closeAvatarCrop();
          return;
        }

        if (modalOpen) {
          closeModal();
          return;
        }

        if (!$("#attachmentMenu").classList.contains("hidden")) {
          $("#attachmentMenu").classList.add("hidden");
          return;
        }

        if (state.replyTo) {
          cancelReply();
          return;
        }

        if (state.pendingAttachment) {
          clearPendingAttachment();
          return;
        }

        if (usesMobileShell() && state.activeId) {
          closeMobileChat();
        }
        return;
      }

      if (modifier && !event.altKey && key === "/") {
        if (state.me && !modalOpen) {
          event.preventDefault();
          openShortcutHelp();
        }
        return;
      }

      if (!state.me || modalOpen) return;

      if (modifier && !event.altKey && key === "k") {
        event.preventDefault();
        if (usesMobileShell() && state.activeId) {
          closeMobileChat();
        }
        const search = $("#chatSearch");
        search?.focus({ preventScroll: true });
        search?.select?.();
        return;
      }

      if (modifier && !event.altKey && !event.shiftKey && key === "n") {
        event.preventDefault();
        openNewChat();
        return;
      }

      if (modifier && !event.altKey && event.shiftKey && key === "s") {
        event.preventDefault();
        openStoryComposer();
        return;
      }

      if (modifier && !event.altKey && event.shiftKey && key === "f") {
        event.preventDefault();
        openFriends();
        return;
      }

      if (modifier && !event.altKey && key === ",") {
        event.preventDefault();
        openSettings();
        return;
      }

      if (
        event.altKey &&
        !modifier &&
        (event.key === "ArrowDown" || event.key === "ArrowUp") &&
        !isEditableShortcutTarget(event.target)
      ) {
        event.preventDefault();
        openAdjacentConversation(event.key === "ArrowDown" ? 1 : -1);
        return;
      }

      if (
        event.altKey &&
        !modifier &&
        key === "m" &&
        !isEditableShortcutTarget(event.target)
      ) {
        event.preventDefault();
        focusMessageComposer();
      }
    });

    document.documentElement.dataset.network = navigator.onLine ? "online" : "offline";

    const refreshPresence = () => {
      schedulePresenceHeartbeat();
      if (!appIsForeground()) {
        clearTimeout(state.typingStopTimer);
        sendTypingState(false, state.typingConversationId).catch(() => {});
      }
    };
    document.addEventListener("visibilitychange", refreshPresence);
    for (const name of ["focus", "blur", "online", "offline", "pageshow"]) {
      window.addEventListener(name, refreshPresence);
    }
    window.addEventListener("pagehide", () => {
      clearTimeout(state.presenceTimer);
      state.presenceTimer = null;
      sendPresenceState(false, { keepalive: true, force: true }).catch(() => {});
      clearTimeout(state.typingStopTimer);
      sendTypingState(false, state.typingConversationId).catch(() => {});
    });

    window.addEventListener("pagehide", () => {
      if (state.storyViewQueue.size) flushStoryViews().catch(() => {});
    });

    document.addEventListener("visibilitychange", () => {
      document.documentElement.dataset.pageHidden =
        document.visibilityState === "hidden" ? "true" : "false";
      if (!state.me) return;

      if (document.visibilityState === "hidden") {
        releaseCallWakeLock();
        scheduleGlobalPoll();

        if (state.call) {
          showActiveCallNotification().catch(() => {});
          scheduleCallStats();
          if (state.call.type === "video") {
            enterCallPictureInPicture().catch(() => {});
          }
        }
        return;
      }

      unlockRingtoneAudio();
      if (state.call) {
        closeActiveCallNotification().catch(() => {});
        requestCallWakeLock().catch(() => {});
        scheduleActiveCallPoll();
      }

      refreshForegroundState().catch(() => {});
      if (state.activeId) schedulePoll();
      scheduleGlobalPoll();

      if (Date.now() - Number(state.lastStoryRefreshAt || 0) > 30000) {
        loadStories().catch(() => {});
      }
    });

    window.addEventListener("focus", () => {
      state.lastRealtimeActivityAt = Date.now();
      refreshForegroundState().catch(() => {});
      scheduleGlobalPoll();
    });

    window.addEventListener("online", () => {
      state.lastRealtimeActivityAt = Date.now();
      document.documentElement.dataset.network = "online";
      setSyncStatus("", state.activeId ? "Reconnecting…" : "Online");
      state.syncFailures = 0;
      state.globalPollFailures = 0;

      if (state.me) {
        flushPushQueue({ immediate: true });
        refreshForegroundState({ force: true }).catch(() => {});
        if (state.activeId) schedulePoll();
        scheduleGlobalPoll();
        if (state.call) {
          getCallIceServers({ force: true })
            .then((servers) => {
              const active = state.call;
              if (!active?.pc) return;
              active.hasRelay = hasTurnIceServer(servers);
              try {
                active.pc.setConfiguration({
                  ...active.pc.getConfiguration(),
                  iceServers: servers,
                });
              } catch {}
              scheduleCallConnectRecovery(active.id, 5000);
              return restartCallIce("online");
            })
            .catch(() => {});
        }
      }
    });

    const networkConnection =
      navigator.connection ||
      navigator.mozConnection ||
      navigator.webkitConnection;
    let callNetworkChangeTimer = null;
    networkConnection?.addEventListener?.("change", () => {
      if (!state.call) return;
      state.call.qualityDegraded = false;
      state.call.poorQualityStreak = 0;
      state.call.goodQualityStreak = 0;
      state.call.networkProfile = "";
      applyCallNetworkProfile().catch(() => {});

      // Phones can emit several connection-change events while handing off
      // between Wi-Fi and cellular. Debounce those into one ICE restart so the
      // call migrates routes without creating an offer storm.
      clearTimeout(callNetworkChangeTimer);
      callNetworkChangeTimer = setTimeout(() => {
        if (!state.call) return;
        getCallIceServers({ force: true })
          .then((servers) => {
            const active = state.call;
            if (!active?.pc) return;
            active.hasRelay = hasTurnIceServer(servers);
            try {
              active.pc.setConfiguration({
                ...active.pc.getConfiguration(),
                iceServers: servers,
              });
            } catch {}
            scheduleCallConnectRecovery(active.id, 4500);
            return restartCallIce("network-change");
          })
          .catch(() => {});
      }, 450);
    });

    window.addEventListener("offline", () => {
      document.documentElement.dataset.network = "offline";
      setSyncStatus("error", "Offline");

      // Drop an in-flight long poll immediately. Mobile radios often keep a
      // dead TCP request alive for seconds after Wi-Fi disappears.
      state.syncController?.abort?.();
      state.globalPollController?.abort();
      clearTimeout(state.pollTimer);
      clearTimeout(state.globalPollTimer);
      schedulePoll();
      scheduleGlobalPoll();
    });

    window.addEventListener("pagehide", () => {
      clearTimeout(state.draftSaveTimer);
      if (state.activeId) persistDraft(state.activeId);
    });

    // iOS Safari and installed PWAs can restore SilkNex from the back-forward
    // cache without re-running startup. Refresh viewport metrics immediately
    // and reconcile server state when that happens so the keyboard, unread
    // counts, call state, and active conversation never come back stale.
    window.addEventListener("pageshow", (event) => {
      updateMobileViewport();
      synchronizeAppShell();
      updateComposer();

      if (!state.me || !event.persisted) return;

      refreshForegroundState({ force: true }).catch(() => {});
      if (state.activeId) schedulePoll();
      scheduleGlobalPoll();
      pollIncomingCall().catch(() => {});
    });

    window.addEventListener("popstate", (event) => {
      if (!usesMobileShell() || !state.me) return;

      const historyChatId = Number(event.state?.neochatChat || 0);

      if (state.activeId && historyChatId !== Number(state.activeId)) {
        closeMobileChat({ fromHistory: true });
        return;
      }

      if (!state.activeId && historyChatId > 0) {
        openConversation(historyChatId, { skipHistory: true }).catch(() => {});
      }
    });

    window.addEventListener("resize", () => {
      scheduleMobileViewportUpdate(true);

      synchronizeAppShell();
    });

    window.visualViewport?.addEventListener("resize", () => {
      scheduleMobileViewportUpdate(false);
    });
    window.visualViewport?.addEventListener("scroll", () => {
      scheduleMobileViewportUpdate(false);
    });
    $("#messageInput").addEventListener("focus", () => {
      updateMobileViewport();
      scheduleMobileViewportUpdate(false);
      setTimeout(() => scheduleMobileViewportUpdate(false), 180);
    });
    $("#messageInput").addEventListener("blur", () => {
      scheduleMobileViewportUpdate(false);
      setTimeout(() => scheduleMobileViewportUpdate(false), 180);
      if (state.typingConversationId) sendTypingState(false, state.typingConversationId);
    });

    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !$("#fullscreenMediaModal")?.classList.contains("hidden")) {
        closeFullscreenMedia();
      }
    });

    const colorSchemeMedia = window.matchMedia?.("(prefers-color-scheme: light)");
    const onColorSchemeChange = () => {
      if (state.themeChoice === "system" || state.iconStyleChoice === "auto") {
        previewThemeAndIcon();

        // Auto icon appearance is resolved on this device. Keep its Push
        // subscription in sync so background notifications use the same
        // light/dark branding even when different devices use different
        // system appearances.
        if (
          state.me?.notifications_enabled &&
          "Notification" in window &&
          Notification.permission === "granted"
        ) {
          ensurePushSubscription().catch(() => {});
        }
      }
    };
    colorSchemeMedia?.addEventListener?.("change", onColorSchemeChange);

    navigator.serviceWorker?.addEventListener("message", (event) => {
      if (event.data?.type === "push-wakeup") {
        state.lastRealtimeActivityAt = Date.now();
        const push = event.data.push || {};
        const conversationId = Number(push.data?.conversation_id || 0);
        const kind = push.data?.type || "message";

        if (!state.me) return;

        loadConversations().catch(() => {});

        if (kind === "call") {
          pollIncomingCall().catch(() => {});
          return;
        }

        if (kind === "friend_request" || kind === "friend_accepted") {
          loadFriends({ notify: kind === "friend_request" }).catch(() => {});
          loadConversations().catch(() => {});
          return;
        }

        // The refreshed conversation list owns foreground message
        // notifications. This avoids a Push wakeup and the unread refresh
        // producing two sounds/cards for the same message.
        if (state.activeId === conversationId) {
          syncConversation().catch(() => {});
        }

        return;
      }

      if (event.data?.type === "open-friends") {
        if (state.me) openFriends();
        else state.pendingOpenFriends = true;
        return;
      }

      if (event.data?.type === "answer-call") {
        const callId = Number(event.data?.call_id || 0);
        const conversationId = Number(event.data?.conversation_id || 0);
        if (callId) {
          state.pendingAnswerCallId = callId;
          if (conversationId) state.pendingOpenConversationId = conversationId;
          if (state.me) processPendingCallAnswer().catch(() => {});
        }
        return;
      }

      if (event.data?.type === "restore-call") {
        const callId = Number(event.data?.call_id || 0);
        if (state.call && (!callId || Number(state.call.id) === callId)) {
          restoreCall().catch(() => {});
          return;
        }
      }

      const conversationId = Number(event.data?.conversation_id || 0);
      if (!conversationId) return;

      if (state.me) {
        openConversation(conversationId);
      } else {
        state.pendingOpenConversationId = conversationId;
      }
    });
  }

  window.SilknexApp = Object.freeze({
    api,
    uploadFile,
    hydrateIcons,
    toast,
    openModal,
    closeModal,
    openFullscreenMedia,
    openUserProfile,
    openGifMakerFromFile,
    openConversation,
    openNewChat,
    openFriends,
    closeMobileChat,
    loadConversations,
    async retryConnection() {
      await loadConversations();
      state.globalPollFailures = 0;
      window.dispatchEvent(new Event("silknex:connection"));
      if (state.activeId) schedulePoll();
      scheduleGlobalPoll();
    },
    setAvatar,
    avatarStyleDataUrl,
    optimizeMessageMedia,
    fileFromBlob,
    createAbortController,
    decodeImageElement,
    sendPreparedMessage,
    endCall,
    loadFriends,
    loadStories,
    get state() { return state; },
  });
  window.dispatchEvent(new Event("silknex:core-ready"));

  bindEvents();
  $("#callZoomRange")?.addEventListener("input", (event) => {
    setCallCameraZoom(event.currentTarget.value).catch(() => {});
  });
  try {
    if (navigator.virtualKeyboard) {
      navigator.virtualKeyboard.addEventListener("geometrychange", () => {
        scheduleMobileViewportUpdate(true);
      });
    }
  } catch {}

  const startupParams = new URLSearchParams(window.location.search);
  const startupConversation = Number(startupParams.get("conversation") || 0);
  const startupAnswerCall = Number(startupParams.get("answer_call") || 0);
  const startupFriends = startupParams.get("friends") === "1";

  if (startupAnswerCall > 0) {
    state.pendingAnswerCallId = startupAnswerCall;
    if (startupConversation > 0) {
      state.pendingOpenConversationId = startupConversation;
    }
  } else if (startupConversation > 0) {
    state.pendingOpenConversationId = startupConversation;
  } else if (startupFriends) {
    state.pendingOpenFriends = true;
  }

  if (startupConversation > 0 || startupAnswerCall > 0 || startupFriends) {
    try {
      const cleanUrl = new URL(window.location.href);
      cleanUrl.searchParams.delete("conversation");
      cleanUrl.searchParams.delete("answer_call");
      cleanUrl.searchParams.delete("friends");
      history.replaceState(null, "", cleanUrl);
    } catch {}
  }

  setAuthMode("login");
  updateMobileViewport();
  updateComposer();
  applyAppearance(null);
  registerServiceWorker();
  restoreSession();
})();
