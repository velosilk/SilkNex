(() => {
  "use strict";

  const VERSION = "53.1";
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const app = () => window.SilknexApp || null;

  const runtime = {
    storyAudienceIds: [],
    profile: null,
    qrStream: null,
    qrScanRaf: 0,
    giphyStickerRequest: 0,
    founderBound: false,
    avatarCardsBuilt: false,
  };

  window.SilkNexV53 = runtime;

  function toast(message) {
    app()?.toast?.(message);
  }

  function escapeUsername(value) {
    return String(value || "")
      .trim()
      .replace(/^@+/, "")
      .toLowerCase()
      .slice(0, 24);
  }

  function isFounder() {
    return String(app()?.state?.me?.role || app()?.state?.me?.account_role || "") === "founder_ceo";
  }

  // ---------------------------------------------------------------------------
  // Viewport + mobile keyboard fit
  // ---------------------------------------------------------------------------
  function syncViewport() {
    const viewport = window.visualViewport;
    const width = Math.max(1, Math.round(viewport?.width || window.innerWidth || document.documentElement.clientWidth));
    const height = Math.max(1, Math.round(viewport?.height || window.innerHeight || document.documentElement.clientHeight));
    const top = Math.max(0, Math.round(viewport?.offsetTop || 0));
    const keyboard = Math.max(0, Math.round((window.innerHeight || height) - height - top));
    const root = document.documentElement;
    root.style.setProperty("--silknex-vv-width", `${width}px`);
    root.style.setProperty("--silknex-vv-height", `${height}px`);
    root.style.setProperty("--silknex-vv-top", `${top}px`);
    root.style.setProperty("--silknex-keyboard-height", `${keyboard}px`);
    root.dataset.keyboardOpen = keyboard > 100 ? "1" : "0";
  }

  function bindViewport() {
    syncViewport();
    const viewport = window.visualViewport;
    viewport?.addEventListener("resize", syncViewport, { passive: true });
    viewport?.addEventListener("scroll", syncViewport, { passive: true });
    window.addEventListener("resize", syncViewport, { passive: true });
    window.addEventListener("orientationchange", () => requestAnimationFrame(syncViewport), { passive: true });

    // Pinch-zoom and iOS gesture zoom can make a fixed chat shell impossible to
    // use. The page's viewport meta disables zoom; these guards cover older
    // WebKit gesture events and multi-touch inside the application shell.
    for (const type of ["gesturestart", "gesturechange", "gestureend"]) {
      document.addEventListener(type, (event) => event.preventDefault(), { passive: false });
    }
    document.addEventListener("touchmove", (event) => {
      if (event.touches?.length > 1) event.preventDefault();
    }, { passive: false });

    // Never let a focused composer sit underneath the soft keyboard.
    $("#messageInput")?.addEventListener("focus", () => {
      requestAnimationFrame(() => {
        syncViewport();
        // Keep scrolling inside the message pane. scrollIntoView on the composer
        // can move the entire layout viewport underneath the iOS/Android keyboard.
        const messages = $("#messages");
        if (messages) messages.scrollTop = Math.max(0, messages.scrollHeight - messages.clientHeight);
      });
    });
  }

  // ---------------------------------------------------------------------------
  // QR generation (QR version 3-L, byte mode) + scanning
  // ---------------------------------------------------------------------------
  function gfMul(a, b) {
    let out = 0;
    for (let i = 0; i < 8; i += 1) {
      if (b & 1) out ^= a;
      const carry = a & 0x80;
      a = (a << 1) & 0xff;
      if (carry) a ^= 0x1d;
      b >>>= 1;
    }
    return out;
  }

  function rsGenerator(degree) {
    let poly = [1];
    let root = 1;
    for (let i = 0; i < degree; i += 1) {
      const next = new Array(poly.length + 1).fill(0);
      for (let j = 0; j < poly.length; j += 1) {
        next[j] ^= poly[j];
        next[j + 1] ^= gfMul(poly[j], root);
      }
      poly = next;
      root = gfMul(root, 2);
    }
    return poly;
  }

  function rsRemainder(data, degree) {
    const divisor = rsGenerator(degree);
    const result = new Array(degree).fill(0);
    for (const byte of data) {
      const factor = byte ^ result[0];
      result.shift();
      result.push(0);
      for (let i = 0; i < degree; i += 1) {
        result[i] ^= gfMul(divisor[i + 1], factor);
      }
    }
    return result;
  }

  function appendBits(bits, value, length) {
    for (let i = length - 1; i >= 0; i -= 1) bits.push((value >>> i) & 1);
  }

  function qrCodewords(text) {
    const bytes = Array.from(new TextEncoder().encode(text));
    if (bytes.length > 53) throw new Error("Profile code is too long.");
    const bits = [];
    appendBits(bits, 0b0100, 4); // byte mode
    appendBits(bits, bytes.length, 8);
    for (const byte of bytes) appendBits(bits, byte, 8);

    const maxBits = 55 * 8; // QR version 3-L data codewords
    appendBits(bits, 0, Math.min(4, Math.max(0, maxBits - bits.length)));
    while (bits.length % 8) bits.push(0);

    const data = [];
    for (let i = 0; i < bits.length; i += 8) {
      let value = 0;
      for (let j = 0; j < 8; j += 1) value = (value << 1) | bits[i + j];
      data.push(value);
    }
    const pads = [0xec, 0x11];
    let padIndex = 0;
    while (data.length < 55) data.push(pads[padIndex++ & 1]);

    return data.concat(rsRemainder(data, 15)); // one RS block, 70 total
  }

  function formatBits(mask = 0) {
    const data = (1 << 3) | (mask & 7); // L = 01
    let rem = data << 10;
    const generator = 0x537;
    for (let bit = 14; bit >= 10; bit -= 1) {
      if ((rem >>> bit) & 1) rem ^= generator << (bit - 10);
    }
    return (((data << 10) | rem) ^ 0x5412) & 0x7fff;
  }

  function qrMatrix(text) {
    const size = 29;
    const modules = Array.from({ length: size }, () => Array(size).fill(null));
    const set = (x, y, value) => {
      if (x >= 0 && y >= 0 && x < size && y < size) modules[y][x] = Boolean(value);
    };

    const finder = (x, y) => {
      for (let dy = -1; dy <= 7; dy += 1) {
        for (let dx = -1; dx <= 7; dx += 1) {
          const xx = x + dx;
          const yy = y + dy;
          if (xx < 0 || yy < 0 || xx >= size || yy >= size) continue;
          const inside = dx >= 0 && dx <= 6 && dy >= 0 && dy <= 6;
          const black = inside && (
            dx === 0 || dx === 6 || dy === 0 || dy === 6 ||
            (dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4)
          );
          set(xx, yy, black);
        }
      }
    };

    finder(0, 0);
    finder(size - 7, 0);
    finder(0, size - 7);

    for (let i = 8; i < size - 8; i += 1) {
      if (modules[6][i] === null) set(i, 6, (i & 1) === 0);
      if (modules[i][6] === null) set(6, i, (i & 1) === 0);
    }

    // Version 3 alignment pattern center.
    const alignment = (cx, cy) => {
      if (modules[cy][cx] !== null) return;
      for (let dy = -2; dy <= 2; dy += 1) {
        for (let dx = -2; dx <= 2; dx += 1) {
          set(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
        }
      }
    };
    alignment(22, 22);

    const fmt = formatBits(0);
    const fmtBit = (i) => ((fmt >>> i) & 1) !== 0;
    for (let i = 0; i <= 5; i += 1) set(8, i, fmtBit(i));
    set(8, 7, fmtBit(6));
    set(8, 8, fmtBit(7));
    set(7, 8, fmtBit(8));
    for (let i = 9; i < 15; i += 1) set(14 - i, 8, fmtBit(i));
    for (let i = 0; i < 8; i += 1) set(size - 1 - i, 8, fmtBit(i));
    for (let i = 8; i < 15; i += 1) set(8, size - 15 + i, fmtBit(i));
    set(8, size - 8, true);

    const dataBits = [];
    for (const byte of qrCodewords(text)) appendBits(dataBits, byte, 8);
    let index = 0;
    let upward = true;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right -= 1;
      for (let vert = 0; vert < size; vert += 1) {
        const y = upward ? size - 1 - vert : vert;
        for (let j = 0; j < 2; j += 1) {
          const x = right - j;
          if (modules[y][x] !== null) continue;
          let bit = index < dataBits.length ? dataBits[index++] : 0;
          if (((x + y) & 1) === 0) bit ^= 1; // mask 0
          set(x, y, Boolean(bit));
        }
      }
      upward = !upward;
    }
    return modules;
  }

  function drawQr(canvas, username) {
    if (!canvas) return;
    const handle = escapeUsername(username);
    const profileUrl = new URL(location.pathname || "/", location.origin);
    profileUrl.searchParams.set("profile", handle);
    const webValue = profileUrl.toString();
    const value = new TextEncoder().encode(webValue).length <= 53
      ? webValue
      : `silknex:${handle}`;
    const matrix = qrMatrix(value);
    const quiet = 4;
    const cells = matrix.length + quiet * 2;
    const dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
    const cssSize = Math.min(328, Math.max(244, canvas.clientWidth || 328));
    canvas.width = Math.round(cssSize * dpr);
    canvas.height = Math.round(cssSize * dpr);
    canvas.style.width = `${cssSize}px`;
    canvas.style.height = `${cssSize}px`;
    const ctx = canvas.getContext("2d", { alpha: false });
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, cssSize, cssSize);
    const cell = cssSize / cells;
    ctx.fillStyle = "#000";
    for (let y = 0; y < matrix.length; y += 1) {
      for (let x = 0; x < matrix.length; x += 1) {
        if (!matrix[y][x]) continue;
        const left = Math.floor((x + quiet) * cell);
        const top = Math.floor((y + quiet) * cell);
        const right = Math.ceil((x + quiet + 1) * cell);
        const bottom = Math.ceil((y + quiet + 1) * cell);
        ctx.fillRect(left, top, right - left, bottom - top);
      }
    }
  }

  async function stopQrScanner() {
    cancelAnimationFrame(runtime.qrScanRaf);
    runtime.qrScanRaf = 0;
    for (const track of runtime.qrStream?.getTracks?.() || []) {
      try { track.stop(); } catch {}
    }
    runtime.qrStream = null;
    const video = $("#qrScannerVideo");
    if (video) video.srcObject = null;
    $("#qrScannerArea")?.classList.add("hidden");
  }

  function usernameFromQr(raw) {
    const value = String(raw || "").trim();
    const direct = value.match(/^silknex:([a-z0-9_.]{3,24})$/i);
    if (direct) return direct[1].toLowerCase();
    try {
      const url = new URL(value, location.href);
      const username = escapeUsername(url.searchParams.get("u") || url.searchParams.get("profile") || "");
      return /^[a-z0-9_.]{3,24}$/.test(username) ? username : "";
    } catch {
      return "";
    }
  }

  async function startQrScanner() {
    if (!navigator.mediaDevices?.getUserMedia || typeof BarcodeDetector === "undefined") {
      toast("QR camera scanning is not supported by this browser. Enter the username below instead.");
      $("#qrManualUsername")?.focus();
      return;
    }

    try {
      await stopQrScanner();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      runtime.qrStream = stream;
      const video = $("#qrScannerVideo");
      const area = $("#qrScannerArea");
      area?.classList.remove("hidden");
      video.srcObject = stream;
      await video.play();
      const detector = new BarcodeDetector({ formats: ["qr_code"] });
      const scan = async () => {
        if (!runtime.qrStream || !video?.videoWidth) {
          runtime.qrScanRaf = requestAnimationFrame(scan);
          return;
        }
        try {
          const codes = await detector.detect(video);
          for (const code of codes) {
            const username = usernameFromQr(code.rawValue);
            if (!username) continue;
            await stopQrScanner();
            app()?.closeModal?.("profileQrModal");
            openPublicProfile(username);
            return;
          }
        } catch {}
        runtime.qrScanRaf = requestAnimationFrame(scan);
      };
      scan();
    } catch (error) {
      toast(error?.name === "NotAllowedError" ? "Camera access was not allowed." : "Could not start the QR scanner.");
    }
  }

  function showProfileQr(username) {
    const handle = escapeUsername(username);
    if (!handle) return;
    $("#profileQrHandle").textContent = `@${handle}`;
    drawQr($("#profileQrCanvas"), handle);
    app()?.openModal?.("#profileQrModal");
  }

  // ---------------------------------------------------------------------------
  // Public profiles + shareable handles
  // ---------------------------------------------------------------------------
  async function openPublicProfile(username, seed = null) {
    const handle = escapeUsername(username);
    if (!/^[a-z0-9_.]{3,24}$/.test(handle)) return;

    // Render a fast shell immediately when the caller already has identity data.
    if (seed) renderPublicProfile({ profile: seed, friendship: {}, stories: [] }, true);
    try {
      const data = await app()?.api?.("public_profile", {}, { username: handle });
      if (data) renderPublicProfile(data, false);
    } catch (error) {
      if (!seed) toast(error?.message || "Could not open that profile.");
    }
  }

  window.SilkNexOpenPublicProfile = openPublicProfile;

  function renderPublicProfile(data, provisional = false) {
    const profile = data?.profile || {};
    const handle = escapeUsername(profile.username);
    if (!handle) return;
    runtime.profile = data;

    const me = app()?.state?.me;
    const mine = Number(profile.id || 0) === Number(me?.id || 0) || handle === escapeUsername(me?.username);
    $("#publicProfileName").textContent = profile.display_name || handle;
    $("#publicProfileHandle").textContent = `@${handle}`;
    $("#publicProfileBio").textContent = String(profile.about || "").trim() || "No bio yet.";
    $("#publicProfileFounderBadge")?.classList.toggle("hidden", String(profile.role || profile.account_role || "") !== "founder_ceo");
    app()?.setAvatar?.(
      $("#publicProfileAvatar"),
      profile.display_name || handle,
      profile.accent || "silver",
      profile.avatar_url || "",
      profile.avatar_style || null
    );

    const banner = $("#publicProfileBanner");
    banner.style.backgroundImage = profile.profile_banner_url ? `url("${String(profile.profile_banner_url).replace(/["\\]/g, "")}")` : "";
    banner.classList.toggle("has-image", Boolean(profile.profile_banner_url));

    const messageButton = $("#publicProfileMessageBtn");
    if (messageButton) {
      messageButton.classList.toggle("hidden", mine);
      messageButton.disabled = provisional;
      messageButton.onclick = async () => {
        try {
          const created = await app().api("create_conversation", {
            method: "POST",
            body: { usernames: [handle] },
          });
          app().closeModal?.("publicProfileModal");
          await app().openConversation?.(Number(created.conversation_id));
        } catch (error) {
          toast(error?.message || "Could not start the chat.");
        }
      };
    }

    $("#publicProfileEditBtn")?.classList.toggle("hidden", !mine);
    $("#publicProfileEditBtn").onclick = () => {
      app()?.closeModal?.("publicProfileModal");
      const settings = $("#settingsBtn");
      settings?.click?.();
    };

    $("#publicProfileQrBtn").onclick = () => showProfileQr(handle);
    $("#publicProfileAvatarBtn").onclick = () => {
      const url = profile.avatar_url || (profile.avatar_style ? app()?.avatarStyleDataUrl?.(profile.avatar_style) : "");
      if (url) app()?.openFullscreenMedia?.(url, "image", `${profile.display_name || handle} profile picture`);
    };

    let friendButton = $("#publicProfileFriendBtn");
    if (!friendButton) {
      friendButton = document.createElement("button");
      friendButton.id = "publicProfileFriendBtn";
      friendButton.type = "button";
      friendButton.className = "secondary-btn";
      $("#publicProfileMessageBtn")?.insertAdjacentElement("afterend", friendButton);
    }
    const status = String(data?.friendship?.status || "none");
    friendButton.classList.toggle("hidden", mine || provisional);
    friendButton.textContent = status === "accepted" ? "Friends" : status === "outgoing" ? "Requested" : status === "incoming" ? "Respond in Friends" : "Add friend";
    friendButton.disabled = status === "accepted" || status === "outgoing";
    friendButton.onclick = async () => {
      if (status === "incoming") {
        app()?.closeModal?.("publicProfileModal");
        app()?.openFriends?.();
        return;
      }
      try {
        await app().api("friend_request", { method: "POST", body: { user_id: Number(profile.id) } });
        toast("Friend request sent.");
        openPublicProfile(handle);
      } catch (error) {
        toast(error?.message || "Could not send friend request.");
      }
    };

    let mutualSection = $("#publicProfileMutuals");
    if (!mutualSection) {
      mutualSection = document.createElement("section");
      mutualSection.id = "publicProfileMutuals";
      mutualSection.className = "public-profile-mutuals hidden";
      const bio = $("#publicProfileBio");
      bio?.insertAdjacentElement("afterend", mutualSection);
    }
    const mutuals = Array.isArray(data?.mutual_friends) ? data.mutual_friends : [];
    mutualSection.replaceChildren();
    mutualSection.classList.toggle("hidden", mine || provisional || mutuals.length === 0);
    if (!mine && !provisional && mutuals.length) {
      const title = document.createElement("small");
      title.className = "public-profile-mutual-title";
      title.textContent = `${mutuals.length} mutual friend${mutuals.length === 1 ? "" : "s"}`;
      mutualSection.appendChild(title);
      const rail = document.createElement("div");
      rail.className = "public-profile-mutual-rail";
      for (const friend of mutuals.slice(0, 24)) {
        const card = document.createElement("button");
        card.type = "button";
        card.className = "public-profile-mutual";
        const avatar = document.createElement("div");
        avatar.className = "avatar";
        app()?.setAvatar?.(
          avatar,
          friend.display_name || friend.username || "Friend",
          friend.accent || "silver",
          friend.avatar_url || "",
          friend.avatar_style || null
        );
        const label = document.createElement("span");
        label.textContent = friend.display_name || `@${friend.username}`;
        card.append(avatar, label);
        card.addEventListener("click", () => openPublicProfile(friend.username, friend));
        rail.appendChild(card);
      }
      mutualSection.appendChild(rail);
    }

    const stories = $("#publicProfileStories");
    stories.replaceChildren();
    for (const story of data?.stories || []) {
      const tile = document.createElement("button");
      tile.type = "button";
      tile.className = "public-story-tile";
      const media = document.createElement(story.media_type === "video" ? "video" : "img");
      media.src = story.media_url;
      media.loading = "lazy";
      media.muted = true;
      media.playsInline = true;
      media.preload = story.media_type === "video" ? "metadata" : undefined;
      tile.appendChild(media);
      const visibility = document.createElement("span");
      visibility.textContent = story.visibility === "public" ? "Public" : story.visibility === "custom" ? "Selected" : "Friends";
      tile.appendChild(visibility);
      tile.addEventListener("click", () => app()?.openFullscreenMedia?.(story.media_url, story.media_type, "Story"));
      stories.appendChild(tile);
    }
    if (!stories.children.length && !provisional) {
      const empty = document.createElement("small");
      empty.className = "public-profile-empty";
      empty.textContent = "No active stories visible to you.";
      stories.appendChild(empty);
    }

    app()?.openModal?.("#publicProfileModal");
  }

  async function uploadProfileBanner(file) {
    if (!file || !/^image\//i.test(file.type)) return;
    const prepared = await app()?.optimizeMessageMedia?.(file) || file;
    const data = new FormData();
    data.append("purpose", "banner");
    data.append("file", prepared, prepared.name || file.name || "banner.jpg");
    try {
      const uploaded = await app().api("upload", { method: "POST", body: data, timeoutMs: 300000 });
      const result = await app().api("public_profile_settings", {
        method: "POST",
        body: { banner_token: uploaded.token },
      });
      if (app()?.state?.me) app().state.me.profile_banner_url = result.profile_banner_url || "";
      toast("Profile banner updated.");
      openPublicProfile(app()?.state?.me?.username);
    } catch (error) {
      toast(error?.message || "Could not update profile banner.");
    }
  }

  function installPublicProfileSettings() {
    const settings = $("#settingsModal .settings-stack, #settingsModal .modal-card");
    if (!settings || $("#v53PublicProfileSettings")) return;
    const section = document.createElement("section");
    section.id = "v53PublicProfileSettings";
    section.className = "settings-section v53-settings-section";
    section.innerHTML = `
      <div class="section-title"><span>Public profile</span></div>
      <div class="setting-row"><div><b>Public profile</b><small>Let signed-in SilkNex users discover your bio, banner, avatar and public stories.</small></div><label class="switch"><input id="v53PublicProfileToggle" type="checkbox" aria-label="Public profile"><span></span></label></div>
      <div class="v53-profile-settings-actions">
        <button id="v53ViewProfileBtn" class="secondary-btn" type="button">View my profile</button>
        <button id="v53MyQrBtn" class="secondary-btn" type="button">My QR code</button>
        <button id="v53BannerBtn" class="secondary-btn" type="button">Choose banner image</button>
        <input id="v53BannerInput" class="hidden" type="file" accept="image/jpeg,image/png,image/webp,image/gif">
      </div>`;
    settings.appendChild(section);

    const toggle = $("#v53PublicProfileToggle");
    toggle.checked = Boolean(app()?.state?.me?.public_profile ?? true);
    toggle.addEventListener("change", async () => {
      try {
        await app().api("public_profile_settings", { method: "POST", body: { public_profile: toggle.checked } });
        if (app()?.state?.me) app().state.me.public_profile = toggle.checked;
        toast(toggle.checked ? "Public profile is on." : "Public profile is friends-only.");
      } catch (error) {
        toggle.checked = !toggle.checked;
        toast(error?.message || "Could not update profile privacy.");
      }
    });
    $("#v53ViewProfileBtn").onclick = () => openPublicProfile(app()?.state?.me?.username);
    $("#v53MyQrBtn").onclick = () => showProfileQr(app()?.state?.me?.username);
    $("#v53BannerBtn").onclick = () => $("#v53BannerInput")?.click();
    $("#v53BannerInput").onchange = (event) => uploadProfileBanner(event.currentTarget.files?.[0]);
  }

  // ---------------------------------------------------------------------------
  // Story audience + preloading
  // ---------------------------------------------------------------------------
  function ensureStoryAudienceModal() {
    if ($("#storyAudienceModal")) return;
    const modal = document.createElement("section");
    modal.id = "storyAudienceModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.innerHTML = `
      <div class="modal-card small">
        <header class="modal-head"><div><small>STORY PRIVACY</small><h2>Selected friends</h2></div><button class="plain-btn close-modal icon-only" type="button" aria-label="Close" data-icon="close"></button></header>
        <div id="storyAudienceFriends" class="story-audience-friends"></div>
        <button id="saveStoryAudienceBtn" class="primary wide" type="button">Use selected friends</button>
      </div>`;
    document.body.appendChild(modal);
    modal.querySelector(".close-modal").addEventListener("click", () => app()?.closeModal?.("storyAudienceModal"));
    modal.querySelector("#saveStoryAudienceBtn").addEventListener("click", () => {
      runtime.storyAudienceIds = $$('input[type="checkbox"]:checked', modal)
        .map((input) => Number(input.value))
        .filter((id) => id > 0)
        .slice(0, 100);
      updateStoryAudienceSummary();
      app()?.closeModal?.("storyAudienceModal");
    });
  }

  function updateStoryAudienceSummary() {
    const select = $("#storyAudience");
    const button = $("#storyAudienceChooseBtn");
    const summary = $("#storyAudienceSummary");
    const custom = select?.value === "custom";
    button?.classList.toggle("hidden", !custom);
    summary?.classList.toggle("hidden", !custom);
    if (summary && custom) {
      summary.textContent = runtime.storyAudienceIds.length
        ? `${runtime.storyAudienceIds.length} friend${runtime.storyAudienceIds.length === 1 ? "" : "s"} selected`
        : "Choose at least one friend.";
    }
  }

  async function chooseStoryAudience() {
    ensureStoryAudienceModal();
    if (!app()?.state?.friendsLoaded) {
      try { await app()?.loadFriends?.({ notify: false }); } catch {}
    }
    const list = $("#storyAudienceFriends");
    list.replaceChildren();
    for (const item of app()?.state?.friends || []) {
      const person = item.person || item;
      if (!person?.id) continue;
      const row = document.createElement("label");
      row.className = "story-audience-person";
      const avatar = document.createElement("div");
      app()?.setAvatar?.(avatar, person.display_name, person.accent, person.avatar_url, person.avatar_style);
      const copy = document.createElement("span");
      copy.innerHTML = `<b></b><small></small>`;
      copy.querySelector("b").textContent = person.display_name || person.username;
      copy.querySelector("small").textContent = `@${person.username}`;
      const check = document.createElement("input");
      check.type = "checkbox";
      check.value = String(person.id);
      check.checked = runtime.storyAudienceIds.includes(Number(person.id));
      row.append(avatar, copy, check);
      list.appendChild(row);
    }
    if (!list.children.length) {
      list.textContent = "Add friends before using a selected-friends story.";
    }
    app()?.openModal?.("#storyAudienceModal");
  }

  function bindStoryPrivacy() {
    $("#storyAudience")?.addEventListener("change", updateStoryAudienceSummary);
    $("#storyAudienceChooseBtn")?.addEventListener("click", chooseStoryAudience);
    updateStoryAudienceSummary();

    // Preload only the next couple of story assets; this makes taps feel
    // immediate without downloading the entire feed into RAM.
    window.addEventListener("silknex:modal", () => {
      const groups = app()?.state?.storyGroups || [];
      for (const group of groups.slice(0, 4)) {
        for (const story of (group.stories || []).slice(0, 2)) {
          if (!story?.media_url || story.media_type === "video") continue;
          const image = new Image();
          image.decoding = "async";
          image.src = story.media_url;
        }
      }
    }, { passive: true });
  }

  // ---------------------------------------------------------------------------
  // GIPHY sticker browser
  // ---------------------------------------------------------------------------
  async function giphyKey() {
    const cached = String(app()?.state?.giphySdkKey || "");
    if (cached) return cached;
    try {
      const data = await app()?.api?.("giphy_config", { showLoader: false });
      return data?.enabled ? String(data.sdk_key || "") : "";
    } catch {
      return "";
    }
  }

  function giphyStickerImage(item) {
    return item?.images?.fixed_width_small?.webp ||
      item?.images?.fixed_width?.webp ||
      item?.images?.downsized_medium?.url ||
      item?.images?.original?.webp ||
      item?.images?.original?.url || "";
  }

  function giphyStickerSendUrl(item) {
    return item?.images?.original?.webp ||
      item?.images?.original?.url ||
      giphyStickerImage(item);
  }

  async function loadGiphyStickers(query = "") {
    const request = ++runtime.giphyStickerRequest;
    const results = $("#giphyStickerResults");
    const status = $("#giphyStickerStatus");
    const key = await giphyKey();
    if (request !== runtime.giphyStickerRequest) return;
    results?.replaceChildren();
    if (!key) {
      if (status) status.textContent = "Add a GIPHY SDK key in config.php";
      return;
    }

    const exact = String(query || "").trim().slice(0, 50);
    if (status) status.textContent = exact ? `Searching “${exact}”` : "Trending stickers";
    const endpoint = exact ? "search" : "trending";
    const params = new URLSearchParams({ api_key: key, limit: "24", rating: "pg-13" });
    if (exact) params.set("q", exact);
    try {
      const response = await fetch(`https://api.giphy.com/v1/stickers/${endpoint}?${params}`, {
        mode: "cors",
        credentials: "omit",
        referrerPolicy: "strict-origin-when-cross-origin",
      });
      if (!response.ok) throw new Error("GIPHY request failed");
      const payload = await response.json();
      if (request !== runtime.giphyStickerRequest) return;
      const items = Array.isArray(payload?.data) ? payload.data : [];
      for (const item of items) {
        const preview = giphyStickerImage(item);
        const sendUrl = giphyStickerSendUrl(item);
        if (!preview || !sendUrl) continue;
        const button = document.createElement("button");
        button.type = "button";
        button.className = "giphy-sticker-tile";
        button.title = item.title || "GIPHY sticker";
        const image = document.createElement("img");
        image.src = preview;
        image.alt = item.title || "Sticker";
        image.loading = "lazy";
        image.decoding = "async";
        button.appendChild(image);
        button.addEventListener("click", async () => {
          const conversationId = Number(app()?.state?.activeId || 0);
          if (!conversationId) return;
          button.disabled = true;
          try {
            const success = await app()?.sendPreparedMessage?.({
              conversationId,
              externalGif: {
                id: String(item.id || ""),
                url: sendUrl,
                title: String(item.title || "GIPHY sticker").slice(0, 120),
              },
              optimisticMedia: {
                message_type: "sticker",
                attachment_url: preview,
                attachment_name: item.title || "GIPHY sticker",
              },
              replyToId: app()?.state?.replyTo?.id || null,
            });
            if (success) app()?.closeModal?.("stickerLibraryModal");
          } catch (error) {
            toast(error?.message || "Could not send sticker.");
          } finally {
            button.disabled = false;
          }
        });
        results.appendChild(button);
      }
      if (status) status.textContent = exact ? `Sticker results for “${exact}”` : "Trending stickers";
    } catch {
      if (status) status.textContent = "Could not load GIPHY stickers";
    }
  }

  function bindStickerTabs() {
    const mine = $("#myStickerTab");
    const giphy = $("#giphyStickerTab");
    const panel = $("#giphyStickerPanel");
    const ownGrid = $("#stickerLibrary");
    const ownEmpty = $("#stickerEmpty");
    const ownCreate = $("#createBlankStickerBtn");
    const switchTab = (tab) => {
      const external = tab === "giphy";
      mine?.classList.toggle("active", !external);
      giphy?.classList.toggle("active", external);
      mine?.setAttribute("aria-selected", external ? "false" : "true");
      giphy?.setAttribute("aria-selected", external ? "true" : "false");
      panel?.classList.toggle("hidden", !external);
      ownGrid?.classList.toggle("hidden", external);
      ownEmpty?.classList.toggle("v53-tab-suppressed", external);
      ownCreate?.classList.toggle("hidden", external);
      if (external) loadGiphyStickers($("#giphyStickerSearch")?.value || "");
    };
    mine?.addEventListener("click", () => switchTab("mine"));
    giphy?.addEventListener("click", () => switchTab("giphy"));
    let timer = 0;
    $("#giphyStickerSearch")?.addEventListener("input", (event) => {
      clearTimeout(timer);
      timer = setTimeout(() => loadGiphyStickers(event.currentTarget.value), 220);
    });
  }

  // ---------------------------------------------------------------------------
  // Avatar Studio visual option cards
  // ---------------------------------------------------------------------------
  const avatarCardFields = {
    avatarFaceShape: "face_shape",
    avatarEyes: "eyes",
    avatarHair: "hair",
    avatarOutfit: "outfit",
    avatarAccessory: "accessory",
    avatarHeadwear: "headwear",
    avatarFacialHair: "facial_hair",
    avatarBackground: "background",
  };

  function currentAvatarStyle() {
    const stateStyle = { ...(app()?.state?.avatarStyleDraft || app()?.state?.me?.avatar_style || {}) };
    const ids = {
      skin: "avatarSkin", face_shape: "avatarFaceShape", hair: "avatarHair",
      hair_color: "avatarHairColor", eye_color: "avatarEyeColor", eyes: "avatarEyes",
      brows: "avatarBrows", nose: "avatarNose", mouth: "avatarMouth",
      face_detail: "avatarFaceDetail", outfit: "avatarOutfit",
      outfit_color: "avatarOutfitColor", outfit_pattern: "avatarOutfitPattern",
      background: "avatarBackground", background_pattern: "avatarBackgroundPattern",
      accessory: "avatarAccessory", accessory_color: "avatarAccessoryColor",
      headwear: "avatarHeadwear", facial_hair: "avatarFacialHair",
      face_width: "avatarFaceWidth", face_length: "avatarFaceLength", jaw_width: "avatarJawWidth",
      eye_scale: "avatarEyeScale", eye_spacing: "avatarEyeSpacing", eye_height: "avatarEyeHeight",
      nose_scale: "avatarNoseScale", mouth_width: "avatarMouthWidth", brow_height: "avatarBrowHeight",
      ear_size: "avatarEarSize", neck_width: "avatarNeckWidth",
      skin_hex: "avatarSkinHex", hair_hex: "avatarHairHex", eye_hex: "avatarEyeHex",
      lip_hex: "avatarLipHex", outfit_hex: "avatarOutfitHex",
      background_hex: "avatarBackgroundHex", accessory_hex: "avatarAccessoryHex",
    };
    for (const [key, id] of Object.entries(ids)) {
      const field = $(`#${id}`);
      if (field) stateStyle[key] = field.value;
    }
    return stateStyle;
  }

  function refreshAvatarCardSelections() {
    for (const [id] of Object.entries(avatarCardFields)) {
      const select = $(`#${id}`);
      const grid = select?.parentElement?.querySelector(".v53-avatar-options");
      if (!select || !grid) continue;
      $$("[data-avatar-value]", grid).forEach((card) => {
        const selected = card.dataset.avatarValue === select.value;
        card.classList.toggle("selected", selected);
        card.setAttribute("aria-pressed", selected ? "true" : "false");
      });
    }
  }

  function buildAvatarChoiceCards() {
    if (runtime.avatarCardsBuilt || !app()?.avatarStyleDataUrl) return;
    runtime.avatarCardsBuilt = true;
    for (const [id, styleKey] of Object.entries(avatarCardFields)) {
      const select = $(`#${id}`);
      if (!select || select.dataset.visualized === "1") continue;
      select.dataset.visualized = "1";
      select.classList.add("v53-avatar-select-fallback");
      const grid = document.createElement("div");
      grid.className = "v53-avatar-options";
      grid.setAttribute("role", "group");
      grid.setAttribute("aria-label", select.closest("label")?.querySelector("span")?.textContent || "Avatar choices");
      for (const option of Array.from(select.options)) {
        const card = document.createElement("button");
        card.type = "button";
        card.className = "v53-avatar-option";
        card.dataset.avatarValue = option.value;
        const sample = { ...currentAvatarStyle(), [styleKey]: option.value };
        const image = document.createElement("img");
        image.alt = "";
        image.loading = "lazy";
        image.decoding = "async";
        image.src = app().avatarStyleDataUrl(sample);
        const label = document.createElement("span");
        label.textContent = option.textContent;
        card.append(image, label);
        card.addEventListener("click", () => {
          select.value = option.value;
          select.dispatchEvent(new Event("change", { bubbles: true }));
          refreshAvatarCardSelections();
          // Refresh previews for neighboring choices so color/skin edits are
          // represented before the next selection.
          requestAnimationFrame(() => refreshAvatarCardPreviews(id, styleKey));
        });
        grid.appendChild(card);
      }
      select.insertAdjacentElement("afterend", grid);
    }
    refreshAvatarCardSelections();
  }

  function refreshAvatarCardPreviews(id, styleKey) {
    const select = $(`#${id}`);
    const grid = select?.parentElement?.querySelector(".v53-avatar-options");
    if (!grid || !app()?.avatarStyleDataUrl) return;
    for (const card of $$("[data-avatar-value]", grid)) {
      const image = card.querySelector("img");
      if (image) image.src = app().avatarStyleDataUrl({
        ...currentAvatarStyle(),
        [styleKey]: card.dataset.avatarValue,
      });
    }
  }

  function bindAvatarCards() {
    $("#avatarBuilder")?.addEventListener("click", () => requestAnimationFrame(buildAvatarChoiceCards), { once: true });
    $("#customAvatarBtn")?.addEventListener("click", () => setTimeout(buildAvatarChoiceCards, 0));
    $("#avatarBuilder")?.addEventListener("change", () => {
      refreshAvatarCardSelections();
    });
  }

  // ---------------------------------------------------------------------------
  // Personal autocorrect dictionary
  // ---------------------------------------------------------------------------
  const PROTECTED_WORDS_KEY = "silknex-autocorrect-protected-v1";

  function protectedWords() {
    try {
      return Array.from(new Set(
        String(localStorage.getItem(PROTECTED_WORDS_KEY) || "")
          .split(/[\s,\n]+/u)
          .map((word) => word.trim())
          .filter((word) => /^[A-Za-z0-9'_.-]{1,40}$/u.test(word))
      )).slice(0, 300);
    } catch {
      return [];
    }
  }

  function saveProtectedWords(words) {
    const normalized = Array.from(new Set(words.map((word) => word.trim()).filter(Boolean))).slice(0, 300);
    try { localStorage.setItem(PROTECTED_WORDS_KEY, normalized.join("\n")); } catch {}
    renderProtectedWords();
  }

  function renderProtectedWords() {
    const list = $("#v53ProtectedWordsList");
    if (!list) return;
    list.replaceChildren();
    for (const word of protectedWords()) {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "v53-word-chip";
      chip.title = "Remove from never-correct list";
      chip.textContent = `${word} ×`;
      chip.onclick = () => saveProtectedWords(protectedWords().filter((item) => item !== word));
      list.appendChild(chip);
    }
    if (!list.children.length) {
      const hint = document.createElement("small");
      hint.textContent = "No protected words yet.";
      list.appendChild(hint);
    }
  }

  function installAutocorrectDictionaryUi() {
    if ($("#v53AutocorrectDictionary")) return;
    const existing = $("#openTextReplacementsBtn")?.closest(".settings-section") || $("#settingsModal .settings-stack");
    if (!existing) return;
    const box = document.createElement("div");
    box.id = "v53AutocorrectDictionary";
    box.className = "v53-autocorrect-dictionary";
    box.innerHTML = `
      <div><b>Never autocorrect</b><small>Add names, slang, game terms, or words that match your typing style.</small></div>
      <div class="v53-word-add"><input id="v53ProtectedWordInput" maxlength="40" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="Add a word"><button id="v53AddProtectedWordBtn" class="secondary-btn" type="button">Add</button></div>
      <div id="v53ProtectedWordsList" class="v53-word-chips"></div>`;
    existing.appendChild(box);
    const add = () => {
      const input = $("#v53ProtectedWordInput");
      const word = String(input?.value || "").trim();
      if (!/^[A-Za-z0-9'_.-]{1,40}$/u.test(word)) {
        toast("Enter one word, name, or handle.");
        return;
      }
      saveProtectedWords([...protectedWords(), word]);
      input.value = "";
    };
    $("#v53AddProtectedWordBtn").onclick = add;
    $("#v53ProtectedWordInput").addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        add();
      }
    });
    renderProtectedWords();
  }

  // ---------------------------------------------------------------------------
  // Founder-only additions: privacy health and manual maintenance
  // ---------------------------------------------------------------------------
  async function installFounderV53() {
    if (!isFounder() || runtime.founderBound) return;
    runtime.founderBound = true;
    const host = $("#ownerControlCenterModal .owner-dashboard, #ownerControlCenterModal .modal-card, #founderControlCenter .modal-card");
    if (!host || $("#v53FounderTools")) return;

    const section = document.createElement("section");
    section.id = "v53FounderTools";
    section.className = "owner-panel-section v53-founder-tools";
    section.innerHTML = `
      <div class="section-title"><span>Founder privacy & maintenance</span></div>
      <div id="v53FounderPrivacyHealth" class="v53-founder-health"><small>Load privacy health to inspect encryption-device coverage without reading private content.</small></div>
      <div class="v53-founder-actions">
        <button id="v53FounderPrivacyRefresh" class="secondary-btn" type="button">Refresh privacy health</button>
        <button id="v53FounderMaintenanceRun" class="secondary-btn" type="button">Run safe cleanup now</button>
      </div>`;
    host.appendChild(section);

    const refresh = async () => {
      const target = $("#v53FounderPrivacyHealth");
      target.textContent = "Loading…";
      try {
        const data = await app().api("owner_privacy_health", { showLoader: false });
        const health = data.health || {};
        target.replaceChildren();
        for (const [label, value] of [
          ["Accounts", health.accounts],
          ["Accounts with E2EE device", health.accounts_with_e2ee_device],
          ["Active E2EE devices", health.active_e2ee_devices],
          ["Public profiles", health.public_profiles],
          ["Active public stories", health.active_public_stories],
          ["Encrypted message rows (24h)", health.encrypted_messages_24h],
        ]) {
          const card = document.createElement("div");
          card.innerHTML = `<small></small><b></b>`;
          card.querySelector("small").textContent = label;
          card.querySelector("b").textContent = Number(value || 0).toLocaleString();
          target.appendChild(card);
        }
      } catch (error) {
        target.textContent = error?.message || "Could not load privacy health.";
      }
    };
    $("#v53FounderPrivacyRefresh").onclick = refresh;
    $("#v53FounderMaintenanceRun").onclick = async () => {
      try {
        const data = await app().api("owner_maintenance_run", { method: "POST", body: {} });
        toast(`Cleanup complete · ${Number(data.expired_stories || 0)} expired stories and ${Number(data.expired_messages || 0)} expired messages removed.`);
        refresh();
      } catch (error) {
        toast(error?.message || "Could not run cleanup.");
      }
    };
    refresh();
  }

  // ---------------------------------------------------------------------------
  // App install polish + startup deep links
  // ---------------------------------------------------------------------------
  function applyStandaloneClass() {
    const standalone = window.matchMedia?.("(display-mode: standalone)")?.matches || navigator.standalone === true;
    document.documentElement.classList.toggle("silknex-installed", Boolean(standalone));
  }

  function bindGlobalActions() {
    $("#scanProfileQrBtn")?.addEventListener("click", startQrScanner);
    $("#stopQrScannerBtn")?.addEventListener("click", stopQrScanner);
    $("#qrManualOpenBtn")?.addEventListener("click", () => {
      const username = escapeUsername($("#qrManualUsername")?.value);
      if (!/^[a-z0-9_.]{3,24}$/.test(username)) {
        toast("Enter a valid SilkNex username.");
        return;
      }
      stopQrScanner();
      app()?.closeModal?.("profileQrModal");
      openPublicProfile(username);
    });
    window.addEventListener("silknex:modal", (event) => {
      if (event.detail?.open === false || event.detail?.id !== "profileQrModal") stopQrScanner();
    });

    const params = new URLSearchParams(location.search);
    const username = escapeUsername(params.get("u") || params.get("profile") || "");
    if (username) {
      setTimeout(() => {
        if (app()?.state?.me) openPublicProfile(username);
      }, 500);
    }

    window.matchMedia?.("(display-mode: standalone)")?.addEventListener?.("change", applyStandaloneClass);
    applyStandaloneClass();
  }

  function initWhenReady() {
    if (!app()) {
      window.addEventListener("silknex:core-ready", initWhenReady, { once: true });
      return;
    }
    document.documentElement.dataset.silknexRelease = VERSION;
    bindViewport();
    bindGlobalActions();
    bindStoryPrivacy();
    bindStickerTabs();
    bindAvatarCards();

    // Delay settings-only enhancements until after authentication hydration.
    const finish = () => {
      installPublicProfileSettings();
      installAutocorrectDictionaryUi();
      installFounderV53();
    };
    setTimeout(finish, 250);
    window.addEventListener("silknex:session", finish);
    window.addEventListener("silknex:owner-ready", installFounderV53);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initWhenReady, { once: true });
  } else {
    initWhenReady();
  }
})();
