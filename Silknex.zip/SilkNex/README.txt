SILKNEX v78.0

Read UPGRADE-v78.txt before updating an existing installation.

Upload the SilkNex directory contents to a PHP/MySQL HTTPS host, including
access-control files. Open index.php. Preserve deployed config.php, private
keys, uploads and browser site storage. Never replace an existing database
with database.sql. The first API request applies schema 58 automatically.
The included configuration incorporates the most recent mail-ready settings.

Requires PHP 8.1+ with PDO MySQL, OpenSSL, mbstring and fileinfo; writable
private/upload storage; WebCrypto and browser storage for encrypted messages.
New account verification also needs configured PHP mail delivery. See
EMAIL-AND-CALL-SETUP.txt. No live host was contacted during development.

New in v78: a separate T0K3N Co-Founder/CEO account, a larger school review bank, and scheduled app access blocks. Earlier features include verified-email access levels, managed school accounts, teacher class
projects, school quote configuration, a local 550-phrase review bank, servers,
channels, ranks, six-person group calls, camera-zoom request fixes, appearance
controls and additional CEO statistics. Existing account, mobile, voice,
subscription, customization and encrypted-message functionality is retained.

Open Spaces in the sidebar or Account, schools & spaces in Settings.
School enrollment and teacher assignment are Founder-only. Text flags are
category indicators for human review, not automatic discipline. School pricing
is $15/student plus $2/student per supported extra per agreed billing period;
it is a quote and does not charge a subscription.

This is a responsive web application, not a native app-store package. Browser
and hardware support vary. FINAL-VERIFICATION.txt records automated test scope;
physical devices, real mail, MySQL migration and multi-user calls still require
staging verification. No universal compatibility or zero-bug claim is made.
