SILKNEX v55.0 — CALLS, MOBILE INPUT, MEDIA & PERSONALIZATION
================================================================

Silknex v55.0 is a compatibility-focused upgrade over v54.0. It keeps the
existing database schema and encrypted-message format while improving live
calls, mobile typing, media handling, public profiles, QR sharing, friend
discovery, stickers, GIF creation, personalization, and Avatar Studio.

Release highlights
------------------
- Voice calls can enable a camera later without disconnecting. Voice sessions
  pre-negotiate a video channel so camera and screen sharing can be added cleanly.
- Camera previews use contain sizing instead of cropping, and compatible cameras
  expose hardware zoom controls. Healthy links target adaptive 720p mobile and
  1080p desktop capture/encoding, with automatic congestion fallback.
- Screen sharing keeps the source aspect ratio, prefers native/high-detail
  capture, and reuses the negotiated call video channel. Mobile browsers use the
  same flow whenever they expose getDisplayMedia.
- The mobile composer tracks the Visual Viewport/Virtual Keyboard so the input
  stays immediately above the software keyboard while the message pane remains
  visible and scrollable.
- Images are optimized to efficient WebP when doing so materially saves space
  without aggressive downscaling. Short large videos can be re-encoded at their
  source dimensions with a lower bitrate when the browser supports it.
- Sticker Maker now erases source-image pixels into real transparency, so manual
  background removal survives export.
- GIF Maker adds HD sizing, 15 FPS, reverse/boomerang playback, visual filters,
  captions, and caption positioning.
- Profile QR codes encode a real profile link when it fits the QR payload and
  retain the Silknex scheme fallback. The QR view also exposes profile sharing.
- Public profiles show mutual friends and keep user-controlled banner images.
  Banner uploads use the media optimizer before storage.
- A customizable in-app quick keyboard supports presets and user-defined keys.
  New appearance toggles include compact composition and flatter message bubbles.
- Avatar Studio adds more background patterns, facial detail, earbuds, headbands,
  and bows while retaining the larger v54 customization catalog.
- Existing P-256/HKDF/AES-GCM E2EE and encrypted attachment compatibility are
  retained; the release avoids introducing incompatible custom cryptography.

Compatibility
-------------
Database schema: 53 (unchanged)
Application release: 55.0
Existing v53/v54 encrypted messages remain compatible.
