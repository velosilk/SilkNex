(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const nowSeconds = () => Math.floor(Date.now() / 1000);
  const cspNonce =
    document.querySelector('script[src*="silknex-features.js"]')?.nonce || "";

  const ads = {
    config: null,
    status: null,
    signedIn: false,
    adsensePromise: null,
    gptPromise: null,
    rendered: new Set(),
    statusTimer: null,
    uiTimer: null,
    rewardToken: "",
    rewardClaimAt: 0,
    rewardSlot: null,
    rewardGranted: false,
    rewardTimeout: null,
    rewardCleanup: null,
    clientKey: "",
    homeRenderPending: false,
    adObserver: null,
    viewportObserver: null,
    homeAnchorMode: "",
    adsenseRetryAfter: 0,
    telemetryQueue: [],
    telemetryTimer: null,
    telemetrySending: false,
    interstitialSlot: null,
    interstitialCleanup: null,
    interstitialPending: false,
    interstitialMarked: false,
    interstitialArmTimer: null,
    homeEligibleSince: 0,
    lastPrivateSurfaceAt: 0,
    sessionInterstitialViews: 0,
    storyAdDue: false,
    campaign: null,
    campaignFetchedAt: 0,
    campaignPromise: null,
    interstitialVisible: false,
    interstitialCloseTimer: null,
    advertisePreviewUrl: "",
  };

  const INTERSTITIAL_HOME_DWELL_MS = 8000;
  const INTERSTITIAL_PRIVATE_COOLDOWN_MS = 45000;
  const INTERSTITIAL_SESSION_MAX = 3;

  function app() {
    return window.SilknexApp || null;
  }

  function randomHex(bytes = 16) {
    const data = new Uint8Array(bytes);
    crypto.getRandomValues(data);
    return Array.from(data, (b) => b.toString(16).padStart(2, "0")).join("");
  }

  function clientKey() {
    if (ads.clientKey) return ads.clientKey;
    try {
      const existing = sessionStorage.getItem("silknex-ad-client-key");
      if (/^[a-f0-9]{32}$/.test(existing || "")) {
        ads.clientKey = existing;
        return existing;
      }
      ads.clientKey = randomHex(16);
      sessionStorage.setItem("silknex-ad-client-key", ads.clientKey);
      return ads.clientKey;
    } catch {
      ads.clientKey = randomHex(16);
      return ads.clientKey;
    }
  }

  function validAdsenseClient(value) {
    return /^ca-pub-\d{8,32}$/i.test(String(value || "").trim());
  }

  function validSlot(value) {
    return /^\d{5,32}$/.test(String(value || "").trim());
  }

  function adsDisabled() {
    // The built-in Founder/CEO identity is always ad-free. This is enforced
    // from the authenticated role rather than a client preference, so ordinary
    // accounts cannot unlock it by editing local storage or CSS.
    return Boolean(
      ads.status?.ads_disabled ||
      app()?.state?.me?.role === "founder_ceo"
    );
  }

  function onHome() {
    const state = app()?.state;
    return Boolean(
      ads.signedIn &&
      state &&
      Number(state.activeId || 0) === 0 &&
      !state.call &&
      !$("#emptyState")?.classList.contains("hidden") &&
      document.visibilityState === "visible"
    );
  }

  function blockingModalOpen() {
    return Boolean(
      document.querySelector(".modal:not(.hidden)") ||
      document.querySelector("#fullscreenMediaModal:not(.hidden)") ||
      document.querySelector("#adInterstitial:not(.hidden)")
    );
  }

  function placeHomeAdForViewport() {
    const slot = $("#homeAdSlot");
    const mobileAnchor = $("#mobileHomeAdAnchor");
    const desktopAnchor = $("#desktopHomeAdAnchor");
    if (!slot || !mobileAnchor || !desktopAnchor) return;

    const mobile = Boolean(window.matchMedia?.("(max-width: 760px)")?.matches);
    const mode = mobile ? "mobile" : "desktop";
    const target = mobile ? mobileAnchor : desktopAnchor;

    // AdSense units should not be moved after they have rendered. If the user
    // rotates the device or crosses the responsive breakpoint, clear the old
    // unit and request a fresh one in its new stable container.
    if (ads.homeAnchorMode && ads.homeAnchorMode !== mode && ads.rendered.has("home")) {
      resetHomeBanner();
    }
    ads.homeAnchorMode = mode;

    if (slot.parentElement !== target) target.appendChild(slot);
    mobileAnchor.setAttribute("aria-hidden", mobile ? "false" : "true");
  }

  function telemetry(eventType, placement, provider = "adsense") {
    if (!ads.signedIn || !app()) return;
    const event = {
      provider: String(provider || "adsense").toLowerCase(),
      placement: String(placement || "").toLowerCase(),
      event_type: String(eventType || "").toLowerCase(),
      client_key: clientKey(),
      client_at: nowSeconds(),
    };
    ads.telemetryQueue.push(event);
    if (ads.telemetryQueue.length > 24) ads.telemetryQueue.splice(0, ads.telemetryQueue.length - 24);

    const flushSoon = ads.telemetryQueue.length >= 6 ? 40 : 900;
    clearTimeout(ads.telemetryTimer);
    ads.telemetryTimer = setTimeout(flushTelemetry, flushSoon);
  }

  async function flushTelemetry() {
    if (ads.telemetrySending || !ads.signedIn || !app() || !ads.telemetryQueue.length) return;
    if (navigator.onLine === false) {
      clearTimeout(ads.telemetryTimer);
      ads.telemetryTimer = setTimeout(flushTelemetry, 3000);
      return;
    }

    const batch = ads.telemetryQueue.splice(0, 12);
    ads.telemetrySending = true;
    try {
      await app().api("ad_events_batch", {
        method: "POST",
        body: { events: batch },
        showLoader: false,
        keepalive: true,
        timeoutMs: 5000,
      });
    } catch {
      ads.telemetryQueue.unshift(...batch);
      if (ads.telemetryQueue.length > 24) ads.telemetryQueue.length = 24;
    } finally {
      ads.telemetrySending = false;
      if (ads.telemetryQueue.length) {
        clearTimeout(ads.telemetryTimer);
        ads.telemetryTimer = setTimeout(flushTelemetry, 1800);
      }
    }
  }

  function waitForAdsense(existing) {
    return new Promise((resolve) => {
      if (Array.isArray(window.adsbygoogle)) {
        resolve(true);
        return;
      }

      let settled = false;
      const finish = (value) => {
        if (settled) return;
        settled = true;
        clearInterval(poll);
        clearTimeout(timeout);
        resolve(value);
      };

      existing?.addEventListener?.("load", () => finish(true), { once: true });
      existing?.addEventListener?.("error", () => finish(false), { once: true });

      const poll = setInterval(() => {
        if (Array.isArray(window.adsbygoogle)) finish(true);
      }, 80);
      const timeout = setTimeout(() => finish(Array.isArray(window.adsbygoogle)), 5000);
    });
  }

  function loadAdsense() {
    const client = String(ads.config?.adsense?.client || "").trim();
    if (!ads.config?.adsense?.enabled || !validAdsenseClient(client)) {
      return Promise.resolve(false);
    }
    if (navigator.onLine === false) return Promise.resolve(false);
    if (Date.now() < ads.adsenseRetryAfter) return Promise.resolve(false);
    if (ads.adsensePromise) return ads.adsensePromise;

    const existing = document.querySelector("script[data-silknex-adsense]");
    if (existing) {
      ads.adsensePromise = waitForAdsense(existing).then((ready) => {
        if (!ready) {
          existing.remove();
          ads.adsensePromise = null;
          ads.adsenseRetryAfter = Date.now() + 30000;
        }
        return ready;
      });
      return ads.adsensePromise;
    }

    ads.adsensePromise = new Promise((resolve) => {
      const script = document.createElement("script");
      script.async = true;
      script.crossOrigin = "anonymous";
      script.fetchPriority = "low";
      if (cspNonce) script.nonce = cspNonce;
      script.dataset.silknexAdsense = "1";
      script.src =
        "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=" +
        encodeURIComponent(client);

      const finish = (ready) => {
        if (!ready) {
          script.remove();
          ads.adsensePromise = null;
          ads.adsenseRetryAfter = Date.now() + 30000;
        } else {
          ads.adsenseRetryAfter = 0;
        }
        resolve(ready);
      };
      script.addEventListener("load", () => finish(true), { once: true });
      script.addEventListener("error", () => finish(false), { once: true });
      document.head.appendChild(script);
    });

    return ads.adsensePromise;
  }

  async function fetchPaidCampaign(force = false) {
    if (!ads.signedIn || !app() || navigator.onLine === false) return null;
    const freshFor = 90000;
    const currentEpoch = Math.floor(Date.now() / 1000);
    if (ads.campaign?.ends_at && Number(ads.campaign.ends_at) <= currentEpoch) {
      ads.campaign = null;
      ads.campaignFetchedAt = 0;
    }
    if (!force && ads.campaignFetchedAt && Date.now() - ads.campaignFetchedAt < freshFor) {
      return ads.campaign;
    }
    if (ads.campaignPromise) return ads.campaignPromise;

    ads.campaignPromise = app().api("ad_inventory", {
      showLoader: false,
      timeoutMs: 7000,
    }).then((data) => {
      ads.campaign = data.campaign || null;
      ads.campaignFetchedAt = Date.now();
      return ads.campaign;
    }).catch(() => {
      ads.campaignFetchedAt = Date.now();
      return null;
    }).finally(() => {
      ads.campaignPromise = null;
    });

    return ads.campaignPromise;
  }

  function buildCampaignCreative(campaign, placement = "home") {
    if (!campaign?.image_url || !campaign?.destination_url) return null;

    const link = document.createElement("a");
    link.className = placement === "interstitial"
      ? "silknex-paid-ad silknex-paid-ad-fullscreen"
      : "silknex-paid-ad silknex-paid-ad-banner";
    link.href = String(campaign.destination_url);
    link.target = "_blank";
    link.rel = "noopener noreferrer sponsored";
    link.dataset.campaignId = String(campaign.id || "");

    const image = document.createElement("img");
    image.src = String(campaign.image_url);
    image.alt = String(campaign.headline || "Sponsored");
    image.loading = placement === "interstitial" ? "eager" : "lazy";
    image.decoding = "async";
    link.appendChild(image);

    const copy = document.createElement("span");
    copy.className = "silknex-paid-ad-copy";
    const label = document.createElement("small");
    label.textContent = "Sponsored";
    const title = document.createElement("b");
    title.textContent = String(campaign.headline || "Sponsored");
    const cta = document.createElement("span");
    cta.className = "silknex-paid-ad-cta";
    cta.textContent = "Learn more";
    copy.append(label, title, cta);
    link.appendChild(copy);

    link.addEventListener("click", () => {
      telemetry("rendered", placement === "interstitial" ? "home_interstitial" : "home", "house");
    }, { passive: true });

    return link;
  }

  function closePaidInterstitial() {
    clearTimeout(ads.interstitialCloseTimer);
    ads.interstitialCloseTimer = null;
    ads.interstitialVisible = false;
    const modal = $("#adInterstitial");
    const target = $("#interstitialAdTarget");
    modal?.classList.add("hidden");
    modal?.setAttribute("aria-hidden", "true");
    target?.replaceChildren();
    document.documentElement.classList.remove("ad-fullscreen-open");
  }

  async function showPaidInterstitial(campaign) {
    if (!campaign || !homeInterstitialEligible() || ads.interstitialVisible) return false;
    const modal = $("#adInterstitial");
    const target = $("#interstitialAdTarget");
    const close = $("#adSkipBtn");
    const title = $("#adInterstitialTitle");
    const countdown = $("#adCountdown");
    if (!modal || !target || !close) return false;

    const creative = buildCampaignCreative(campaign, "interstitial");
    if (!creative) return false;

    target.replaceChildren(creative);
    if (title) title.textContent = String(campaign.headline || "Advertisement");
    if (countdown) countdown.textContent = "Ad";

    modal.classList.remove("hidden");
    modal.setAttribute("aria-hidden", "false");
    document.documentElement.classList.add("ad-fullscreen-open");
    ads.interstitialVisible = true;
    ads.storyAdDue = false;
    ads.sessionInterstitialViews += 1;
    if (ads.status) {
      ads.status.interstitial_due = false;
      const minSeconds = Math.max(
        900,
        Number(ads.status.interstitial_min_seconds || ads.config?.ad_manager?.interstitial_min_seconds || 1200)
      );
      ads.status.interstitial_next_at = nowSeconds() + minSeconds;
    }
    telemetry("interstitial_viewed", "home_interstitial", "house");

    // Keep this dismissible and reasonable while preventing accidental instant
    // taps from closing a just-opened full-screen placement.
    close.disabled = true;
    close.textContent = "Close in 4";
    let remaining = 4;
    const tick = () => {
      remaining -= 1;
      if (remaining <= 0) {
        close.disabled = false;
        close.textContent = "Close";
        ads.interstitialCloseTimer = null;
        return;
      }
      close.textContent = `Close in ${remaining}`;
      ads.interstitialCloseTimer = setTimeout(tick, 1000);
    };
    ads.interstitialCloseTimer = setTimeout(tick, 1000);

    try {
      const data = await app().api("interstitial_impression", {
        method: "POST",
        body: { provider: "house" },
        showLoader: false,
        timeoutMs: 6000,
      });
      ads.status = data.status || ads.status;
      updatePlanUi();
    } catch {}

    return true;
  }

  async function renderPaidHomeBanner(slot, target, stateLabel) {
    const campaign = await fetchPaidCampaign();
    if (!campaign || !onHome() || adsDisabled()) return false;
    const creative = buildCampaignCreative(campaign, "home");
    if (!creative) return false;

    try { ads.adObserver?.disconnect?.(); } catch {}
    ads.adObserver = null;
    target.replaceChildren(creative);
    slot.classList.remove("hidden");
    ads.rendered.add("home");
    if (stateLabel) stateLabel.textContent = "Sponsored";
    telemetry("rendered", "home", "house");
    return true;
  }

  function resetHomeBanner() {
    const slot = $("#homeAdSlot");
    const target = slot?.querySelector(".ad-render-target");
    try { ads.adObserver?.disconnect?.(); } catch {}
    ads.adObserver = null;
    try { ads.viewportObserver?.disconnect?.(); } catch {}
    ads.viewportObserver = null;
    slot?.classList.add("hidden");
    target?.replaceChildren();
    ads.rendered.delete("home");
  }

  function observeAdState(unit, placement) {
    if (!unit || typeof MutationObserver === "undefined") return;
    try { ads.adObserver?.disconnect?.(); } catch {}

    let last = "";
    const observer = new MutationObserver(() => {
      const status = String(unit.getAttribute("data-ad-status") || "");
      if (!status || status === last) return;
      last = status;

      if (status === "filled") {
        telemetry("rendered", placement);
        observer.disconnect();
        if (ads.adObserver === observer) ads.adObserver = null;
      } else if (status === "unfilled") {
        telemetry("unfilled", placement);
        observer.disconnect();
        if (ads.adObserver === observer) ads.adObserver = null;
        if (placement === "home") {
          // Do not leave a large empty sponsored card behind when Google has
          // no fill for this request.
          setTimeout(() => {
            if (String(unit.getAttribute("data-ad-status") || "") === "unfilled") {
              resetHomeBanner();
            }
          }, 180);
        }
      }
    });
    observer.observe(unit, {
      attributes: true,
      attributeFilter: ["data-ad-status"],
    });
    ads.adObserver = observer;
  }

  async function renderHomeBanner() {
    placeHomeAdForViewport();
    const slot = $("#homeAdSlot");
    const target = slot?.querySelector(".ad-render-target");
    const stateLabel = $("#homeAdState");
    const cfg = ads.config?.adsense || {};

    if (!slot || !target) return;

    if (
      ads.signedIn &&
      !adsDisabled() &&
      onHome() &&
      !ads.rendered.has("home") &&
      await renderPaidHomeBanner(slot, target, stateLabel)
    ) {
      $("#chatAdSlot")?.classList.add("hidden");
      return;
    }

    const eligible =
      ads.signedIn &&
      !adsDisabled() &&
      onHome() &&
      Boolean(cfg.enabled) &&
      Boolean(cfg.manual_home_enabled) &&
      validAdsenseClient(cfg.client) &&
      validSlot(cfg.home_slot);

    slot.classList.toggle("hidden", !eligible);
    $("#chatAdSlot")?.classList.add("hidden");

    if (!eligible) {
      if (
        !ads.signedIn ||
        adsDisabled() ||
        !cfg.enabled ||
        !cfg.manual_home_enabled ||
        !validAdsenseClient(cfg.client) ||
        !validSlot(cfg.home_slot)
      ) {
        resetHomeBanner();
      }
      return;
    }
    if (ads.rendered.has("home")) return;

    if (stateLabel) stateLabel.textContent = "Loading";
    const ready = await loadAdsense();
    if (!ready || ads.rendered.has("home") || !onHome() || adsDisabled()) {
      telemetry("blocked", "home");
      if (!ready || !onHome() || adsDisabled()) resetHomeBanner();
      return;
    }

    target.replaceChildren();
    const unit = document.createElement("ins");
    unit.className = "adsbygoogle silknex-adsense-unit";
    unit.style.display = "block";
    unit.dataset.adClient = String(cfg.client);
    unit.dataset.adSlot = String(cfg.home_slot);
    unit.dataset.adFormat = "auto";
    unit.dataset.fullWidthResponsive = "true";
    if (cfg.channel) unit.dataset.adChannel = String(cfg.channel);
    if (cfg.test_mode) unit.dataset.adtest = "on";
    target.appendChild(unit);

    ads.rendered.add("home");
    telemetry("requested", "home");
    observeAdState(unit, "home");

    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
      if (stateLabel) stateLabel.textContent = "Sponsored";
    } catch {
      telemetry("blocked", "home");
      resetHomeBanner();
    }
  }

  function updatePlanUi() {
    const status = ads.status || {};
    const title = $("#adPlanTitle");
    const copy = $("#adPlanStatus");
    const progress = $("#rewardProgress");
    const watch = $("#watchRewardAdBtn");
    const subscribe = $("#subscribeNoAdsBtn");
    const rewardedReady = Boolean(ads.config?.ad_manager?.rewarded_enabled);

    if (progress) progress.textContent = `${Number(status.rewarded_count || 0)}/5`;

    if (status.subscription_active) {
      if (title) title.textContent = "SilkNex Plus · Ad-free";
      if (copy) copy.textContent = "Your subscription removes SilkNex ad placements on this account.";
      if (watch) {
        watch.disabled = true;
        watch.textContent = "Ads disabled";
      }
      if (subscribe) {
        subscribe.disabled = true;
        subscribe.textContent = "Subscribed · No ads";
      }
      return;
    }

    if (status.pass_active) {
      const remaining = Math.max(0, Number(status.ad_pass_until || 0) - nowSeconds());
      const minutes = Math.max(1, Math.ceil(remaining / 60));
      if (title) title.textContent = `Ad pass active · ${minutes} min left`;
      if (copy) copy.textContent = "SilkNex ad placements are paused until this pass expires.";
      if (watch) {
        watch.disabled = true;
        watch.textContent = "Ad pass active";
      }
    } else {
      if (title) title.textContent = "Ad-supported";
      if (copy) {
        copy.textContent = rewardedReady
          ? "Watch 5 optional rewarded ads for a 30-minute pass, or subscribe for $2.50/month."
          : "Google AdSense supports the home placement. Reward ads need an optional Google Ad Manager rewarded unit.";
      }
      if (watch) {
        watch.disabled = !rewardedReady;
        watch.innerHTML = rewardedReady
          ? `Watch reward ad <span id="rewardProgress">${Number(status.rewarded_count || 0)}/5</span>`
          : "Reward ads unavailable";
      }
    }

    if (subscribe) {
      subscribe.disabled = false;
      subscribe.textContent = "$2.50/month · No ads";
    }
  }

  function scheduleHomeBanner() {
    if (ads.homeRenderPending) return;
    ads.homeRenderPending = true;

    const run = () => {
      ads.homeRenderPending = false;
      renderHomeBanner().catch(() => {});
    };

    const anchor = window.matchMedia?.("(max-width: 760px)")?.matches
      ? $("#mobileHomeAdAnchor")
      : $("#desktopHomeAdAnchor");

    if (
      anchor &&
      typeof IntersectionObserver !== "undefined" &&
      onHome() &&
      !adsDisabled()
    ) {
      try { ads.viewportObserver?.disconnect?.(); } catch {}
      ads.viewportObserver = new IntersectionObserver((entries, observer) => {
        if (!entries.some((entry) => entry.isIntersecting || entry.intersectionRatio > 0)) return;
        observer.disconnect();
        if (ads.viewportObserver === observer) ads.viewportObserver = null;
        if ("requestIdleCallback" in window) {
          window.requestIdleCallback(run, { timeout: 900 });
        } else {
          setTimeout(run, 80);
        }
      }, { rootMargin: "420px 0px" });
      ads.viewportObserver.observe(anchor);
      return;
    }

    if ("requestIdleCallback" in window) {
      window.requestIdleCallback(run, { timeout: 1200 });
    } else {
      setTimeout(run, 160);
    }
  }


  function clearHomeInterstitial() {
    if (ads.interstitialVisible) closePaidInterstitial();
    try { ads.interstitialCleanup?.(); } catch {}
    ads.interstitialCleanup = null;
    const slot = ads.interstitialSlot;
    ads.interstitialSlot = null;
    ads.interstitialPending = false;
    ads.interstitialMarked = false;
    if (slot && window.googletag?.destroySlots) {
      try { window.googletag.destroySlots([slot]); } catch {}
    }
  }

  function clearInterstitialArmTimer() {
    clearTimeout(ads.interstitialArmTimer);
    ads.interstitialArmTimer = null;
  }

  function notePrivateSurface() {
    ads.lastPrivateSurfaceAt = Date.now();
    ads.homeEligibleSince = 0;
    clearInterstitialArmTimer();
    clearHomeInterstitial();
  }

  function interstitialReadyAt() {
    const homeSince = Math.max(0, Number(ads.homeEligibleSince || 0));
    const afterHomeDwell = homeSince > 0
      ? homeSince + INTERSTITIAL_HOME_DWELL_MS
      : Number.POSITIVE_INFINITY;
    const afterPrivateCooldown =
      Math.max(0, Number(ads.lastPrivateSurfaceAt || 0)) +
      INTERSTITIAL_PRIVATE_COOLDOWN_MS;
    return Math.max(afterHomeDwell, afterPrivateCooldown);
  }

  function homeInterstitialEligible() {
    const cfg = ads.config?.ad_manager || {};
    const now = Date.now();
    const googleReady =
      cfg.interstitial_enabled &&
      /^\/\d{3,20}\/[A-Za-z0-9_./-]{1,180}$/.test(
        String(cfg.interstitial_ad_unit || "")
      );
    const firstPartyReady = Boolean(ads.config?.self_serve_ads?.enabled);
    return Boolean(
      onHome() &&
      !blockingModalOpen() &&
      !adsDisabled() &&
      navigator.onLine !== false &&
      (typeof document.hasFocus !== "function" || document.hasFocus()) &&
      ads.status?.interstitial_due &&
      ads.sessionInterstitialViews < INTERSTITIAL_SESSION_MAX &&
      now >= interstitialReadyAt() &&
      (googleReady || firstPartyReady)
    );
  }

  async function registerHomeInterstitial() {
    if (!homeInterstitialEligible() || ads.interstitialSlot || ads.interstitialPending) {
      if (!homeInterstitialEligible() && ads.interstitialSlot) clearHomeInterstitial();
      return;
    }

    ads.interstitialPending = true;

    const paidCampaign = await fetchPaidCampaign();
    if (paidCampaign && homeInterstitialEligible()) {
      ads.interstitialPending = false;
      await showPaidInterstitial(paidCampaign);
      return;
    }

    const cfg = ads.config?.ad_manager || {};
    const googleReady =
      cfg.interstitial_enabled &&
      /^\/\d{3,20}\/[A-Za-z0-9_./-]{1,180}$/.test(String(cfg.interstitial_ad_unit || ""));
    if (!googleReady) {
      ads.interstitialPending = false;
      return;
    }

    const loaded = await loadGpt();
    if (!loaded || !homeInterstitialEligible()) {
      ads.interstitialPending = false;
      return;
    }

    const unitPath = String(cfg.interstitial_ad_unit || "");
    window.googletag.cmd.push(() => {
      if (!homeInterstitialEligible() || ads.interstitialSlot) {
        ads.interstitialPending = false;
        return;
      }

      let slot = null;
      let pubads = null;

      const cleanup = () => {
        if (!pubads?.removeEventListener) return;
        try { pubads.removeEventListener("slotRenderEnded", onRender); } catch {}
        try { pubads.removeEventListener("impressionViewable", onViewable); } catch {}
      };

      const onRender = (event) => {
        if (event.slot !== slot) return;
        if (event.isEmpty) {
          telemetry("unfilled", "home_interstitial", "admanager");
          setTimeout(() => {
            if (ads.interstitialSlot === slot) clearHomeInterstitial();
          }, 250);
          return;
        }
        telemetry("interstitial_rendered", "home_interstitial", "admanager");
      };

      const onViewable = (event) => {
        if (event.slot !== slot || ads.interstitialMarked) return;
        ads.interstitialMarked = true;
        ads.storyAdDue = false;
        ads.sessionInterstitialViews += 1;
        telemetry("interstitial_viewed", "home_interstitial", "admanager");
        app()?.api("interstitial_impression", {
          method: "POST",
          body: { provider: "admanager" },
          showLoader: false,
          timeoutMs: 6000,
        }).then((data) => {
          ads.status = data.status || ads.status;
          updatePlanUi();
        }).catch(() => {});
      };

      try {
        slot = window.googletag.defineOutOfPageSlot(
          unitPath,
          window.googletag.enums.OutOfPageFormat.INTERSTITIAL
        );
        if (!slot) {
          ads.interstitialPending = false;
          return;
        }

        ads.interstitialSlot = slot;
        slot.addService(window.googletag.pubads());
        pubads = window.googletag.pubads();
        pubads.addEventListener("slotRenderEnded", onRender);
        pubads.addEventListener("impressionViewable", onViewable);
        ads.interstitialCleanup = cleanup;

        window.googletag.enableServices();
        window.googletag.display(slot);
        ads.interstitialPending = false;
        telemetry("interstitial_registered", "home_interstitial", "admanager");
      } catch {
        cleanup();
        ads.interstitialPending = false;
        clearHomeInterstitial();
      }
    });
  }

  function scheduleHomeInterstitial() {
    clearInterstitialArmTimer();

    if (!onHome() || blockingModalOpen() || adsDisabled()) {
      if (ads.interstitialSlot || ads.interstitialPending) clearHomeInterstitial();
      return;
    }

    if (!ads.homeEligibleSince) ads.homeEligibleSince = Date.now();

    if (!homeInterstitialEligible()) {
      if (ads.interstitialSlot || ads.interstitialPending) clearHomeInterstitial();

      const cfg = ads.config?.ad_manager || {};
      const canEventuallyShow = Boolean(
        ads.status?.interstitial_due &&
        ads.sessionInterstitialViews < INTERSTITIAL_SESSION_MAX &&
        (
          Boolean(ads.config?.self_serve_ads?.enabled) ||
          (
            cfg.interstitial_enabled &&
            /^\/\d{3,20}\/[A-Za-z0-9_./-]{1,180}$/.test(
              String(cfg.interstitial_ad_unit || "")
            )
          )
        )
      );
      if (canEventuallyShow) {
        const remaining = Math.max(250, interstitialReadyAt() - Date.now());
        ads.interstitialArmTimer = setTimeout(() => {
          ads.interstitialArmTimer = null;
          scheduleHomeInterstitial();
        }, Math.min(remaining + 120, 60000));
      }
      return;
    }

    const run = () => registerHomeInterstitial().catch(() => {});
    if ("requestIdleCallback" in window) {
      window.requestIdleCallback(run, { timeout: 2200 });
    } else {
      setTimeout(run, 900);
    }
  }

  function updateSurfaces() {
    $("#chatAdSlot")?.classList.add("hidden");
    if (onHome()) {
      if (!ads.homeEligibleSince) ads.homeEligibleSince = Date.now();
    } else {
      ads.homeEligibleSince = 0;
    }
    updatePlanUi();
    scheduleHomeBanner();
    scheduleHomeInterstitial();
  }

  function loadGpt() {
    if (window.googletag?.apiReady) return Promise.resolve(true);
    if (ads.gptPromise) return ads.gptPromise;

    ads.gptPromise = new Promise((resolve) => {
      window.googletag = window.googletag || { cmd: [] };
      const existing = document.querySelector("script[data-silknex-gpt]");

      const settle = (ready) => {
        if (!ready) {
          existing?.remove?.();
          ads.gptPromise = null;
        }
        resolve(ready);
      };

      if (existing) {
        let tries = 0;
        const poll = setInterval(() => {
          tries += 1;
          if (window.googletag?.apiReady) {
            clearInterval(poll);
            settle(true);
          } else if (tries > 80) {
            clearInterval(poll);
            settle(false);
          }
        }, 50);
        return;
      }

      const script = document.createElement("script");
      script.async = true;
      if (cspNonce) script.nonce = cspNonce;
      script.dataset.silknexGpt = "1";
      script.src = "https://securepubads.g.doubleclick.net/tag/js/gpt.js";
      script.addEventListener("load", () => resolve(true), { once: true });
      script.addEventListener("error", () => {
        script.remove();
        ads.gptPromise = null;
        resolve(false);
      }, { once: true });
      document.head.appendChild(script);
    });

    return ads.gptPromise;
  }

  function clearRewardRuntime() {
    if (ads.rewardTimeout) clearTimeout(ads.rewardTimeout);
    ads.rewardTimeout = null;
    try { ads.rewardCleanup?.(); } catch {}
    ads.rewardCleanup = null;

    const slot = ads.rewardSlot;
    ads.rewardSlot = null;
    if (slot && window.googletag?.destroySlots) {
      try { window.googletag.destroySlots([slot]); } catch {}
    }
  }

  async function claimRewardWhenAllowed() {
    if (!ads.rewardGranted || !ads.rewardToken || !app()) return;
    const wait = Math.max(0, ads.rewardClaimAt - Date.now());
    if (wait > 0) {
      ads.rewardTimeout = setTimeout(claimRewardWhenAllowed, wait + 40);
      return;
    }

    const token = ads.rewardToken;
    ads.rewardToken = "";
    clearRewardRuntime();

    try {
      const data = await app().api("rewarded_ad_complete", {
        method: "POST",
        body: { reward_token: token },
        showLoader: false,
      });
      ads.status = data.status || ads.status;
      updateSurfaces();
      app().toast(
        ads.status?.pass_active
          ? "30-minute ad pass unlocked."
          : "Reward counted toward your ad pass."
      );
    } catch (error) {
      app().toast(error.message || "Could not credit the reward.");
    }
  }

  async function requestRewardedAd() {
    const unitPath = String(ads.config?.ad_manager?.rewarded_ad_unit || "");
    if (!ads.config?.ad_manager?.rewarded_enabled || !unitPath) {
      throw new Error("Reward ads are not configured yet.");
    }

    const loaded = await loadGpt();
    if (!loaded) throw new Error("Google Ad Manager could not load.");

    return new Promise((resolve, reject) => {
      let settled = false;
      let pubads = null;
      let slot = null;

      const cleanupListeners = () => {
        if (!pubads?.removeEventListener) return;
        try { pubads.removeEventListener("rewardedSlotReady", onReady); } catch {}
        try { pubads.removeEventListener("rewardedSlotGranted", onGranted); } catch {}
        try { pubads.removeEventListener("rewardedSlotClosed", onClosed); } catch {}
      };

      const fail = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(failTimer);
        cleanupListeners();
        if (ads.rewardCleanup === cleanupListeners) ads.rewardCleanup = null;
        reject(error instanceof Error ? error : new Error(String(error || "Reward ad failed.")));
      };

      const onReady = (event) => {
        if (event.slot !== slot || settled) return;
        settled = true;
        clearTimeout(failTimer);
        telemetry("reward_ready", "reward_pass", "admanager");

        let visible = false;
        try { visible = event.makeRewardedVisible() !== false; } catch {}
        if (!visible) {
          cleanupListeners();
          if (ads.rewardCleanup === cleanupListeners) ads.rewardCleanup = null;
          reject(new Error("The rewarded ad could not be displayed."));
          return;
        }
        resolve(true);
      };

      const onGranted = (event) => {
        if (event.slot !== slot) return;
        ads.rewardGranted = true;
        telemetry("reward_granted", "reward_pass", "admanager");
        claimRewardWhenAllowed().catch(() => {});
      };

      const onClosed = (event) => {
        if (event.slot !== slot) return;
        telemetry("reward_closed", "reward_pass", "admanager");
        cleanupListeners();
        if (ads.rewardCleanup === cleanupListeners) ads.rewardCleanup = null;
        if (!ads.rewardGranted) {
          ads.rewardToken = "";
          clearRewardRuntime();
          app()?.toast?.("Reward ad closed before the reward was granted.");
        }
      };

      const failTimer = setTimeout(() => {
        fail(new Error("No rewarded ad is available right now."));
      }, 12000);

      window.googletag.cmd.push(() => {
        try {
          slot = window.googletag.defineOutOfPageSlot(
            unitPath,
            window.googletag.enums.OutOfPageFormat.REWARDED
          );
          if (!slot) {
            fail(new Error("Reward ads are not supported on this device."));
            return;
          }

          ads.rewardSlot = slot;
          ads.rewardGranted = false;
          slot.addService(window.googletag.pubads());

          pubads = window.googletag.pubads();
          pubads.addEventListener("rewardedSlotReady", onReady);
          pubads.addEventListener("rewardedSlotGranted", onGranted);
          pubads.addEventListener("rewardedSlotClosed", onClosed);
          ads.rewardCleanup = cleanupListeners;

          window.googletag.enableServices();
          window.googletag.display(slot);
        } catch (error) {
          fail(error);
        }
      });
    });
  }

  async function startRewardAd() {
    if (!onHome()) {
      app()?.toast?.("Reward ads can only start from the SilkNex home screen.");
      return;
    }
    if (adsDisabled()) {
      app()?.toast?.("Ads are already disabled for your account.");
      return;
    }
    if (!ads.config?.ad_manager?.rewarded_enabled) {
      app()?.toast?.("Connect a Google Ad Manager rewarded unit first.");
      return;
    }

    app()?.closeModal?.();
    try {
      const data = await app().api("rewarded_ad_start", {
        method: "POST",
        body: { provider: "admanager" },
        loadingLabel: "Preparing rewarded ad…",
      });

      ads.status = data.status || ads.status;
      if (data.already_ad_free) {
        updateSurfaces();
        return;
      }

      ads.rewardToken = String(data.reward_token || "");
      ads.rewardClaimAt = Number(data.complete_after || 0) * 1000;
      if (!ads.rewardToken) throw new Error("Reward ad could not start.");

      await requestRewardedAd();
    } catch (error) {
      ads.rewardToken = "";
      clearRewardRuntime();
      app()?.toast?.(error.message || "Reward ad is unavailable.");
    }
  }

  async function subscribe() {
    try {
      const data = await app().api("subscription_checkout", {
        method: "POST",
        body: {},
        loadingLabel: "Opening secure checkout…",
      });
      if (!/^https:\/\/checkout\.stripe\.com\//i.test(String(data.url || ""))) {
        throw new Error("Secure checkout is unavailable.");
      }
      window.location.assign(data.url);
    } catch (error) {
      app()?.toast?.(error.message);
    }
  }

  async function refreshAdStatus() {
    if (!ads.signedIn || !app()) return;
    try {
      const data = await app().api("ad_status", { showLoader: false, timeoutMs: 8000 });
      ads.status = data.status || ads.status;
      updateSurfaces();
    } catch {}
  }

  function scheduleAdsInitialization() {
    const run = () => {
      if (ads.signedIn) initializeAds();
    };

    // Ad configuration must never compete with session/inbox startup.
    if ("requestIdleCallback" in window) {
      window.requestIdleCallback(run, { timeout: 1600 });
    } else {
      setTimeout(run, 320);
    }
  }

  async function initializeAds() {
    if (!ads.signedIn || !app()) return;
    try {
      const data = await app().api("ad_config", { showLoader: false, timeoutMs: 8000 });
      ads.config = data;
      ads.status = data.status || null;
      updateSurfaces();
    } catch {
      ads.config = null;
      ads.status = null;
      updateSurfaces();
    }
  }

  function handleStoryAd(data) {
    if (data?.ad_status) ads.status = data.ad_status;
    if (data?.show_ad) ads.storyAdDue = true;

    // The story counter creates an ad opportunity, not a forced overlay. The
    // supported Google Ad Manager reactive unit is considered after the story
    // modal closes and only if the server's >=15 minute cap is also due.
    updateSurfaces();
  }

  function updateAdvertisePrice() {
    const input = $("#advertiseDays");
    const total = $("#advertiseTotal");
    const copy = $("#advertisePriceCopy");
    if (!input || !total || !copy) return;

    let days = Number.parseInt(input.value || "1", 10);
    if (!Number.isFinite(days)) days = 1;
    days = Math.max(1, Math.min(30, days));
    input.value = String(days);
    total.textContent = `$${(days * 5).toFixed(2)}`;
    copy.textContent = `${days} ${days === 1 ? "day" : "days"} · $5/day`;
  }

  function renderAdvertiseCampaigns(items = []) {
    const host = $("#advertiseCampaignList");
    if (!host) return;
    host.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("small");
      empty.textContent = "No campaigns yet.";
      host.appendChild(empty);
      return;
    }

    for (const campaign of items.slice(0, 8)) {
      const row = document.createElement("div");
      row.className = "advertise-campaign-row";

      const image = document.createElement("img");
      image.src = String(campaign.image_url || "");
      image.alt = "";
      image.loading = "lazy";
      image.decoding = "async";

      const body = document.createElement("div");
      const title = document.createElement("b");
      title.textContent = String(campaign.headline || "Campaign");
      const meta = document.createElement("small");
      const status = String(campaign.status || "pending");
      const endsAt = Number(campaign.ends_at || 0);
      const suffix = endsAt > 0
        ? ` · ends ${new Date(endsAt * 1000).toLocaleDateString()}`
        : "";
      meta.textContent = `${status.charAt(0).toUpperCase()}${status.slice(1)} · ${Number(campaign.days || 1)}d${suffix}`;
      body.append(title, meta);

      const price = document.createElement("span");
      price.textContent = `$${(Number(campaign.price_cents || 0) / 100).toFixed(2)}`;

      row.append(image, body, price);
      host.appendChild(row);
    }
  }

  async function loadAdvertiseCampaigns() {
    if (!ads.signedIn || !app()) return;
    try {
      const data = await app().api("ad_campaigns", {
        showLoader: false,
        timeoutMs: 8000,
      });
      renderAdvertiseCampaigns(Array.isArray(data.campaigns) ? data.campaigns : []);
    } catch {}
  }

  function renderAdvertisePreview(file) {
    const preview = $("#advertiseImagePreview");
    if (!preview) return;

    if (ads.advertisePreviewUrl) {
      try { URL.revokeObjectURL(ads.advertisePreviewUrl); } catch {}
      ads.advertisePreviewUrl = "";
    }
    preview.replaceChildren();

    if (!file) {
      const icon = document.createElement("i");
      icon.textContent = "+";
      icon.setAttribute("aria-hidden", "true");
      const title = document.createElement("b");
      title.textContent = "Add creative";
      const copy = document.createElement("small");
      copy.textContent = "PNG, JPEG, or WebP · landscape works best";
      preview.append(icon, title, copy);
      return;
    }

    ads.advertisePreviewUrl = URL.createObjectURL(file);
    const image = document.createElement("img");
    image.src = ads.advertisePreviewUrl;
    image.alt = "Ad creative preview";
    preview.appendChild(image);
  }

  async function prepareAdCreative(file) {
    if (!file) throw new Error("Choose an ad image.");
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
      throw new Error("Use a PNG, JPEG, or WebP image.");
    }
    if (file.size > 12 * 1024 * 1024) {
      throw new Error("Choose an image smaller than 12 MB.");
    }

    let bitmap = null;
    try {
      bitmap = await createImageBitmap(file);
    } catch {
      return file;
    }

    const maxWidth = 1600;
    const maxHeight = 1000;
    const ratio = Math.min(1, maxWidth / bitmap.width, maxHeight / bitmap.height);
    const needsResize = ratio < 1 || file.size > 4.5 * 1024 * 1024;
    if (!needsResize) {
      bitmap.close?.();
      return file;
    }

    const width = Math.max(1, Math.round(bitmap.width * ratio));
    const height = Math.max(1, Math.round(bitmap.height * ratio));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) {
      bitmap.close?.();
      return file;
    }

    ctx.clearRect(0, 0, width, height);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(bitmap, 0, 0, width, height);
    bitmap.close?.();

    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/webp", 0.88));
    canvas.width = 1;
    canvas.height = 1;
    if (!blob) return file;
    return new File([blob], "silknex-ad.webp", { type: "image/webp" });
  }

  async function openAdvertise() {
    if (!ads.signedIn || !app()) return;
    updateAdvertisePrice();
    app().openModal?.("#advertiseModal");
    loadAdvertiseCampaigns();

    const checkout = $("#advertiseCheckoutBtn");
    if (checkout && ads.config?.self_serve_ads) {
      const salesPaused = Boolean(ads.config.self_serve_ads.sales_paused);
      const ready = Boolean(ads.config.self_serve_ads.checkout_ready);
      checkout.disabled = !ready;
      checkout.textContent = salesPaused
        ? "New campaign sales are paused"
        : ready
          ? "Continue to checkout"
          : "Checkout needs Stripe setup";
    }
  }

  async function submitAdvertise(event) {
    event.preventDefault();
    if (!ads.signedIn || !app()) return;

    const button = $("#advertiseCheckoutBtn");
    const file = $("#advertiseImage")?.files?.[0] || null;
    const headline = String($("#advertiseHeadline")?.value || "").trim();
    const destinationUrl = String($("#advertiseUrl")?.value || "").trim();
    let days = Number.parseInt($("#advertiseDays")?.value || "1", 10);
    days = Math.max(1, Math.min(30, Number.isFinite(days) ? days : 1));

    if (headline.length < 3) {
      app().toast?.("Add a headline with at least 3 characters.");
      return;
    }
    if (!/^https:\/\//i.test(destinationUrl)) {
      app().toast?.("Use an https:// destination link.");
      return;
    }
    if (!file) {
      app().toast?.("Choose an ad image.");
      return;
    }

    if (button) {
      button.disabled = true;
      button.textContent = "Preparing creative…";
    }

    try {
      const prepared = await prepareAdCreative(file);
      const form = new FormData();
      form.append("purpose", "ad");
      form.append("file", prepared, prepared.name || "silknex-ad.webp");

      if (button) button.textContent = "Uploading…";
      const uploaded = await app().api("upload", {
        method: "POST",
        body: form,
        showLoader: false,
        timeoutMs: 120000,
      });

      if (!/^[a-f0-9]{48}$/i.test(String(uploaded.token || ""))) {
        throw new Error("The ad image could not be prepared.");
      }

      if (button) button.textContent = "Opening checkout…";
      const checkout = await app().api("ad_campaign_checkout", {
        method: "POST",
        body: {
          upload_token: uploaded.token,
          headline,
          destination_url: destinationUrl,
          days,
        },
        showLoader: false,
        timeoutMs: 30000,
      });

      if (!/^https:\/\/checkout\.stripe\.com\//i.test(String(checkout.url || ""))) {
        throw new Error("Secure checkout is unavailable.");
      }
      window.location.assign(checkout.url);
    } catch (error) {
      app().toast?.(error?.message || "Could not create the ad campaign.");
      if (button) {
        button.disabled = false;
        button.textContent = "Continue to checkout";
      }
    }
  }

  function bindUi() {
    $("#watchRewardAdBtn")?.addEventListener("click", startRewardAd);
    $("#subscribeNoAdsBtn")?.addEventListener("click", subscribe);
    $("#openAdvertiseBtn")?.addEventListener("click", openAdvertise);
    $("#advertiseDays")?.addEventListener("input", updateAdvertisePrice);
    $("#advertiseImage")?.addEventListener("change", (event) => {
      renderAdvertisePreview(event.target?.files?.[0] || null);
    });
    $("#advertiseForm")?.addEventListener("submit", submitAdvertise);
    $("#adSkipBtn")?.addEventListener("click", () => {
      if ($("#adSkipBtn")?.disabled) return;
      closePaidInterstitial();
    });

    window.addEventListener("silknex:session", (event) => {
      ads.signedIn = Boolean(event.detail?.signedIn);

      if (!ads.signedIn) {
        ads.config = null;
        ads.status = null;
        ads.rendered.clear();
        ads.rewardToken = "";
        ads.storyAdDue = false;
        ads.campaign = null;
        ads.campaignFetchedAt = 0;
        ads.campaignPromise = null;
        ads.homeEligibleSince = 0;
        ads.lastPrivateSurfaceAt = 0;
        ads.sessionInterstitialViews = 0;
        clearInterstitialArmTimer();
        clearRewardRuntime();
        clearHomeInterstitial();
        resetHomeBanner();
        $("#chatAdSlot")?.classList.add("hidden");
        return;
      }

      scheduleAdsInitialization();
    });

    if (app()?.state?.me) {
      ads.signedIn = true;
      scheduleAdsInitialization();
    }

    const scheduleUiRefresh = () => {
      clearTimeout(ads.uiTimer);
      const delay = document.visibilityState === "hidden" ? 60000 : 15000;
      ads.uiTimer = setTimeout(() => {
        updatePlanUi();
        scheduleUiRefresh();
      }, delay);
    };

    const scheduleStatusRefresh = () => {
      clearTimeout(ads.statusTimer);
      const delay = document.visibilityState === "hidden" ? 300000 : 90000;
      ads.statusTimer = setTimeout(async () => {
        if (ads.signedIn) await refreshAdStatus();
        scheduleStatusRefresh();
      }, delay);
    };

    scheduleUiRefresh();
    scheduleStatusRefresh();

    document.addEventListener("visibilitychange", () => {
      scheduleUiRefresh();
      scheduleStatusRefresh();
      if (document.visibilityState === "visible") {
        refreshAdStatus();
        updateSurfaces();
      } else {
        clearInterstitialArmTimer();
        clearHomeInterstitial();
      }
    });

    window.addEventListener("online", () => {
      if (ads.signedIn) initializeAds();
    });

    window.addEventListener("silknex:conversation", (event) => {
      const conversationId = Number(event.detail?.id || 0);
      if (conversationId > 0) {
        notePrivateSurface();
      } else {
        ads.homeEligibleSince = Date.now();
      }
      updateSurfaces();
    });

    window.addEventListener("silknex:modal", (event) => {
      if (event.detail?.open) {
        clearHomeInterstitial();
        return;
      }
      updateSurfaces();
    });

    window.addEventListener("pageshow", (event) => {
      if (!event.persisted) return;
      refreshAdStatus();
      updateSurfaces();
    });

    let callWasActive = document.documentElement.dataset.callActive === "true";
    const callStateObserver = new MutationObserver(() => {
      const callActive = document.documentElement.dataset.callActive === "true";
      if (callActive) {
        notePrivateSurface();
      } else if (callWasActive) {
        ads.lastPrivateSurfaceAt = Date.now();
        ads.homeEligibleSince = onHome() ? Date.now() : 0;
      }
      callWasActive = callActive;
      if (!onHome()) clearHomeInterstitial();
      updateSurfaces();
    });
    callStateObserver.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["data-call-active"],
    });

    let resizeFrame = 0;
    window.addEventListener("resize", () => {
      if (resizeFrame) return;
      resizeFrame = requestAnimationFrame(() => {
        resizeFrame = 0;
        placeHomeAdForViewport();
        if (ads.signedIn) updateSurfaces();
      });
    }, { passive: true });

    placeHomeAdForViewport();

    const params = new URLSearchParams(window.location.search);
    const subscription = params.get("subscription");
    const advertise = params.get("advertise");
    if (
      subscription === "success" ||
      subscription === "cancelled" ||
      advertise === "success" ||
      advertise === "cancelled"
    ) {
      setTimeout(() => {
        if (subscription === "success") {
          refreshAdStatus();
          app()?.toast?.("Subscription checkout completed.");
        } else if (advertise === "success") {
          ads.campaignFetchedAt = 0;
          app()?.toast?.("Payment received. Your campaign activates after Stripe confirms it.");
        } else if (advertise === "cancelled") {
          app()?.toast?.("Ad checkout cancelled.");
        }
        try {
          const url = new URL(window.location.href);
          url.searchParams.delete("subscription");
          url.searchParams.delete("advertise");
          history.replaceState(history.state, "", url);
        } catch {}
      }, 300);
    }
  }

  window.SilknexAds = Object.freeze({
    handleStoryAd,
    refresh: refreshAdStatus,
    get config() { return ads.config; },
  });

  bindUi();

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flushTelemetry();
  }, { passive: true });

  window.addEventListener("pagehide", () => {
    flushTelemetry();
  }, { passive: true });

  window.addEventListener("silknex:network", (event) => {
    if (event.detail?.online) {
      ads.adsenseRetryAfter = 0;
      flushTelemetry();
      scheduleHomeBanner();
    }
  });

})();