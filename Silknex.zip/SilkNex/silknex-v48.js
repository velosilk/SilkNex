(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const runtime = {
    installPrompt: null,
    signedIn: false,
    smartText: true,
    enterToSend: false,
    correcting: false,
    resizeRaf: 0,
    desktopAdAbort: null,
    desktopAdFetchAt: 0,
    desktopCampaigns: [],
    desktopAdSignature: "",
    inputSeenAt: 0,
    replacements: Object.create(null),
    startupShortcutHandled: false,
    savedItems: [],
  };

  const STORAGE = Object.freeze({
    smartText: "silknex-smart-text-v1",
    enterToSend: "silknex-enter-to-send-v1",
    replacements: "silknex-text-replacements-v1",
    protectedWords: "silknex-autocorrect-protected-v1",
    typingStyle: "silknex-typing-style-v1",
  });

  const COMMON_TYPOS = Object.freeze({
    teh: "the",
    thier: "their",
    recieve: "receive",
    recieved: "received",
    definately: "definitely",
    seperate: "separate",
    occured: "occurred",
    untill: "until",
    becuase: "because",
    wierd: "weird",
    adress: "address",
    mesage: "message",
    messsage: "message",
    freind: "friend",
    frend: "friend",
    tommorow: "tomorrow",
    tomorow: "tomorrow",
    accomodate: "accommodate",
    embarass: "embarrass",
    independant: "independent",
    goverment: "government",
    relevent: "relevant",
    calender: "calendar",
    occured: "occurred",
    sucess: "success",
    succesful: "successful",
    definately: "definitely",
    dont: "don't",
    doesnt: "doesn't",
    didnt: "didn't",
    cant: "can't",
    couldnt: "couldn't",
    wont: "won't",
    wouldnt: "wouldn't",
    shouldnt: "shouldn't",
    isnt: "isn't",
    arent: "aren't",
    wasnt: "wasn't",
    werent: "weren't",
    ive: "I've",
    im: "I'm",
    youre: "you're",
    theyre: "they're",
    thats: "that's",
    whats: "what's",
    lets: "let's",
    alot: "a lot",
    aswell: "as well",
    atleast: "at least",
    probaly: "probably",
    probablyy: "probably",
    actualy: "actually",
    actualyl: "actually",
    thsi: "this",
    taht: "that",
    jsut: "just",
    adn: "and",
    knwo: "know",
    waht: "what",
    woudl: "would",
    shoudl: "should",
    coudl: "could",
    becasue: "because",
    peopel: "people",
    somthing: "something",
    everytime: "every time",
  });

  function safeStorageGet(key, fallback = "") {
    try {
      const value = localStorage.getItem(key);
      return value === null ? fallback : value;
    } catch {
      return fallback;
    }
  }

  function safeStorageSet(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch {}
  }

  function parseTextReplacements(raw) {
    const result = Object.create(null);
    const lines = String(raw || "").split(/\r?\n/u);
    let count = 0;

    for (const line of lines) {
      if (count >= 40) break;
      const separator = line.indexOf("=");
      if (separator < 1) continue;

      const shortcut = line.slice(0, separator).trim().toLowerCase();
      const replacement = line.slice(separator + 1).trim();
      if (
        !/^[a-z][a-z0-9'_-]{1,23}$/u.test(shortcut) ||
        !replacement ||
        replacement.length > 120
      ) {
        continue;
      }

      result[shortcut] = replacement;
      count += 1;
    }

    return result;
  }

  function loadTextReplacements() {
    const raw = safeStorageGet(STORAGE.replacements, "");
    runtime.replacements = parseTextReplacements(raw);
    const input = $("#textReplacementsInput");
    if (input) input.value = raw;
  }

  function saveTextReplacements() {
    const input = $("#textReplacementsInput");
    const raw = String(input?.value || "").trim();
    runtime.replacements = parseTextReplacements(raw);

    const normalized = Object.entries(runtime.replacements)
      .map(([shortcut, replacement]) => `${shortcut} = ${replacement}`)
      .join("\n");

    safeStorageSet(STORAGE.replacements, normalized);
    if (input) input.value = normalized;
    app()?.toast?.(
      `${Object.keys(runtime.replacements).length} text replacement${
        Object.keys(runtime.replacements).length === 1 ? "" : "s"
      } saved.`
    );
  }

  function adClientKey() {
    try {
      const existing = sessionStorage.getItem("silknex-ad-client-key");
      if (/^[a-f0-9]{32}$/.test(existing || "")) return existing;

      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      const created = Array.from(bytes, (value) =>
        value.toString(16).padStart(2, "0")
      ).join("");
      sessionStorage.setItem("silknex-ad-client-key", created);
      return created;
    } catch {
      return "";
    }
  }

  function isStandalone() {
    return Boolean(
      window.matchMedia?.("(display-mode: standalone)")?.matches ||
      window.matchMedia?.("(display-mode: fullscreen)")?.matches ||
      navigator.standalone === true
    );
  }

  function isIosLike() {
    const platform = String(navigator.platform || "");
    const ua = String(navigator.userAgent || "");
    return /iPad|iPhone|iPod/i.test(ua) ||
      (platform === "MacIntel" && Number(navigator.maxTouchPoints || 0) > 1);
  }

  function isDesktopLayout() {
    return window.matchMedia?.("(min-width: 801px)")?.matches === true;
  }

  function chatSurfaceActive() {
    const state = app()?.state;
    return Boolean(
      Number(state?.activeId || 0) > 0 &&
      !$("#chatView")?.classList.contains("hidden")
    );
  }

  function privateSurfaceActive() {
    // Desktop chat ads are now allowed in the dedicated rail only. Calls,
    // fullscreen media, and blocking private surfaces remain ad-free.
    return Boolean(app()?.state?.call);
  }

  function updateTypingSettingsUi() {
    const smart = $("#smartTextToggle");
    const enter = $("#enterToSendToggle");
    if (smart) smart.checked = runtime.smartText;
    if (enter) enter.checked = runtime.enterToSend;
    document.documentElement.dataset.smartText = runtime.smartText ? "true" : "false";
    document.documentElement.dataset.enterToSend = runtime.enterToSend ? "true" : "false";
  }

  function loadTypingSettings() {
    runtime.smartText = safeStorageGet(STORAGE.smartText, "1") !== "0";
    runtime.enterToSend = safeStorageGet(STORAGE.enterToSend, "0") === "1";
    updateTypingSettingsUi();
  }

  function configureNativeComposer() {
    const input = $("#messageInput");
    if (!input) return;
    input.setAttribute("autocomplete", "on");
    input.setAttribute("autocapitalize", "sentences");
    input.setAttribute("spellcheck", "true");
    input.setAttribute("autocorrect", "on");
    input.setAttribute("inputmode", "text");
    input.setAttribute("enterkeyhint", "send");
  }

  function looksSensitiveOrStructured(text) {
    const tail = String(text || "").slice(-160);
    if (!tail) return false;

    return (
      /https?:\/\/\S*$/i.test(tail) ||
      /www\.\S*$/i.test(tail) ||
      /\b[\w.+-]+@[\w.-]*$/i.test(tail) ||
      /(?:^|\s)@\w*$/i.test(tail) ||
      /(?:^|\s)#[A-Fa-f0-9]{3,8}$/i.test(tail) ||
      /[`{}[\]\\]|=>|==|!=|::|<\/?[a-z][^>]*$/i.test(tail)
    );
  }

  function preserveCase(source, replacement) {
    if (!source) return replacement;
    if (source === source.toUpperCase() && source.length > 1) {
      return replacement.toUpperCase();
    }
    if (source[0] === source[0].toUpperCase()) {
      return replacement[0].toUpperCase() + replacement.slice(1);
    }
    return replacement;
  }

  function protectedAutocorrectWords() {
    return new Set(
      safeStorageGet(STORAGE.protectedWords, "")
        .split(/[\s,\n]+/u)
        .map((word) => word.trim().toLowerCase())
        .filter((word) => /^[a-z0-9'_.-]{1,40}$/u.test(word))
        .slice(0, 300)
    );
  }

  function typingStyleProfile() {
    try {
      const parsed = JSON.parse(safeStorageGet(STORAGE.typingStyle, "{}"));
      return {
        total: Math.max(0, Number(parsed.total || 0)),
        lowercase: Math.max(0, Number(parsed.lowercase || 0)),
      };
    } catch {
      return { total: 0, lowercase: 0 };
    }
  }

  function prefersLowercaseStyle() {
    const profile = typingStyleProfile();
    return profile.total >= 12 && (profile.lowercase / Math.max(1, profile.total)) >= 0.70;
  }

  function learnTypingStyle(value) {
    const text = String(value || "").trim();
    const first = text.match(/[A-Za-z]/u)?.[0] || "";
    if (!first) return;
    const profile = typingStyleProfile();
    profile.total = Math.min(200, profile.total + 1);
    profile.lowercase = Math.min(200, profile.lowercase + (first === first.toLowerCase() ? 1 : 0));
    if (profile.total >= 200) {
      profile.total = Math.round(profile.total * .75);
      profile.lowercase = Math.round(profile.lowercase * .75);
    }
    safeStorageSet(STORAGE.typingStyle, JSON.stringify(profile));
  }

  function smartCorrectPrefix(prefix) {
    if (!prefix || looksSensitiveOrStructured(prefix)) return prefix;

    let value = prefix;

    // Replace only a completed final word. This avoids fighting the keyboard
    // while the user is still typing and leaves deliberate slang mostly alone.
    value = value.replace(
      /(^|[\s(\["'“‘])([A-Za-z']{2,})([\s.,!?;:)\]"'”’])$/u,
      (match, lead, word, boundary) => {
        const normalizedWord = word.toLowerCase();
        if (protectedAutocorrectWords().has(normalizedWord)) return match;
        const replacement =
          runtime.replacements[normalizedWord] ||
          COMMON_TYPOS[normalizedWord];
        if (!replacement) return match;
        return `${lead}${preserveCase(word, replacement)}${boundary}`;
      }
    );

    // Standalone lowercase "i" is almost always accidental in normal prose.
    if (!protectedAutocorrectWords().has("i") && !prefersLowercaseStyle()) {
      value = value.replace(/(^|[\s(])i([\s.,!?;:)])$/u, "$1I$2");
    }

    // Remove spaces before closing punctuation at the caret.
    value = value.replace(/\s+([,!?;:)])$/u, "$1");

    // Collapse accidental runs of spaces, but keep newlines and indentation.
    value = value.replace(/([^\n]) {2,}$/u, "$1 ");

    // Capitalize the first alphabetic character of a sentence only when the
    // user has just completed the first word. Mixed-case/code-ish text is left.
    const sentenceMatch = value.match(/(^|[.!?]\s+)([a-z])([a-z']*)([\s.,!?;:]?)$/u);
    if (sentenceMatch && !prefersLowercaseStyle() && !/[A-Z].*[A-Z]/.test(sentenceMatch[2] + sentenceMatch[3])) {
      const start = sentenceMatch.index + sentenceMatch[1].length;
      value =
        value.slice(0, start) +
        sentenceMatch[2].toUpperCase() +
        value.slice(start + 1);
    }

    return value;
  }

  function maybeApplySmartCorrection(event) {
    if (!runtime.smartText || runtime.correcting) return;
    if (event?.isComposing) return;

    const input = $("#messageInput");
    if (!input || document.activeElement !== input) return;
    if (input.selectionStart !== input.selectionEnd) return;

    const caret = Number(input.selectionStart || 0);
    if (caret <= 0) return;

    const inserted = String(event?.data ?? "");
    const inputType = String(event?.inputType || "");

    const boundaryTyped =
      /\s|[.,!?;:)]/.test(inserted) ||
      inputType === "insertParagraph" ||
      inputType === "insertLineBreak";

    if (!boundaryTyped) return;

    const before = input.value.slice(0, caret);
    const after = input.value.slice(caret);
    const corrected = smartCorrectPrefix(before);
    if (corrected === before) return;

    runtime.correcting = true;
    input.value = corrected + after;
    const nextCaret = corrected.length;
    try {
      input.setSelectionRange(nextCaret, nextCaret);
    } catch {}
    input.dispatchEvent(new Event("input", { bubbles: true }));
    runtime.correcting = false;
  }

  function applyFinalSmartCorrection() {
    if (!runtime.smartText || runtime.correcting) return;
    const input = $("#messageInput");
    if (!input || input.selectionStart !== input.selectionEnd) return;
    if (Number(input.selectionEnd || 0) !== input.value.length) return;

    const source = String(input.value || "");
    if (!source || looksSensitiveOrStructured(source)) return;

    // Append a temporary boundary so the same safe word-correction rules can
    // handle the final word when the user presses Send without typing a space.
    const correctedWithBoundary = smartCorrectPrefix(`${source} `);
    const corrected = correctedWithBoundary.endsWith(" ")
      ? correctedWithBoundary.slice(0, -1)
      : correctedWithBoundary;

    if (corrected === source) return;
    runtime.correcting = true;
    input.value = corrected;
    try {
      input.setSelectionRange(corrected.length, corrected.length);
    } catch {}
    input.dispatchEvent(new Event("input", { bubbles: true }));
    runtime.correcting = false;
  }

  function bindSmartTyping() {
    const input = $("#messageInput");
    if (!input || input.dataset.v48TypingBound === "1") return;
    input.dataset.v48TypingBound = "1";

    input.addEventListener("input", (event) => {
      runtime.inputSeenAt = Date.now();
      maybeApplySmartCorrection(event);
    });

    // The legacy core sends Enter everywhere. Intercept it on desktop when the
    // user explicitly prefers Enter=newline. Mobile keeps its normal send-key
    // behavior because virtual keyboards rely on enterkeyhint="send".
    input.addEventListener("keydown", (event) => {
      if (
        event.key === "Enter" &&
        !event.shiftKey &&
        !event.isComposing &&
        isDesktopLayout() &&
        !runtime.enterToSend
      ) {
        event.stopImmediatePropagation();
      }
    }, true);

    $("#messageForm")?.addEventListener("submit", () => {
      learnTypingStyle($("#messageInput")?.value || "");
      applyFinalSmartCorrection();
    }, true);

    $("#openTextReplacementsBtn")?.addEventListener("click", () => {
      loadTextReplacements();
      app()?.openModal?.("#textReplacementsModal");
      requestAnimationFrame(() => $("#textReplacementsInput")?.focus());
    });

    $("#closeTextReplacementsBtn")?.addEventListener("click", () => {
      app()?.closeModal?.("textReplacementsModal");
    });

    $("#saveTextReplacementsBtn")?.addEventListener("click", () => {
      saveTextReplacements();
      app()?.closeModal?.("textReplacementsModal");
    });

    $("#clearTextReplacementsBtn")?.addEventListener("click", () => {
      runtime.replacements = Object.create(null);
      safeStorageSet(STORAGE.replacements, "");
      const replacementsInput = $("#textReplacementsInput");
      if (replacementsInput) replacementsInput.value = "";
      app()?.toast?.("Text replacements cleared.");
    });

    $("#smartTextToggle")?.addEventListener("change", (event) => {
      runtime.smartText = Boolean(event.currentTarget.checked);
      safeStorageSet(STORAGE.smartText, runtime.smartText ? "1" : "0");
      updateTypingSettingsUi();
      app()?.toast?.(
        runtime.smartText
          ? "Smarter autocorrect is on."
          : "Smarter autocorrect is off."
      );
    });

    $("#enterToSendToggle")?.addEventListener("change", (event) => {
      runtime.enterToSend = Boolean(event.currentTarget.checked);
      safeStorageSet(STORAGE.enterToSend, runtime.enterToSend ? "1" : "0");
      updateTypingSettingsUi();
      app()?.toast?.(
        runtime.enterToSend
          ? "Enter will send messages on computers."
          : "Enter will create a new line on computers."
      );
    });
  }

  function updateInstallUi() {
    const installed = isStandalone();
    const available = Boolean(runtime.installPrompt) || isIosLike() || !installed;

    $("#installAppHomeBtn")?.classList.toggle("hidden", installed || !available);

    const settingsButton = $("#installAppSettingsBtn");
    const status = $("#installAppStatus");
    if (settingsButton) {
      settingsButton.disabled = installed;
      settingsButton.textContent = installed ? "Installed" : "Install";
    }

    if (status) {
      if (installed) {
        status.textContent = "SilkNex is installed on this device.";
      } else if (runtime.installPrompt) {
        status.textContent = "Optional. Install only when you choose to.";
      } else if (isIosLike()) {
        status.textContent = "Optional. Use Share → Add to Home Screen when you want it.";
      } else {
        status.textContent = "Optional. Your browser may offer Install or Add to Home Screen.";
      }
    }
  }

  function showInstallHelp() {
    const modal = $("#installHelpModal");
    const heading = $("#installHelpHeading");
    const copy = $("#installHelpCopy");

    if (heading && copy) {
      if (isIosLike()) {
        heading.textContent = "Add SilkNex to your Home Screen";
        copy.textContent =
          "Open the browser Share menu, choose “Add to Home Screen”, then confirm. This is optional—SilkNex keeps working in the browser.";
      } else {
        heading.textContent = "Install SilkNex from your browser";
        copy.textContent =
          "Open your browser menu and choose Install app, Install SilkNex, or Add to Home Screen. This is optional and can be removed like any other installed web app.";
      }
    }

    if (modal && app()?.openModal) {
      app().openModal("#installHelpModal");
    } else {
      app()?.toast?.("Use your browser’s Install or Add to Home Screen option.");
    }
  }

  async function requestInstall() {
    if (isStandalone()) {
      app()?.toast?.("SilkNex is already installed.");
      return;
    }

    const prompt = runtime.installPrompt;
    if (!prompt) {
      showInstallHelp();
      return;
    }

    runtime.installPrompt = null;

    try {
      await prompt.prompt();
      const result = await prompt.userChoice;
      if (result?.outcome === "accepted") {
        app()?.toast?.("SilkNex installation started.");
      }
    } catch {
      showInstallHelp();
    } finally {
      updateInstallUi();
    }
  }

  function bindInstallFlow() {
    window.addEventListener("beforeinstallprompt", (event) => {
      // Never interrupt the user with an automatic install prompt.
      event.preventDefault();
      runtime.installPrompt = event;
      updateInstallUi();
    });

    window.addEventListener("appinstalled", () => {
      runtime.installPrompt = null;
      updateInstallUi();
      app()?.toast?.("SilkNex was installed.");
    });

    $("#installAppHomeBtn")?.addEventListener("click", requestInstall);
    $("#installAppSettingsBtn")?.addEventListener("click", requestInstall);
    $("#installHelpDoneBtn")?.addEventListener("click", () => app()?.closeModal?.());
    updateInstallUi();
  }

  function campaignCreative(campaign, placement) {
    if (!campaign?.image_url || !campaign?.destination_url) return null;

    const link = document.createElement("a");
    link.className = "silknex-paid-ad silknex-paid-ad-banner";
    link.href = String(campaign.destination_url);
    link.target = "_blank";
    link.rel = "noopener noreferrer sponsored";
    link.dataset.campaignId = String(campaign.id || "");
    link.dataset.desktopPlacement = placement;

    const image = document.createElement("img");
    image.src = String(campaign.image_url);
    image.alt = String(campaign.headline || "Sponsored");
    image.loading = "lazy";
    image.decoding = "async";
    link.appendChild(image);

    const copy = document.createElement("span");
    copy.className = "silknex-paid-ad-copy";

    const label = document.createElement("small");
    label.textContent = "Sponsored";

    const title = document.createElement("b");
    title.textContent = String(campaign.headline || "Sponsored");

    const cta = document.createElement("span");
    cta.className = "silknex-paid-ad-cta";
    cta.textContent = "Learn more";

    copy.append(label, title, cta);
    link.appendChild(copy);

    link.addEventListener("click", () => {
      app()?.api?.("ad_event", {
        method: "POST",
        body: {
          event_type: "rendered",
          placement: `desktop_${placement}`,
          provider: "house",
          client_key: adClientKey(),
        },
        showLoader: false,
        keepalive: true,
        timeoutMs: 4000,
      }).catch(() => {});
    }, { passive: true });

    return link;
  }

  function desktopAdCapacity() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    const chatOpen = chatSurfaceActive();

    if (height < 600) return 0;
    if (chatOpen) {
      if (width < 1024) return 0;
      if (width >= 2400 && height >= 820) return 3;
      if (width >= 1680 && height >= 760) return 2;
      return 1;
    }

    if (width < 1180) return 0;
    if (width >= 2200 && height >= 820) return 5;
    if (width >= 1600 && height >= 820) return 3;
    return 2;
  }

  function clearDesktopAds() {
    runtime.desktopAdAbort?.abort?.();
    runtime.desktopAdAbort = null;
    runtime.desktopAdSignature = "";

    $("#desktopAdRail")?.classList.add("hidden");
    $("#desktopAdBottom")?.classList.add("hidden");
    $("#desktopChatAdRail")?.classList.add("hidden");

    $$("[data-desktop-ad-slot],[data-desktop-chat-ad-slot]")
      .forEach((slot) => slot.replaceChildren());
  }

  function renderDesktopAds(campaigns) {
    const capacity = desktopAdCapacity();
    const chatOpen = chatSurfaceActive();

    if (
      !runtime.signedIn ||
      !isDesktopLayout() ||
      privateSurfaceActive() ||
      capacity < 1 ||
      !Array.isArray(campaigns) ||
      !campaigns.length
    ) {
      clearDesktopAds();
      return;
    }

    const valid = campaigns
      .filter((campaign) =>
        campaign &&
        campaign.image_url &&
        campaign.destination_url &&
        Number(campaign.ends_at || 0) > Math.floor(Date.now() / 1000)
      )
      .slice(0, capacity);

    if (!valid.length) {
      clearDesktopAds();
      return;
    }

    const selector = chatOpen
      ? "[data-desktop-chat-ad-slot]"
      : "[data-desktop-ad-slot]";
    const slots = $$(selector).slice(0, capacity);
    const signature =
      `${chatOpen ? "chat" : "home"}:${valid.map((item) => item.id).join(",")}:${capacity}`;

    if (runtime.desktopAdSignature === signature) {
      if (chatOpen) {
        $("#desktopChatAdRail")?.classList.remove("hidden");
        $("#desktopAdRail")?.classList.add("hidden");
        $("#desktopAdBottom")?.classList.add("hidden");
      } else {
        $("#desktopAdRail")?.classList.remove("hidden");
        $("#desktopAdBottom")?.classList.remove("hidden");
        $("#desktopChatAdRail")?.classList.add("hidden");
      }
      return;
    }

    $$("[data-desktop-ad-slot],[data-desktop-chat-ad-slot]")
      .forEach((slot) => slot.replaceChildren());

    valid.forEach((campaign, index) => {
      const slot = slots[index];
      if (!slot) return;
      const placement = String(
        slot.dataset.desktopChatAdSlot ||
        slot.dataset.desktopAdSlot ||
        `slot-${index + 1}`
      );
      const creative = campaignCreative(campaign, placement);
      if (creative) slot.appendChild(creative);
    });

    const homeRailHasAd = Boolean(
      $("#desktopAdRail [data-desktop-ad-slot]:not(:empty)")
    );
    const bottomHasAd = Boolean(
      $("#desktopAdBottom [data-desktop-ad-slot]:not(:empty)")
    );
    const chatRailHasAd = Boolean(
      $("#desktopChatAdRail [data-desktop-chat-ad-slot]:not(:empty)")
    );

    $("#desktopAdRail")?.classList.toggle("hidden", chatOpen || !homeRailHasAd);
    $("#desktopAdBottom")?.classList.toggle("hidden", chatOpen || !bottomHasAd);
    $("#desktopChatAdRail")?.classList.toggle("hidden", !chatOpen || !chatRailHasAd);
    runtime.desktopAdSignature = signature;
  }

  async function refreshDesktopAds(force = false) {
    if (
      !runtime.signedIn ||
      !isDesktopLayout() ||
      privateSurfaceActive() ||
      desktopAdCapacity() < 1 ||
      navigator.onLine === false
    ) {
      clearDesktopAds();
      return;
    }

    if (
      !force &&
      runtime.desktopCampaigns.length &&
      Date.now() - runtime.desktopAdFetchAt < 90_000
    ) {
      renderDesktopAds(runtime.desktopCampaigns);
      return;
    }

    runtime.desktopAdAbort?.abort?.();
    const controller = new AbortController();
    runtime.desktopAdAbort = controller;

    try {
      const data = await app()?.api?.("ad_inventory", {
        signal: controller.signal,
        showLoader: false,
        timeoutMs: 7000,
      }, { limit: Math.max(3, desktopAdCapacity()) });

      if (controller.signal.aborted) return;

      const campaigns = Array.isArray(data?.campaigns)
        ? data.campaigns
        : (data?.campaign ? [data.campaign] : []);

      runtime.desktopCampaigns = campaigns;
      runtime.desktopAdFetchAt = Date.now();
      renderDesktopAds(campaigns);
    } catch (error) {
      if (error?.name !== "AbortError") {
        runtime.desktopAdFetchAt = Date.now();
      }
      clearDesktopAds();
    } finally {
      if (runtime.desktopAdAbort === controller) {
        runtime.desktopAdAbort = null;
      }
    }
  }

  function setSignedIn(signedIn) {
    runtime.signedIn = Boolean(signedIn);
    if (!runtime.signedIn) {
      runtime.desktopCampaigns = [];
      runtime.desktopAdFetchAt = 0;
      clearDesktopAds();
      return;
    }

    setTimeout(() => refreshDesktopAds(true), 0);
  }

  function updateSavedMessageButtons() {
    const savedIds = app()?.state?.savedMessageIds;
    if (!(savedIds instanceof Set)) return;

    $$("[data-save-message-id]").forEach((button) => {
      const messageId = Number(button.dataset.saveMessageId || 0);
      const saved = savedIds.has(messageId);
      button.classList.toggle("selected", saved);
      button.setAttribute("aria-pressed", saved ? "true" : "false");
      button.title = saved ? "Remove from saved" : "Save";
      button.setAttribute(
        "aria-label",
        saved ? "Remove from saved messages" : "Save message"
      );
    });
  }

  function savedMessageFallback(item) {
    const type = String(item?.message_type || "text");
    return {
      image: "Photo",
      gif: "GIF",
      video: "Video",
      audio: "Voice message",
      video_note: "Video message",
      sticker: "Sticker",
    }[type] || "Encrypted message";
  }

  async function savedMessagePreview(item) {
    const serverPreview = String(item?.preview || "").trim();
    if (serverPreview) return serverPreview;
    if (!item?.e2ee_payload) return savedMessageFallback(item);

    try {
      const decrypted = await window.SilknexE2EE?.decryptMessage?.({
        id: Number(item.message_id || 0),
        conversation_id: Number(item.conversation_id || 0),
        sender_id: Number(item.sender_id || 0),
        e2ee_payload: String(item.e2ee_payload || ""),
        message_type: String(item.message_type || "text"),
        body: "",
      });
      return String(decrypted?.body || "").trim() || savedMessageFallback(item);
    } catch {
      return savedMessageFallback(item);
    }
  }

  function formatSavedTime(timestamp) {
    const seconds = Number(timestamp || 0);
    if (!seconds) return "";
    try {
      return new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        year: new Date(seconds * 1000).getFullYear() === new Date().getFullYear()
          ? undefined
          : "numeric",
      }).format(new Date(seconds * 1000));
    } catch {
      return "";
    }
  }

  async function renderSavedMessages(items) {
    const list = $("#savedMessagesList");
    if (!list) return;
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "saved-message-empty";
      empty.textContent = "No saved messages yet.";
      list.appendChild(empty);
      return;
    }

    for (const item of items) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "saved-message-row";

      const head = document.createElement("span");
      head.className = "saved-message-head";

      const title = document.createElement("strong");
      title.textContent = String(item.conversation_title || "Conversation");

      const date = document.createElement("small");
      date.textContent = formatSavedTime(item.created_at);

      head.append(title, date);

      const preview = document.createElement("span");
      preview.className = "saved-message-preview";
      preview.textContent = "Decrypting preview…";

      const sender = document.createElement("small");
      sender.className = "saved-message-sender";
      sender.textContent = `From ${String(item.sender_display_name || "SilkNex")}`;

      row.append(head, preview, sender);
      row.addEventListener("click", () => {
        const conversationId = Number(item.conversation_id || 0);
        const messageId = Number(item.message_id || 0);
        app()?.closeModal?.();
        if (!conversationId) return;

        Promise.resolve(app()?.openConversation?.(conversationId))
          .finally(() => {
            setTimeout(() => {
              const target = document.querySelector(
                `[data-message-id="${CSS.escape(String(messageId))}"]`
              );
              target?.scrollIntoView?.({ block: "center", behavior: "smooth" });
              target?.classList.add("message-jump-highlight");
              setTimeout(() => target?.classList.remove("message-jump-highlight"), 1600);
            }, 120);
          });
      });

      list.appendChild(row);
      savedMessagePreview(item).then((text) => {
        preview.textContent = text;
      }).catch(() => {
        preview.textContent = savedMessageFallback(item);
      });
    }
  }

  async function refreshSavedMessages(renderList = false) {
    if (!runtime.signedIn || !app()?.api) return [];
    try {
      const data = await app().api(
        "saved_messages",
        { showLoader: false }
      );
      const items = Array.isArray(data?.items) ? data.items : [];
      runtime.savedItems = items;

      const state = app()?.state;
      if (state) {
        if (!(state.savedMessageIds instanceof Set)) {
          state.savedMessageIds = new Set();
        } else {
          state.savedMessageIds.clear();
        }
        for (const item of items) {
          const id = Number(item.message_id || 0);
          if (id) state.savedMessageIds.add(id);
        }
      }

      updateSavedMessageButtons();
      if (renderList) await renderSavedMessages(items);
      return items;
    } catch (error) {
      if (renderList) {
        const list = $("#savedMessagesList");
        if (list) list.textContent = error?.message || "Could not load saved messages.";
      }
      return [];
    }
  }

  function bindSavedMessages() {
    $("#openSavedMessagesBtn")?.addEventListener("click", () => {
      app()?.openModal?.("#savedMessagesModal");
      refreshSavedMessages(true);
    });

    $("#closeSavedMessagesBtn")?.addEventListener("click", () => {
      app()?.closeModal?.();
    });

    window.addEventListener("silknex:saved-message", () => {
      updateSavedMessageButtons();
      if (!$("#savedMessagesModal")?.classList.contains("hidden")) {
        refreshSavedMessages(true);
      }
    });
  }

  function updateViewportClass() {
    const root = document.documentElement;
    const compact = Boolean(window.matchMedia?.(
      "(max-width: 900px), (pointer: coarse) and (max-height: 540px)"
    )?.matches);
    root.dataset.viewport =
      window.innerWidth <= 360
        ? "phone-narrow"
        : compact
          ? "phone"
          : window.innerWidth >= 2200
            ? "ultrawide"
            : "desktop";

    root.style.setProperty("--v48-screen-width", `${Math.max(0, window.innerWidth)}px`);

    if (compact) {
      // Use visualViewport only for keyboard height. Keeping the fixed shell at
      // top:0 avoids the double-offset bug seen in mobile Safari hit testing.
      const viewportHeight = Math.round(
        window.visualViewport?.height ||
        window.innerHeight ||
        document.documentElement.clientHeight ||
        0
      );
      if (viewportHeight > 0) {
        root.style.setProperty("--app-height", `${viewportHeight}px`);
      }
      root.style.setProperty("--viewport-top", "0px");
    }
  }

  function scheduleViewportRefresh() {
    cancelAnimationFrame(runtime.resizeRaf);
    runtime.resizeRaf = requestAnimationFrame(() => {
      runtime.resizeRaf = 0;
      updateViewportClass();
      updateInstallUi();

      if (isDesktopLayout()) {
        refreshDesktopAds(false);
      } else {
        clearDesktopAds();
      }
    });
  }

  function runStartupShortcut() {
    if (runtime.startupShortcutHandled || !runtime.signedIn) return;

    let url;
    try {
      url = new URL(window.location.href);
    } catch {
      return;
    }

    const compose = url.searchParams.get("compose") === "1";
    const friends = url.searchParams.get("friends") === "1";
    if (!compose && !friends) return;

    runtime.startupShortcutHandled = true;
    url.searchParams.delete("compose");
    url.searchParams.delete("friends");
    try {
      history.replaceState(history.state, "", url);
    } catch {}

    requestAnimationFrame(() => {
      if (compose) {
        app()?.openNewChat?.();
      } else if (friends) {
        app()?.openFriends?.();
      }
    });
  }

  function bindRuntimeEvents() {
    window.addEventListener("silknex:session", (event) => {
      setSignedIn(Boolean(event.detail?.signedIn));
      runStartupShortcut();
      if (runtime.signedIn) refreshSavedMessages(false);
    });

    window.addEventListener("silknex:conversation", () => {
      // Home inventory and the dedicated desktop chat rail use separate slots.
      // Re-render against the active surface instead of suppressing ads merely
      // because a conversation is open.
      setTimeout(() => refreshDesktopAds(false), 0);
    });

    window.addEventListener("silknex:modal", () => {
      // Keep desktop ads behind dialogs and avoid unnecessary animated/GPU
      // layers while a modal is open.
      const anyOpen = Boolean(document.querySelector(".modal:not(.hidden)"));
      document.documentElement.dataset.modalOpen = anyOpen ? "true" : "false";
    });

    window.addEventListener("resize", scheduleViewportRefresh, { passive: true });
    window.visualViewport?.addEventListener?.("resize", scheduleViewportRefresh, { passive: true });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        scheduleViewportRefresh();
        if (runtime.signedIn) refreshDesktopAds(false);
      }
    });

    window.addEventListener("online", () => {
      if (runtime.signedIn) refreshDesktopAds(true);
    });
  }

  function improveTouchAccessibility() {
    // Some mobile browsers keep a stale hover layer after orientation changes.
    // Toggling a tiny data attribute forces style recalc without rebuilding DOM.
    let lastOrientation = window.innerWidth > window.innerHeight ? "landscape" : "portrait";

    window.addEventListener("orientationchange", () => {
      const root = document.documentElement;
      root.dataset.orientationChanging = "true";
      setTimeout(() => {
        lastOrientation = window.innerWidth > window.innerHeight ? "landscape" : "portrait";
        root.dataset.orientation = lastOrientation;
        delete root.dataset.orientationChanging;
        scheduleViewportRefresh();
      }, 120);
    });

    document.documentElement.dataset.orientation = lastOrientation;
  }

  function boot() {
    loadTypingSettings();
    loadTextReplacements();
    configureNativeComposer();
    bindSmartTyping();
    bindInstallFlow();
    bindSavedMessages();
    bindRuntimeEvents();
    improveTouchAccessibility();
    updateViewportClass();

    runtime.signedIn = Boolean(app()?.state?.me);
    if (runtime.signedIn) {
      runStartupShortcut();
      refreshSavedMessages(false);
      refreshDesktopAds(true);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
