(() => {
  "use strict";

  // Older embedded Android/iOS browsers may have Promise without allSettled.
  // SilkNex uses allSettled for non-critical parallel cleanup, so provide the
  // small standards-compatible subset before deferred application scripts run.
  if (window.Promise && typeof Promise.allSettled !== "function") {
    Promise.allSettled = function allSettled(iterable) {
      return Promise.all(Array.from(iterable, (value) =>
        Promise.resolve(value).then(
          (result) => ({ status: "fulfilled", value: result }),
          (reason) => ({ status: "rejected", reason })
        )
      ));
    };
  }

  const root = document.documentElement;
  const prefersLight = () =>
    Boolean(window.matchMedia?.("(prefers-color-scheme: light)")?.matches);

  let themeChoice = "dark";
  let iconStyle = "auto";

  try {
    themeChoice =
      window.SilknexStorage.getItem("neochat-theme-choice") ||
      window.SilknexStorage.getItem("neochat-theme") ||
      "dark";
    iconStyle = window.SilknexStorage.getItem("neochat-icon-style") || "auto";
  } catch {}

  if (!["system", "dark", "light", "amoled"].includes(themeChoice)) {
    themeChoice = "dark";
  }
  if (!["auto", "dark", "light"].includes(iconStyle)) {
    iconStyle = "auto";
  }

  const resolvedTheme =
    themeChoice === "system"
      ? (prefersLight() ? "light" : "dark")
      : themeChoice;
  const resolvedIcon =
    iconStyle === "auto"
      ? (resolvedTheme === "light" ? "light" : "dark")
      : iconStyle;

  root.dataset.themeChoice = themeChoice;
  root.dataset.theme = resolvedTheme;
  root.dataset.iconStyle = resolvedIcon;

  const connection =
    navigator.connection ||
    navigator.mozConnection ||
    navigator.webkitConnection ||
    null;
  const memory = Number(navigator.deviceMemory || 0);
  const cores = Number(navigator.hardwareConcurrency || 0);
  const efficientMode =
    Boolean(connection?.saveData) ||
    (memory > 0 && memory <= 4) ||
    (cores > 0 && cores <= 4);

  root.dataset.performance = efficientMode ? "efficient" : "full";
  root.dataset.pageHidden = document.visibilityState === "hidden" ? "true" : "false";
  root.dataset.network = navigator.onLine === false ? "offline" : "online";

  const favicon = document.getElementById("faviconPng");
  const appleTouchIcon = document.getElementById("appleTouchIcon");
  const manifest = document.getElementById("appManifest");
  const themeColor = document.querySelector('meta[name="theme-color"]');
  const statusBar = document.querySelector(
    'meta[name="apple-mobile-web-app-status-bar-style"]'
  );

  if (favicon) favicon.href = resolvedIcon === "light"
    ? "app-icon-white.png"
    : "app-icon-black.png";
  if (appleTouchIcon) appleTouchIcon.href = resolvedIcon === "light"
    ? "app-icon-white.png"
    : "app-icon-black.png";
  if (manifest) manifest.href = `manifest-${resolvedIcon}.webmanifest`;
  if (themeColor) {
    themeColor.content =
      resolvedTheme === "light"
        ? "#f6f7fb"
        : resolvedTheme === "amoled"
          ? "#000000"
          : "#07070a";
  }
  if (statusBar) {
    statusBar.content =
      resolvedTheme === "light" ? "default" : "black-translucent";
  }

  /*
   * v44 warm startup
   * ----------------
   * Start authenticated bootstrap requests before deferred application scripts
   * finish parsing. app.js consumes these responses instead of issuing duplicate
   * requests. The splash therefore represents real startup work rather than a
   * fixed timer.
   */
  const startedAt = performance.now();
  const MIN_SPLASH_MS = 140;
  const MAX_SPLASH_MS = 1400;
  let appReady = false;
  let splashClosed = false;
  let progress = 6;
  let progressTimer = null;
  const stageState = new Map([
    ["shell", "loading"],
    ["session", "loading"],
    ["chats", "waiting"],
    ["security", "waiting"],
  ]);

  const splashNodes = () => ({
    splash: document.getElementById("brandSplash"),
    bar: document.getElementById("splashProgressBar"),
    status: document.getElementById("splashStatusText"),
    elapsed: document.getElementById("splashElapsed"),
  });

  function renderStage(name) {
    const value = stageState.get(name) || "waiting";
    const node = document.querySelector(`[data-boot-stage="${name}"]`);
    if (!node) return;
    node.classList.toggle("is-loading", value === "loading");
    node.classList.toggle("is-ready", value === "ready");
    node.classList.toggle("is-skip", value === "skip");
    node.classList.toggle("is-error", value === "error");
    node.dataset.state = value;
  }

  function stage(name, state = "ready") {
    if (!stageState.has(name)) return;
    stageState.set(name, state);
    renderStage(name);
  }

  function setSplashProgress(value, label = "") {
    progress = Math.max(progress, Math.min(100, Number(value) || 0));
    const { bar, status } = splashNodes();
    if (bar) bar.style.transform = `scaleX(${progress / 100})`;
    if (status && label) status.textContent = label;
  }

  function finishSplash(force = false) {
    if (splashClosed) return;
    const elapsed = performance.now() - startedAt;
    if (!force && elapsed < MIN_SPLASH_MS) {
      setTimeout(() => finishSplash(force), Math.max(0, MIN_SPLASH_MS - elapsed));
      return;
    }

    splashClosed = true;
    if (progressTimer) clearInterval(progressTimer);
    setSplashProgress(100, "Ready");
    const { splash } = splashNodes();
    if (!splash) return;

    splash.classList.add("splash-finished");
    splash.setAttribute("aria-hidden", "true");
    setTimeout(() => splash.remove(), 220);
    try { performance.mark("silknex-ui-ready"); } catch {}
  }

  function markReady(label = "Ready") {
    appReady = true;
    setSplashProgress(100, label);
    finishSplash();
  }

  async function earlyJson(url, timeoutMs = 7000) {
    if (navigator.onLine === false) {
      return { ok: false, status: 0, data: null, offline: true };
    }

    let timeoutId = 0;
    let controller = null;
    let timedOut = false;

    try {
      if (typeof AbortController === "function") {
        try { controller = new AbortController(); } catch {}
      }

      const request = fetch(url, {
        method: "GET",
        headers: { Accept: "application/json" },
        credentials: "same-origin",
        cache: "no-store",
        priority: "high",
        signal: controller?.signal,
      });

      const timeout = new Promise((_, reject) => {
        timeoutId = setTimeout(() => {
          timedOut = true;
          try { controller?.abort(); } catch {}
          reject(new Error("boot_request_timeout"));
        }, Math.max(1000, Number(timeoutMs) || 7000));
      });

      const response = await Promise.race([request, timeout]);
      let data = null;
      try { data = await Promise.race([response.json(), timeout]); } catch (error) { if (timedOut) throw error; }
      return {
        ok: Boolean(response.ok && data && data.ok !== false),
        status: Number(response.status || 0),
        data,
      };
    } catch {
      return { ok: false, status: 0, data: null, timedOut };
    } finally {
      if (timeoutId) clearTimeout(timeoutId);
    }
  }

  let conversationsPromise = null;
  const sessionPromise = earlyJson("api.php?action=me").then((result) => {
    if (result.ok) {
      stage("session", "ready");
      stage("chats", "loading");
      setSplashProgress(40, "Restoring your chats…");
      conversationsPromise = earlyJson("api.php?action=conversations").then((inbox) => {
        stage("chats", inbox.ok ? "ready" : "error");
        if (inbox.ok) setSplashProgress(66, "Preparing encrypted previews…");
        return inbox;
      });
    } else if (result.status === 401) {
      stage("session", "skip");
      stage("chats", "skip");
      stage("security", "skip");
      setSplashProgress(62, "Opening sign in…");
    } else {
      stage("session", "error");
      stage("chats", "skip");
    }
    return result;
  });

  window.SilknexBoot = Object.freeze({
    ready: markReady,
    progress: setSplashProgress,
    stage,
    session: () => sessionPromise,
    conversations: async () => {
      await sessionPromise;
      return conversationsPromise ? conversationsPromise : null;
    },
  });

  document.addEventListener("DOMContentLoaded", () => {
    for (const name of stageState.keys()) renderStage(name);
    setSplashProgress(18, "Loading interface…");
    progressTimer = setInterval(() => {
      if (appReady || splashClosed) return;
      const elapsed = performance.now() - startedAt;
      const target = Math.min(92, 18 + (elapsed / MAX_SPLASH_MS) * 72);
      setSplashProgress(target);
      const { elapsed: elapsedNode } = splashNodes();
      if (elapsedNode) elapsedNode.textContent = `${Math.max(0, Math.round(elapsed))} ms`;
    }, 90);
  }, { once: true });

  window.addEventListener("silknex:core-ready", () => {
    stage("shell", "ready");
    setSplashProgress(72, "Starting secure messaging…");
  }, { once: true });

  window.addEventListener("silknex:startup-ready", () => {
    markReady("Ready");
  }, { once: true });

  // A slow or unavailable network must never turn branding into a blocker.
  setTimeout(() => finishSplash(true), MAX_SPLASH_MS);

  document.addEventListener("visibilitychange", () => {
    root.dataset.pageHidden = document.visibilityState === "hidden" ? "true" : "false";
  }, { passive: true });

  const updateNetworkState = () => {
    root.dataset.network = navigator.onLine === false ? "offline" : "online";
    window.dispatchEvent(new CustomEvent("silknex:network", {
      detail: { online: navigator.onLine !== false },
    }));
  };

  window.addEventListener("online", updateNetworkState, { passive: true });
  window.addEventListener("offline", updateNetworkState, { passive: true });
})();