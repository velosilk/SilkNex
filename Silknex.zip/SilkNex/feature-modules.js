/* Consolidated feature modules. Maintained source; no build step required. */
/* Feature module 48 */
try {
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const runtime = {
    installPrompt: null,
    signedIn: false,
    smartText: true,
    enterToSend: false,
    correcting: false,
    resizeRaf: 0,
    desktopAdAbort: null,
    desktopAdFetchAt: 0,
    desktopCampaigns: [],
    desktopAdSignature: "",
    inputSeenAt: 0,
    replacements: Object.create(null),
    startupShortcutHandled: false,
    savedItems: [],
  };

  const STORAGE = Object.freeze({
    smartText: "silknex-smart-text-v1",
    enterToSend: "silknex-enter-to-send-v1",
    replacements: "silknex-text-replacements-v1",
    protectedWords: "silknex-autocorrect-protected-v1",
    typingStyle: "silknex-typing-style-v1",
  });

  const COMMON_TYPOS = Object.freeze({
    teh: "the",
    thier: "their",
    recieve: "receive",
    recieved: "received",
    definately: "definitely",
    seperate: "separate",
    occured: "occurred",
    untill: "until",
    becuase: "because",
    wierd: "weird",
    adress: "address",
    mesage: "message",
    messsage: "message",
    freind: "friend",
    frend: "friend",
    tommorow: "tomorrow",
    tomorow: "tomorrow",
    accomodate: "accommodate",
    embarass: "embarrass",
    independant: "independent",
    goverment: "government",
    relevent: "relevant",
    calender: "calendar",
    occured: "occurred",
    sucess: "success",
    succesful: "successful",
    definately: "definitely",
    dont: "don't",
    doesnt: "doesn't",
    didnt: "didn't",
    cant: "can't",
    couldnt: "couldn't",
    wont: "won't",
    wouldnt: "wouldn't",
    shouldnt: "shouldn't",
    isnt: "isn't",
    arent: "aren't",
    wasnt: "wasn't",
    werent: "weren't",
    ive: "I've",
    im: "I'm",
    youre: "you're",
    theyre: "they're",
    thats: "that's",
    whats: "what's",
    lets: "let's",
    alot: "a lot",
    aswell: "as well",
    atleast: "at least",
    probaly: "probably",
    probablyy: "probably",
    actualy: "actually",
    actualyl: "actually",
    thsi: "this",
    taht: "that",
    jsut: "just",
    adn: "and",
    knwo: "know",
    waht: "what",
    woudl: "would",
    shoudl: "should",
    coudl: "could",
    becasue: "because",
    peopel: "people",
    somthing: "something",
    everytime: "every time",
  });

  function safeStorageGet(key, fallback = "") {
    try {
      const value = window.SilknexStorage.getItem(key);
      return value === null ? fallback : value;
    } catch {
      return fallback;
    }
  }

  function safeStorageSet(key, value) {
    try {
      window.SilknexStorage.setItem(key, value);
    } catch {}
  }

  function parseTextReplacements(raw) {
    const result = Object.create(null);
    const lines = String(raw || "").split(/\r?\n/u);
    let count = 0;

    for (const line of lines) {
      if (count >= 40) break;
      const separator = line.indexOf("=");
      if (separator < 1) continue;

      const shortcut = line.slice(0, separator).trim().toLowerCase();
      const replacement = line.slice(separator + 1).trim();
      if (
        !/^[a-z][a-z0-9'_-]{1,23}$/u.test(shortcut) ||
        !replacement ||
        replacement.length > 120
      ) {
        continue;
      }

      result[shortcut] = replacement;
      count += 1;
    }

    return result;
  }

  function loadTextReplacements() {
    const raw = safeStorageGet(STORAGE.replacements, "");
    runtime.replacements = parseTextReplacements(raw);
    const input = $("#textReplacementsInput");
    if (input) input.value = raw;
  }

  function saveTextReplacements() {
    const input = $("#textReplacementsInput");
    const raw = String(input?.value || "").trim();
    runtime.replacements = parseTextReplacements(raw);

    const normalized = Object.entries(runtime.replacements)
      .map(([shortcut, replacement]) => `${shortcut} = ${replacement}`)
      .join("\n");

    safeStorageSet(STORAGE.replacements, normalized);
    if (input) input.value = normalized;
    app()?.toast?.(
      `${Object.keys(runtime.replacements).length} text replacement${
        Object.keys(runtime.replacements).length === 1 ? "" : "s"
      } saved.`
    );
  }

  function adClientKey() {
    try {
      const existing = sessionStorage.getItem("silknex-ad-client-key");
      if (/^[a-f0-9]{32}$/.test(existing || "")) return existing;

      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      const created = Array.from(bytes, (value) =>
        value.toString(16).padStart(2, "0")
      ).join("");
      sessionStorage.setItem("silknex-ad-client-key", created);
      return created;
    } catch {
      return "";
    }
  }

  function isStandalone() {
    return Boolean(
      window.matchMedia?.("(display-mode: standalone)")?.matches ||
      window.matchMedia?.("(display-mode: fullscreen)")?.matches ||
      navigator.standalone === true
    );
  }

  function isIosLike() {
    const platform = String(navigator.platform || "");
    const ua = String(navigator.userAgent || "");
    return /iPad|iPhone|iPod/i.test(ua) ||
      (platform === "MacIntel" && Number(navigator.maxTouchPoints || 0) > 1);
  }

  function isDesktopLayout() {
    return window.matchMedia?.("(min-width: 801px)")?.matches === true;
  }

  function chatSurfaceActive() {
    const state = app()?.state;
    return Boolean(
      Number(state?.activeId || 0) > 0 &&
      !$("#chatView")?.classList.contains("hidden")
    );
  }

  function privateSurfaceActive() {
    // Desktop chat ads are now allowed in the dedicated rail only. Calls,
    // fullscreen media, and blocking private surfaces remain ad-free.
    return Boolean(app()?.state?.call);
  }

  function updateTypingSettingsUi() {
    const smart = $("#smartTextToggle");
    const enter = $("#enterToSendToggle");
    if (smart) smart.checked = runtime.smartText;
    if (enter) enter.checked = runtime.enterToSend;
    document.documentElement.dataset.smartText = runtime.smartText ? "true" : "false";
    document.documentElement.dataset.enterToSend = runtime.enterToSend ? "true" : "false";
  }

  function loadTypingSettings() {
    runtime.smartText = safeStorageGet(STORAGE.smartText, "1") !== "0";
    runtime.enterToSend = safeStorageGet(STORAGE.enterToSend, "0") === "1";
    updateTypingSettingsUi();
  }

  function configureNativeComposer() {
    const input = $("#messageInput");
    if (!input) return;
    input.setAttribute("autocomplete", "on");
    input.setAttribute("autocapitalize", "sentences");
    input.setAttribute("spellcheck", "true");
    input.setAttribute("autocorrect", "on");
    input.setAttribute("inputmode", "text");
    input.setAttribute("enterkeyhint", "send");
  }

  function looksSensitiveOrStructured(text) {
    const tail = String(text || "").slice(-160);
    if (!tail) return false;

    return (
      /https?:\/\/\S*$/i.test(tail) ||
      /www\.\S*$/i.test(tail) ||
      /\b[\w.+-]+@[\w.-]*$/i.test(tail) ||
      /(?:^|\s)@\w*$/i.test(tail) ||
      /(?:^|\s)#[A-Fa-f0-9]{3,8}$/i.test(tail) ||
      /[`{}[\]\\]|=>|==|!=|::|<\/?[a-z][^>]*$/i.test(tail)
    );
  }

  function preserveCase(source, replacement) {
    if (!source) return replacement;
    if (source === source.toUpperCase() && source.length > 1) {
      return replacement.toUpperCase();
    }
    if (source[0] === source[0].toUpperCase()) {
      return replacement[0].toUpperCase() + replacement.slice(1);
    }
    return replacement;
  }

  function protectedAutocorrectWords() {
    return new Set(
      safeStorageGet(STORAGE.protectedWords, "")
        .split(/[\s,\n]+/u)
        .map((word) => word.trim().toLowerCase())
        .filter((word) => /^[a-z0-9'_.-]{1,40}$/u.test(word))
        .slice(0, 300)
    );
  }

  function typingStyleProfile() {
    try {
      const parsed = JSON.parse(safeStorageGet(STORAGE.typingStyle, "{}"));
      return {
        total: Math.max(0, Number(parsed.total || 0)),
        lowercase: Math.max(0, Number(parsed.lowercase || 0)),
      };
    } catch {
      return { total: 0, lowercase: 0 };
    }
  }

  function prefersLowercaseStyle() {
    const profile = typingStyleProfile();
    return profile.total >= 12 && (profile.lowercase / Math.max(1, profile.total)) >= 0.70;
  }

  function learnTypingStyle(value) {
    const text = String(value || "").trim();
    const first = text.match(/[A-Za-z]/u)?.[0] || "";
    if (!first) return;
    const profile = typingStyleProfile();
    profile.total = Math.min(200, profile.total + 1);
    profile.lowercase = Math.min(200, profile.lowercase + (first === first.toLowerCase() ? 1 : 0));
    if (profile.total >= 200) {
      profile.total = Math.round(profile.total * .75);
      profile.lowercase = Math.round(profile.lowercase * .75);
    }
    safeStorageSet(STORAGE.typingStyle, JSON.stringify(profile));
  }

  function smartCorrectPrefix(prefix) {
    if (!prefix || looksSensitiveOrStructured(prefix)) return prefix;

    let value = prefix;

    // Replace only a completed final word. This avoids fighting the keyboard
    // while the user is still typing and leaves deliberate slang mostly alone.
    value = value.replace(
      /(^|[\s(\["'“‘])([A-Za-z']{2,})([\s.,!?;:)\]"'”’])$/u,
      (match, lead, word, boundary) => {
        const normalizedWord = word.toLowerCase();
        if (protectedAutocorrectWords().has(normalizedWord)) return match;
        const replacement =
          runtime.replacements[normalizedWord] ||
          COMMON_TYPOS[normalizedWord];
        if (!replacement) return match;
        return `${lead}${preserveCase(word, replacement)}${boundary}`;
      }
    );

    // Standalone lowercase "i" is almost always accidental in normal prose.
    if (!protectedAutocorrectWords().has("i") && !prefersLowercaseStyle()) {
      value = value.replace(/(^|[\s(])i([\s.,!?;:)])$/u, "$1I$2");
    }

    // Remove spaces before closing punctuation at the caret.
    value = value.replace(/\s+([,!?;:)])$/u, "$1");

    // Collapse accidental runs of spaces, but keep newlines and indentation.
    value = value.replace(/([^\n]) {2,}$/u, "$1 ");

    // Capitalize the first alphabetic character of a sentence only when the
    // user has just completed the first word. Mixed-case/code-ish text is left.
    const sentenceMatch = value.match(/(^|[.!?]\s+)([a-z])([a-z']*)([\s.,!?;:]?)$/u);
    if (sentenceMatch && !prefersLowercaseStyle() && !/[A-Z].*[A-Z]/.test(sentenceMatch[2] + sentenceMatch[3])) {
      const start = sentenceMatch.index + sentenceMatch[1].length;
      value =
        value.slice(0, start) +
        sentenceMatch[2].toUpperCase() +
        value.slice(start + 1);
    }

    return value;
  }

  function maybeApplySmartCorrection(event) {
    if (!runtime.smartText || runtime.correcting) return;
    if (event?.isComposing) return;

    const input = $("#messageInput");
    if (!input || document.activeElement !== input) return;
    if (input.selectionStart !== input.selectionEnd) return;

    const caret = Number(input.selectionStart || 0);
    if (caret <= 0) return;

    const inserted = String(event?.data ?? "");
    const inputType = String(event?.inputType || "");

    const boundaryTyped =
      /\s|[.,!?;:)]/.test(inserted) ||
      inputType === "insertParagraph" ||
      inputType === "insertLineBreak";

    if (!boundaryTyped) return;

    const before = input.value.slice(0, caret);
    const after = input.value.slice(caret);
    const corrected = smartCorrectPrefix(before);
    if (corrected === before) return;

    runtime.correcting = true;
    input.value = corrected + after;
    const nextCaret = corrected.length;
    try {
      input.setSelectionRange(nextCaret, nextCaret);
    } catch {}
    input.dispatchEvent(new Event("input", { bubbles: true }));
    runtime.correcting = false;
  }

  function applyFinalSmartCorrection() {
    if (!runtime.smartText || runtime.correcting) return;
    const input = $("#messageInput");
    if (!input || input.selectionStart !== input.selectionEnd) return;
    if (Number(input.selectionEnd || 0) !== input.value.length) return;

    const source = String(input.value || "");
    if (!source || looksSensitiveOrStructured(source)) return;

    // Append a temporary boundary so the same safe word-correction rules can
    // handle the final word when the user presses Send without typing a space.
    const correctedWithBoundary = smartCorrectPrefix(`${source} `);
    const corrected = correctedWithBoundary.endsWith(" ")
      ? correctedWithBoundary.slice(0, -1)
      : correctedWithBoundary;

    if (corrected === source) return;
    runtime.correcting = true;
    input.value = corrected;
    try {
      input.setSelectionRange(corrected.length, corrected.length);
    } catch {}
    input.dispatchEvent(new Event("input", { bubbles: true }));
    runtime.correcting = false;
  }

  function bindSmartTyping() {
    const input = $("#messageInput");
    if (!input || input.dataset.v48TypingBound === "1") return;
    input.dataset.v48TypingBound = "1";

    input.addEventListener("input", (event) => {
      runtime.inputSeenAt = Date.now();
      maybeApplySmartCorrection(event);
    });

    // The legacy core sends Enter everywhere. Intercept it on desktop when the
    // user explicitly prefers Enter=newline. Mobile keeps its normal send-key
    // behavior because virtual keyboards rely on enterkeyhint="send".
    input.addEventListener("keydown", (event) => {
      if (
        event.key === "Enter" &&
        !event.shiftKey &&
        !event.isComposing &&
        isDesktopLayout() &&
        !runtime.enterToSend
      ) {
        event.stopImmediatePropagation();
      }
    }, true);

    $("#messageForm")?.addEventListener("submit", () => {
      learnTypingStyle($("#messageInput")?.value || "");
      applyFinalSmartCorrection();
    }, true);

    $("#openTextReplacementsBtn")?.addEventListener("click", () => {
      loadTextReplacements();
      app()?.openModal?.("#textReplacementsModal");
      requestAnimationFrame(() => $("#textReplacementsInput")?.focus());
    });

    $("#closeTextReplacementsBtn")?.addEventListener("click", () => {
      app()?.closeModal?.("textReplacementsModal");
    });

    $("#saveTextReplacementsBtn")?.addEventListener("click", () => {
      saveTextReplacements();
      app()?.closeModal?.("textReplacementsModal");
    });

    $("#clearTextReplacementsBtn")?.addEventListener("click", () => {
      runtime.replacements = Object.create(null);
      safeStorageSet(STORAGE.replacements, "");
      const replacementsInput = $("#textReplacementsInput");
      if (replacementsInput) replacementsInput.value = "";
      app()?.toast?.("Text replacements cleared.");
    });

    $("#smartTextToggle")?.addEventListener("change", (event) => {
      runtime.smartText = Boolean(event.currentTarget.checked);
      safeStorageSet(STORAGE.smartText, runtime.smartText ? "1" : "0");
      updateTypingSettingsUi();
      app()?.toast?.(
        runtime.smartText
          ? "Smarter autocorrect is on."
          : "Smarter autocorrect is off."
      );
    });

    $("#enterToSendToggle")?.addEventListener("change", (event) => {
      runtime.enterToSend = Boolean(event.currentTarget.checked);
      safeStorageSet(STORAGE.enterToSend, runtime.enterToSend ? "1" : "0");
      updateTypingSettingsUi();
      app()?.toast?.(
        runtime.enterToSend
          ? "Enter will send messages on computers."
          : "Enter will create a new line on computers."
      );
    });
  }

  function updateInstallUi() {
    const installed = isStandalone();
    const available = Boolean(runtime.installPrompt) || isIosLike() || !installed;

    $("#installAppHomeBtn")?.classList.toggle("hidden", installed || !available);

    const settingsButton = $("#installAppSettingsBtn");
    const status = $("#installAppStatus");
    if (settingsButton) {
      settingsButton.disabled = installed;
      settingsButton.textContent = installed ? "Installed" : "Install";
    }

    if (status) {
      if (installed) {
        status.textContent = "Silknex is installed on this device.";
      } else if (runtime.installPrompt) {
        status.textContent = "Optional. Install only when you choose to.";
      } else if (isIosLike()) {
        status.textContent = "Optional. Use Share → Add to Home Screen when you want it.";
      } else {
        status.textContent = "Optional. Your browser may offer Install or Add to Home Screen.";
      }
    }
  }

  function showInstallHelp() {
    const modal = $("#installHelpModal");
    const heading = $("#installHelpHeading");
    const copy = $("#installHelpCopy");

    if (heading && copy) {
      if (isIosLike()) {
        heading.textContent = "Add Silknex to your Home Screen";
        copy.textContent =
          "Open the browser Share menu, choose “Add to Home Screen”, then confirm. This is optional—Silknex keeps working in the browser.";
      } else {
        heading.textContent = "Install Silknex from your browser";
        copy.textContent =
          "Open your browser menu and choose Install app, Install Silknex, or Add to Home Screen. This is optional and can be removed like any other installed web app.";
      }
    }

    if (modal && app()?.openModal) {
      app().openModal("#installHelpModal");
    } else {
      app()?.toast?.("Use your browser’s Install or Add to Home Screen option.");
    }
  }

  async function requestInstall() {
    if (isStandalone()) {
      app()?.toast?.("Silknex is already installed.");
      return;
    }

    const prompt = runtime.installPrompt;
    if (!prompt) {
      showInstallHelp();
      return;
    }

    runtime.installPrompt = null;

    try {
      await prompt.prompt();
      const result = await prompt.userChoice;
      if (result?.outcome === "accepted") {
        app()?.toast?.("Silknex installation started.");
      }
    } catch {
      showInstallHelp();
    } finally {
      updateInstallUi();
    }
  }

  function bindInstallFlow() {
    window.addEventListener("beforeinstallprompt", (event) => {
      // Never interrupt the user with an automatic install prompt.
      event.preventDefault();
      runtime.installPrompt = event;
      updateInstallUi();
    });

    window.addEventListener("appinstalled", () => {
      runtime.installPrompt = null;
      updateInstallUi();
      app()?.toast?.("Silknex was installed.");
    });

    $("#installAppHomeBtn")?.addEventListener("click", requestInstall);
    $("#installAppSettingsBtn")?.addEventListener("click", requestInstall);
    $("#installHelpDoneBtn")?.addEventListener("click", () => app()?.closeModal?.());
    updateInstallUi();
  }

  function campaignCreative(campaign, placement) {
    if (!campaign?.image_url || !campaign?.destination_url) return null;

    const link = document.createElement("a");
    link.className = "silknex-paid-ad silknex-paid-ad-banner";
    link.href = String(campaign.destination_url);
    link.target = "_blank";
    link.rel = "noopener noreferrer sponsored";
    link.dataset.campaignId = String(campaign.id || "");
    link.dataset.desktopPlacement = placement;

    const image = document.createElement("img");
    image.src = String(campaign.image_url);
    image.alt = String(campaign.headline || "Sponsored");
    image.loading = "lazy";
    image.decoding = "async";
    link.appendChild(image);

    const copy = document.createElement("span");
    copy.className = "silknex-paid-ad-copy";

    const label = document.createElement("small");
    label.textContent = "Sponsored";

    const title = document.createElement("b");
    title.textContent = String(campaign.headline || "Sponsored");

    const cta = document.createElement("span");
    cta.className = "silknex-paid-ad-cta";
    cta.textContent = "Learn more";

    copy.append(label, title, cta);
    link.appendChild(copy);

    link.addEventListener("click", () => {
      app()?.api?.("ad_event", {
        method: "POST",
        body: {
          event_type: "rendered",
          placement: `desktop_${placement}`,
          provider: "house",
          client_key: adClientKey(),
        },
        showLoader: false,
        keepalive: true,
        timeoutMs: 4000,
      }).catch(() => {});
    }, { passive: true });

    return link;
  }

  function desktopAdCapacity() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    const chatOpen = chatSurfaceActive();

    if (height < 600) return 0;
    if (chatOpen) {
      if (width < 1024) return 0;
      if (width >= 2400 && height >= 820) return 3;
      if (width >= 1680 && height >= 760) return 2;
      return 1;
    }

    if (width < 1180) return 0;
    if (width >= 2200 && height >= 820) return 5;
    if (width >= 1600 && height >= 820) return 3;
    return 2;
  }

  function clearDesktopAds() {
    runtime.desktopAdAbort?.abort?.();
    runtime.desktopAdAbort = null;
    runtime.desktopAdSignature = "";

    $("#desktopAdRail")?.classList.add("hidden");
    $("#desktopAdBottom")?.classList.add("hidden");
    $("#desktopChatAdRail")?.classList.add("hidden");

    $$("[data-desktop-ad-slot],[data-desktop-chat-ad-slot]")
      .forEach((slot) => slot.replaceChildren());
  }

  function renderDesktopAds(campaigns) {
    const capacity = desktopAdCapacity();
    const chatOpen = chatSurfaceActive();

    if (
      !runtime.signedIn ||
      !isDesktopLayout() ||
      privateSurfaceActive() ||
      capacity < 1 ||
      !Array.isArray(campaigns) ||
      !campaigns.length
    ) {
      clearDesktopAds();
      return;
    }

    const valid = campaigns
      .filter((campaign) =>
        campaign &&
        campaign.image_url &&
        campaign.destination_url &&
        Number(campaign.ends_at || 0) > Math.floor(Date.now() / 1000)
      )
      .slice(0, capacity);

    if (!valid.length) {
      clearDesktopAds();
      return;
    }

    const selector = chatOpen
      ? "[data-desktop-chat-ad-slot]"
      : "[data-desktop-ad-slot]";
    const slots = $$(selector).slice(0, capacity);
    const signature =
      `${chatOpen ? "chat" : "home"}:${valid.map((item) => item.id).join(",")}:${capacity}`;

    if (runtime.desktopAdSignature === signature) {
      if (chatOpen) {
        $("#desktopChatAdRail")?.classList.remove("hidden");
        $("#desktopAdRail")?.classList.add("hidden");
        $("#desktopAdBottom")?.classList.add("hidden");
      } else {
        $("#desktopAdRail")?.classList.remove("hidden");
        $("#desktopAdBottom")?.classList.remove("hidden");
        $("#desktopChatAdRail")?.classList.add("hidden");
      }
      return;
    }

    $$("[data-desktop-ad-slot],[data-desktop-chat-ad-slot]")
      .forEach((slot) => slot.replaceChildren());

    valid.forEach((campaign, index) => {
      const slot = slots[index];
      if (!slot) return;
      const placement = String(
        slot.dataset.desktopChatAdSlot ||
        slot.dataset.desktopAdSlot ||
        `slot-${index + 1}`
      );
      const creative = campaignCreative(campaign, placement);
      if (creative) slot.appendChild(creative);
    });

    const homeRailHasAd = Boolean(
      $("#desktopAdRail [data-desktop-ad-slot]:not(:empty)")
    );
    const bottomHasAd = Boolean(
      $("#desktopAdBottom [data-desktop-ad-slot]:not(:empty)")
    );
    const chatRailHasAd = Boolean(
      $("#desktopChatAdRail [data-desktop-chat-ad-slot]:not(:empty)")
    );

    $("#desktopAdRail")?.classList.toggle("hidden", chatOpen || !homeRailHasAd);
    $("#desktopAdBottom")?.classList.toggle("hidden", chatOpen || !bottomHasAd);
    $("#desktopChatAdRail")?.classList.toggle("hidden", !chatOpen || !chatRailHasAd);
    runtime.desktopAdSignature = signature;
  }

  async function refreshDesktopAds(force = false) {
    if (
      !runtime.signedIn ||
      !isDesktopLayout() ||
      privateSurfaceActive() ||
      desktopAdCapacity() < 1 ||
      navigator.onLine === false
    ) {
      clearDesktopAds();
      return;
    }

    if (
      !force &&
      runtime.desktopCampaigns.length &&
      Date.now() - runtime.desktopAdFetchAt < 90_000
    ) {
      renderDesktopAds(runtime.desktopCampaigns);
      return;
    }

    runtime.desktopAdAbort?.abort?.();
    const controller = app().createAbortController();
    runtime.desktopAdAbort = controller;

    try {
      const data = await app()?.api?.("ad_inventory", {
        signal: controller.signal,
        showLoader: false,
        timeoutMs: 7000,
      }, { limit: Math.max(3, desktopAdCapacity()) });

      if (controller.signal?.aborted) return;

      const campaigns = Array.isArray(data?.campaigns)
        ? data.campaigns
        : (data?.campaign ? [data.campaign] : []);

      runtime.desktopCampaigns = campaigns;
      runtime.desktopAdFetchAt = Date.now();
      renderDesktopAds(campaigns);
    } catch (error) {
      if (error?.name !== "AbortError") {
        runtime.desktopAdFetchAt = Date.now();
      }
      clearDesktopAds();
    } finally {
      if (runtime.desktopAdAbort === controller) {
        runtime.desktopAdAbort = null;
      }
    }
  }

  function setSignedIn(signedIn) {
    runtime.signedIn = Boolean(signedIn);
    if (!runtime.signedIn) {
      runtime.desktopCampaigns = [];
      runtime.desktopAdFetchAt = 0;
      clearDesktopAds();
      return;
    }

    setTimeout(() => refreshDesktopAds(true), 0);
  }

  function updateSavedMessageButtons() {
    const savedIds = app()?.state?.savedMessageIds;
    if (!(savedIds instanceof Set)) return;

    $$("[data-save-message-id]").forEach((button) => {
      const messageId = Number(button.dataset.saveMessageId || 0);
      const saved = savedIds.has(messageId);
      button.classList.toggle("selected", saved);
      button.setAttribute("aria-pressed", saved ? "true" : "false");
      button.title = saved ? "Remove from saved" : "Save";
      button.setAttribute(
        "aria-label",
        saved ? "Remove from saved messages" : "Save message"
      );
    });
  }

  function savedMessageFallback(item) {
    const type = String(item?.message_type || "text");
    return {
      image: "Photo",
      gif: "GIF",
      video: "Video",
      audio: "Voice message",
      video_note: "Video message",
      sticker: "Sticker",
    }[type] || "Message";
  }

  async function savedMessagePreview(item) {
    const serverPreview = String(item?.preview || "").trim();
    if (serverPreview) return serverPreview;
    if (!item?.e2ee_payload) return savedMessageFallback(item);

    try {
      const decrypted = await window.SilknexE2EE?.decryptMessage?.({
        id: Number(item.message_id || 0),
        conversation_id: Number(item.conversation_id || 0),
        sender_id: Number(item.sender_id || 0),
        e2ee_payload: String(item.e2ee_payload || ""),
        message_type: String(item.message_type || "text"),
        body: "",
      });
      return String(decrypted?.body || "").trim() || savedMessageFallback(item);
    } catch {
      return savedMessageFallback(item);
    }
  }

  function formatSavedTime(timestamp) {
    const seconds = Number(timestamp || 0);
    if (!seconds) return "";
    try {
      return new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        year: new Date(seconds * 1000).getFullYear() === new Date().getFullYear()
          ? undefined
          : "numeric",
      }).format(new Date(seconds * 1000));
    } catch {
      return "";
    }
  }

  async function renderSavedMessages(items) {
    const list = $("#savedMessagesList");
    if (!list) return;
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "saved-message-empty";
      empty.textContent = "No saved messages yet.";
      list.appendChild(empty);
      return;
    }

    for (const item of items) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "saved-message-row";

      const head = document.createElement("span");
      head.className = "saved-message-head";

      const title = document.createElement("strong");
      title.textContent = String(item.conversation_title || "Conversation");

      const date = document.createElement("small");
      date.textContent = formatSavedTime(item.created_at);

      head.append(title, date);

      const preview = document.createElement("span");
      preview.className = "saved-message-preview";
      preview.textContent = "Decrypting preview…";

      const sender = document.createElement("small");
      sender.className = "saved-message-sender";
      sender.textContent = `From ${String(item.sender_display_name || "Silknex")}`;

      row.append(head, preview, sender);
      row.addEventListener("click", () => {
        const conversationId = Number(item.conversation_id || 0);
        const messageId = Number(item.message_id || 0);
        app()?.closeModal?.();
        if (!conversationId) return;

        Promise.resolve(app()?.openConversation?.(conversationId))
          .finally(() => {
            setTimeout(() => {
              const target = document.querySelector(
                `[data-message-id="${CSS.escape(String(messageId))}"]`
              );
              target?.scrollIntoView?.({ block: "center", behavior: "smooth" });
              target?.classList.add("message-jump-highlight");
              setTimeout(() => target?.classList.remove("message-jump-highlight"), 1600);
            }, 120);
          });
      });

      list.appendChild(row);
      savedMessagePreview(item).then((text) => {
        preview.textContent = text;
      }).catch(() => {
        preview.textContent = savedMessageFallback(item);
      });
    }
  }

  async function refreshSavedMessages(renderList = false) {
    if (!runtime.signedIn || !app()?.api) return [];
    try {
      const data = await app().api(
        "saved_messages",
        { showLoader: false }
      );
      const items = Array.isArray(data?.items) ? data.items : [];
      runtime.savedItems = items;

      const state = app()?.state;
      if (state) {
        if (!(state.savedMessageIds instanceof Set)) {
          state.savedMessageIds = new Set();
        } else {
          state.savedMessageIds.clear();
        }
        for (const item of items) {
          const id = Number(item.message_id || 0);
          if (id) state.savedMessageIds.add(id);
        }
      }

      updateSavedMessageButtons();
      if (renderList) await renderSavedMessages(items);
      return items;
    } catch (error) {
      if (renderList) {
        const list = $("#savedMessagesList");
        if (list) list.textContent = error?.message || "Could not load saved messages.";
      }
      return [];
    }
  }

  function bindSavedMessages() {
    $("#openSavedMessagesBtn")?.addEventListener("click", () => {
      app()?.openModal?.("#savedMessagesModal");
      refreshSavedMessages(true);
    });

    $("#closeSavedMessagesBtn")?.addEventListener("click", () => {
      app()?.closeModal?.();
    });

    window.addEventListener("silknex:saved-message", () => {
      updateSavedMessageButtons();
      if (!$("#savedMessagesModal")?.classList.contains("hidden")) {
        refreshSavedMessages(true);
      }
    });
  }

  function updateViewportClass() {
    const root = document.documentElement;
    const compact = Boolean(window.matchMedia?.(
      "(max-width: 900px), (pointer: coarse) and (max-height: 540px)"
    )?.matches);
    root.dataset.viewport =
      window.innerWidth <= 360
        ? "phone-narrow"
        : compact
          ? "phone"
          : window.innerWidth >= 2200
            ? "ultrawide"
            : "desktop";

    root.style.setProperty("--v48-screen-width", `${Math.max(0, window.innerWidth)}px`);

    // App viewport dimensions are owned by app.js.
  }

  function scheduleViewportRefresh() {
    cancelAnimationFrame(runtime.resizeRaf);
    runtime.resizeRaf = requestAnimationFrame(() => {
      runtime.resizeRaf = 0;
      updateViewportClass();
      updateInstallUi();

      if (isDesktopLayout()) {
        refreshDesktopAds(false);
      } else {
        clearDesktopAds();
      }
    });
  }

  function runStartupShortcut() {
    if (runtime.startupShortcutHandled || !runtime.signedIn) return;

    let url;
    try {
      url = new URL(window.location.href);
    } catch {
      return;
    }

    const compose = url.searchParams.get("compose") === "1";
    const friends = url.searchParams.get("friends") === "1";
    if (!compose && !friends) return;

    runtime.startupShortcutHandled = true;
    url.searchParams.delete("compose");
    url.searchParams.delete("friends");
    try {
      history.replaceState(history.state, "", url);
    } catch {}

    requestAnimationFrame(() => {
      if (compose) {
        app()?.openNewChat?.();
      } else if (friends) {
        app()?.openFriends?.();
      }
    });
  }

  function bindRuntimeEvents() {
    window.addEventListener("silknex:session", (event) => {
      setSignedIn(Boolean(event.detail?.signedIn));
      runStartupShortcut();
      if (runtime.signedIn) refreshSavedMessages(false);
    });

    window.addEventListener("silknex:conversation", () => {
      // Home inventory and the dedicated desktop chat rail use separate slots.
      // Re-render against the active surface instead of suppressing ads merely
      // because a conversation is open.
      setTimeout(() => refreshDesktopAds(false), 0);
    });

    window.addEventListener("silknex:modal", () => {
      // Keep desktop ads behind dialogs and avoid unnecessary animated/GPU
      // layers while a modal is open.
      const anyOpen = Boolean(document.querySelector(".modal:not(.hidden)"));
      document.documentElement.dataset.modalOpen = anyOpen ? "true" : "false";
    });

    window.addEventListener("resize", scheduleViewportRefresh, { passive: true });
    window.visualViewport?.addEventListener?.("resize", scheduleViewportRefresh, { passive: true });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        scheduleViewportRefresh();
        if (runtime.signedIn) refreshDesktopAds(false);
      }
    });

    window.addEventListener("online", () => {
      if (runtime.signedIn) refreshDesktopAds(true);
    });
  }

  function improveTouchAccessibility() {
    // Some mobile browsers keep a stale hover layer after orientation changes.
    // Toggling a tiny data attribute forces style recalc without rebuilding DOM.
    let lastOrientation = window.innerWidth > window.innerHeight ? "landscape" : "portrait";

    window.addEventListener("orientationchange", () => {
      const root = document.documentElement;
      root.dataset.orientationChanging = "true";
      setTimeout(() => {
        lastOrientation = window.innerWidth > window.innerHeight ? "landscape" : "portrait";
        root.dataset.orientation = lastOrientation;
        delete root.dataset.orientationChanging;
        scheduleViewportRefresh();
      }, 120);
    });

    document.documentElement.dataset.orientation = lastOrientation;
  }

  function boot() {
    loadTypingSettings();
    loadTextReplacements();
    configureNativeComposer();
    bindSmartTyping();
    bindInstallFlow();
    bindSavedMessages();
    bindRuntimeEvents();
    improveTouchAccessibility();
    updateViewportClass();

    runtime.signedIn = Boolean(app()?.state?.me);
    if (runtime.signedIn) {
      runStartupShortcut();
      refreshSavedMessages(false);
      refreshDesktopAds(true);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();

} catch (error) { console.error("Silknex feature module 48:", error); }

;
/* Feature module 49 */
try {
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const runtime = {
    signedIn: false,
    founder: false,
    pinnedIds: new Set(),
    pinConversationId: 0,
    pinRefreshTimer: null,
    announcementTimer: null,
    messageObserver: null,
    ownerDashboard: null,
  };

  function toast(message) {
    app()?.toast?.(String(message || ""));
  }

  function svgIcon(name) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    svg.classList.add("v49-action-icon");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "1.8");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");

    const paths = {
      pin: [
        "M8.5 3.5h7",
        "M9.5 3.5l.8 5.2-3 3v1.8h9.4v-1.8l-3-3 .8-5.2",
        "M12 13.5v7",
      ],
      speaker: [
        "M5 10v4h3l4 3V7l-4 3H5Z",
        "M15 9.2c1 .8 1.5 1.7 1.5 2.8s-.5 2-1.5 2.8",
        "M17.5 7c1.6 1.4 2.5 3 2.5 5s-.9 3.6-2.5 5",
      ],
      link: [
        "M9.5 14.5 14.5 9.5",
        "M7.2 16.8 5.8 18.2a3 3 0 0 1-4.2-4.2L5 10.6a3 3 0 0 1 4.2 0",
        "m14.8 7.2 1.4-1.4a3 3 0 0 1 4.2 4.2L17 13.4a3 3 0 0 1-4.2 0",
      ],
      crown: [
        "m4 8 4 4 4-7 4 7 4-4-2 10H6L4 8Z",
        "M7 21h10",
      ],
      refresh: [
        "M20 7v5h-5",
        "M4 17v-5h5",
        "M6.1 8.2A7 7 0 0 1 18.6 6L20 12",
        "M4 12l1.4 6A7 7 0 0 0 17.9 15.8",
      ],
    };

    for (const d of paths[name] || paths.link) {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", d);
      svg.appendChild(path);
    }
    return svg;
  }

  function setSignedIn(value) {
    runtime.signedIn = Boolean(value);
    runtime.founder = Boolean(
      runtime.signedIn &&
      ["founder_ceo", "cofounder_ceo"].includes(app()?.state?.me?.role)
    );

    document.documentElement.dataset.founder = runtime.founder ? "true" : "false";

    if (runtime.founder) {
      ensureOwnerUi();
    } else {
      $("#v49OwnerSettings")?.remove();
      $("#v49OwnerModal")?.remove();
    }

    if (runtime.signedIn) {
      scheduleAnnouncementRefresh(true);
    } else {
      clearTimeout(runtime.announcementTimer);
      runtime.announcementTimer = null;
      hideAnnouncement();
      stopPinRefresh();
      runtime.pinnedIds.clear();
      runtime.pinConversationId = 0;
      updatePinButtons();
    }
  }

  function copyText(text, success = "Copied.") {
    const value = String(text || "");
    if (!value) return Promise.resolve(false);

    if (navigator.clipboard?.writeText) {
      return navigator.clipboard.writeText(value)
        .then(() => {
          toast(success);
          return true;
        })
        .catch(() => fallbackCopy(value, success));
    }

    return Promise.resolve(fallbackCopy(value, success));
  }

  function fallbackCopy(text, success) {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.left = "-9999px";
    document.body.appendChild(area);
    area.select();

    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch {}
    area.remove();

    if (ok) toast(success);
    else toast("Copy is unavailable in this browser.");
    return ok;
  }

  function conversationLink() {
    const id = Number(app()?.state?.activeId || 0);
    if (!id) return "";

    const url = new URL(window.location.href);
    url.search = "";
    url.hash = "";
    url.searchParams.set("conversation", String(id));
    return url.toString();
  }

  async function shareConversation() {
    const url = conversationLink();
    if (!url) {
      toast("Open a conversation first.");
      return;
    }

    const title = String(
      app()?.state?.activeConversation?.title || "Silknex conversation"
    );

    if (navigator.share) {
      try {
        await navigator.share({ title, url });
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }

    await copyText(url, "Conversation link copied.");
  }

  /* ------------------------------------------------------------------ */
  /* Global founder announcements                                       */
  /* ------------------------------------------------------------------ */

  function announcementDismissKey(id) {
    return `silknex:announcement:dismissed:${String(id || "")}`;
  }

  function announcementWasDismissed(id) {
    if (!id) return false;
    try {
      return sessionStorage.getItem(announcementDismissKey(id)) === "1";
    } catch {
      return false;
    }
  }

  function dismissAnnouncement(id) {
    if (id) {
      try {
        sessionStorage.setItem(announcementDismissKey(id), "1");
      } catch {}
    }
    hideAnnouncement();
  }

  function ensureAnnouncementBar() {
    let bar = $("#systemAnnouncementBar");
    if (bar) return bar;

    bar = document.createElement("aside");
    bar.id = "systemAnnouncementBar";
    bar.className = "system-announcement hidden";
    bar.setAttribute("role", "status");
    bar.setAttribute("aria-live", "polite");

    const badge = document.createElement("span");
    badge.className = "system-announcement-badge";
    badge.textContent = "SILKNEX";

    const text = document.createElement("span");
    text.id = "systemAnnouncementText";
    text.className = "system-announcement-text";

    const close = document.createElement("button");
    close.type = "button";
    close.className = "system-announcement-close";
    close.setAttribute("aria-label", "Dismiss announcement");
    close.textContent = "×";
    close.addEventListener("click", () => {
      dismissAnnouncement(bar.dataset.announcementId || "");
    });

    bar.append(badge, text, close);
    document.body.appendChild(bar);
    return bar;
  }

  function hideAnnouncement() {
    const bar = $("#systemAnnouncementBar");
    if (!bar) return;
    bar.classList.add("hidden");
    bar.dataset.announcementId = "";
  }

  function renderAnnouncement(announcement) {
    const bar = ensureAnnouncementBar();
    const id = String(announcement?.id || "");
    const text = String(announcement?.text || "").trim();
    const expiresAt = Number(announcement?.expires_at || 0);

    if (
      !id ||
      !text ||
      expiresAt <= Math.floor(Date.now() / 1000) ||
      announcementWasDismissed(id)
    ) {
      hideAnnouncement();
      return;
    }

    bar.dataset.announcementId = id;
    $("#systemAnnouncementText", bar).textContent = text;
    bar.classList.remove("hidden");
  }

  async function refreshAnnouncement() {
    if (!runtime.signedIn || !app()?.api || document.visibilityState === "hidden") {
      return;
    }

    try {
      const data = await app().api(
        "system_announcement",
        { showLoader: false, timeoutMs: 5000 }
      );
      renderAnnouncement(data?.announcement || null);
    } catch {
      // Announcements are optional and must never interfere with messaging.
    }
  }

  function scheduleAnnouncementRefresh(immediate = false) {
    clearTimeout(runtime.announcementTimer);
    runtime.announcementTimer = null;
    if (!runtime.signedIn) return;

    const run = async () => {
      await refreshAnnouncement();
      runtime.announcementTimer = setTimeout(run, 5 * 60 * 1000);
    };

    runtime.announcementTimer = setTimeout(run, immediate ? 20 : 5 * 60 * 1000);
  }

  /* ------------------------------------------------------------------ */
  /* Pinned messages                                                     */
  /* ------------------------------------------------------------------ */

  function messageFallback(item) {
    return {
      image: "Photo",
      gif: "GIF",
      video: "Video",
      audio: "Voice message",
      video_note: "Video message",
      sticker: "Sticker",
    }[String(item?.message_type || "text")] || "Message";
  }

  async function pinPreview(item) {
    const serverPreview = String(item?.preview || "").trim();
    if (serverPreview) return serverPreview;
    if (!item?.e2ee_payload) return messageFallback(item);

    try {
      const decrypted = await window.SilknexE2EE?.decryptMessage?.({
        id: Number(item.message_id || 0),
        conversation_id: Number(item.conversation_id || 0),
        sender_id: Number(item.sender_id || 0),
        e2ee_payload: String(item.e2ee_payload || ""),
        message_type: String(item.message_type || "text"),
        body: "",
      });
      return String(decrypted?.body || "").trim() || messageFallback(item);
    } catch {
      return messageFallback(item);
    }
  }

  function formatShortTime(timestamp) {
    const value = Number(timestamp || 0);
    if (!value) return "";
    try {
      return new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      }).format(new Date(value * 1000));
    } catch {
      return "";
    }
  }

  function ensurePinsModal() {
    if ($("#v49PinsModal")) return;

    const modal = document.createElement("section");
    modal.id = "v49PinsModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v49PinsHeading");
    modal.innerHTML = `
      <div class="modal-card v49-pins-card">
        <header class="modal-head">
          <div><small>CONVERSATION</small><h2 id="v49PinsHeading">Pinned messages</h2></div>
          <button id="v49PinsClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <div id="v49PinsList" class="v49-pins-list" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(modal);
    $("#v49PinsClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
  }

  async function renderPins(items) {
    ensurePinsModal();
    const list = $("#v49PinsList");
    if (!list) return;
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "v49-pins-empty";
      empty.textContent = "No pinned messages in this conversation.";
      list.appendChild(empty);
      return;
    }

    for (const item of items) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "v49-pin-row";

      const head = document.createElement("span");
      head.className = "v49-pin-row-head";

      const sender = document.createElement("strong");
      sender.textContent = String(item.sender_display_name || "Silknex");

      const date = document.createElement("small");
      date.textContent = formatShortTime(item.created_at);
      head.append(sender, date);

      const preview = document.createElement("span");
      preview.className = "v49-pin-preview";
      preview.textContent = "Decrypting preview…";

      row.append(head, preview);
      row.addEventListener("click", () => {
        const id = Number(item.message_id || 0);
        app()?.closeModal?.();
        setTimeout(() => {
          const target = document.querySelector(
            `.message[data-message-id="${CSS.escape(String(id))}"]`
          );
          if (!target) {
            toast("That pinned message is outside the currently loaded history.");
            return;
          }
          target.scrollIntoView({ block: "center", behavior: "smooth" });
          target.classList.add("message-jump-highlight");
          setTimeout(() => target.classList.remove("message-jump-highlight"), 1800);
        }, 80);
      });

      list.appendChild(row);
      pinPreview(item)
        .then((text) => {
          preview.textContent = text;
        })
        .catch(() => {
          preview.textContent = messageFallback(item);
        });
    }
  }

  async function refreshPins({ render = false, quiet = true } = {}) {
    const cid = Number(app()?.state?.activeId || 0);
    if (!runtime.signedIn || !cid || !app()?.api) {
      runtime.pinConversationId = 0;
      runtime.pinnedIds.clear();
      updatePinButtons();
      if (render) renderPins([]);
      return [];
    }

    try {
      const data = await app().api(
        "message_pins",
        {
          showLoader: !quiet,
          timeoutMs: 6000,
        },
        { conversation_id: cid }
      );

      if (cid !== Number(app()?.state?.activeId || 0)) return [];

      const items = Array.isArray(data?.pins) ? data.pins : [];
      runtime.pinConversationId = cid;
      runtime.pinnedIds = new Set(
        items.map((item) => Number(item.message_id || 0)).filter(Boolean)
      );
      updatePinButtons();
      if (render) await renderPins(items);
      return items;
    } catch (error) {
      if (render) {
        ensurePinsModal();
        const list = $("#v49PinsList");
        if (list) list.textContent = error?.message || "Could not load pinned messages.";
      }
      return [];
    }
  }

  async function togglePin(messageId, button) {
    const cid = Number(app()?.state?.activeId || 0);
    const id = Number(messageId || 0);
    if (!cid || !id || !app()?.api || button?.disabled) return;

    if (button) button.disabled = true;
    try {
      const data = await app().api("message_pin_toggle", {
        method: "POST",
        body: {
          conversation_id: cid,
          message_id: id,
        },
        showLoader: false,
      });

      if (data?.pinned) runtime.pinnedIds.add(id);
      else runtime.pinnedIds.delete(id);
      updatePinButtons();
      toast(data?.pinned ? "Message pinned." : "Message unpinned.");

      if (!$("#v49PinsModal")?.classList.contains("hidden")) {
        await refreshPins({ render: true });
      }
    } catch (error) {
      toast(error?.message || "Could not update the pin.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function pinButtonFor(messageId) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "message-action icon-action v49-pin-action";
    button.dataset.pinMessageId = String(messageId);
    button.title = "Pin message";
    button.setAttribute("aria-label", "Pin message");
    button.appendChild(svgIcon("pin"));
    button.addEventListener("click", () => togglePin(messageId, button));
    return button;
  }

  function readButtonFor(messageId) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "message-action icon-action v49-read-action";
    button.title = "Read aloud";
    button.setAttribute("aria-label", "Read message aloud");
    button.appendChild(svgIcon("speaker"));
    button.addEventListener("click", () => {
      const message = app()?.state?.messages?.get?.(Number(messageId));
      const text = String(message?.body || "").trim();
      if (!text || !("speechSynthesis" in window)) return;

      try {
        speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text.slice(0, 4000));
        utterance.rate = 1;
        speechSynthesis.speak(utterance);
      } catch {
        toast("Read aloud is unavailable in this browser.");
      }
    });
    return button;
  }

  function decorateMessages() {
    const state = app()?.state;
    const map = state?.messages;
    if (!(map instanceof Map)) return;

    $$("#messages .message[data-message-id]").forEach((row) => {
      const id = Number(row.dataset.messageId || 0);
      if (!id) return;

      const actions = $(".message-actions", row);
      if (!actions) return;

      if (!$(".v49-pin-action", actions)) {
        actions.appendChild(pinButtonFor(id));
      }

      const message = map.get(id);
      if (
        message?.message_type === "text" &&
        String(message?.body || "").trim() &&
        "speechSynthesis" in window &&
        !$(".v49-read-action", actions)
      ) {
        actions.appendChild(readButtonFor(id));
      }
    });

    updatePinButtons();
  }

  function updatePinButtons() {
    $$("[data-pin-message-id]").forEach((button) => {
      const id = Number(button.dataset.pinMessageId || 0);
      const pinned =
        runtime.pinConversationId === Number(app()?.state?.activeId || 0) &&
        runtime.pinnedIds.has(id);
      button.classList.toggle("selected", pinned);
      button.setAttribute("aria-pressed", pinned ? "true" : "false");
      button.title = pinned ? "Unpin message" : "Pin message";
      button.setAttribute("aria-label", pinned ? "Unpin message" : "Pin message");
    });
  }

  function startPinRefresh() {
    stopPinRefresh();

    const run = async () => {
      if (
        document.visibilityState === "visible" &&
        Number(app()?.state?.activeId || 0) > 0
      ) {
        await refreshPins({ render: false });
      }
      runtime.pinRefreshTimer = setTimeout(run, 45000);
    };

    runtime.pinRefreshTimer = setTimeout(run, 45000);
  }

  function stopPinRefresh() {
    clearTimeout(runtime.pinRefreshTimer);
    runtime.pinRefreshTimer = null;
  }

  function ensureChatUtilityControls() {
    const modal = $("#chatSettingsModal .modal-card");
    if (!modal || $("#v49ChatUtilities")) return;

    const section = document.createElement("section");
    section.id = "v49ChatUtilities";
    section.className = "settings-section v49-chat-utilities";
    section.innerHTML = `
      <div class="section-title"><span>Conversation tools</span></div>
      <div class="v49-utility-grid">
        <button id="v49OpenPinsBtn" class="secondary-btn" type="button">Pinned messages</button>
        <button id="v49CopyChatLinkBtn" class="secondary-btn" type="button">Copy chat link</button>
        <button id="v49ShareChatBtn" class="secondary-btn" type="button">Share conversation</button>
      </div>
    `;

    const header = $(".modal-head", modal);
    header?.insertAdjacentElement("afterend", section);

    $("#v49OpenPinsBtn", section)?.addEventListener("click", () => {
      ensurePinsModal();
      app()?.openModal?.("#v49PinsModal");
      refreshPins({ render: true, quiet: false });
    });

    $("#v49CopyChatLinkBtn", section)?.addEventListener("click", () => {
      const url = conversationLink();
      if (!url) {
        toast("Open a conversation first.");
        return;
      }
      copyText(url, "Conversation link copied.");
    });

    $("#v49ShareChatBtn", section)?.addEventListener("click", shareConversation);
  }

  /* ------------------------------------------------------------------ */
  /* Founder-only control center                                        */
  /* ------------------------------------------------------------------ */

  function ownerStat(label, value) {
    const card = document.createElement("div");
    card.className = "v49-owner-stat";
    const small = document.createElement("small");
    small.textContent = label;
    const strong = document.createElement("strong");
    strong.textContent = String(value ?? "—");
    card.append(small, strong);
    return card;
  }

  function formatInteger(value) {
    const n = Number(value || 0);
    try {
      return new Intl.NumberFormat().format(Number.isFinite(n) ? n : 0);
    } catch {
      return String(Number.isFinite(n) ? n : 0);
    }
  }

  function ensureOwnerUi() {
    if (!runtime.founder) return;

    let section = $("#v49OwnerSettings");
    if (!section) {
      section = document.createElement("section");
      section.id = "v49OwnerSettings";
      section.className = "settings-section v49-owner-settings";
      section.innerHTML = `
        <div class="section-title"><span>Founder controls</span></div>
        <div class="v49-owner-entry">
          <div>
            <b>Silknex Control Center</b>
            <small>Private operational tools available only to the Founder/CEO account.</small>
          </div>
          <button id="v49OpenOwnerBtn" class="primary" type="button">Open Control Center</button>
        </div>
      `;

      const monetization = $("#monetizationSettings");
      if (monetization) monetization.insertAdjacentElement("afterend", section);
      else $("#settingsModal .settings-card")?.appendChild(section);

      $("#v49OpenOwnerBtn", section)?.addEventListener("click", () => {
        ensureOwnerModal();
        app()?.openModal?.("#v49OwnerModal");
        refreshOwnerDashboard(false);
      });
    }

    ensureOwnerModal();
  }

  function ensureOwnerModal() {
    if (!runtime.founder || $("#v49OwnerModal")) return;

    const modal = document.createElement("section");
    modal.id = "v49OwnerModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v49OwnerHeading");
    modal.innerHTML = `
      <div class="modal-card v49-owner-card">
        <header class="modal-head">
          <div>
            <small>FOUNDER / CEO</small>
            <h2 id="v49OwnerHeading">Silknex Control Center</h2>
          </div>
          <div class="v49-owner-head-actions">
            <button id="v49OwnerRefreshBtn" class="plain-btn icon-only" type="button" aria-label="Refresh dashboard"></button>
            <button id="v49OwnerCloseBtn" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
          </div>
        </header>

        <section class="v49-owner-hero">
          <div class="v49-owner-crown" aria-hidden="true"></div>
          <div>
            <strong>Founder mode</strong>
            <small>Your account is ad-free and has server-side gated operational controls.</small>
          </div>
        </section>

        <section>
          <div class="section-title"><span>Live overview</span></div>
          <div id="v49OwnerStats" class="v49-owner-stats" aria-live="polite"></div>
        </section>

        <section class="v49-owner-block">
          <div class="section-title"><span>Global announcement</span></div>
          <label class="field">
            <span>Message shown to signed-in users</span>
            <textarea id="v49AnnouncementText" maxlength="280" rows="3" placeholder="Service update, new feature, planned maintenance…"></textarea>
          </label>
          <div class="v49-owner-inline">
            <label class="field v49-owner-hours">
              <span>Hours</span>
              <input id="v49AnnouncementHours" type="number" min="1" max="168" value="24">
            </label>
            <button id="v49PublishAnnouncementBtn" class="primary" type="button">Publish</button>
            <button id="v49ClearAnnouncementBtn" class="secondary-btn" type="button">Clear</button>
          </div>
        </section>

        <section class="v49-owner-block">
          <div class="section-title"><span>Registration</span></div>
          <div class="v49-owner-control-row">
            <div>
              <b id="v49RegistrationTitle">Loading…</b>
              <small id="v49RegistrationCopy">Control whether new accounts can be created.</small>
            </div>
            <button id="v49RegistrationToggle" class="secondary-btn" type="button">Toggle</button>
          </div>
        </section>

        <section class="v49-owner-block">
          <div class="section-title"><span>Security</span></div>
          <form id="v49RevokeSessionsForm" class="v49-owner-revoke">
            <label class="field">
              <span>Force a user to sign in again</span>
              <input id="v49RevokeUsername" maxlength="24" autocomplete="off" placeholder="username">
            </label>
            <button class="secondary-btn" type="submit">Revoke sessions</button>
          </form>
          <small class="v49-owner-note">This invalidates the target account's browser sessions and remember tokens without deleting messages or encryption devices.</small>
        </section>
      </div>
    `;

    document.body.appendChild(modal);

    const refreshIcon = $("#v49OwnerRefreshBtn", modal);
    refreshIcon?.appendChild(svgIcon("refresh"));
    const crown = $(".v49-owner-crown", modal);
    crown?.appendChild(svgIcon("crown"));

    $("#v49OwnerCloseBtn", modal)?.addEventListener("click", () => app()?.closeModal?.());
    $("#v49OwnerRefreshBtn", modal)?.addEventListener("click", () => refreshOwnerDashboard(false));
    $("#v49PublishAnnouncementBtn", modal)?.addEventListener("click", publishOwnerAnnouncement);
    $("#v49ClearAnnouncementBtn", modal)?.addEventListener("click", clearOwnerAnnouncement);
    $("#v49RegistrationToggle", modal)?.addEventListener("click", toggleRegistration);
    $("#v49RevokeSessionsForm", modal)?.addEventListener("submit", revokeUserSessions);
  }

  function renderOwnerDashboard(data) {
    const dashboard = data || {};
    runtime.ownerDashboard = dashboard;
    const stats = $("#v49OwnerStats");
    if (stats) {
      stats.replaceChildren(
        ownerStat("Users", formatInteger(dashboard.users_total)),
        ownerStat("Online now", formatInteger(dashboard.online_now)),
        ownerStat("Messages", formatInteger(dashboard.messages_total)),
        ownerStat("Conversations", formatInteger(dashboard.conversations_total)),
        ownerStat("Uploads", formatInteger(dashboard.uploads_total)),
        ownerStat("Scheduled", formatInteger(dashboard.scheduled_pending)),
        ownerStat("Active ads", formatInteger(dashboard.active_ad_campaigns)),
        ownerStat("Schema", `v${String(dashboard.schema_version || "—")}`)
      );
    }

    const registrationOpen = Boolean(dashboard.registration_open);
    const title = $("#v49RegistrationTitle");
    const copy = $("#v49RegistrationCopy");
    const button = $("#v49RegistrationToggle");
    if (title) title.textContent = registrationOpen ? "Registration is open" : "Registration is paused";
    if (copy) {
      copy.textContent = registrationOpen
        ? "New users can create accounts."
        : "Existing users can still sign in; new account creation is blocked.";
    }
    if (button) {
      button.textContent = registrationOpen ? "Pause signups" : "Open signups";
      button.dataset.registrationOpen = registrationOpen ? "true" : "false";
    }

    const announcement = dashboard.announcement;
    const text = $("#v49AnnouncementText");
    if (text && document.activeElement !== text) {
      text.value = String(announcement?.text || "");
    }
  }

  async function refreshOwnerDashboard(quiet = true) {
    if (!runtime.founder || !app()?.api) return;

    const stats = $("#v49OwnerStats");
    if (stats && !quiet) stats.setAttribute("aria-busy", "true");

    try {
      const data = await app().api("owner_dashboard", {
        showLoader: false,
        timeoutMs: 8000,
      });
      renderOwnerDashboard(data?.dashboard || {});
    } catch (error) {
      toast(error?.message || "Could not load founder controls.");
    } finally {
      stats?.removeAttribute("aria-busy");
    }
  }

  async function publishOwnerAnnouncement() {
    if (!runtime.founder) return;
    const text = String($("#v49AnnouncementText")?.value || "").trim();
    const hours = Math.min(168, Math.max(1, Number($("#v49AnnouncementHours")?.value || 24)));
    if (!text) {
      toast("Write an announcement first.");
      return;
    }

    const button = $("#v49PublishAnnouncementBtn");
    if (button) button.disabled = true;
    try {
      const data = await app().api("owner_announcement_set", {
        method: "POST",
        body: { text, hours },
        showLoader: false,
      });
      renderAnnouncement(data?.announcement || null);
      toast("Announcement published.");
      await refreshOwnerDashboard(true);
    } catch (error) {
      toast(error?.message || "Could not publish the announcement.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function clearOwnerAnnouncement() {
    if (!runtime.founder) return;
    const button = $("#v49ClearAnnouncementBtn");
    if (button) button.disabled = true;
    try {
      await app().api("owner_announcement_set", {
        method: "POST",
        body: { text: "", hours: 1 },
        showLoader: false,
      });
      const field = $("#v49AnnouncementText");
      if (field) field.value = "";
      hideAnnouncement();
      toast("Announcement cleared.");
      await refreshOwnerDashboard(true);
    } catch (error) {
      toast(error?.message || "Could not clear the announcement.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function toggleRegistration() {
    if (!runtime.founder) return;

    const currentlyOpen =
      $("#v49RegistrationToggle")?.dataset.registrationOpen === "true";
    const nextOpen = !currentlyOpen;
    const button = $("#v49RegistrationToggle");
    if (button) button.disabled = true;

    try {
      const data = await app().api("owner_registration_set", {
        method: "POST",
        body: { open: nextOpen },
        showLoader: false,
      });
      runtime.ownerDashboard = {
        ...(runtime.ownerDashboard || {}),
        registration_open: Boolean(data?.registration_open),
      };
      renderOwnerDashboard(runtime.ownerDashboard);
      toast(data?.registration_open ? "Registration opened." : "Registration paused.");
    } catch (error) {
      toast(error?.message || "Could not update registration.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function revokeUserSessions(event) {
    event.preventDefault();
    if (!runtime.founder) return;

    const input = $("#v49RevokeUsername");
    const username = String(input?.value || "").trim();
    if (!username) {
      toast("Enter a username.");
      return;
    }

    const submit = $("#v49RevokeSessionsForm button[type='submit']");
    if (submit) submit.disabled = true;

    try {
      const data = await app().api("owner_revoke_sessions", {
        method: "POST",
        body: { username },
        showLoader: false,
      });
      if (input) input.value = "";
      toast(`Sessions revoked for @${String(data?.username || username)}.`);
    } catch (error) {
      toast(error?.message || "Could not revoke sessions.");
    } finally {
      if (submit) submit.disabled = false;
    }
  }

  /* ------------------------------------------------------------------ */
  /* Wiring                                                              */
  /* ------------------------------------------------------------------ */

  function bindMessageObserver() {
    const box = $("#messages");
    if (!box || runtime.messageObserver) return;

    let decorationQueued = false;
    runtime.messageObserver = new MutationObserver((records) => {
      const addedRows = records.some(record => [...record.addedNodes].some(node =>
        node instanceof Element && (node.matches(".message[data-message-id], .message-actions") || node.querySelector(".message[data-message-id], .message-actions"))
      ));
      if (!addedRows || decorationQueued) return;
      decorationQueued = true;
      requestAnimationFrame(() => { decorationQueued = false; decorateMessages(); });
    });

    runtime.messageObserver.observe(box, {
      childList: true,
      subtree: true,
    });

    decorateMessages();
  }

  function onConversationEvent(event) {
    const id = Number(event.detail?.id || 0);
    const loaded = Boolean(event.detail?.conversation);

    if (!id) {
      runtime.pinConversationId = 0;
      runtime.pinnedIds.clear();
      stopPinRefresh();
      updatePinButtons();
      return;
    }

    if (!loaded) return;

    runtime.pinConversationId = id;
    runtime.pinnedIds.clear();
    decorateMessages();
    refreshPins({ render: false });
    startPinRefresh();
  }

  function boot() {
    ensureAnnouncementBar();
    ensurePinsModal();
    ensureChatUtilityControls();
    bindMessageObserver();

    runtime.signedIn = Boolean(app()?.state?.me);
    runtime.founder = Boolean(["founder_ceo", "cofounder_ceo"].includes(app()?.state?.me?.role));
    setSignedIn(runtime.signedIn);

    window.addEventListener("silknex:session", (event) => {
      setTimeout(() => {
        setSignedIn(Boolean(event.detail?.signedIn));
      }, 0);
    });

    window.addEventListener("silknex:conversation", onConversationEvent);

    window.addEventListener("silknex:saved-message", () => {
      // Message action rows can be rebuilt around saved-state updates.
      requestAnimationFrame(decorateMessages);
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible" && runtime.signedIn) {
        refreshAnnouncement();
        if (Number(app()?.state?.activeId || 0) > 0) {
          refreshPins({ render: false });
        }
      }
    });

    window.addEventListener("online", () => {
      if (runtime.signedIn) refreshAnnouncement();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();

} catch (error) { console.error("Silknex feature module 49:", error); }

;
/* Feature module 50 */
try {
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const runtime = {
    signedIn: false,
    founder: false,
    reminderTimer: null,
    reminderObserver: null,
    reminderIds: new Set(),
    reminderMessageId: 0,
    nextReminderAt: 0,
    ownerRefreshTimer: null,
  };


  function toast(message) {
    app()?.toast?.(String(message || ""));
  }


  function icon(name) {
    const paths = {
      bell: ["M6 17h12", "M8 17V10a4 4 0 0 1 8 0v7", "M10 20h4"],
      search: ["M11 18a7 7 0 1 1 0-14 7 7 0 0 1 0 14Z", "m16 16 4 4"],
      command: ["M9 6H6a3 3 0 1 0 3 3V6Zm0 0v12m0 0H6a3 3 0 1 1 3-3v3Zm6-12h3a3 3 0 1 1-3 3V6Zm0 0v12m0 0h3a3 3 0 1 0-3-3v3Z"],
      download: ["M12 3v12", "m8 11 4 4 4-4", "M5 20h14"],
      activity: ["M3 12h4l2-6 4 12 2-6h6"],
      shield: ["M12 3 5 6v5c0 4.5 2.8 8 7 10 4.2-2 7-5.5 7-10V6l-7-3Z", "m9 12 2 2 4-5"],
      user: ["M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z", "M4 21a8 8 0 0 1 16 0"],
      pause: ["M8 6v12", "M16 6v12"],
      play: ["m9 6 9 6-9 6Z"],
      list: ["M8 6h13", "M8 12h13", "M8 18h13", "M3 6h.01", "M3 12h.01", "M3 18h.01"],
      export: ["M12 3v12", "m8 11 4 4 4-4", "M5 20h14"],
      focus: ["M8 3H3v5", "M16 3h5v5", "M8 21H3v-5", "M16 21h5v-5"],
    };
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    svg.classList.add("v50-icon");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "1.8");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    for (const d of paths[name] || paths.command) {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", d);
      svg.appendChild(path);
    }
    return svg;
  }

  function isFounder() {
    return Boolean(
      app()?.state?.me &&
      ["founder_ceo", "cofounder_ceo"].includes(app()?.state?.me?.role)
    );
  }

  function formatDate(timestamp) {
    const seconds = Number(timestamp || 0);
    if (!seconds) return "—";
    try {
      return new Intl.DateTimeFormat(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(seconds * 1000));
    } catch {
      return new Date(seconds * 1000).toLocaleString();
    }
  }

  function formatInteger(value) {
    const number = Number(value || 0);
    try {
      return new Intl.NumberFormat().format(Number.isFinite(number) ? number : 0);
    } catch {
      return String(Number.isFinite(number) ? number : 0);
    }
  }

  function money(cents) {
    try {
      return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency: "USD",
      }).format(Number(cents || 0) / 100);
    } catch {
      return `$${(Number(cents || 0) / 100).toFixed(2)}`;
    }
  }

  function localDateTimeValue(timestamp) {
    const date = new Date(timestamp);
    const offsetMs = date.getTimezoneOffset() * 60000;
    return new Date(date.getTime() - offsetMs).toISOString().slice(0, 16);
  }

  /* ------------------------------------------------------------------ */
  /* Connectivity + focus mode                                           */
  /* ------------------------------------------------------------------ */

  function ensureConnectivityChip() {
    let chip = $("#v50Connectivity");
    if (chip) return chip;

    chip = document.createElement("button");
    chip.id = "v50Connectivity";
    chip.className = "v50-connectivity";
    chip.type = "button";
    chip.setAttribute("aria-live", "polite");
    chip.title = "Connection status";
    chip.append(icon("activity"), document.createElement("span"));

    const target = $("#syncStatus")?.parentElement || $("#chatHeader") || $(".sidebar-header");
    target?.appendChild(chip);
    chip.addEventListener("click", () => {
      if (!navigator.onLine) {
        toast("Silknex is offline. Messages will sync again when your connection returns.");
      } else {
        toast("Connected. Silknex is syncing normally.");
      }
    });
    return chip;
  }

  function updateConnectivity() {
    const chip = ensureConnectivityChip();
    if (!chip) return;
    const online = navigator.onLine;
    chip.classList.toggle("offline", !online);
    const label = $("span", chip);
    if (label) label.textContent = online ? "Online" : "Offline";
    chip.setAttribute("aria-label", online ? "Silknex is online" : "Silknex is offline");
  }

  /* ------------------------------------------------------------------ */
  /* Message reminders                                                   */
  /* ------------------------------------------------------------------ */

  function messageFallback(item) {
    return {
      image: "Photo",
      gif: "GIF",
      video: "Video",
      audio: "Voice message",
      video_note: "Video message",
      sticker: "Sticker",
    }[String(item?.message_type || "text")] || "Message";
  }

  async function reminderPreview(item) {
    const loaded = app()?.state?.messages?.get?.(Number(item?.message_id || 0));
    if (loaded && String(loaded.body || "").trim()) {
      return String(loaded.body).trim();
    }

    const serverPreview = String(item?.preview || "").trim();
    if (serverPreview) return serverPreview;
    if (!item?.e2ee_payload) return messageFallback(item);

    try {
      const decrypted = await window.SilknexE2EE?.decryptMessage?.({
        id: Number(item.message_id || 0),
        conversation_id: Number(item.conversation_id || 0),
        sender_id: Number(item.sender_id || 0),
        e2ee_payload: String(item.e2ee_payload || ""),
        message_type: String(item.message_type || "text"),
        body: "",
      });
      return String(decrypted?.body || "").trim() || messageFallback(item);
    } catch {
      return messageFallback(item);
    }
  }

  function ensureReminderModal() {
    if ($("#v50ReminderModal")) return;

    const modal = document.createElement("section");
    modal.id = "v50ReminderModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v50ReminderTitle");
    modal.innerHTML = `
      <div class="modal-card v50-reminder-card">
        <header class="modal-head">
          <div><small>REMINDERS</small><h2 id="v50ReminderTitle">Message reminders</h2></div>
          <button id="v50ReminderClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <div id="v50ReminderList" class="v50-reminder-list" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(modal);
    $("#v50ReminderClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
  }

  function ensureReminderPicker() {
    if ($("#v50ReminderPicker")) return;

    const modal = document.createElement("section");
    modal.id = "v50ReminderPicker";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v50ReminderPickerTitle");
    modal.innerHTML = `
      <div class="modal-card v50-reminder-picker-card">
        <header class="modal-head">
          <div><small>MESSAGE</small><h2 id="v50ReminderPickerTitle">Remind me</h2></div>
          <button id="v50ReminderPickerClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <div class="v50-reminder-presets">
          <button type="button" data-reminder-offset="600">In 10 minutes</button>
          <button type="button" data-reminder-offset="3600">In 1 hour</button>
          <button type="button" data-reminder-preset="tomorrow">Tomorrow at 9:00 AM</button>
          <button type="button" data-reminder-offset="604800">In 1 week</button>
        </div>
        <form id="v50ReminderCustomForm" class="v50-reminder-custom">
          <label class="field">
            <span>Custom date and time</span>
            <input id="v50ReminderCustomTime" type="datetime-local" required>
          </label>
          <button class="primary" type="submit">Set reminder</button>
        </form>
      </div>
    `;
    document.body.appendChild(modal);

    $("#v50ReminderPickerClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
    $$("[data-reminder-offset]", modal).forEach((button) => {
      button.addEventListener("click", () => {
        const offset = Number(button.dataset.reminderOffset || 0);
        setMessageReminder(runtime.reminderMessageId, Math.floor(Date.now() / 1000) + offset);
      });
    });
    $("[data-reminder-preset='tomorrow']", modal)?.addEventListener("click", () => {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(9, 0, 0, 0);
      setMessageReminder(runtime.reminderMessageId, Math.floor(tomorrow.getTime() / 1000));
    });
    $("#v50ReminderCustomForm", modal)?.addEventListener("submit", (event) => {
      event.preventDefault();
      const value = $("#v50ReminderCustomTime")?.value;
      const timestamp = value ? Math.floor(new Date(value).getTime() / 1000) : 0;
      if (!timestamp || timestamp <= Math.floor(Date.now() / 1000) + 30) {
        toast("Choose a future time.");
        return;
      }
      setMessageReminder(runtime.reminderMessageId, timestamp);
    });
  }

  function openReminderPicker(messageId) {
    const id = Number(messageId || 0);
    const cid = Number(app()?.state?.activeId || 0);
    if (!id || !cid) return;

    runtime.reminderMessageId = id;
    ensureReminderPicker();
    const input = $("#v50ReminderCustomTime");
    if (input) {
      input.min = localDateTimeValue(Date.now() + 60000);
      input.value = localDateTimeValue(Date.now() + 3600000);
    }
    app()?.openModal?.("#v50ReminderPicker");
  }

  async function setMessageReminder(messageId, remindAt) {
    const cid = Number(app()?.state?.activeId || 0);
    const id = Number(messageId || 0);
    if (!cid || !id || !app()?.api) return;

    try {
      await app().api("message_reminder_set", {
        method: "POST",
        body: {
          conversation_id: cid,
          message_id: id,
          remind_at: Number(remindAt || 0),
        },
        showLoader: false,
      });
      runtime.reminderIds.add(id);
      updateReminderButtons();
      app()?.closeModal?.();
      toast(`Reminder set for ${formatDate(remindAt)}.`);
      scheduleReminderRefresh(2000);
    } catch (error) {
      toast(error?.message || "Could not set the reminder.");
    }
  }

  async function deleteReminder(messageId, quiet = false) {
    const id = Number(messageId || 0);
    if (!id || !app()?.api) return;
    try {
      await app().api("message_reminder_delete", {
        method: "POST",
        body: { message_id: id },
        showLoader: false,
      });
      runtime.reminderIds.delete(id);
      updateReminderButtons();
      if (!quiet) toast("Reminder removed.");
    } catch (error) {
      if (!quiet) toast(error?.message || "Could not remove the reminder.");
    }
  }

  async function loadReminders({ render = false, processDue = false } = {}) {
    if (!runtime.signedIn || !app()?.api) return [];
    try {
      const data = await app().api("message_reminders", {
        showLoader: false,
        timeoutMs: 7000,
      });
      const items = Array.isArray(data?.reminders) ? data.reminders : [];
      runtime.reminderIds = new Set(items.map((item) => Number(item.message_id || 0)).filter(Boolean));
      runtime.nextReminderAt = items.reduce((earliest, item) => {
        const at = Number(item?.remind_at || 0);
        if (!at) return earliest;
        return earliest === 0 ? at : Math.min(earliest, at);
      }, 0);
      updateReminderButtons();
      if (processDue) await processDueReminders(items, Number(data?.server_time || 0));
      if (render) await renderReminders(items);
      return items;
    } catch (error) {
      if (render) {
        const list = $("#v50ReminderList");
        if (list) list.textContent = error?.message || "Could not load reminders.";
      }
      return [];
    }
  }

  async function renderReminders(items) {
    ensureReminderModal();
    const list = $("#v50ReminderList");
    if (!list) return;
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "v50-reminder-empty";
      empty.textContent = "No upcoming message reminders.";
      list.appendChild(empty);
      return;
    }

    for (const item of items) {
      const row = document.createElement("article");
      row.className = "v50-reminder-row";

      const head = document.createElement("div");
      head.className = "v50-reminder-row-head";
      const title = document.createElement("strong");
      title.textContent = String(item.conversation_title || "Conversation");
      const when = document.createElement("time");
      when.textContent = formatDate(item.remind_at);
      head.append(title, when);

      const copy = document.createElement("p");
      copy.textContent = "Decrypting preview…";

      const actions = document.createElement("div");
      actions.className = "v50-reminder-row-actions";
      const open = document.createElement("button");
      open.type = "button";
      open.className = "secondary-btn";
      open.textContent = "Open chat";
      open.addEventListener("click", () => {
        app()?.closeModal?.();
        app()?.openConversation?.(Number(item.conversation_id || 0));
      });
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "plain-btn";
      remove.textContent = "Remove";
      remove.addEventListener("click", async () => {
        await deleteReminder(item.message_id);
        await loadReminders({ render: true });
      });
      actions.append(open, remove);
      row.append(head, copy, actions);
      list.appendChild(row);

      reminderPreview(item).then((text) => {
        copy.textContent = text.slice(0, 260);
      });
    }
  }

  async function processDueReminders(items, serverNow) {
    const now = serverNow || Math.floor(Date.now() / 1000);
    const due = items.filter((item) => Number(item.remind_at || 0) <= now);
    for (const item of due) {
      const id = Number(item.message_id || 0);
      if (!id) continue;
      const preview = await reminderPreview(item);
      toast(`Reminder · ${String(item.conversation_title || "Chat")}: ${preview.slice(0, 140)}`);

      if (
        document.visibilityState === "hidden" &&
        "Notification" in window &&
        Notification.permission === "granted"
      ) {
        try {
          const notification = new Notification("Silknex reminder", {
            body: `${String(item.conversation_title || "Chat")}: ${preview.slice(0, 180)}`,
            icon: "app-icon-black.png",
            tag: `silknex-reminder-${id}`,
          });
          notification.onclick = () => {
            window.focus();
            app()?.openConversation?.(Number(item.conversation_id || 0));
            notification.close();
          };
        } catch {}
      }

      await deleteReminder(id, true);
    }
  }

  function scheduleReminderRefresh(delay = null) {
    clearTimeout(runtime.reminderTimer);
    runtime.reminderTimer = null;
    if (!runtime.signedIn) return;

    let nextDelay = Number(delay);
    if (!Number.isFinite(nextDelay) || nextDelay < 0) {
      const now = Math.floor(Date.now() / 1000);
      const untilDue = runtime.nextReminderAt > now
        ? (runtime.nextReminderAt - now) * 1000
        : 0;
      nextDelay = untilDue > 0
        ? Math.min(300000, Math.max(15000, untilDue + 750))
        : 300000;
      if (
        document.visibilityState === "hidden" &&
        !(untilDue > 0 && untilDue <= 300000)
      ) {
        nextDelay = Math.max(nextDelay, 300000);
      }
    }

    runtime.reminderTimer = setTimeout(async () => {
      if (navigator.onLine) {
        await loadReminders({ processDue: true });
      }
      scheduleReminderRefresh();
    }, Math.max(1000, nextDelay));
  }

  function reminderButton(messageId) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "message-action icon-action v50-reminder-action";
    button.dataset.reminderMessageId = String(messageId);
    button.title = "Remind me";
    button.setAttribute("aria-label", "Remind me about this message");
    button.appendChild(icon("bell"));
    button.addEventListener("click", () => {
      if (runtime.reminderIds.has(Number(messageId))) {
        deleteReminder(messageId);
      } else {
        openReminderPicker(messageId);
      }
    });
    return button;
  }

  function decorateReminderButtons() {
    $$("#messages .message[data-message-id]").forEach((row) => {
      const id = Number(row.dataset.messageId || 0);
      const actions = $(".message-actions", row);
      if (!id || !actions || $(".v50-reminder-action", actions)) return;
      actions.appendChild(reminderButton(id));
    });
    updateReminderButtons();
  }

  function updateReminderButtons() {
    $$("[data-reminder-message-id]").forEach((button) => {
      const id = Number(button.dataset.reminderMessageId || 0);
      const active = runtime.reminderIds.has(id);
      button.classList.toggle("selected", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
      button.title = active ? "Remove reminder" : "Remind me";
      button.setAttribute(
        "aria-label",
        active ? "Remove reminder for this message" : "Remind me about this message"
      );
    });
  }

  function bindReminderObserver() {
    const box = $("#messages");
    if (!box || runtime.reminderObserver) return;
    runtime.reminderObserver = new MutationObserver(() => {
      requestAnimationFrame(decorateReminderButtons);
    });
    runtime.reminderObserver.observe(box, { childList: true, subtree: true });
    decorateReminderButtons();
  }

  function openReminders() {
    ensureReminderModal();
    app()?.openModal?.("#v50ReminderModal");
    loadReminders({ render: true, processDue: true });
  }

  /* ------------------------------------------------------------------ */
  /* Local decrypted export                                              */
  /* ------------------------------------------------------------------ */

  function safeFilename(value) {
    return String(value || "conversation")
      .normalize("NFKD")
      .replace(/[^\w.-]+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 80) || "conversation";
  }

  function exportMessageBody(message) {
    const body = String(message?.body || "").trim();
    if (body) return body;
    return messageFallback(message);
  }

  function exportCurrentChat() {
    const state = app()?.state;
    if (!state?.activeId || !(state.messages instanceof Map)) {
      toast("Open a conversation first.");
      return;
    }

    const title = String(state.activeConversation?.title || "Silknex chat");
    const messages = [...state.messages.values()]
      .filter((message) => !message?.deleted_at)
      .sort((a, b) => Number(a.id || 0) - Number(b.id || 0));

    if (!messages.length) {
      toast("There are no loaded messages to export.");
      return;
    }

    const meId = Number(state.me?.id || 0);
    const lines = [
      `Silknex conversation export`,
      `Conversation: ${title}`,
      `Exported: ${new Date().toLocaleString()}`,
      `Scope: messages currently loaded on this device`,
      "",
    ];

    for (const message of messages) {
      const when = Number(message.created_at || 0)
        ? new Date(Number(message.created_at) * 1000).toLocaleString()
        : "";
      const sender = Number(message.sender_id || 0) === meId
        ? String(state.me?.display_name || state.me?.username || "You")
        : String(message.sender_display_name || message.sender_name || "Participant");
      lines.push(`[${when}] ${sender}: ${exportMessageBody(message)}`);
    }

    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${safeFilename(title)}-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("Loaded chat exported.");
  }

  function activeConversationListItem() {
    const id = Number(app()?.state?.activeId || 0);
    return (app()?.state?.conversations || []).find((item) => Number(item.id) === id) || null;
  }

  function updateChatOrganizationButtons() {
    const item = activeConversationListItem();
    const pin = $("#v50PinChatBtn");
    const favorite = $("#v50FavoriteChatBtn");
    const archive = $("#v50ArchiveChatBtn");

    if (!item) {
      for (const button of [pin, favorite, archive]) {
        if (button) button.disabled = true;
      }
      return;
    }

    if (pin) {
      pin.disabled = false;
      pin.textContent = item.pinned ? "Unpin chat" : "Pin chat";
      pin.classList.toggle("active", Boolean(item.pinned));
    }
    if (favorite) {
      favorite.disabled = false;
      favorite.textContent = item.favorite ? "Unfavorite" : "Favorite";
      favorite.classList.toggle("active", Boolean(item.favorite));
    }
    if (archive) {
      archive.disabled = false;
      archive.textContent = item.archived ? "Unarchive" : "Archive";
      archive.classList.toggle("active", Boolean(item.archived));
    }
  }

  async function setActiveConversationListState(changes) {
    const item = activeConversationListItem();
    if (!item || !app()?.api) return;

    const next = {
      favorite: changes.favorite ?? Boolean(item.favorite),
      archived: changes.archived ?? Boolean(item.archived),
    };

    try {
      await app().api("conversation_list_state", {
        method: "POST",
        body: {
          conversation_id: Number(item.id),
          favorite: Boolean(next.favorite),
          archived: Boolean(next.archived),
        },
        showLoader: false,
      });
      item.favorite = Boolean(next.favorite);
      item.archived = Boolean(next.archived);
      if (item.archived) {
        item.pinned = false;
        item.pinned_at = null;
      }
      await app()?.loadConversations?.();
      updateChatOrganizationButtons();
      toast(item.archived
        ? "Chat archived."
        : changes.favorite !== undefined
          ? (item.favorite ? "Added to favorites." : "Removed from favorites.")
          : "Chat restored.");
    } catch (error) {
      toast(error?.message || "Could not update the chat.");
    }
  }

  async function toggleActivePin() {
    const item = activeConversationListItem();
    if (!item || !app()?.api) return;

    try {
      await app().api("pin_conversation", {
        method: "POST",
        body: {
          conversation_id: Number(item.id),
          pinned: !Boolean(item.pinned),
        },
        showLoader: false,
      });
      item.pinned = !Boolean(item.pinned);
      await app()?.loadConversations?.();
      updateChatOrganizationButtons();
      toast(item.pinned ? "Chat pinned." : "Chat unpinned.");
    } catch (error) {
      toast(error?.message || "Could not update the pin.");
    }
  }

  function ensureGeneralTools() {
    const modal = $("#chatSettingsModal .modal-card");
    if (modal && !$("#v50ChatTools")) {
      const section = document.createElement("section");
      section.id = "v50ChatTools";
      section.className = "settings-section v50-chat-tools";
      section.innerHTML = `
        <div class="section-title"><span>More tools</span></div>
        <div class="v50-tool-grid">
          <button id="v50ExportChatBtn" class="secondary-btn" type="button">Export loaded chat</button>
          <button id="v50OpenRemindersBtn" class="secondary-btn" type="button">Message reminders</button>
        </div>
        <div class="section-title v50-organize-title"><span>Organize chat</span></div>
        <div class="v50-tool-grid v50-organize-grid">
          <button id="v50PinChatBtn" class="secondary-btn" type="button">Pin chat</button>
          <button id="v50FavoriteChatBtn" class="secondary-btn" type="button">Favorite</button>
          <button id="v50ArchiveChatBtn" class="secondary-btn" type="button">Archive</button>
        </div>
      `;
      const utility = $("#v49ChatUtilities", modal);
      if (utility) utility.insertAdjacentElement("afterend", section);
      else $(".modal-head", modal)?.insertAdjacentElement("afterend", section);
      $("#v50ExportChatBtn", section)?.addEventListener("click", exportCurrentChat);
      $("#v50OpenRemindersBtn", section)?.addEventListener("click", openReminders);
      $("#v50PinChatBtn", section)?.addEventListener("click", toggleActivePin);
      $("#v50FavoriteChatBtn", section)?.addEventListener("click", () => {
        const item = activeConversationListItem();
        if (item) setActiveConversationListState({ favorite: !Boolean(item.favorite) });
      });
      $("#v50ArchiveChatBtn", section)?.addEventListener("click", () => {
        const item = activeConversationListItem();
        if (item) setActiveConversationListState({ archived: !Boolean(item.archived) });
      });
      updateChatOrganizationButtons();
    }

    const settings = $("#settingsModal .settings-card");
    if (settings && !$("#v50ProductivitySettings")) {
      const section = document.createElement("section");
      section.id = "v50ProductivitySettings";
      section.className = "settings-section v50-productivity-settings";
      section.innerHTML = `
        <div class="section-title"><span>Productivity</span></div>
        <div class="v50-setting-actions">
          <button id="v50CommandSettingsBtn" class="secondary-btn" type="button">Open command palette</button>
          <button id="v50ReminderSettingsBtn" class="secondary-btn" type="button">Message reminders</button>
          <button id="v50FocusSettingsBtn" class="secondary-btn" type="button">Toggle Focus mode</button>
        </div>
        <small class="v50-setting-note">Tip: press Ctrl+K or ⌘K anywhere in Silknex to jump to a chat or feature.</small>
      `;
      const monetization = $("#monetizationSettings");
      if (monetization) monetization.insertAdjacentElement("beforebegin", section);
      else settings.appendChild(section);
      $("#v50CommandSettingsBtn", section)?.addEventListener("click", () => {
        $("#quickSwitcherHomeBtn")?.click();
      });
      $("#v50ReminderSettingsBtn", section)?.addEventListener("click", openReminders);
      $("#v50FocusSettingsBtn", section)?.addEventListener("click", () => {
        $("#focusModeHomeBtn")?.click();
      });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Founder v50 operations                                              */
  /* ------------------------------------------------------------------ */

  function founderMetric(label, value, sub = "") {
    const card = document.createElement("div");
    card.className = "v50-founder-metric";
    const small = document.createElement("small");
    small.textContent = label;
    const strong = document.createElement("strong");
    strong.textContent = String(value ?? "—");
    card.append(small, strong);
    if (sub) {
      const note = document.createElement("span");
      note.textContent = sub;
      card.appendChild(note);
    }
    return card;
  }

  function ensureFounderExtras() {
    if (!isFounder()) return;
    const modal = $("#v49OwnerModal .v49-owner-card");
    if (!modal || $("#v50FounderExtras", modal)) return;

    const section = document.createElement("section");
    section.id = "v50FounderExtras";
    section.className = "v50-founder-extras";
    section.innerHTML = `
      <section class="v49-owner-block">
        <div class="section-title"><span>Traffic & health</span></div>
        <div id="v50FounderMetrics" class="v50-founder-metrics" aria-live="polite"></div>
      </section>

      <section class="v49-owner-block">
        <div class="section-title"><span>Ad serving</span></div>
        <div class="v50-founder-control-row">
          <div>
            <b id="v50AdsPauseTitle">Loading…</b>
            <small id="v50AdsPauseCopy">Pause Silknex-served campaign inventory globally without deleting campaigns.</small>
          </div>
          <button id="v50AdsPauseBtn" class="secondary-btn" type="button">Loading…</button>
        </div>
      </section>

      <section class="v49-owner-block">
        <div class="section-title"><span>User operations</span></div>
        <form id="v50FounderLookupForm" class="v50-founder-user-form">
          <label class="field">
            <span>Username</span>
            <input id="v50FounderUsername" maxlength="24" autocomplete="off" placeholder="username">
          </label>
          <button class="secondary-btn" type="submit">Look up</button>
        </form>
        <div id="v50FounderUserResult" class="v50-founder-user-result hidden"></div>
        <div class="v50-founder-grant">
          <label class="field">
            <span>Complimentary ad-free hours</span>
            <input id="v50FounderGrantHours" type="number" min="1" max="720" value="24">
          </label>
          <button id="v50FounderGrantBtn" class="secondary-btn" type="button">Grant ad-free</button>
        </div>
      </section>

      <section class="v49-owner-block">
        <div class="v50-founder-audit-head">
          <div class="section-title"><span>Founder audit log</span></div>
          <button id="v50AuditRefreshBtn" class="plain-btn" type="button">Refresh</button>
        </div>
        <div id="v50FounderAudit" class="v50-founder-audit" aria-live="polite"></div>
      </section>
    `;
    modal.appendChild(section);

    $("#v50AdsPauseBtn", section)?.addEventListener("click", toggleGlobalAds);
    $("#v50FounderLookupForm", section)?.addEventListener("submit", lookupFounderUser);
    $("#v50FounderGrantBtn", section)?.addEventListener("click", grantFounderAdFree);
    $("#v50AuditRefreshBtn", section)?.addEventListener("click", loadFounderAudit);
    installFounderRequests(section);
  }

  function installFounderRequests(parent) {
    const section = document.createElement("section");
    section.className = "v49-owner-block founder-requests";
    section.innerHTML = `<h3>Feature request inbox</h3><div class="founder-request-toolbar"><label>Status <select aria-label="Feature request status"><option value="submitted">Submitted</option><option value="reviewing">Reviewing</option><option value="planned">Planned</option><option value="closed">Closed</option></select></label><button type="button" class="secondary-btn">Refresh requests</button></div><div class="founder-request-list" aria-live="polite"></div><button type="button" class="secondary-btn" hidden>Next page</button>`;
    parent.append(section);
    const filter = section.querySelector("select"), list = section.querySelector(".founder-request-list");
    const [refresh, next] = section.querySelectorAll("button");
    let cursor = 0, sequence = 0;
    const load = async (before = 0) => {
      if (!isFounder()) return;
      const request = ++sequence, session = app().state.me;
      const current = () => request === sequence && app().state.me === session && isFounder();
      refresh.disabled = next.disabled = true;
      list.setAttribute("aria-busy", "true");
      try {
        const data = await app().api("owner_feature_requests", {showLoader:false}, {status:filter.value,before});
        if (!current()) return;
        list.replaceChildren();
        for (const item of data.requests || []) {
          const row = document.createElement("article");
          const title = document.createElement("strong"); title.textContent = item.title;
          const by = document.createElement("small"); by.textContent = `@${item.username}`;
          const details = document.createElement("p"); details.textContent = item.details;
          const status = filter.cloneNode(true); status.value = item.status; status.setAttribute("aria-label", "Status for " + item.title);
          const save = document.createElement("button"); save.type = "button"; save.className = "secondary-btn"; save.textContent = "Save status";
          save.addEventListener("click", async () => {
            if (!current() || save.disabled) return;
            save.disabled = true;
            try {
              await app().api("owner_feature_request_set", {method:"POST",body:{id:item.id,status:status.value},showLoader:false});
              if (!current()) return;
              toast("Request status saved."); loadFounderAudit(); await load(before);
            } catch (error) { if (current()) toast(error.message || "Could not update request."); }
            finally { save.disabled = false; }
          });
          row.append(title, by, details, status, save); list.append(row);
        }
        if (!list.children.length) list.textContent = "No requests in this status.";
        cursor = Number(data.next_before || 0); next.hidden = !cursor;
      } catch (error) { if (current()) list.textContent = error.message || "Could not load requests."; }
      finally { if (current()) {refresh.disabled = next.disabled = false;list.removeAttribute("aria-busy");} }
    };
    refresh.addEventListener("click", () => load());
    filter.addEventListener("change", () => load());
    next.addEventListener("click", () => load(cursor));
    // Fetch only when requested, so opening Settings does not load extra data.
    list.textContent = "Refresh to review requests from your community.";
  }

  function renderFounderDashboard(dashboard) {
    const metrics = $("#v50FounderMetrics");
    if (metrics) {
      metrics.replaceChildren(
        founderMetric("Online", formatInteger(dashboard.online_now), "foreground presence"),
        founderMetric("New users", formatInteger(dashboard.new_users_24h), "24 hours"),
        founderMetric("Messages", formatInteger(dashboard.messages_1h), "last hour"),
        founderMetric("Messages", formatInteger(dashboard.messages_24h), "24 hours"),
        founderMetric("Messages", formatInteger(dashboard.messages_7d), "7 days"),
        founderMetric("Active calls", formatInteger(dashboard.active_calls)),
        founderMetric("Paid ads", money(dashboard.paid_ad_revenue_cents), "collected"),
        founderMetric("Campaigns", formatInteger(dashboard.active_ad_campaigns), "active")
      );
    }

    const paused = Boolean(dashboard.feature_flags?.ads_paused);
    const title = $("#v50AdsPauseTitle");
    const copy = $("#v50AdsPauseCopy");
    const button = $("#v50AdsPauseBtn");
    if (title) title.textContent = paused ? "Campaign ads are paused" : "Campaign ads are serving";
    if (copy) {
      copy.textContent = paused
        ? "Paid campaigns remain scheduled, but Silknex is not serving campaign inventory."
        : "Campaign inventory can appear on eligible home/desktop ad surfaces.";
    }
    if (button) {
      button.textContent = paused ? "Resume ads" : "Pause ads";
      button.dataset.paused = paused ? "true" : "false";
    }
  }

  async function refreshFounderExtras() {
    if (!isFounder() || !app()?.api || !$("#v49OwnerModal")) return;
    ensureFounderExtras();
    try {
      const data = await app().api("owner_dashboard", {
        showLoader: false,
        timeoutMs: 8000,
      });
      renderFounderDashboard(data?.dashboard || {});
    } catch {}
    loadFounderAudit();
  }

  async function toggleGlobalAds() {
    if (!isFounder()) return;
    const button = $("#v50AdsPauseBtn");
    const paused = button?.dataset.paused === "true";
    if (button) button.disabled = true;
    try {
      const data = await app().api("owner_ads_pause_set", {
        method: "POST",
        body: { paused: !paused },
        showLoader: false,
      });
      toast(!paused ? "Global campaign ads paused." : "Global campaign ads resumed.");
      await refreshFounderExtras();
    } catch (error) {
      toast(error?.message || "Could not update ad serving.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function renderFounderUser(user) {
    const box = $("#v50FounderUserResult");
    if (!box) return;
    box.classList.remove("hidden");
    box.replaceChildren();

    const heading = document.createElement("div");
    heading.className = "v50-founder-user-heading";
    const strong = document.createElement("strong");
    strong.textContent = String(user.display_name || user.username || "User");
    const handle = document.createElement("span");
    handle.textContent = `@${String(user.username || "")}`;
    heading.append(strong, handle);

    const grid = document.createElement("div");
    grid.className = "v50-founder-user-grid";
    const fields = [
      ["Role", user.account_role || "member"],
      ["Last seen", formatDate(user.last_seen_at)],
      ["Joined", formatDate(user.created_at)],
      ["Friends", formatInteger(user.friends)],
      ["Chats", formatInteger(user.conversations)],
      ["Messages / 24h", formatInteger(user.messages_24h)],
      ["Ad-free until", Number(user.ad_pass_until || 0) > Math.floor(Date.now() / 1000)
        ? formatDate(user.ad_pass_until)
        : "No active pass"],
      ["Subscription", user.subscription_status || "inactive"],
    ];
    for (const [label, value] of fields) {
      grid.appendChild(founderMetric(label, value));
    }
    grid.prepend(founderMetric("Account", user.disabled ? "Suspended" : "Active"));
    box.append(heading, grid);
    if (!["founder_ceo", "cofounder_ceo"].includes(user.account_role)) {
      const controls = document.createElement("form");
      controls.className = "founder-account-controls";
      const label = document.createElement("label");
      label.textContent = "Reason for account status change";
      const reason = document.createElement("input");
      reason.type = "text"; reason.maxLength = 200; reason.minLength = 4; reason.required = true;
      label.append(reason);
      const button = document.createElement("button");
      button.type = "submit"; button.className = user.disabled ? "secondary-btn" : "danger-btn";
      button.textContent = user.disabled ? "Restore account" : "Suspend account";
      controls.append(label, button);
      controls.addEventListener("submit", async event => {
        event.preventDefault();
        if (!isFounder() || button.disabled) return;
        const session = app().state.me;
        button.disabled = true;
        try {
          const result = await app().api("owner_account_status_set", {method:"POST", body:{username:user.username, disabled:!user.disabled, reason:reason.value}});
          if (app().state.me !== session || !isFounder()) return;
          if (box.dataset.username === user.username) renderFounderUser({...user, disabled:result.disabled});
          toast(result.disabled ? "Account suspended and sessions revoked." : "Account restored. The user can sign in again.");
          loadFounderAudit();
        } catch (error) { if (app().state.me === session) toast(error.message || "Could not change account status."); }
        finally { button.disabled = false; }
      });
      box.append(controls);
    }
    box.dataset.username = String(user.username || "");
  }

  let founderLookupSequence = 0;
  async function lookupFounderUser(event) {
    event.preventDefault();
    if (!isFounder()) return;
    const request = ++founderLookupSequence;
    const session = app().state.me;
    const input = $("#v50FounderUsername");
    const username = String(input?.value || "").trim();
    if (!username) {
      toast("Enter a username.");
      return;
    }
    try {
      const data = await app().api(
        "owner_user_lookup",
        { showLoader: false, timeoutMs: 7000 },
        { username }
      );
      if (request !== founderLookupSequence || session !== app().state.me || !isFounder()) return;
      renderFounderUser(data?.user || {});
    } catch (error) {
      if (request !== founderLookupSequence || session !== app().state.me || !isFounder()) return;
      $("#v50FounderUserResult")?.classList.add("hidden");
      toast(error?.message || "Could not find that user.");
    }
  }

  async function grantFounderAdFree() {
    if (!isFounder()) return;
    const username = String(
      $("#v50FounderUserResult")?.dataset.username ||
      $("#v50FounderUsername")?.value ||
      ""
    ).trim();
    const hours = Math.min(720, Math.max(1, Number($("#v50FounderGrantHours")?.value || 24)));
    if (!username) {
      toast("Look up a user first.");
      return;
    }
    const button = $("#v50FounderGrantBtn");
    if (button) button.disabled = true;
    try {
      const data = await app().api("owner_ad_free_grant", {
        method: "POST",
        body: { username, hours },
        showLoader: false,
      });
      toast(`Ad-free access granted to @${String(data?.username || username)}.`);
      $("#v50FounderUsername").value = username;
      await lookupFounderUser({ preventDefault() {} });
      await loadFounderAudit();
    } catch (error) {
      toast(error?.message || "Could not grant ad-free access.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function auditLabel(action) {
    const labels = {
      "announcement.publish": "Published announcement",
      "announcement.clear": "Cleared announcement",
      "account.suspend": "Suspended account",
      "account.restore": "Restored account",
      "feature.status": "Updated feature request",
      "registration.open": "Opened registration",
      "registration.pause": "Paused registration",
      "security.revoke_sessions": "Revoked sessions",
      "ads.pause": "Paused campaign ads",
      "ads.resume": "Resumed campaign ads",
      "ads.grant_pass": "Granted ad-free access",
      "ads.sales_pause": "Paused new ad campaign sales",
      "ads.sales_resume": "Resumed new ad campaign sales",
      "security.protection_enable": "Enabled traffic protection",
      "security.protection_disable": "Disabled traffic protection",
    };
    return labels[action] || String(action || "Founder action").replace(/[._:-]+/g, " ");
  }

  async function loadFounderAudit() {
    if (!isFounder() || !app()?.api) return;
    const list = $("#v50FounderAudit");
    if (!list) return;
    try {
      const data = await app().api("owner_audit", {
        showLoader: false,
        timeoutMs: 7000,
      });
      const items = Array.isArray(data?.audit) ? data.audit : [];
      list.replaceChildren();
      if (!items.length) {
        const empty = document.createElement("small");
        empty.textContent = "No Founder actions have been recorded yet.";
        list.appendChild(empty);
        return;
      }
      for (const item of items.slice(0, 40)) {
        const row = document.createElement("div");
        row.className = "v50-audit-row";
        const copy = document.createElement("div");
        const strong = document.createElement("strong");
        strong.textContent = auditLabel(item.action);
        const target = document.createElement("small");
        target.textContent = item.target ? String(item.target) : "Silknex";
        copy.append(strong, target);
        if (item.details?.reason || item.details?.status) {
          const detail = document.createElement("small");
          detail.textContent = String(item.details.reason || item.details.status).slice(0, 200);
          copy.append(detail);
        }
        const time = document.createElement("time");
        time.textContent = formatDate(item.created_at);
        row.append(copy, time);
        list.appendChild(row);
      }
    } catch (error) {
      list.textContent = error?.message || "Could not load the audit log.";
    }
  }

  function scheduleFounderRefresh() {
    clearTimeout(runtime.ownerRefreshTimer);
    runtime.ownerRefreshTimer = null;
    if (!runtime.founder) return;
    runtime.ownerRefreshTimer = setTimeout(async () => {
      if (
        document.visibilityState === "visible" &&
        !$("#v49OwnerModal")?.classList.contains("hidden")
      ) {
        await refreshFounderExtras();
      }
      scheduleFounderRefresh();
    }, 60000);
  }

  /* ------------------------------------------------------------------ */
  /* Wiring                                                              */
  /* ------------------------------------------------------------------ */

  function setSignedIn(value) {
    runtime.signedIn = Boolean(value);
    runtime.founder = runtime.signedIn && isFounder();

    if (runtime.signedIn) {
      ensureGeneralTools();
      ensureReminderModal();
      ensureReminderPicker();
      bindReminderObserver();
      scheduleReminderRefresh(1500);
      if (runtime.founder) {
        setTimeout(() => {
          ensureFounderExtras();
          scheduleFounderRefresh();
        }, 50);
      }
    } else {
      clearTimeout(runtime.reminderTimer);
      runtime.reminderTimer = null;
      clearTimeout(runtime.ownerRefreshTimer);
      runtime.ownerRefreshTimer = null;
      runtime.reminderIds.clear();
    }
  }

  function boot() {
    ensureConnectivityChip();
    updateConnectivity();
    ensureReminderModal();
    ensureReminderPicker();
    ensureGeneralTools();
    bindReminderObserver();

    setSignedIn(Boolean(app()?.state?.me));

    window.addEventListener("online", updateConnectivity);
    window.addEventListener("offline", updateConnectivity);

    window.addEventListener("silknex:session", (event) => {
      setTimeout(() => setSignedIn(Boolean(event.detail?.signedIn)), 0);
    });

    window.addEventListener("silknex:conversation", () => {
      setTimeout(() => {
        decorateReminderButtons();
        updateChatOrganizationButtons();
      }, 0);
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible" && runtime.signedIn) {
        scheduleReminderRefresh(800);
      }
    });

    // v49 creates its Founder modal lazily when authenticated. Observe only
    // direct body additions so this does not become a hot full-document observer.
    const bodyObserver = new MutationObserver((records) => {
      if (!runtime.founder) return;
      for (const record of records) {
        if ([...record.addedNodes].some((node) =>
          node instanceof Element &&
          (node.id === "v49OwnerModal" || node.querySelector?.("#v49OwnerModal"))
        )) {
          ensureFounderExtras();
          break;
        }
      }
    });
    bodyObserver.observe(document.body, { childList: true });
  }

  function start() {
    if (window.SilknexApp) boot();
    else window.addEventListener("silknex:core-ready", boot, { once: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }

  window.SilknexV50 = Object.freeze({
    openReminders,
    exportCurrentChat,
    refreshFounderExtras,
  });
})();

} catch (error) { console.error("Silknex feature module 50:", error); }

;
/* Feature module 51 */
try {
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const runtime = {
    signedIn: false,
    founder: false,
    conversationObserver: null,
    ownerObserver: null,
    ownerRefreshTimer: null,
    ownerDashboard: null,
    ownerTimeseries: [],
    starredIds: new Set(),
    starConversationId: 0,
    messageObserver: null,
  };

  function toast(message) {
    app()?.toast?.(String(message || ""));
  }

  function isFounder() {
    return Boolean(
      runtime.signedIn &&
      ["founder_ceo", "cofounder_ceo"].includes(app()?.state?.me?.role)
    );
  }

  function activeConversationItem() {
    const id = Number(app()?.state?.activeId || 0);
    return app()?.state?.conversations?.find?.(
      (item) => Number(item.id) === id
    ) || null;
  }

  function formatTime(epochSeconds) {
    const value = Number(epochSeconds || 0);
    if (!value) return "—";

    try {
      return new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      }).format(new Date(value * 1000));
    } catch {
      return new Date(value * 1000).toLocaleString();
    }
  }

  function formatNumber(value) {
    const number = Number(value || 0);
    try {
      return new Intl.NumberFormat().format(Number.isFinite(number) ? number : 0);
    } catch {
      return String(Number.isFinite(number) ? number : 0);
    }
  }

  function downloadBlob(filename, type, body) {
    const blob = new Blob([body], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.rel = "noopener";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  /* ------------------------------------------------------------------ */
  /* Per-conversation notification mute                                 */
  /* ------------------------------------------------------------------ */

  function ensureMuteModal() {
    if ($("#v51MuteModal")) return;

    const modal = document.createElement("section");
    modal.id = "v51MuteModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v51MuteTitle");
    modal.innerHTML = `
      <div class="modal-card v51-mute-card">
        <header class="modal-head">
          <div>
            <small>NOTIFICATIONS</small>
            <h2 id="v51MuteTitle">Mute this chat</h2>
          </div>
          <button id="v51MuteClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <p id="v51MuteCopy" class="v51-muted-copy">
          Message notifications will be silenced. Incoming call alerts still work.
        </p>
        <div class="v51-mute-grid">
          <button type="button" data-v51-mute="3600">1 hour</button>
          <button type="button" data-v51-mute="28800">8 hours</button>
          <button type="button" data-v51-mute="86400">1 day</button>
          <button type="button" data-v51-mute="604800">1 week</button>
          <button type="button" data-v51-mute="2592000">30 days</button>
          <button type="button" data-v51-mute="-1">Until I turn it off</button>
        </div>
        <button id="v51UnmuteBtn" class="secondary-btn v51-unmute-btn hidden" type="button">
          Turn notifications back on
        </button>
      </div>
    `;
    document.body.appendChild(modal);

    $("#v51MuteClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
    $$("#v51MuteModal [data-v51-mute]").forEach((button) => {
      button.addEventListener("click", () => {
        setConversationMute(
          Number(app()?.state?.activeId || 0),
          Number(button.dataset.v51Mute || 0)
        );
      });
    });
    $("#v51UnmuteBtn", modal)?.addEventListener("click", () => {
      setConversationMute(Number(app()?.state?.activeId || 0), 0);
    });
  }

  function updateMuteUi() {
    const item = activeConversationItem();
    const mutedUntil = Number(item?.muted_until || 0);
    const muted = Boolean(item?.muted && mutedUntil > Math.floor(Date.now() / 1000));

    const button = $("#v51MuteChatBtn");
    if (button) {
      button.textContent = muted ? "Unmute notifications" : "Mute notifications";
      button.classList.toggle("active", muted);
      button.setAttribute("aria-pressed", muted ? "true" : "false");
    }

    const unmute = $("#v51UnmuteBtn");
    unmute?.classList.toggle("hidden", !muted);

    const copy = $("#v51MuteCopy");
    if (copy) {
      copy.textContent = muted
        ? `Muted until ${formatTime(mutedUntil)}. Incoming call alerts still work.`
        : "Message notifications will be silenced. Incoming call alerts still work.";
    }
  }

  function openMuteModal() {
    const item = activeConversationItem();
    if (!item) {
      toast("Open a chat first.");
      return;
    }
    ensureMuteModal();
    updateMuteUi();
    app()?.openModal?.("#v51MuteModal");
  }

  async function setConversationMute(conversationId, durationSeconds) {
    const id = Number(conversationId || 0);
    if (!id || !app()?.api) return;

    const allowed = new Set([0, 3600, 28800, 86400, 604800, 2592000, -1]);
    if (!allowed.has(Number(durationSeconds))) return;

    try {
      const data = await app().api("conversation_mute", {
        method: "POST",
        body: {
          conversation_id: id,
          duration_seconds: Number(durationSeconds),
        },
        showLoader: false,
      });

      const item = app()?.state?.conversations?.find?.(
        (conversation) => Number(conversation.id) === id
      );
      if (item) {
        item.muted = Boolean(data?.muted);
        item.muted_until = data?.muted_until ? Number(data.muted_until) : null;
      }

      app()?.closeModal?.();
      await app()?.loadConversations?.();
      decorateMutedConversations();
      updateMuteUi();
      toast(data?.muted ? "Message notifications muted." : "Notifications turned back on.");
    } catch (error) {
      toast(error?.message || "Could not change notification settings.");
    }
  }

  function decorateMutedConversations() {
    const now = Math.floor(Date.now() / 1000);
    const conversations = new Map(
      (app()?.state?.conversations || []).map(
        (item) => [Number(item.id), item]
      )
    );

    $$("#conversationList [data-conversation-id]").forEach((button) => {
      const id = Number(button.dataset.conversationId || 0);
      const item = conversations.get(id);
      const muted = Boolean(
        item?.muted &&
        Number(item?.muted_until || 0) > now
      );

      button.closest(".conversation-wrap")?.classList.toggle("v51-muted", muted);
      button.classList.toggle("v51-muted", muted);

      const name = $(".conversation-name", button);
      if (!name) return;

      let mark = $(".v51-mute-mark", name);
      if (!muted) {
        mark?.remove();
        return;
      }

      if (!mark) {
        mark = document.createElement("span");
        mark.className = "v51-mute-mark";
        mark.textContent = "Muted";
        mark.title = "Message notifications muted";
        name.appendChild(mark);
      }
    });
  }

  function bindConversationObserver() {
    const list = $("#conversationList");
    if (!list || runtime.conversationObserver) return;

    runtime.conversationObserver = new MutationObserver(() => {
      requestAnimationFrame(decorateMutedConversations);
    });
    runtime.conversationObserver.observe(list, { childList: true, subtree: true });
    decorateMutedConversations();
  }

  /* ------------------------------------------------------------------ */
  /* Quick replies                                                      */
  /* ------------------------------------------------------------------ */

  function quickReplyStorageKey() {
    const userId = Number(app()?.state?.me?.id || 0);
    return userId ? `silknex:v51:quick-replies:${userId}` : "";
  }

  function loadQuickReplies() {
    const key = quickReplyStorageKey();
    if (!key) return [];

    try {
      const parsed = JSON.parse(window.SilknexStorage.getItem(key) || "[]");
      if (!Array.isArray(parsed)) return [];
      return parsed
        .map((item) => String(item || "").trim().slice(0, 300))
        .filter(Boolean)
        .slice(0, 12);
    } catch {
      return [];
    }
  }

  function saveQuickReplies(items) {
    const key = quickReplyStorageKey();
    if (!key) return;

    const clean = [...new Set(
      items
        .map((item) => String(item || "").trim().slice(0, 300))
        .filter(Boolean)
    )].slice(0, 12);

    try {
      window.SilknexStorage.setItem(key, JSON.stringify(clean));
    } catch {
      toast("Quick replies could not be saved on this device.");
    }
  }

  function ensureQuickReplyModal() {
    if ($("#v51QuickReplyModal")) return;

    const modal = document.createElement("section");
    modal.id = "v51QuickReplyModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v51QuickReplyTitle");
    modal.innerHTML = `
      <div class="modal-card v51-quick-card">
        <header class="modal-head">
          <div>
            <small>COMPOSER</small>
            <h2 id="v51QuickReplyTitle">Quick replies</h2>
          </div>
          <button id="v51QuickReplyClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <p class="v51-muted-copy">
          Save up to 12 reusable replies on this device. They are never sent until you press Send.
        </p>
        <form id="v51QuickReplyForm" class="v51-quick-form">
          <label class="field">
            <span>New quick reply</span>
            <textarea id="v51QuickReplyInput" rows="2" maxlength="300" placeholder="Type a reusable reply"></textarea>
          </label>
          <button class="primary" type="submit">Add</button>
        </form>
        <div id="v51QuickReplyList" class="v51-quick-list" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(modal);

    $("#v51QuickReplyClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
    $("#v51QuickReplyForm", modal)?.addEventListener("submit", (event) => {
      event.preventDefault();
      const input = $("#v51QuickReplyInput", modal);
      const value = String(input?.value || "").trim();
      if (!value) return;

      const items = loadQuickReplies();
      if (items.length >= 12) {
        toast("Quick replies are full. Remove one before adding another.");
        return;
      }

      items.unshift(value);
      saveQuickReplies(items);
      if (input) input.value = "";
      renderQuickReplies();
    });
  }

  function insertQuickReply(text) {
    const input = $("#messageInput");
    if (!input || !app()?.state?.activeId) {
      toast("Open a chat before using a quick reply.");
      return;
    }

    const value = String(text || "").trim();
    if (!value) return;

    const start = Number.isFinite(input.selectionStart)
      ? input.selectionStart
      : input.value.length;
    const end = Number.isFinite(input.selectionEnd)
      ? input.selectionEnd
      : start;
    const prefix = start > 0 && !/\s$/.test(input.value.slice(0, start)) ? " " : "";
    const suffix = end < input.value.length && !/^\s/.test(input.value.slice(end)) ? " " : "";

    input.setRangeText(`${prefix}${value}${suffix}`, start, end, "end");
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.focus({ preventScroll: true });
    app()?.closeModal?.();
  }

  function renderQuickReplies() {
    const list = $("#v51QuickReplyList");
    if (!list) return;

    const items = loadQuickReplies();
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "v51-quick-empty";
      empty.textContent = "No quick replies yet.";
      list.appendChild(empty);
      return;
    }

    items.forEach((text, index) => {
      const row = document.createElement("div");
      row.className = "v51-quick-row";

      const copy = document.createElement("p");
      copy.textContent = text;

      const actions = document.createElement("div");
      actions.className = "v51-quick-actions";

      const use = document.createElement("button");
      use.type = "button";
      use.className = "primary compact";
      use.textContent = "Use";
      use.addEventListener("click", () => insertQuickReply(text));

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "secondary-btn compact";
      remove.textContent = "Delete";
      remove.addEventListener("click", () => {
        const next = loadQuickReplies();
        next.splice(index, 1);
        saveQuickReplies(next);
        renderQuickReplies();
      });

      actions.append(use, remove);
      row.append(copy, actions);
      list.appendChild(row);
    });
  }

  function openQuickReplies() {
    ensureQuickReplyModal();
    renderQuickReplies();
    app()?.openModal?.("#v51QuickReplyModal");
  }

  /* ------------------------------------------------------------------ */
  /* Personal starred messages                                         */
  /* ------------------------------------------------------------------ */

  function messageFallback(item) {
    return {
      image: "Photo",
      gif: "GIF",
      video: "Video",
      audio: "Voice message",
      video_note: "Video message",
      sticker: "Sticker",
    }[String(item?.message_type || "text")] || "Message";
  }

  async function starredPreview(item) {
    const loaded = app()?.state?.messages?.get?.(Number(item?.message_id || 0));
    if (loaded && String(loaded.body || "").trim()) {
      return String(loaded.body).trim();
    }

    const serverPreview = String(item?.preview || "").trim();
    if (serverPreview) return serverPreview;
    if (!item?.e2ee_payload) return messageFallback(item);

    try {
      const decrypted = await window.SilknexE2EE?.decryptMessage?.({
        id: Number(item.message_id || 0),
        conversation_id: Number(item.conversation_id || 0),
        sender_id: Number(item.sender_id || 0),
        e2ee_payload: String(item.e2ee_payload || ""),
        message_type: String(item.message_type || "text"),
        body: "",
      });
      return String(decrypted?.body || "").trim() || messageFallback(item);
    } catch {
      return messageFallback(item);
    }
  }

  function ensureStarredModal() {
    if ($("#v51StarredModal")) return;

    const modal = document.createElement("section");
    modal.id = "v51StarredModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v51StarredTitle");
    modal.innerHTML = `
      <div class="modal-card v51-starred-card">
        <header class="modal-head">
          <div>
            <small>PERSONAL</small>
            <h2 id="v51StarredTitle">Starred messages</h2>
          </div>
          <button id="v51StarredClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <p class="v51-muted-copy">Stars are private to your account and sync across your Silknex devices.</p>
        <div id="v51StarredList" class="v51-starred-list" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(modal);
    $("#v51StarredClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
  }

  async function renderStarredMessages(items) {
    ensureStarredModal();
    const list = $("#v51StarredList");
    if (!list) return;
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "v51-starred-empty";
      empty.textContent = "Star a message from its message actions and it will appear here.";
      list.appendChild(empty);
      return;
    }

    for (const item of items) {
      const row = document.createElement("article");
      row.className = "v51-starred-row";

      const body = document.createElement("button");
      body.type = "button";
      body.className = "v51-starred-open";

      const meta = document.createElement("div");
      meta.className = "v51-starred-meta";
      const sender = document.createElement("strong");
      sender.textContent = String(item.sender_display_name || "Silknex user");
      const time = document.createElement("small");
      time.textContent = formatTime(item.created_at);
      meta.append(sender, time);

      const preview = document.createElement("p");
      preview.textContent = (await starredPreview(item)).slice(0, 500);
      body.append(meta, preview);

      body.addEventListener("click", async () => {
        app()?.closeModal?.();
        await app()?.openConversation?.(Number(item.conversation_id || 0));
        setTimeout(() => {
          const message = document.querySelector(
            `#messages .message[data-message-id="${Number(item.message_id || 0)}"]`
          );
          message?.scrollIntoView?.({ block: "center", behavior: "smooth" });
          message?.classList.add("v51-star-highlight");
          setTimeout(() => message?.classList.remove("v51-star-highlight"), 1600);
        }, 350);
      });

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "plain-btn v51-starred-remove";
      remove.textContent = "Unstar";
      remove.addEventListener("click", async () => {
        await toggleStar(
          Number(item.message_id || 0),
          Number(item.conversation_id || 0),
          remove
        );
        await openStarredMessages({ reopen: false });
      });

      row.append(body, remove);
      list.appendChild(row);
    }
  }

  async function refreshStars({ render = false, all = false } = {}) {
    if (!runtime.signedIn || !app()?.api) return [];

    const cid = all ? 0 : Number(app()?.state?.activeId || 0);
    if (!all && !cid) {
      runtime.starConversationId = 0;
      runtime.starredIds.clear();
      updateStarButtons();
      if (render) await renderStarredMessages([]);
      return [];
    }

    try {
      const query = cid > 0 ? { conversation_id: cid } : {};
      const data = await app().api(
        "message_stars",
        { showLoader: false, timeoutMs: 7000 },
        query
      );
      const items = Array.isArray(data?.stars) ? data.stars : [];

      if (!all && cid === Number(app()?.state?.activeId || 0)) {
        runtime.starConversationId = cid;
        runtime.starredIds = new Set(
          items.map((item) => Number(item.message_id || 0)).filter(Boolean)
        );
        updateStarButtons();
      }

      if (render) await renderStarredMessages(items);
      return items;
    } catch (error) {
      if (render) {
        ensureStarredModal();
        const list = $("#v51StarredList");
        if (list) list.textContent = error?.message || "Could not load starred messages.";
      }
      return [];
    }
  }

  async function toggleStar(messageId, conversationId, button) {
    const id = Number(messageId || 0);
    const cid = Number(conversationId || app()?.state?.activeId || 0);
    if (!id || !cid || !app()?.api || button?.disabled) return;

    if (button) button.disabled = true;
    try {
      const data = await app().api("message_star_toggle", {
        method: "POST",
        body: {
          conversation_id: cid,
          message_id: id,
        },
        showLoader: false,
      });

      if (cid === Number(app()?.state?.activeId || 0)) {
        if (data?.starred) runtime.starredIds.add(id);
        else runtime.starredIds.delete(id);
        runtime.starConversationId = cid;
        updateStarButtons();
      }
      toast(data?.starred ? "Message starred." : "Message unstarred.");
    } catch (error) {
      toast(error?.message || "Could not update the star.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function starButtonFor(messageId) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "message-action icon-action v51-star-action";
    button.dataset.starMessageId = String(messageId);
    button.title = "Star message";
    button.setAttribute("aria-label", "Star message");
    button.textContent = "☆";
    button.addEventListener("click", () => {
      toggleStar(messageId, Number(app()?.state?.activeId || 0), button);
    });
    return button;
  }

  function updateStarButtons() {
    const activeId = Number(app()?.state?.activeId || 0);
    $$("[data-star-message-id]").forEach((button) => {
      const id = Number(button.dataset.starMessageId || 0);
      const starred =
        runtime.starConversationId === activeId &&
        runtime.starredIds.has(id);
      button.classList.toggle("selected", starred);
      const glyph = starred ? "★" : "☆";
      if (button.textContent !== glyph) button.textContent = glyph;
      button.title = starred ? "Unstar message" : "Star message";
      button.setAttribute("aria-label", starred ? "Unstar message" : "Star message");
      button.setAttribute("aria-pressed", starred ? "true" : "false");
    });
  }

  function decorateStarActions() {
    $$("#messages .message[data-message-id]").forEach((row) => {
      const id = Number(row.dataset.messageId || 0);
      if (!id) return;
      const actions = $(".message-actions", row);
      if (!actions || $(".v51-star-action", actions)) return;
      actions.appendChild(starButtonFor(id));
    });
    updateStarButtons();
  }

  function bindMessageObserver() {
    const messages = $("#messages");
    if (!messages || runtime.messageObserver) return;

    let queued = false;
    runtime.messageObserver = new MutationObserver((records) => {
      const addedRows = records.some(record => [...record.addedNodes].some(node =>
        node instanceof Element && (node.matches(".message[data-message-id], .message-actions") || node.querySelector(".message[data-message-id], .message-actions"))
      ));
      if (!addedRows || queued) return;
      queued = true;
      requestAnimationFrame(() => { queued = false; decorateStarActions(); });
    });
    runtime.messageObserver.observe(messages, { childList: true, subtree: true });
    decorateStarActions();
  }

  async function openStarredMessages({ reopen = true } = {}) {
    ensureStarredModal();
    if (reopen) app()?.openModal?.("#v51StarredModal");
    const list = $("#v51StarredList");
    if (list) list.textContent = "Loading starred messages…";
    await refreshStars({ render: true, all: true });
  }

  /* ------------------------------------------------------------------ */
  /* General UI                                                         */
  /* ------------------------------------------------------------------ */

  function ensureGeneralUi() {
    ensureMuteModal();
    ensureQuickReplyModal();
    ensureStarredModal();

    const organize = $("#v50ChatTools .v50-organize-grid");
    if (organize && !$("#v51MuteChatBtn")) {
      const button = document.createElement("button");
      button.id = "v51MuteChatBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Mute notifications";
      button.addEventListener("click", () => {
        const item = activeConversationItem();
        const muted = Boolean(
          item?.muted &&
          Number(item?.muted_until || 0) > Math.floor(Date.now() / 1000)
        );
        if (muted) setConversationMute(item.id, 0);
        else openMuteModal();
      });
      organize.appendChild(button);
    }

    const tools = $("#v50ChatTools .v50-tool-grid");
    if (tools && !$("#v51QuickRepliesBtn")) {
      const button = document.createElement("button");
      button.id = "v51QuickRepliesBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Quick replies";
      button.addEventListener("click", openQuickReplies);
      tools.appendChild(button);
    }

    if (tools && !$("#v51StarredMessagesBtn")) {
      const button = document.createElement("button");
      button.id = "v51StarredMessagesBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Starred messages";
      button.addEventListener("click", () => openStarredMessages());
      tools.appendChild(button);
    }

    const productivity = $("#v50ProductivitySettings .v50-setting-actions");
    if (productivity && !$("#v51QuickRepliesSettingsBtn")) {
      const button = document.createElement("button");
      button.id = "v51QuickRepliesSettingsBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Manage quick replies";
      button.addEventListener("click", openQuickReplies);
      productivity.appendChild(button);
    }

    updateMuteUi();
    bindConversationObserver();
    bindMessageObserver();
    decorateStarActions();
  }

  /* ------------------------------------------------------------------ */
  /* Founder / CEO operations                                           */
  /* ------------------------------------------------------------------ */

  function ensureFounderOps() {
    if (!isFounder()) return;

    const card = $("#v49OwnerModal .v49-owner-card");
    if (!card || $("#v51FounderOps", card)) return;

    const section = document.createElement("section");
    section.id = "v51FounderOps";
    section.className = "v51-founder-ops";
    section.innerHTML = `
      <section class="v49-owner-block">
        <div class="section-title"><span>Founder traffic shield</span></div>
        <div class="v51-founder-grid">
          <div class="v51-founder-control">
            <div>
              <strong>Protection mode</strong>
              <small>Temporarily lowers per-account send burst limits during abuse or traffic spikes.</small>
            </div>
            <button id="v51ProtectionBtn" class="secondary-btn" type="button">Loading…</button>
          </div>
          <div class="v51-founder-control">
            <div>
              <strong>New ad campaign sales</strong>
              <small>Pause new $5/day campaign checkouts without stopping campaigns that are already paid and active.</small>
            </div>
            <button id="v51AdSalesBtn" class="secondary-btn" type="button">Loading…</button>
          </div>
        </div>
      </section>

      <section class="v49-owner-block">
        <div class="v51-founder-chart-head">
          <div class="section-title"><span>24-hour message activity</span></div>
          <small id="v51FounderChartSummary">Loading…</small>
        </div>
        <div id="v51FounderChart" class="v51-founder-chart" aria-label="Messages per hour for the last 24 hours"></div>
      </section>

      <section class="v49-owner-block">
        <div class="section-title"><span>Founder diagnostics</span></div>
        <div class="v51-diagnostic-row">
          <div>
            <strong>Download operational snapshot</strong>
            <small>Exports aggregate platform health, feature flags, and browser diagnostics. Private message contents are never included.</small>
          </div>
          <button id="v51FounderDiagnosticsBtn" class="secondary-btn" type="button">Download JSON</button>
        </div>
      </section>
    `;

    const extras = $("#v50FounderExtras", card);
    if (extras) extras.insertAdjacentElement("afterend", section);
    else card.appendChild(section);

    $("#v51ProtectionBtn", section)?.addEventListener("click", toggleProtectionMode);
    $("#v51AdSalesBtn", section)?.addEventListener("click", toggleAdSales);
    $("#v51FounderDiagnosticsBtn", section)?.addEventListener("click", downloadFounderDiagnostics);

    refreshFounderOps();
  }

  function renderFounderFlags(dashboard) {
    const flags = dashboard?.feature_flags || {};

    const protection = $("#v51ProtectionBtn");
    if (protection) {
      const enabled = Boolean(flags.protection_mode);
      protection.dataset.enabled = enabled ? "true" : "false";
      protection.textContent = enabled ? "Turn off protection" : "Turn on protection";
      protection.classList.toggle("active", enabled);
    }

    const sales = $("#v51AdSalesBtn");
    if (sales) {
      const paused = Boolean(flags.ad_sales_paused);
      sales.dataset.paused = paused ? "true" : "false";
      sales.textContent = paused ? "Resume ad sales" : "Pause ad sales";
      sales.classList.toggle("active", paused);
    }
  }

  function renderFounderTimeseries(hours) {
    const chart = $("#v51FounderChart");
    if (!chart) return;

    const items = Array.isArray(hours) ? hours.slice(-24) : [];
    chart.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("small");
      empty.textContent = "No activity data is available yet.";
      chart.appendChild(empty);
      return;
    }

    const maxMessages = Math.max(1, ...items.map((item) => Number(item.messages || 0)));
    let totalMessages = 0;
    let peakMessages = 0;

    for (const item of items) {
      const count = Number(item.messages || 0);
      totalMessages += count;
      peakMessages = Math.max(peakMessages, count);

      const column = document.createElement("div");
      column.className = "v51-chart-column";

      const bar = document.createElement("div");
      bar.className = "v51-chart-bar";
      bar.style.setProperty("--v51-bar", `${Math.max(4, Math.round((count / maxMessages) * 100))}%`);
      bar.title = `${formatTime(item.bucket)} · ${formatNumber(count)} messages · ${formatNumber(item.active_senders)} active senders`;

      const label = document.createElement("span");
      const date = new Date(Number(item.bucket || 0) * 1000);
      label.textContent = Number.isFinite(date.getTime())
        ? date.toLocaleTimeString([], { hour: "numeric" })
        : "";

      column.append(bar, label);
      chart.appendChild(column);
    }

    const summary = $("#v51FounderChartSummary");
    if (summary) {
      summary.textContent = `${formatNumber(totalMessages)} messages · peak ${formatNumber(peakMessages)}/hr`;
    }
  }

  async function refreshFounderOps() {
    if (!isFounder() || !app()?.api) return;

    try {
      const [dashboardData, seriesData] = await Promise.all([
        app().api("owner_dashboard", {
          showLoader: false,
          timeoutMs: 8000,
        }),
        app().api("owner_timeseries", {
          showLoader: false,
          timeoutMs: 8000,
        }),
      ]);

      runtime.ownerDashboard = dashboardData?.dashboard || {};
      runtime.ownerTimeseries = Array.isArray(seriesData?.hours) ? seriesData.hours : [];
      renderFounderFlags(runtime.ownerDashboard);
      renderFounderTimeseries(runtime.ownerTimeseries);
    } catch (error) {
      $("#v51FounderChartSummary")?.replaceChildren(
        document.createTextNode(error?.message || "Could not refresh analytics.")
      );
    }
  }

  async function toggleProtectionMode() {
    if (!isFounder()) return;

    const button = $("#v51ProtectionBtn");
    const enabled = button?.dataset.enabled === "true";
    if (button) button.disabled = true;

    try {
      await app().api("owner_protection_set", {
        method: "POST",
        body: { enabled: !enabled },
        showLoader: false,
      });
      toast(!enabled ? "Founder Protection Mode enabled." : "Founder Protection Mode disabled.");
      await refreshFounderOps();
      await window.SilknexV50?.refreshFounderExtras?.();
    } catch (error) {
      toast(error?.message || "Could not change protection mode.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function toggleAdSales() {
    if (!isFounder()) return;

    const button = $("#v51AdSalesBtn");
    const paused = button?.dataset.paused === "true";
    if (button) button.disabled = true;

    try {
      await app().api("owner_ad_sales_set", {
        method: "POST",
        body: { paused: !paused },
        showLoader: false,
      });
      toast(!paused ? "New ad campaign sales paused." : "New ad campaign sales resumed.");
      await refreshFounderOps();
      await window.SilknexV50?.refreshFounderExtras?.();
    } catch (error) {
      toast(error?.message || "Could not change ad sales.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function downloadFounderDiagnostics() {
    if (!isFounder()) return;

    if (!runtime.ownerDashboard || !runtime.ownerTimeseries.length) {
      await refreshFounderOps();
    }

    const payload = {
      generated_at: new Date().toISOString(),
      release: "52.0",
      dashboard: runtime.ownerDashboard || {},
      activity_24h: runtime.ownerTimeseries || [],
      browser: {
        user_agent: navigator.userAgent,
        language: navigator.language,
        online: navigator.onLine,
        visibility: document.visibilityState,
        screen: {
          width: window.screen?.width || 0,
          height: window.screen?.height || 0,
          pixel_ratio: window.devicePixelRatio || 1,
        },
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight,
        },
        service_worker: Boolean(navigator.serviceWorker),
        installed_display_mode: window.matchMedia?.("(display-mode: standalone)")?.matches || false,
      },
    };

    downloadBlob(
      `silknex-founder-diagnostics-${new Date().toISOString().slice(0, 10)}.json`,
      "application/json;charset=utf-8",
      JSON.stringify(payload, null, 2)
    );
    toast("Founder diagnostics downloaded.");
  }

  function scheduleFounderRefresh() {
    clearTimeout(runtime.ownerRefreshTimer);
    runtime.ownerRefreshTimer = null;
    if (!runtime.founder) return;

    runtime.ownerRefreshTimer = setTimeout(async () => {
      if (
        document.visibilityState === "visible" &&
        !$("#v49OwnerModal")?.classList.contains("hidden")
      ) {
        await refreshFounderOps();
      }
      scheduleFounderRefresh();
    }, 60000);
  }

  function bindOwnerObserver() {
    if (runtime.ownerObserver) return;

    runtime.ownerObserver = new MutationObserver((records) => {
      if (!runtime.founder) return;

      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (
            node.id === "v49OwnerModal" ||
            node.matches?.("#v49OwnerModal") ||
            node.querySelector?.("#v49OwnerModal")
          ) {
            ensureFounderOps();
            return;
          }
        }
      }
    });
    runtime.ownerObserver.observe(document.body, { childList: true });
  }

  /* ------------------------------------------------------------------ */
  /* Wiring                                                             */
  /* ------------------------------------------------------------------ */

  function setSignedIn(value) {
    runtime.signedIn = Boolean(value);
    runtime.founder = isFounder();

    if (!runtime.signedIn) {
      clearTimeout(runtime.ownerRefreshTimer);
      runtime.ownerRefreshTimer = null;
      runtime.ownerDashboard = null;
      runtime.ownerTimeseries = [];
      runtime.starConversationId = 0;
      runtime.starredIds.clear();
      updateStarButtons();
      return;
    }

    ensureGeneralUi();
    refreshStars({ render: false, all: false });

    if (runtime.founder) {
      ensureFounderOps();
      bindOwnerObserver();
      scheduleFounderRefresh();
    }
  }

  function boot() {
    setSignedIn(Boolean(app()?.state?.me));

    window.addEventListener("silknex:session", (event) => {
      setTimeout(() => setSignedIn(Boolean(event.detail?.signedIn)), 0);
    });

    window.addEventListener("silknex:conversation", () => {
      setTimeout(() => {
        ensureGeneralUi();
        updateMuteUi();
        decorateMutedConversations();
        refreshStars({ render: false, all: false });
      }, 0);
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        decorateMutedConversations();
      }
    });

    // v50/v49 add parts of Settings after initial app bootstrap.
    const uiObserver = new MutationObserver(() => {
      if (!runtime.signedIn) return;
      ensureGeneralUi();
      if (runtime.founder) ensureFounderOps();
    });
    uiObserver.observe(document.body, { childList: true, subtree: false });
  }

  function start() {
    if (window.SilknexApp) boot();
    else window.addEventListener("silknex:core-ready", boot, { once: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }

  window.SilknexV51 = Object.freeze({
    openQuickReplies,
    openMuteModal,
    setConversationMute,
    openStarredMessages,
    refreshFounderOps,
  });
})();

} catch (error) { console.error("Silknex feature module 51:", error); }

;
/* Feature module 52 */
try {
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const DEFAULT_QUIET = Object.freeze({
    quiet_enabled: false,
    quiet_start_minute: 22 * 60,
    quiet_end_minute: 7 * 60,
    timezone: "UTC",
  });

  const runtime = {
    signedIn: false,
    founder: false,
    preferences: { ...DEFAULT_QUIET },
    preferencesLoaded: false,
    dataSaver: false,
    mediaObserver: null,
    uiObserver: null,
    ownerObserver: null,
    ownerRefreshTimer: null,
    clearingUnread: new Set(),
    lastHealth: null,
  };

  function toast(message) {
    app()?.toast?.(String(message || ""));
  }

  function isFounder() {
    return Boolean(
      runtime.signedIn &&
      ["founder_ceo", "cofounder_ceo"].includes(app()?.state?.me?.role)
    );
  }

  function activeConversationItem() {
    const id = Number(app()?.state?.activeId || 0);
    return app()?.state?.conversations?.find?.(
      (item) => Number(item.id) === id
    ) || null;
  }

  function userStorageKey(name) {
    const userId = Number(app()?.state?.me?.id || 0);
    return userId ? `silknex:v52:${name}:${userId}` : "";
  }

  function readBooleanSetting(name, fallback = false) {
    const key = userStorageKey(name);
    if (!key) return Boolean(fallback);

    try {
      const value = window.SilknexStorage.getItem(key);
      if (value === "1") return true;
      if (value === "0") return false;
    } catch {}
    return Boolean(fallback);
  }

  function writeBooleanSetting(name, value) {
    const key = userStorageKey(name);
    if (!key) return;
    try {
      window.SilknexStorage.setItem(key, value ? "1" : "0");
    } catch {}
  }

  function timezoneName() {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
    } catch {
      return "UTC";
    }
  }

  function minuteToTime(value) {
    const minute = Math.max(0, Math.min(1439, Number(value || 0)));
    const hours = Math.floor(minute / 60);
    const minutes = minute % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
  }

  function timeToMinute(value, fallback) {
    const match = /^(\d{1,2}):(\d{2})$/.exec(String(value || ""));
    if (!match) return fallback;
    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    if (
      !Number.isInteger(hours) ||
      !Number.isInteger(minutes) ||
      hours < 0 ||
      hours > 23 ||
      minutes < 0 ||
      minutes > 59
    ) {
      return fallback;
    }
    return hours * 60 + minutes;
  }

  function quietHoursActive(now = new Date()) {
    const prefs = runtime.preferences || DEFAULT_QUIET;
    if (!prefs.quiet_enabled) return false;

    const start = Math.max(0, Math.min(1439, Number(prefs.quiet_start_minute || 0)));
    const end = Math.max(0, Math.min(1439, Number(prefs.quiet_end_minute || 0)));
    if (start === end) return false;

    let minute;
    try {
      const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: String(prefs.timezone || "UTC"),
        hourCycle: "h23",
        hour: "2-digit",
        minute: "2-digit",
      }).formatToParts(now);
      const hour = Number(parts.find((part) => part.type === "hour")?.value || 0);
      const mins = Number(parts.find((part) => part.type === "minute")?.value || 0);
      minute = hour * 60 + mins;
    } catch {
      minute = now.getHours() * 60 + now.getMinutes();
    }

    return start < end
      ? minute >= start && minute < end
      : minute >= start || minute < end;
  }

  async function loadNotificationPreferences() {
    if (!runtime.signedIn || !app()?.api) return;

    try {
      const data = await app().api("notification_preferences", {
        showLoader: false,
        timeoutMs: 7000,
      });
      const prefs = data?.preferences || {};
      runtime.preferences = {
        quiet_enabled: Boolean(prefs.quiet_enabled),
        quiet_start_minute: Number(prefs.quiet_start_minute ?? DEFAULT_QUIET.quiet_start_minute),
        quiet_end_minute: Number(prefs.quiet_end_minute ?? DEFAULT_QUIET.quiet_end_minute),
        timezone: String(prefs.timezone || timezoneName()),
      };
      runtime.preferencesLoaded = true;
      syncPreferenceControls();
    } catch {
      runtime.preferences = {
        ...DEFAULT_QUIET,
        timezone: timezoneName(),
      };
      runtime.preferencesLoaded = false;
      syncPreferenceControls();
    }
  }

  async function saveNotificationPreferences() {
    if (!runtime.signedIn || !app()?.api) return;

    const toggle = $("#v52QuietHoursToggle");
    const startInput = $("#v52QuietStart");
    const endInput = $("#v52QuietEnd");
    const button = $("#v52QuietSaveBtn");

    const next = {
      quiet_enabled: Boolean(toggle?.checked),
      quiet_start_minute: timeToMinute(
        startInput?.value,
        runtime.preferences.quiet_start_minute
      ),
      quiet_end_minute: timeToMinute(
        endInput?.value,
        runtime.preferences.quiet_end_minute
      ),
      timezone: timezoneName(),
    };

    if (button) button.disabled = true;
    try {
      const data = await app().api("notification_preferences", {
        method: "POST",
        body: next,
        showLoader: false,
      });
      runtime.preferences = {
        ...next,
        ...(data?.preferences || {}),
        quiet_enabled: Boolean(data?.preferences?.quiet_enabled ?? next.quiet_enabled),
      };
      runtime.preferencesLoaded = true;
      syncPreferenceControls();
      button?.classList.remove("attention");
      toast(
        runtime.preferences.quiet_enabled
          ? "Quiet hours saved. Message alerts will stay silent during that window."
          : "Quiet hours turned off."
      );
    } catch (error) {
      toast(error?.message || "Could not save quiet hours.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function syncPreferenceControls() {
    const prefs = runtime.preferences || DEFAULT_QUIET;
    const toggle = $("#v52QuietHoursToggle");
    const start = $("#v52QuietStart");
    const end = $("#v52QuietEnd");
    const status = $("#v52QuietStatus");

    if (toggle) toggle.checked = Boolean(prefs.quiet_enabled);
    if (start) start.value = minuteToTime(prefs.quiet_start_minute);
    if (end) end.value = minuteToTime(prefs.quiet_end_minute);
    if (status) {
      if (!prefs.quiet_enabled) {
        status.textContent = "Off";
      } else {
        status.textContent = quietHoursActive()
          ? `Quiet now · ${minuteToTime(prefs.quiet_start_minute)}–${minuteToTime(prefs.quiet_end_minute)}`
          : `${minuteToTime(prefs.quiet_start_minute)}–${minuteToTime(prefs.quiet_end_minute)}`;
      }
    }

    const dataSaver = $("#v52DataSaverToggle");
    if (dataSaver) dataSaver.checked = runtime.dataSaver;
  }

  function optimizeMediaNode(node) {
    if (!(node instanceof Element)) return;

    const videos = node.matches("video")
      ? [node]
      : $$("video", node);
    for (const video of videos) {
      if (!video.closest("#messages, #storyViewer, .story-viewer")) continue;
      if (runtime.dataSaver) {
        video.preload = "metadata";
        if (!video.closest(".call-stage, #callModal")) {
          video.autoplay = false;
          video.removeAttribute("autoplay");
        }
      }
    }

    const images = node.matches("img")
      ? [node]
      : $$("img", node);
    for (const image of images) {
      if (!image.closest("#messages, #storyViewer, .story-viewer")) continue;
      image.loading = "lazy";
      image.decoding = "async";
    }
  }

  function applyDataSaver() {
    document.documentElement.classList.toggle("v52-data-saver", runtime.dataSaver);
    optimizeMediaNode(document.body);

    if (!runtime.mediaObserver) {
      runtime.mediaObserver = new MutationObserver((records) => {
        if (!runtime.dataSaver) return;
        for (const record of records) {
          for (const node of record.addedNodes) {
            if (node instanceof Element) optimizeMediaNode(node);
          }
        }
      });
      runtime.mediaObserver.observe(document.body, {
        childList: true,
        subtree: true,
      });
    }
  }

  function setDataSaver(enabled) {
    runtime.dataSaver = Boolean(enabled);
    writeBooleanSetting("data-saver", runtime.dataSaver);
    applyDataSaver();
    syncPreferenceControls();
    toast(runtime.dataSaver ? "Data Saver enabled." : "Data Saver disabled.");
  }

  async function setManualUnread(conversationId, unread) {
    const id = Number(conversationId || 0);
    if (!id || !runtime.signedIn || !app()?.api) return false;

    try {
      const data = await app().api("conversation_unread_set", {
        method: "POST",
        body: {
          conversation_id: id,
          unread: Boolean(unread),
        },
        showLoader: false,
      });

      const item = app()?.state?.conversations?.find?.(
        (conversation) => Number(conversation.id) === id
      );
      if (item) item.manual_unread = Boolean(data?.manual_unread ?? unread);

      await app()?.loadConversations?.();
      updateUnreadButton();
      return true;
    } catch (error) {
      toast(error?.message || "Could not update unread status.");
      return false;
    }
  }

  function updateUnreadButton() {
    const button = $("#v52MarkUnreadBtn");
    if (!button) return;

    const item = activeConversationItem();
    const marked = Boolean(item?.manual_unread);
    button.disabled = !item;
    button.classList.toggle("active", marked);
    button.textContent = marked ? "Marked unread" : "Mark as unread";
    button.setAttribute("aria-pressed", marked ? "true" : "false");
  }

  async function markCurrentUnread() {
    const item = activeConversationItem();
    if (!item) {
      toast("Open a chat first.");
      return;
    }

    const next = !Boolean(item.manual_unread);
    if (await setManualUnread(item.id, next)) {
      toast(next ? "Chat marked unread." : "Unread marker cleared.");
    }
  }

  async function clearManualUnreadOnOpen(conversation) {
    const id = Number(conversation?.id || 0);
    if (!id || runtime.clearingUnread.has(id)) return;

    const item = app()?.state?.conversations?.find?.(
      (candidate) => Number(candidate.id) === id
    );
    if (!item?.manual_unread) return;

    runtime.clearingUnread.add(id);
    try {
      await setManualUnread(id, false);
    } finally {
      runtime.clearingUnread.delete(id);
    }
  }

  function ensureGeneralUi() {
    const productivity = $("#v50ProductivitySettings");
    if (productivity && !$("#v52NotificationTools")) {
      const section = document.createElement("div");
      section.id = "v52NotificationTools";
      section.className = "v52-settings-tools";
      section.innerHTML = `
        <div class="section-title"><span>Notifications & data</span></div>

        <div class="v52-setting-row">
          <div class="v52-setting-copy">
            <strong>Quiet hours</strong>
            <small>Silence message notifications on every Silknex device during a schedule. Incoming calls still alert.</small>
          </div>
          <label class="v52-switch">
            <input id="v52QuietHoursToggle" type="checkbox" aria-label="Enable quiet hours">
            <span aria-hidden="true"></span>
          </label>
        </div>

        <div class="v52-quiet-grid">
          <label class="field">
            <span>Starts</span>
            <input id="v52QuietStart" type="time" value="22:00">
          </label>
          <label class="field">
            <span>Ends</span>
            <input id="v52QuietEnd" type="time" value="07:00">
          </label>
          <button id="v52QuietSaveBtn" class="secondary-btn" type="button">Save quiet hours</button>
          <small id="v52QuietStatus" class="v52-inline-status">Off</small>
        </div>

        <div class="v52-setting-row">
          <div class="v52-setting-copy">
            <strong>Data Saver</strong>
            <small>Use less bandwidth and memory by reducing media preloading and nonessential motion on this device.</small>
          </div>
          <label class="v52-switch">
            <input id="v52DataSaverToggle" type="checkbox" aria-label="Enable Data Saver">
            <span aria-hidden="true"></span>
          </label>
        </div>
      `;
      productivity.appendChild(section);

      $("#v52QuietSaveBtn", section)?.addEventListener("click", saveNotificationPreferences);
      $("#v52QuietHoursToggle", section)?.addEventListener("change", () => {
        $("#v52QuietSaveBtn")?.classList.add("attention");
      });
      $("#v52QuietStart", section)?.addEventListener("change", () => {
        $("#v52QuietSaveBtn")?.classList.add("attention");
      });
      $("#v52QuietEnd", section)?.addEventListener("change", () => {
        $("#v52QuietSaveBtn")?.classList.add("attention");
      });
      $("#v52DataSaverToggle", section)?.addEventListener("change", (event) => {
        setDataSaver(Boolean(event.currentTarget.checked));
      });
      syncPreferenceControls();
    }

    const organize = $("#v50ChatTools .v50-organize-grid");
    if (organize && !$("#v52MarkUnreadBtn")) {
      const button = document.createElement("button");
      button.id = "v52MarkUnreadBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Mark as unread";
      button.addEventListener("click", markCurrentUnread);
      organize.appendChild(button);
      updateUnreadButton();
    }
  }

  function formatInteger(value) {
    const number = Number(value || 0);
    try {
      return new Intl.NumberFormat().format(Number.isFinite(number) ? number : 0);
    } catch {
      return String(Number.isFinite(number) ? number : 0);
    }
  }

  function formatBytes(value) {
    let bytes = Math.max(0, Number(value || 0));
    const units = ["B", "KB", "MB", "GB"];
    let unit = 0;
    while (bytes >= 1024 && unit < units.length - 1) {
      bytes /= 1024;
      unit += 1;
    }
    return `${bytes >= 10 || unit === 0 ? bytes.toFixed(0) : bytes.toFixed(1)} ${units[unit]}`;
  }

  function healthMetric(label, value, note = "") {
    const card = document.createElement("div");
    card.className = "v52-health-card";

    const small = document.createElement("small");
    small.textContent = label;
    const strong = document.createElement("strong");
    strong.textContent = String(value ?? "—");
    card.append(small, strong);

    if (note) {
      const span = document.createElement("span");
      span.textContent = note;
      card.appendChild(span);
    }

    return card;
  }

  function ensureFounderUi() {
    if (!isFounder()) return;

    const card = $("#v49OwnerModal .v49-owner-card");
    if (!card || $("#v52FounderOps", card)) return;

    const section = document.createElement("section");
    section.id = "v52FounderOps";
    section.className = "v52-founder-ops";
    section.innerHTML = `
      <section class="v49-owner-block">
        <div class="v52-founder-head">
          <div class="section-title"><span>Service controls</span></div>
          <button id="v52HealthRefreshBtn" class="plain-btn" type="button">Refresh health</button>
        </div>
        <div class="v52-founder-control-grid">
          <div class="v52-founder-control">
            <div>
              <strong>Media uploads</strong>
              <small>Pause new user uploads during storage, CPU, or bandwidth incidents. Text messaging stays online.</small>
            </div>
            <button id="v52UploadsBtn" class="secondary-btn" type="button">Loading…</button>
          </div>
          <div class="v52-founder-control">
            <div>
              <strong>New calls</strong>
              <small>Pause new call starts if realtime calling is degraded. Existing messaging remains available.</small>
            </div>
            <button id="v52CallsBtn" class="secondary-btn" type="button">Loading…</button>
          </div>
        </div>
      </section>

      <section class="v49-owner-block">
        <div class="v52-founder-head">
          <div class="section-title"><span>System health</span></div>
          <small id="v52HealthUpdated">Loading…</small>
        </div>
        <div id="v52HealthGrid" class="v52-health-grid" aria-live="polite"></div>
        <div class="v52-health-actions">
          <button id="v52CopyHealthBtn" class="secondary-btn" type="button">Copy health snapshot</button>
        </div>
      </section>
    `;

    card.appendChild(section);
    $("#v52HealthRefreshBtn", section)?.addEventListener("click", refreshFounderHealth);
    $("#v52UploadsBtn", section)?.addEventListener("click", () => toggleFounderService("uploads"));
    $("#v52CallsBtn", section)?.addEventListener("click", () => toggleFounderService("calls"));
    $("#v52CopyHealthBtn", section)?.addEventListener("click", copyFounderHealth);

    refreshFounderHealth();
  }

  function renderFounderHealth(health) {
    runtime.lastHealth = health || null;

    const flags = health?.feature_flags || {};
    const uploads = $("#v52UploadsBtn");
    const calls = $("#v52CallsBtn");

    if (uploads) {
      const paused = Boolean(flags.uploads_paused);
      uploads.dataset.paused = paused ? "true" : "false";
      uploads.textContent = paused ? "Resume uploads" : "Pause uploads";
      uploads.classList.toggle("active", paused);
    }

    if (calls) {
      const paused = Boolean(flags.calls_paused);
      calls.dataset.paused = paused ? "true" : "false";
      calls.textContent = paused ? "Resume calls" : "Pause calls";
      calls.classList.toggle("active", paused);
    }

    const grid = $("#v52HealthGrid");
    if (grid) {
      grid.replaceChildren(
        healthMetric("Active users", formatInteger(health?.active_users_5m), "last 5 min"),
        healthMetric("Accounts", `~${formatInteger(health?.accounts_estimate)}`, "database estimate"),
        healthMetric("Active calls", formatInteger(health?.active_calls)),
        healthMetric("Ringing", formatInteger(health?.ringing_calls)),
        healthMetric("Push queue", formatInteger(health?.pending_push_jobs)),
        healthMetric("Request RAM", formatBytes(health?.request_memory_bytes)),
        healthMetric("Peak RAM", formatBytes(health?.request_peak_memory_bytes)),
        healthMetric("Schema", `v${String(health?.schema_version || "—")}`)
      );
    }

    const updated = $("#v52HealthUpdated");
    if (updated) {
      updated.textContent = `PHP ${String(health?.php_version || "—")} · refreshed ${new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`;
    }
  }

  async function refreshFounderHealth() {
    if (!isFounder() || !app()?.api) return;

    try {
      const data = await app().api("owner_system_health", {
        showLoader: false,
        timeoutMs: 8000,
      });
      renderFounderHealth(data?.health || {});
    } catch (error) {
      const grid = $("#v52HealthGrid");
      if (grid) grid.textContent = error?.message || "Could not load system health.";
    }
  }

  async function toggleFounderService(kind) {
    if (!isFounder()) return;

    const isUploads = kind === "uploads";
    const button = isUploads ? $("#v52UploadsBtn") : $("#v52CallsBtn");
    const paused = button?.dataset.paused === "true";
    if (button) button.disabled = true;
    try {
      const request = isUploads
        ? app().api("owner_uploads_set", {
            method: "POST",
            body: { paused: !paused },
            showLoader: false,
          })
        : app().api("owner_calls_set", {
            method: "POST",
            body: { paused: !paused },
            showLoader: false,
          });
      await request;
      toast(
        isUploads
          ? (!paused ? "New media uploads paused." : "Media uploads resumed.")
          : (!paused ? "New calls paused." : "New calls resumed.")
      );
      await Promise.allSettled([
        refreshFounderHealth(),
        window.SilknexV51?.refreshFounderOps?.(),
        window.SilknexV50?.refreshFounderExtras?.(),
      ]);
    } catch (error) {
      toast(error?.message || "Could not update service controls.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function copyFounderHealth() {
    if (!isFounder()) return;
    if (!runtime.lastHealth) await refreshFounderHealth();
    if (!runtime.lastHealth) return;

    const payload = {
      generated_at: new Date().toISOString(),
      release: "52.0",
      ...runtime.lastHealth,
    };

    try {
      await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
      toast("System health copied.");
    } catch {
      toast("Could not copy system health.");
    }
  }

  function scheduleFounderRefresh() {
    clearTimeout(runtime.ownerRefreshTimer);
    runtime.ownerRefreshTimer = null;
    if (!runtime.founder) return;

    runtime.ownerRefreshTimer = setTimeout(async () => {
      if (
        document.visibilityState === "visible" &&
        !$("#v49OwnerModal")?.classList.contains("hidden")
      ) {
        await refreshFounderHealth();
      }
      scheduleFounderRefresh();
    }, 45000);
  }

  function bindUiObserver() {
    if (runtime.uiObserver) return;
    runtime.uiObserver = new MutationObserver(() => {
      if (!runtime.signedIn) return;
      ensureGeneralUi();
      if (runtime.founder) ensureFounderUi();
    });
    runtime.uiObserver.observe(document.body, { childList: true, subtree: false });
  }

  function initializeDeviceSettings() {
    const key = userStorageKey("data-saver");
    let hasStored = false;
    if (key) {
      try {
        hasStored = window.SilknexStorage.getItem(key) !== null;
      } catch {}
    }
    const connectionSaveData = Boolean(navigator.connection?.saveData);
    runtime.dataSaver = readBooleanSetting(
      "data-saver",
      !hasStored && connectionSaveData
    );
    applyDataSaver();
  }

  function setSignedIn(value) {
    runtime.signedIn = Boolean(value);
    runtime.founder = isFounder();

    if (!runtime.signedIn) {
      clearTimeout(runtime.ownerRefreshTimer);
      runtime.ownerRefreshTimer = null;
      runtime.preferencesLoaded = false;
      runtime.preferences = { ...DEFAULT_QUIET };
      runtime.lastHealth = null;
      document.documentElement.classList.remove("v52-data-saver");
      return;
    }

    initializeDeviceSettings();
    ensureGeneralUi();
    loadNotificationPreferences();

    if (runtime.founder) {
      ensureFounderUi();
      scheduleFounderRefresh();
    }
  }

  function boot() {
    bindUiObserver();
    setSignedIn(Boolean(app()?.state?.me));

    window.addEventListener("silknex:session", (event) => {
      setTimeout(() => setSignedIn(Boolean(event.detail?.signedIn)), 0);
    });

    window.addEventListener("silknex:conversation", (event) => {
      setTimeout(() => {
        ensureGeneralUi();
        updateUnreadButton();
        if (event.detail?.conversation) {
          clearManualUnreadOnOpen(event.detail.conversation);
        }
      }, 0);
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        syncPreferenceControls();
      }
    });
  }

  function start() {
    if (window.SilknexApp) boot();
    else window.addEventListener("silknex:core-ready", boot, { once: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }

  window.SilknexV52 = Object.freeze({
    quietHoursActive,
    refreshFounderHealth,
    setDataSaver,
    markCurrentUnread,
  });
})();

} catch (error) { console.error("Silknex feature module 52:", error); }

;
/* Feature module 53 */
try {
(() => {
  "use strict";

  const VERSION = "53.1";
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const app = () => window.SilknexApp || null;

  const runtime = {
    storyAudienceIds: [],
    profile: null,
    qrStream: null,
    qrScanRaf: 0,
    giphyStickerRequest: 0,
    founderBound: false,
    avatarCardsBuilt: false,
  };

  window.SilkNexV53 = runtime;

  function toast(message) {
    app()?.toast?.(message);
  }

  function escapeUsername(value) {
    return String(value || "")
      .trim()
      .replace(/^@+/, "")
      .toLowerCase()
      .slice(0, 24);
  }

  function isFounder() {
    return ["founder_ceo", "cofounder_ceo"].includes(String(app()?.state?.me?.role || app()?.state?.me?.account_role || ""));
  }

  // ---------------------------------------------------------------------------
  // Viewport + mobile keyboard fit
  // ---------------------------------------------------------------------------
  // Viewport and keyboard handling are centralized in app.js.

  // ---------------------------------------------------------------------------
  // QR generation (QR version 3-L, byte mode) + scanning
  // ---------------------------------------------------------------------------
  function gfMul(a, b) {
    let out = 0;
    for (let i = 0; i < 8; i += 1) {
      if (b & 1) out ^= a;
      const carry = a & 0x80;
      a = (a << 1) & 0xff;
      if (carry) a ^= 0x1d;
      b >>>= 1;
    }
    return out;
  }

  function rsGenerator(degree) {
    let poly = [1];
    let root = 1;
    for (let i = 0; i < degree; i += 1) {
      const next = new Array(poly.length + 1).fill(0);
      for (let j = 0; j < poly.length; j += 1) {
        next[j] ^= poly[j];
        next[j + 1] ^= gfMul(poly[j], root);
      }
      poly = next;
      root = gfMul(root, 2);
    }
    return poly;
  }

  function rsRemainder(data, degree) {
    const divisor = rsGenerator(degree);
    const result = new Array(degree).fill(0);
    for (const byte of data) {
      const factor = byte ^ result[0];
      result.shift();
      result.push(0);
      for (let i = 0; i < degree; i += 1) {
        result[i] ^= gfMul(divisor[i + 1], factor);
      }
    }
    return result;
  }

  function appendBits(bits, value, length) {
    for (let i = length - 1; i >= 0; i -= 1) bits.push((value >>> i) & 1);
  }

  function qrCodewords(text) {
    const bytes = Array.from(new TextEncoder().encode(text));
    if (bytes.length > 53) throw new Error("Profile code is too long.");
    const bits = [];
    appendBits(bits, 0b0100, 4); // byte mode
    appendBits(bits, bytes.length, 8);
    for (const byte of bytes) appendBits(bits, byte, 8);

    const maxBits = 55 * 8; // QR version 3-L data codewords
    appendBits(bits, 0, Math.min(4, Math.max(0, maxBits - bits.length)));
    while (bits.length % 8) bits.push(0);

    const data = [];
    for (let i = 0; i < bits.length; i += 8) {
      let value = 0;
      for (let j = 0; j < 8; j += 1) value = (value << 1) | bits[i + j];
      data.push(value);
    }
    const pads = [0xec, 0x11];
    let padIndex = 0;
    while (data.length < 55) data.push(pads[padIndex++ & 1]);

    return data.concat(rsRemainder(data, 15)); // one RS block, 70 total
  }

  function formatBits(mask = 0) {
    const data = (1 << 3) | (mask & 7); // L = 01
    let rem = data << 10;
    const generator = 0x537;
    for (let bit = 14; bit >= 10; bit -= 1) {
      if ((rem >>> bit) & 1) rem ^= generator << (bit - 10);
    }
    return (((data << 10) | rem) ^ 0x5412) & 0x7fff;
  }

  function qrMatrix(text) {
    const size = 29;
    const modules = Array.from({ length: size }, () => Array(size).fill(null));
    const set = (x, y, value) => {
      if (x >= 0 && y >= 0 && x < size && y < size) modules[y][x] = Boolean(value);
    };

    const finder = (x, y) => {
      for (let dy = -1; dy <= 7; dy += 1) {
        for (let dx = -1; dx <= 7; dx += 1) {
          const xx = x + dx;
          const yy = y + dy;
          if (xx < 0 || yy < 0 || xx >= size || yy >= size) continue;
          const inside = dx >= 0 && dx <= 6 && dy >= 0 && dy <= 6;
          const black = inside && (
            dx === 0 || dx === 6 || dy === 0 || dy === 6 ||
            (dx >= 2 && dx <= 4 && dy >= 2 && dy <= 4)
          );
          set(xx, yy, black);
        }
      }
    };

    finder(0, 0);
    finder(size - 7, 0);
    finder(0, size - 7);

    for (let i = 8; i < size - 8; i += 1) {
      if (modules[6][i] === null) set(i, 6, (i & 1) === 0);
      if (modules[i][6] === null) set(6, i, (i & 1) === 0);
    }

    // Version 3 alignment pattern center.
    const alignment = (cx, cy) => {
      if (modules[cy][cx] !== null) return;
      for (let dy = -2; dy <= 2; dy += 1) {
        for (let dx = -2; dx <= 2; dx += 1) {
          set(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
        }
      }
    };
    alignment(22, 22);

    const fmt = formatBits(0);
    const fmtBit = (i) => ((fmt >>> i) & 1) !== 0;
    for (let i = 0; i <= 5; i += 1) set(8, i, fmtBit(i));
    set(8, 7, fmtBit(6));
    set(8, 8, fmtBit(7));
    set(7, 8, fmtBit(8));
    for (let i = 9; i < 15; i += 1) set(14 - i, 8, fmtBit(i));
    for (let i = 0; i < 8; i += 1) set(size - 1 - i, 8, fmtBit(i));
    for (let i = 8; i < 15; i += 1) set(8, size - 15 + i, fmtBit(i));
    set(8, size - 8, true);

    const dataBits = [];
    for (const byte of qrCodewords(text)) appendBits(dataBits, byte, 8);
    let index = 0;
    let upward = true;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right -= 1;
      for (let vert = 0; vert < size; vert += 1) {
        const y = upward ? size - 1 - vert : vert;
        for (let j = 0; j < 2; j += 1) {
          const x = right - j;
          if (modules[y][x] !== null) continue;
          let bit = index < dataBits.length ? dataBits[index++] : 0;
          if (((x + y) & 1) === 0) bit ^= 1; // mask 0
          set(x, y, Boolean(bit));
        }
      }
      upward = !upward;
    }
    return modules;
  }

  function drawQr(canvas, username) {
    if (!canvas) return;
    const handle = escapeUsername(username);
    const profileUrl = new URL(`/@${handle}`, location.origin);
    const webValue = profileUrl.toString();
    const value = new TextEncoder().encode(webValue).length <= 53
      ? webValue
      : `silknex:${handle}`;
    const matrix = qrMatrix(value);
    const quiet = 4;
    const cells = matrix.length + quiet * 2;
    const dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
    const cssSize = Math.min(328, Math.max(244, canvas.clientWidth || 328));
    canvas.width = Math.round(cssSize * dpr);
    canvas.height = Math.round(cssSize * dpr);
    canvas.style.width = `${cssSize}px`;
    canvas.style.height = `${cssSize}px`;
    const ctx = canvas.getContext("2d", { alpha: false });
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, cssSize, cssSize);
    const cell = cssSize / cells;
    ctx.fillStyle = "#000";
    for (let y = 0; y < matrix.length; y += 1) {
      for (let x = 0; x < matrix.length; x += 1) {
        if (!matrix[y][x]) continue;
        const left = Math.floor((x + quiet) * cell);
        const top = Math.floor((y + quiet) * cell);
        const right = Math.ceil((x + quiet + 1) * cell);
        const bottom = Math.ceil((y + quiet + 1) * cell);
        ctx.fillRect(left, top, right - left, bottom - top);
      }
    }
  }

  async function stopQrScanner() {
    cancelAnimationFrame(runtime.qrScanRaf);
    runtime.qrScanRaf = 0;
    for (const track of runtime.qrStream?.getTracks?.() || []) {
      try { track.stop(); } catch {}
    }
    runtime.qrStream = null;
    const video = $("#qrScannerVideo");
    if (video) video.srcObject = null;
    $("#qrScannerArea")?.classList.add("hidden");
  }

  function usernameFromQr(raw) {
    const value = String(raw || "").trim();
    const direct = value.match(/^silknex:([a-z0-9_.]{3,24})$/i);
    if (direct) return direct[1].toLowerCase();
    try {
      const url = new URL(value, location.href);
      if (url.origin !== location.origin) return "";
      const pathHandle = url.pathname.match(/^\/@([a-z0-9_.-]{3,24})\/?$/i)?.[1] || "";
      const username = escapeUsername(pathHandle || url.searchParams.get("u") || url.searchParams.get("profile") || "");
      return /^[a-z0-9_.]{3,24}$/.test(username) ? username : "";
    } catch {
      return "";
    }
  }

  async function startQrScanner() {
    if (!navigator.mediaDevices?.getUserMedia || typeof BarcodeDetector === "undefined") {
      toast("QR camera scanning is not supported by this browser. Enter the username below instead.");
      $("#qrManualUsername")?.focus();
      return;
    }

    try {
      await stopQrScanner();
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      runtime.qrStream = stream;
      const video = $("#qrScannerVideo");
      const area = $("#qrScannerArea");
      area?.classList.remove("hidden");
      video.srcObject = stream;
      await video.play();
      const detector = new BarcodeDetector({ formats: ["qr_code"] });
      const scan = async () => {
        if (!runtime.qrStream || !video?.videoWidth) {
          runtime.qrScanRaf = requestAnimationFrame(scan);
          return;
        }
        try {
          const codes = await detector.detect(video);
          for (const code of codes) {
            const username = usernameFromQr(code.rawValue);
            if (!username) continue;
            await stopQrScanner();
            app()?.closeModal?.("profileQrModal");
            openPublicProfile(username);
            return;
          }
        } catch {}
        runtime.qrScanRaf = requestAnimationFrame(scan);
      };
      scan();
    } catch (error) {
      toast(error?.name === "NotAllowedError" ? "Camera access was not allowed." : "Could not start the QR scanner.");
    }
  }

  function showProfileQr(username) {
    const handle = escapeUsername(username);
    if (!handle) return;
    $("#profileQrHandle").textContent = `@${handle}`;
    drawQr($("#profileQrCanvas"), handle);
    app()?.openModal?.("#profileQrModal");
  }

  // ---------------------------------------------------------------------------
  // Public profiles + shareable handles
  // ---------------------------------------------------------------------------
  async function openPublicProfile(username, seed = null) {
    const handle = escapeUsername(username);
    const session = app()?.state?.me;
    if (!session || !/^[a-z0-9_.]{3,24}$/.test(handle)) return;
    const requestId = runtime.profileRequestId = (runtime.profileRequestId || 0) + 1;

    // Render a fast shell immediately when the caller already has identity data.
    renderPublicProfile({ profile: seed || { username: handle, display_name: "Loading profile…" }, friendship: {}, stories: [] }, true);
    try {
      const data = await app()?.api?.("public_profile", { showLoader: false, timeoutMs: 12000 }, { username: handle });
      if (requestId !== runtime.profileRequestId || app()?.state?.me !== session || $("#publicProfileModal")?.classList.contains("hidden")) return;
      if (data) renderPublicProfile(data, false);
    } catch (error) {
      if (requestId !== runtime.profileRequestId || app()?.state?.me !== session) return;
      $("#publicProfileName").textContent = "Profile unavailable";
      $("#publicProfileBio").textContent = error?.message || "Could not open that profile.";
    }
  }

  window.SilkNexOpenPublicProfile = openPublicProfile;

  function renderPublicProfile(data, provisional = false) {
    const profile = data?.profile || {};
    const handle = escapeUsername(profile.username);
    if (!handle) return;
    runtime.profile = data;

    const me = app()?.state?.me;
    const mine = Number(profile.id || 0) === Number(me?.id || 0) || handle === escapeUsername(me?.username);
    $("#publicProfileName").textContent = profile.display_name || handle;
    $("#publicProfileHandle").textContent = `@${handle}`;
    $("#publicProfileBio").textContent = String(profile.about || "").trim() || "No bio yet.";
    const staffBadge = $("#publicProfileFounderBadge");
    if (staffBadge) { staffBadge.textContent = String(profile.role || profile.account_role || "") === "cofounder_ceo" ? "CO-FOUNDER/CEO" : "FOUNDER/CEO"; staffBadge.classList.toggle("hidden", !["founder_ceo", "cofounder_ceo"].includes(String(profile.role || profile.account_role || ""))); }
    app()?.setAvatar?.(
      $("#publicProfileAvatar"),
      profile.display_name || handle,
      profile.accent || "silver",
      profile.avatar_url || "",
      profile.avatar_style || null
    );

    const banner = $("#publicProfileBanner");
    banner.style.backgroundImage = profile.profile_banner_url ? `url("${String(profile.profile_banner_url).replace(/["\\]/g, "")}")` : "";
    banner.classList.toggle("has-image", Boolean(profile.profile_banner_url));

    const mutualCount = Array.isArray(data?.mutual_friends) ? data.mutual_friends.length : 0;
    const storyCount = Array.isArray(data?.stories) ? data.stories.length : 0;
    const friendCount = Math.max(0, Number(data?.friend_count || 0));
    if ($("#publicProfileFriendCount")) $("#publicProfileFriendCount").textContent = friendCount.toLocaleString();
    if ($("#publicProfileMutualCount")) $("#publicProfileMutualCount").textContent = mutualCount.toLocaleString();
    if ($("#publicProfileStoryCount")) $("#publicProfileStoryCount").textContent = storyCount.toLocaleString();

    const aboutPanel = $("#publicProfileAboutPanel");
    if (aboutPanel) {
      aboutPanel.replaceChildren();
      const items = [
        ["Username", `@${handle}`],
        ["Status", profile.online ? "Online" : "Offline"],
        ["Friends", friendCount.toLocaleString()],
        ["Visible stories", storyCount.toLocaleString()],
        ...(!mine ? [["Mutual friends", mutualCount.toLocaleString()]] : []),
      ];
      for (const [label, value] of items) {
        const row = document.createElement("div");
        row.className = "public-profile-about-row";
        const key = document.createElement("small");
        key.textContent = label;
        const val = document.createElement("b");
        val.textContent = value;
        row.append(key, val);
        aboutPanel.appendChild(row);
      }
      const bio = document.createElement("p");
      bio.className = "public-profile-about-bio";
      bio.textContent = String(profile.about || "").trim() || "No bio yet.";
      aboutPanel.appendChild(bio);
    }

    const tabs = Array.from(document.querySelectorAll("#publicProfileModal [data-profile-tab]"));
    const panels = Array.from(document.querySelectorAll("#publicProfileModal [data-profile-panel]"));
    const selectTab = (name) => {
      tabs.forEach((button) => {
        const active = button.dataset.profileTab === name;
        button.classList.toggle("active", active);
        button.setAttribute("aria-selected", active ? "true" : "false");
      });
      panels.forEach((panel) => panel.classList.toggle("hidden", panel.dataset.profilePanel !== name));
    };
    tabs.forEach((button) => {
      button.onclick = () => selectTab(button.dataset.profileTab || "stories");
    });
    selectTab("stories");

    const messageButton = $("#publicProfileMessageBtn");
    if (messageButton) {
      messageButton.classList.toggle("hidden", mine);
      messageButton.disabled = provisional;
      messageButton.onclick = async () => {
        if (messageButton.disabled) return;
        messageButton.disabled = true;
        try {
          const created = await app().api("create_conversation", {
            method: "POST",
            body: { usernames: [handle] },
          });
          app().closeModal?.("publicProfileModal");
          await app().openConversation?.(Number(created.conversation_id));
        } catch (error) {
          toast(error?.message || "Could not start the chat.");
        } finally { messageButton.disabled = false; }
      };
    }

    $("#publicProfileEditBtn")?.classList.toggle("hidden", !mine);
    $("#publicProfileEditBtn").onclick = () => {
      app()?.closeModal?.("publicProfileModal");
      const settings = $("#settingsBtn");
      settings?.click?.();
    };

    $("#publicProfileQrBtn").onclick = () => showProfileQr(handle);
    $("#publicProfileAvatarBtn").onclick = () => {
      const url = profile.avatar_url || (profile.avatar_style ? app()?.avatarStyleDataUrl?.(profile.avatar_style) : "");
      if (url) app()?.openFullscreenMedia?.(url, "image", `${profile.display_name || handle} profile picture`);
    };

    let friendButton = $("#publicProfileFriendBtn");
    if (!friendButton) {
      friendButton = document.createElement("button");
      friendButton.id = "publicProfileFriendBtn";
      friendButton.type = "button";
      friendButton.className = "secondary-btn";
      $("#publicProfileMessageBtn")?.insertAdjacentElement("afterend", friendButton);
    }
    const status = String(data?.friendship?.status || "none");
    friendButton.classList.toggle("hidden", mine || provisional);
    friendButton.textContent = status === "accepted" ? "Friends" : status === "outgoing" ? "Requested" : status === "incoming" ? "Respond in Friends" : "Add friend";
    friendButton.disabled = status === "accepted" || status === "outgoing";
    friendButton.onclick = async () => {
      if (status === "incoming") {
        app()?.closeModal?.("publicProfileModal");
        app()?.openFriends?.();
        return;
      }
      try {
        await app().api("friend_request", { method: "POST", body: { user_id: Number(profile.id) } });
        toast("Friend request sent.");
        openPublicProfile(handle);
      } catch (error) {
        toast(error?.message || "Could not send friend request.");
      }
    };

    let mutualSection = $("#publicProfileMutuals");
    if (!mutualSection) {
      mutualSection = document.createElement("section");
      mutualSection.id = "publicProfileMutuals";
      mutualSection.className = "public-profile-mutuals hidden";
      const stats = $("#publicProfileStats");
      const bio = $("#publicProfileBio");
      if (stats) stats.insertAdjacentElement("afterend", mutualSection);
      else bio?.insertAdjacentElement("afterend", mutualSection);
    }
    const mutuals = Array.isArray(data?.mutual_friends) ? data.mutual_friends : [];
    mutualSection.replaceChildren();
    mutualSection.classList.toggle("hidden", mine || provisional || mutuals.length === 0);
    if (!mine && !provisional && mutuals.length) {
      const title = document.createElement("small");
      title.className = "public-profile-mutual-title";
      title.textContent = `${mutuals.length} mutual friend${mutuals.length === 1 ? "" : "s"}`;
      mutualSection.appendChild(title);
      const rail = document.createElement("div");
      rail.className = "public-profile-mutual-rail";
      for (const friend of mutuals.slice(0, 24)) {
        const card = document.createElement("button");
        card.type = "button";
        card.className = "public-profile-mutual";
        const avatar = document.createElement("div");
        avatar.className = "avatar";
        app()?.setAvatar?.(
          avatar,
          friend.display_name || friend.username || "Friend",
          friend.accent || "silver",
          friend.avatar_url || "",
          friend.avatar_style || null
        );
        const label = document.createElement("span");
        label.textContent = friend.display_name || `@${friend.username}`;
        card.append(avatar, label);
        card.addEventListener("click", () => openPublicProfile(friend.username, friend));
        rail.appendChild(card);
      }
      mutualSection.appendChild(rail);
    }

    const stories = $("#publicProfileStories");
    stories.replaceChildren();
    for (const story of data?.stories || []) {
      const tile = document.createElement("button");
      tile.type = "button";
      tile.className = "public-story-tile";
      tile.setAttribute("aria-label", `Open ${profile.display_name || handle}'s story`);
      const media = document.createElement(story.media_type === "video" ? "video" : "img");
      media.src = story.media_url;
      media.loading = "lazy";
      media.muted = true;
      media.playsInline = true;
      media.preload = story.media_type === "video" ? "metadata" : undefined;
      tile.appendChild(media);
      const visibility = document.createElement("span");
      visibility.textContent = story.visibility === "public" ? "Public" : story.visibility === "custom" ? "Selected" : "Friends";
      tile.appendChild(visibility);
      if (story.caption) {
        const caption = document.createElement("span");
        caption.textContent = String(story.caption).slice(0, 80);
        tile.appendChild(caption);
      }
      tile.addEventListener("click", () => app()?.openFullscreenMedia?.(story.media_url, story.media_type, "Story"));
      stories.appendChild(tile);
    }
    if (!stories.children.length && !provisional) {
      const empty = document.createElement("small");
      empty.className = "public-profile-empty";
      empty.textContent = "No active stories visible to you.";
      stories.appendChild(empty);
    }

    const posts = $("#publicProfilePosts");
    if (posts) {
      posts.replaceChildren();
      if (mine && !provisional) {
        const composer = document.createElement("form");
        composer.className = "public-post-composer";
        const entry = document.createElement("textarea");
        entry.maxLength = 2000;
        entry.rows = 3;
        entry.placeholder = "Share an update, image, or video";
        entry.setAttribute("aria-label", "Post text");
        const file = document.createElement("input");
        file.type = "file";
        file.accept = "image/*,video/*";
        file.setAttribute("aria-label", "Post image or video");
        const submit = document.createElement("button");
        submit.type = "submit";
        submit.className = "primary";
        submit.textContent = "Post to profile";
        composer.append(entry, file, submit);
        composer.addEventListener("submit", async (event) => {
          event.preventDefault();
          if (!entry.value.trim() && !file.files?.length) return;
          submit.disabled = true;
          try {
            let uploadToken = "";
            if (file.files?.[0]) {
              const uploaded = await app().uploadFile(file.files[0], "story");
              uploadToken = uploaded.token;
            }
            await app().api("profile_post_create", { method: "POST", body: { body: entry.value.trim(), upload_token: uploadToken } });
            await openPublicProfile(handle);
            $("#publicProfileModal [data-profile-tab='posts']")?.click();
            toast("Post shared.");
          } catch (error) { toast(error?.message || "Could not share post."); }
          finally { submit.disabled = false; }
        });
        posts.appendChild(composer);
      }
      for (const post of data?.posts || []) {
        const card = document.createElement("article");
        card.className = "public-post-card";
        const date = document.createElement("time");
        date.textContent = new Date(Number(post.created_at) * 1000).toLocaleDateString();
        card.appendChild(date);
        if (post.body) {
          const body = document.createElement("p");
          body.textContent = post.body;
          card.appendChild(body);
        }
        if (post.media_url) {
          const media = document.createElement(post.media_type === "video" ? "video" : "img");
          media.src = post.media_url;
          if (media instanceof HTMLVideoElement) { media.controls = true; media.preload = "metadata"; media.playsInline = true; }
          else { media.alt = "Profile post"; media.loading = "lazy"; }
          card.appendChild(media);
        }
        if (mine) {
          const remove = document.createElement("button");
          remove.type = "button";
          remove.className = "secondary-btn";
          remove.textContent = "Delete post";
          remove.addEventListener("click", async () => {
            if (!confirm("Delete this post?")) return;
            remove.disabled = true;
            try { await app().api("profile_post_delete", { method: "POST", body: { id: post.id } }); await openPublicProfile(handle); $("#publicProfileModal [data-profile-tab='posts']")?.click(); }
            catch (error) { toast(error?.message || "Could not delete post."); remove.disabled = false; }
          });
          card.appendChild(remove);
        }
        posts.appendChild(card);
      }
      if (!posts.children.length && !provisional) {
        const empty = document.createElement("small");
        empty.className = "public-profile-empty";
        empty.textContent = "No posts yet.";
        posts.appendChild(empty);
      }
    }

    app()?.openModal?.("#publicProfileModal");
  }

  async function uploadProfileBanner(file) {
    if (!file || !/^image\//i.test(file.type)) return;
    const prepared = await app()?.optimizeMessageMedia?.(file) || file;
    const data = new FormData();
    data.append("purpose", "banner");
    data.append("file", prepared, prepared.name || file.name || "banner.jpg");
    try {
      const uploaded = await app().api("upload", { method: "POST", body: data, timeoutMs: 300000 });
      const result = await app().api("public_profile_settings", {
        method: "POST",
        body: { banner_token: uploaded.token },
      });
      if (app()?.state?.me) app().state.me.profile_banner_url = result.profile_banner_url || "";
      toast("Profile banner updated.");
      openPublicProfile(app()?.state?.me?.username);
    } catch (error) {
      toast(error?.message || "Could not update profile banner.");
    }
  }

  function installPublicProfileSettings() {
    const settings = $("#settingsModal .settings-stack, #settingsModal .modal-card");
    if (!settings || $("#v53PublicProfileSettings")) return;
    const section = document.createElement("section");
    section.id = "v53PublicProfileSettings";
    section.className = "settings-section v53-settings-section";
    section.innerHTML = `
      <div class="section-title"><span>Public profile</span></div>
      <div class="setting-row"><div><b>Public profile</b><small>Let signed-in Silknex users discover your bio, banner, avatar and public stories.</small></div><label class="switch"><input id="v53PublicProfileToggle" type="checkbox" aria-label="Public profile"><span></span></label></div>
      <div class="v53-profile-settings-actions">
        <button id="v53ViewProfileBtn" class="secondary-btn" type="button">View my profile</button>
        <button id="v53MyQrBtn" class="secondary-btn" type="button">My QR code</button>
        <button id="v53BannerBtn" class="secondary-btn" type="button">Choose banner image</button>
        ${$("#v53BannerInput") ? "" : '<input id="v53BannerInput" class="hidden" type="file" accept="image/jpeg,image/png,image/webp,image/gif">'}
      </div>`;
    settings.appendChild(section);

    const toggle = $("#v53PublicProfileToggle");
    toggle.checked = Boolean(app()?.state?.me?.public_profile ?? true);
    toggle.addEventListener("change", async () => {
      try {
        await app().api("public_profile_settings", { method: "POST", body: { public_profile: toggle.checked } });
        if (app()?.state?.me) app().state.me.public_profile = toggle.checked;
        toast(toggle.checked ? "Public profile is on." : "Public profile is friends-only.");
      } catch (error) {
        toggle.checked = !toggle.checked;
        toast(error?.message || "Could not update profile privacy.");
      }
    });
    $("#v53ViewProfileBtn").onclick = () => openPublicProfile(app()?.state?.me?.username);
    $("#v53MyQrBtn").onclick = () => showProfileQr(app()?.state?.me?.username);
    $("#v53BannerBtn").onclick = () => $("#v53BannerInput")?.click();
    $("#v53BannerInput").onchange = (event) => uploadProfileBanner(event.currentTarget.files?.[0]);
  }

  // ---------------------------------------------------------------------------
  // Story audience + preloading
  // ---------------------------------------------------------------------------
  function ensureStoryAudienceModal() {
    if ($("#storyAudienceModal")) return;
    const modal = document.createElement("section");
    modal.id = "storyAudienceModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.innerHTML = `
      <div class="modal-card small">
        <header class="modal-head"><div><small>STORY PRIVACY</small><h2>Selected friends</h2></div><button class="plain-btn close-modal icon-only" type="button" aria-label="Close" data-icon="close"></button></header>
        <div id="storyAudienceFriends" class="story-audience-friends"></div>
        <button id="saveStoryAudienceBtn" class="primary wide" type="button">Use selected friends</button>
      </div>`;
    document.body.appendChild(modal);
    modal.querySelector(".close-modal").addEventListener("click", () => app()?.closeModal?.("storyAudienceModal"));
    modal.querySelector("#saveStoryAudienceBtn").addEventListener("click", () => {
      runtime.storyAudienceIds = $$('input[type="checkbox"]:checked', modal)
        .map((input) => Number(input.value))
        .filter((id) => id > 0)
        .slice(0, 100);
      updateStoryAudienceSummary();
      app()?.closeModal?.("storyAudienceModal");
    });
  }

  function updateStoryAudienceSummary() {
    const select = $("#storyAudience");
    const button = $("#storyAudienceChooseBtn");
    const summary = $("#storyAudienceSummary");
    const custom = select?.value === "custom";
    button?.classList.toggle("hidden", !custom);
    summary?.classList.toggle("hidden", !custom);
    if (summary && custom) {
      summary.textContent = runtime.storyAudienceIds.length
        ? `${runtime.storyAudienceIds.length} friend${runtime.storyAudienceIds.length === 1 ? "" : "s"} selected`
        : "Choose at least one friend.";
    }
  }

  async function chooseStoryAudience() {
    ensureStoryAudienceModal();
    if (!app()?.state?.friendsLoaded) {
      try { await app()?.loadFriends?.({ notify: false }); } catch {}
    }
    const list = $("#storyAudienceFriends");
    list.replaceChildren();
    for (const item of app()?.state?.friends || []) {
      const person = item.person || item;
      if (!person?.id) continue;
      const row = document.createElement("label");
      row.className = "story-audience-person";
      const avatar = document.createElement("div");
      app()?.setAvatar?.(avatar, person.display_name, person.accent, person.avatar_url, person.avatar_style);
      const copy = document.createElement("span");
      copy.innerHTML = `<b></b><small></small>`;
      copy.querySelector("b").textContent = person.display_name || person.username;
      copy.querySelector("small").textContent = `@${person.username}`;
      const check = document.createElement("input");
      check.type = "checkbox";
      check.value = String(person.id);
      check.checked = runtime.storyAudienceIds.includes(Number(person.id));
      row.append(avatar, copy, check);
      list.appendChild(row);
    }
    if (!list.children.length) {
      list.textContent = "Add friends before using a selected-friends story.";
    }
    app()?.openModal?.("#storyAudienceModal");
  }

  function bindStoryPrivacy() {
    $("#storyAudience")?.addEventListener("change", updateStoryAudienceSummary);
    $("#storyAudienceChooseBtn")?.addEventListener("click", chooseStoryAudience);
    updateStoryAudienceSummary();

    // Preload only the next couple of story assets; this makes taps feel
    // immediate without downloading the entire feed into RAM.
    window.addEventListener("silknex:modal", () => {
      const groups = app()?.state?.storyGroups || [];
      for (const group of groups.slice(0, 4)) {
        for (const story of (group.stories || []).slice(0, 2)) {
          if (!story?.media_url || story.media_type === "video") continue;
          const image = new Image();
          image.decoding = "async";
          image.src = story.media_url;
        }
      }
    }, { passive: true });
  }

  // ---------------------------------------------------------------------------
  // GIPHY sticker browser
  // ---------------------------------------------------------------------------
  async function giphyKey() {
    const cached = String(app()?.state?.giphySdkKey || "");
    if (cached) return cached;
    try {
      const data = await app()?.api?.("giphy_config", { showLoader: false });
      return data?.enabled ? String(data.sdk_key || "") : "";
    } catch {
      return "";
    }
  }

  function giphyStickerImage(item) {
    return item?.images?.fixed_width_small?.webp ||
      item?.images?.fixed_width?.webp ||
      item?.images?.downsized_medium?.url ||
      item?.images?.original?.webp ||
      item?.images?.original?.url || "";
  }

  function giphyStickerSendUrl(item) {
    return item?.images?.original?.webp ||
      item?.images?.original?.url ||
      giphyStickerImage(item);
  }

  async function loadGiphyStickers(query = "") {
    const request = ++runtime.giphyStickerRequest;
    const results = $("#giphyStickerResults");
    const status = $("#giphyStickerStatus");
    const key = await giphyKey();
    if (request !== runtime.giphyStickerRequest) return;
    results?.replaceChildren();
    if (!key) {
      if (status) status.textContent = "Add a GIPHY SDK key in config.php";
      return;
    }

    const exact = String(query || "").trim().slice(0, 50);
    if (status) status.textContent = exact ? `Searching “${exact}”` : "Trending stickers";
    const endpoint = exact ? "search" : "trending";
    const params = new URLSearchParams({ api_key: key, limit: "24", rating: "pg-13" });
    if (exact) params.set("q", exact);
    try {
      const response = await fetch(`https://api.giphy.com/v1/stickers/${endpoint}?${params}`, {
        mode: "cors",
        credentials: "omit",
        referrerPolicy: "strict-origin-when-cross-origin",
      });
      if (!response.ok) throw new Error("GIPHY request failed");
      const payload = await response.json();
      if (request !== runtime.giphyStickerRequest) return;
      const items = Array.isArray(payload?.data) ? payload.data : [];
      for (const item of items) {
        const preview = giphyStickerImage(item);
        const sendUrl = giphyStickerSendUrl(item);
        if (!preview || !sendUrl) continue;
        const button = document.createElement("button");
        button.type = "button";
        button.className = "giphy-sticker-tile";
        button.title = item.title || "GIPHY sticker";
        const image = document.createElement("img");
        image.src = preview;
        image.alt = item.title || "Sticker";
        image.loading = "lazy";
        image.decoding = "async";
        button.appendChild(image);
        button.addEventListener("click", async () => {
          const conversationId = Number(app()?.state?.activeId || 0);
          if (!conversationId) return;
          button.disabled = true;
          try {
            const success = await app()?.sendPreparedMessage?.({
              conversationId,
              externalGif: {
                id: String(item.id || ""),
                url: sendUrl,
                title: String(item.title || "GIPHY sticker").slice(0, 120),
              },
              optimisticMedia: {
                message_type: "sticker",
                attachment_url: preview,
                attachment_name: item.title || "GIPHY sticker",
              },
              replyToId: app()?.state?.replyTo?.id || null,
            });
            if (success) app()?.closeModal?.("stickerLibraryModal");
          } catch (error) {
            toast(error?.message || "Could not send sticker.");
          } finally {
            button.disabled = false;
          }
        });
        results.appendChild(button);
      }
      if (status) status.textContent = exact ? `Sticker results for “${exact}”` : "Trending stickers";
    } catch {
      if (status) status.textContent = "Could not load GIPHY stickers";
    }
  }

  function bindStickerTabs() {
    const mine = $("#myStickerTab");
    const giphy = $("#giphyStickerTab");
    const panel = $("#giphyStickerPanel");
    const ownGrid = $("#stickerLibrary");
    const ownEmpty = $("#stickerEmpty");
    const ownCreate = $("#createBlankStickerBtn");
    const switchTab = (tab) => {
      const external = tab === "giphy";
      mine?.classList.toggle("active", !external);
      giphy?.classList.toggle("active", external);
      mine?.setAttribute("aria-selected", external ? "false" : "true");
      giphy?.setAttribute("aria-selected", external ? "true" : "false");
      panel?.classList.toggle("hidden", !external);
      ownGrid?.classList.toggle("hidden", external);
      ownEmpty?.classList.toggle("v53-tab-suppressed", external);
      ownCreate?.classList.toggle("hidden", external);
      if (external) loadGiphyStickers($("#giphyStickerSearch")?.value || "");
    };
    mine?.addEventListener("click", () => switchTab("mine"));
    giphy?.addEventListener("click", () => switchTab("giphy"));
    let timer = 0;
    $("#giphyStickerSearch")?.addEventListener("input", (event) => {
      clearTimeout(timer);
      timer = setTimeout(() => loadGiphyStickers(event.currentTarget.value), 220);
    });
  }

  // ---------------------------------------------------------------------------
  // Avatar Studio visual option cards
  // ---------------------------------------------------------------------------
  const avatarCardFields = {
    avatarFaceShape: "face_shape",
    avatarEyes: "eyes",
    avatarHair: "hair",
    avatarOutfit: "outfit",
    avatarAccessory: "accessory",
    avatarHeadwear: "headwear",
    avatarFacialHair: "facial_hair",
    avatarBackground: "background",
  };

  function currentAvatarStyle() {
    const stateStyle = { ...(app()?.state?.avatarStyleDraft || app()?.state?.me?.avatar_style || {}) };
    const ids = {
      skin: "avatarSkin", face_shape: "avatarFaceShape", hair: "avatarHair",
      hair_color: "avatarHairColor", eye_color: "avatarEyeColor", eyes: "avatarEyes",
      brows: "avatarBrows", nose: "avatarNose", mouth: "avatarMouth",
      face_detail: "avatarFaceDetail", outfit: "avatarOutfit",
      outfit_color: "avatarOutfitColor", outfit_pattern: "avatarOutfitPattern",
      background: "avatarBackground", background_pattern: "avatarBackgroundPattern",
      accessory: "avatarAccessory", accessory_color: "avatarAccessoryColor",
      headwear: "avatarHeadwear", facial_hair: "avatarFacialHair",
      face_width: "avatarFaceWidth", face_length: "avatarFaceLength", jaw_width: "avatarJawWidth",
      eye_scale: "avatarEyeScale", eye_spacing: "avatarEyeSpacing", eye_height: "avatarEyeHeight",
      nose_scale: "avatarNoseScale", mouth_width: "avatarMouthWidth", brow_height: "avatarBrowHeight",
      ear_size: "avatarEarSize", neck_width: "avatarNeckWidth",
      skin_hex: "avatarSkinHex", hair_hex: "avatarHairHex", eye_hex: "avatarEyeHex",
      lip_hex: "avatarLipHex", outfit_hex: "avatarOutfitHex",
      background_hex: "avatarBackgroundHex", accessory_hex: "avatarAccessoryHex",
    };
    for (const [key, id] of Object.entries(ids)) {
      const field = $(`#${id}`);
      if (field) stateStyle[key] = field.value;
    }
    return stateStyle;
  }

  function refreshAvatarCardSelections() {
    for (const [id] of Object.entries(avatarCardFields)) {
      const select = $(`#${id}`);
      const grid = select?.parentElement?.querySelector(".v53-avatar-options");
      if (!select || !grid) continue;
      $$("[data-avatar-value]", grid).forEach((card) => {
        const selected = card.dataset.avatarValue === select.value;
        card.classList.toggle("selected", selected);
        card.setAttribute("aria-pressed", selected ? "true" : "false");
      });
    }
  }

  function buildAvatarChoiceCards() {
    if (runtime.avatarCardsBuilt || !app()?.avatarStyleDataUrl) return;
    runtime.avatarCardsBuilt = true;
    for (const [id, styleKey] of Object.entries(avatarCardFields)) {
      const select = $(`#${id}`);
      if (!select || select.dataset.visualized === "1") continue;
      select.dataset.visualized = "1";
      select.classList.add("v53-avatar-select-fallback");
      const grid = document.createElement("div");
      grid.className = "v53-avatar-options";
      grid.setAttribute("role", "group");
      grid.setAttribute("aria-label", select.closest("label")?.querySelector("span")?.textContent || "Avatar choices");
      for (const option of Array.from(select.options)) {
        const card = document.createElement("button");
        card.type = "button";
        card.className = "v53-avatar-option";
        card.dataset.avatarValue = option.value;
        const sample = { ...currentAvatarStyle(), [styleKey]: option.value };
        const image = document.createElement("img");
        image.alt = "";
        image.loading = "lazy";
        image.decoding = "async";
        image.src = app().avatarStyleDataUrl(sample);
        const label = document.createElement("span");
        label.textContent = option.textContent;
        card.append(image, label);
        card.addEventListener("click", () => {
          select.value = option.value;
          select.dispatchEvent(new Event("change", { bubbles: true }));
          refreshAvatarCardSelections();
          // Refresh previews for neighboring choices so color/skin edits are
          // represented before the next selection.
          requestAnimationFrame(() => refreshAvatarCardPreviews(id, styleKey));
        });
        grid.appendChild(card);
      }
      select.insertAdjacentElement("afterend", grid);
    }
    refreshAvatarCardSelections();
  }

  function refreshAvatarCardPreviews(id, styleKey) {
    const select = $(`#${id}`);
    const grid = select?.parentElement?.querySelector(".v53-avatar-options");
    if (!grid || !app()?.avatarStyleDataUrl) return;
    for (const card of $$("[data-avatar-value]", grid)) {
      const image = card.querySelector("img");
      if (image) image.src = app().avatarStyleDataUrl({
        ...currentAvatarStyle(),
        [styleKey]: card.dataset.avatarValue,
      });
    }
  }

  function bindAvatarCards() {
    $("#avatarBuilder")?.addEventListener("click", () => requestAnimationFrame(buildAvatarChoiceCards), { once: true });
    $("#customAvatarBtn")?.addEventListener("click", () => setTimeout(buildAvatarChoiceCards, 0));
    $("#avatarBuilder")?.addEventListener("change", () => {
      refreshAvatarCardSelections();
    });
  }

  // ---------------------------------------------------------------------------
  // Personal autocorrect dictionary
  // ---------------------------------------------------------------------------
  const PROTECTED_WORDS_KEY = "silknex-autocorrect-protected-v1";

  function protectedWords() {
    try {
      return Array.from(new Set(
        String(window.SilknexStorage.getItem(PROTECTED_WORDS_KEY) || "")
          .split(/[\s,\n]+/u)
          .map((word) => word.trim())
          .filter((word) => /^[A-Za-z0-9'_.-]{1,40}$/u.test(word))
      )).slice(0, 300);
    } catch {
      return [];
    }
  }

  function saveProtectedWords(words) {
    const normalized = Array.from(new Set(words.map((word) => word.trim()).filter(Boolean))).slice(0, 300);
    try { window.SilknexStorage.setItem(PROTECTED_WORDS_KEY, normalized.join("\n")); } catch {}
    renderProtectedWords();
  }

  function renderProtectedWords() {
    const list = $("#v53ProtectedWordsList");
    if (!list) return;
    list.replaceChildren();
    for (const word of protectedWords()) {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "v53-word-chip";
      chip.title = "Remove from never-correct list";
      chip.textContent = `${word} ×`;
      chip.onclick = () => saveProtectedWords(protectedWords().filter((item) => item !== word));
      list.appendChild(chip);
    }
    if (!list.children.length) {
      const hint = document.createElement("small");
      hint.textContent = "No protected words yet.";
      list.appendChild(hint);
    }
  }

  function installAutocorrectDictionaryUi() {
    if ($("#v53AutocorrectDictionary")) return;
    const existing = $("#openTextReplacementsBtn")?.closest(".settings-section") || $("#settingsModal .settings-stack");
    if (!existing) return;
    const box = document.createElement("div");
    box.id = "v53AutocorrectDictionary";
    box.className = "v53-autocorrect-dictionary";
    box.innerHTML = `
      <div><b>Never autocorrect</b><small>Add names, slang, game terms, or words that match your typing style.</small></div>
      <div class="v53-word-add"><input id="v53ProtectedWordInput" maxlength="40" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="Add a word"><button id="v53AddProtectedWordBtn" class="secondary-btn" type="button">Add</button></div>
      <div id="v53ProtectedWordsList" class="v53-word-chips"></div>`;
    existing.appendChild(box);
    const add = () => {
      const input = $("#v53ProtectedWordInput");
      const word = String(input?.value || "").trim();
      if (!/^[A-Za-z0-9'_.-]{1,40}$/u.test(word)) {
        toast("Enter one word, name, or handle.");
        return;
      }
      saveProtectedWords([...protectedWords(), word]);
      input.value = "";
    };
    $("#v53AddProtectedWordBtn").onclick = add;
    $("#v53ProtectedWordInput").addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        add();
      }
    });
    renderProtectedWords();
  }

  // ---------------------------------------------------------------------------
  // Founder-only additions: privacy health and manual maintenance
  // ---------------------------------------------------------------------------
  async function installFounderV53() {
    if (!isFounder() || runtime.founderBound) return;
    runtime.founderBound = true;
    const host = $("#ownerControlCenterModal .owner-dashboard, #ownerControlCenterModal .modal-card, #founderControlCenter .modal-card");
    if (!host || $("#v53FounderTools")) return;

    const section = document.createElement("section");
    section.id = "v53FounderTools";
    section.className = "owner-panel-section v53-founder-tools";
    section.innerHTML = `
      <div class="section-title"><span>Founder privacy & maintenance</span></div>
      <div id="v53FounderPrivacyHealth" class="v53-founder-health"><small>Load privacy health to inspect encryption-device coverage without reading private content.</small></div>
      <div class="v53-founder-actions">
        <button id="v53FounderPrivacyRefresh" class="secondary-btn" type="button">Refresh privacy health</button>
        <button id="v53FounderMaintenanceRun" class="secondary-btn" type="button">Run safe cleanup now</button>
      </div>`;
    host.appendChild(section);

    const refresh = async () => {
      const target = $("#v53FounderPrivacyHealth");
      target.textContent = "Loading…";
      try {
        const data = await app().api("owner_privacy_health", { showLoader: false });
        const health = data.health || {};
        target.replaceChildren();
        for (const [label, value] of [
          ["Accounts", health.accounts],
          ["Accounts with E2EE device", health.accounts_with_e2ee_device],
          ["Active E2EE devices", health.active_e2ee_devices],
          ["Public profiles", health.public_profiles],
          ["Active public stories", health.active_public_stories],
          ["Encrypted message rows (24h)", health.encrypted_messages_24h],
        ]) {
          const card = document.createElement("div");
          card.innerHTML = `<small></small><b></b>`;
          card.querySelector("small").textContent = label;
          card.querySelector("b").textContent = Number(value || 0).toLocaleString();
          target.appendChild(card);
        }
      } catch (error) {
        target.textContent = error?.message || "Could not load privacy health.";
      }
    };
    $("#v53FounderPrivacyRefresh").onclick = refresh;
    $("#v53FounderMaintenanceRun").onclick = async () => {
      try {
        const data = await app().api("owner_maintenance_run", { method: "POST", body: {} });
        toast(`Cleanup complete · ${Number(data.expired_stories || 0)} expired stories and ${Number(data.expired_messages || 0)} expired messages removed.`);
        refresh();
      } catch (error) {
        toast(error?.message || "Could not run cleanup.");
      }
    };
    refresh();
  }

  // ---------------------------------------------------------------------------
  // App install polish + startup deep links
  // ---------------------------------------------------------------------------
  function applyStandaloneClass() {
    const standalone = window.matchMedia?.("(display-mode: standalone)")?.matches || navigator.standalone === true;
    document.documentElement.classList.toggle("silknex-installed", Boolean(standalone));
  }

  function bindGlobalActions() {
    $("#scanProfileQrBtn")?.addEventListener("click", startQrScanner);
    $("#stopQrScannerBtn")?.addEventListener("click", stopQrScanner);
    $("#qrManualOpenBtn")?.addEventListener("click", () => {
      const username = escapeUsername($("#qrManualUsername")?.value);
      if (!/^[a-z0-9_.]{3,24}$/.test(username)) {
        toast("Enter a valid Silknex username.");
        return;
      }
      stopQrScanner();
      app()?.closeModal?.("profileQrModal");
      openPublicProfile(username);
    });
    window.addEventListener("silknex:modal", (event) => {
      if (event.detail?.open === false || event.detail?.id !== "profileQrModal") stopQrScanner();
    });

    const params = new URLSearchParams(location.search);
    const pathHandle = location.pathname.match(/^\/@([a-z0-9_.-]{3,24})\/?$/i)?.[1] || "";
    const username = escapeUsername(pathHandle || params.get("u") || params.get("profile") || "");
    if (username) {
      if (app()?.state?.me) setTimeout(() => openPublicProfile(username), 0);
      else {
        const afterSignIn = (event) => {
          if (!event.detail?.signedIn) return;
          window.removeEventListener("silknex:session", afterSignIn);
          setTimeout(() => openPublicProfile(username), 0);
        };
        window.addEventListener("silknex:session", afterSignIn);
      }
    }

    window.matchMedia?.("(display-mode: standalone)")?.addEventListener?.("change", applyStandaloneClass);
    applyStandaloneClass();
  }

  function initWhenReady() {
    if (!app()) {
      window.addEventListener("silknex:core-ready", initWhenReady, { once: true });
      return;
    }
    document.documentElement.dataset.silknexRelease = VERSION;
    bindGlobalActions();
    bindStoryPrivacy();
    bindStickerTabs();
    bindAvatarCards();

    // Delay settings-only enhancements until after authentication hydration.
    const finish = () => {
      installPublicProfileSettings();
      installAutocorrectDictionaryUi();
      installFounderV53();
    };
    setTimeout(finish, 250);
    window.addEventListener("silknex:session", finish);
    window.addEventListener("silknex:owner-ready", installFounderV53);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initWhenReady, { once: true });
  } else {
    initWhenReady();
  }
})();

} catch (error) { console.error("Silknex feature module 53:", error); }

;
/* Feature module 54 */
try {
(() => {
  "use strict";

  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const root = document.documentElement;

  const app = () => window.SilknexApp || null;
  let referenceUrl = "";
  let adResizeObserver = null;
  let chatObserver = null;
  let gesturePointer = null;

  function isMobile() {
    return Boolean(window.matchMedia?.("(max-width: 900px), (pointer: coarse) and (max-height: 540px)")?.matches);
  }

  function chatOpen() {
    return Boolean(
      Number(app()?.state?.activeId || 0) > 0 &&
      !$("#chatView")?.classList.contains("hidden")
    );
  }

  function updateSurfaceState() {
    const open = chatOpen();
    root.dataset.v54ChatOpen = open ? "1" : "0";
    $("#appView")?.classList.toggle("desktop-chat-active", open && !isMobile());

    if (!isMobile()) {
      $("#mobileNav")?.querySelectorAll(".mobile-nav-item")
        .forEach((button) => button.removeAttribute("data-v54-active"));
    }
  }

  function setMobileShortcutActive(id) {
    if (!isMobile()) return;
    $$("#mobileNav .mobile-nav-item").forEach((button) => {
      const active = button.id === id;
      button.classList.toggle("active", active);
      button.toggleAttribute("data-v54-active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
  }

  function bindMobileShortcuts() {
    const nav = $("#mobileNav");
    if (!nav || nav.dataset.v54Bound === "1") return;
    nav.dataset.v54Bound = "1";

    const stories = $("#mobileStoriesBtn");
    if (stories) {
      stories.addEventListener("click", () => {
        if (!isMobile()) return;
        setMobileShortcutActive("mobileStoriesBtn");
        const panel = $(".stories-panel");
        panel?.classList.add("v54-stories-attention");
        panel?.scrollIntoView?.({ behavior: "smooth", block: "start" });
        setTimeout(() => panel?.classList.remove("v54-stories-attention"), 700);
        const target = $("#storiesRail button, #storiesRail [role='button']");
        target?.focus?.({ preventScroll: true });
      });
    }

    $("#mobileChatsBtn")?.addEventListener("click", () => setMobileShortcutActive("mobileChatsBtn"));
    $("#mobileFriendsBtn")?.addEventListener("click", () => setMobileShortcutActive("mobileFriendsBtn"));
    $("#mobileNewChatBtn")?.addEventListener("click", () => setMobileShortcutActive("mobileNewChatBtn"));
    $("#mobileSettingsBtn")?.addEventListener("click", () => setMobileShortcutActive("mobileSettingsBtn"));
  }

  function bindEdgeBackGesture() {
    const view = $("#chatView");
    if (!view || view.dataset.v54GestureBound === "1") return;
    view.dataset.v54GestureBound = "1";

    const cancel = () => {
      gesturePointer = null;
      view.style.removeProperty("--v54-edge-progress");
      view.classList.remove("v54-edge-back");
    };

    view.addEventListener("pointerdown", (event) => {
      if (!isMobile() || !chatOpen()) return;
      if (event.pointerType === "mouse") return;
      if (event.clientX > 26) return;
      gesturePointer = {
        id: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        x: event.clientX,
      };
    }, { passive: true });

    view.addEventListener("pointermove", (event) => {
      if (!gesturePointer || gesturePointer.id !== event.pointerId) return;
      const dx = event.clientX - gesturePointer.startX;
      const dy = event.clientY - gesturePointer.startY;
      if (Math.abs(dy) > Math.max(20, dx * .65)) {
        cancel();
        return;
      }
      if (dx <= 0) return;
      gesturePointer.x = event.clientX;
      const progress = Math.max(0, Math.min(1, dx / 110));
      view.style.setProperty("--v54-edge-progress", progress.toFixed(3));
      view.classList.toggle("v54-edge-back", progress > .05);
    }, { passive: true });

    view.addEventListener("pointerup", (event) => {
      if (!gesturePointer || gesturePointer.id !== event.pointerId) return;
      const dx = event.clientX - gesturePointer.startX;
      const dy = Math.abs(event.clientY - gesturePointer.startY);
      const shouldClose = dx >= 72 && dy <= 56;
      cancel();
      if (shouldClose) {
        try { navigator.vibrate?.(10); } catch {}
        app()?.closeMobileChat?.();
      }
    });

    view.addEventListener("pointercancel", cancel);
  }

  function bindReferencePhoto() {
    const input = $("#avatarReferenceInput");
    const button = $("#avatarReferenceBtn");
    const preview = $("#avatarReferencePreview");
    const image = $("#avatarReferenceImage");
    const clear = $("#avatarReferenceClear");
    if (!input || !button || !preview || !image || button.dataset.v54Bound === "1") return;
    button.dataset.v54Bound = "1";

    const reset = () => {
      if (referenceUrl) {
        try { URL.revokeObjectURL(referenceUrl); } catch {}
      }
      referenceUrl = "";
      input.value = "";
      image.removeAttribute("src");
      preview.classList.add("hidden");
      button.classList.remove("hidden");
    };

    button.addEventListener("click", () => input.click());
    clear?.addEventListener("click", reset);
    input.addEventListener("change", () => {
      const file = input.files?.[0];
      if (!file || !/^image\/(?:jpeg|png|webp)$/i.test(file.type)) {
        reset();
        if (file) app()?.toast?.("Choose a JPEG, PNG, or WebP reference photo.");
        return;
      }
      if (file.size > 16 * 1024 * 1024) {
        reset();
        app()?.toast?.("Reference photos must be 16 MB or smaller.");
        return;
      }
      if (referenceUrl) {
        try { URL.revokeObjectURL(referenceUrl); } catch {}
      }
      referenceUrl = URL.createObjectURL(file);
      image.src = referenceUrl;
      preview.classList.remove("hidden");
      button.classList.add("hidden");
    });

    window.addEventListener("pagehide", () => {
      if (referenceUrl) {
        try { URL.revokeObjectURL(referenceUrl); } catch {}
        referenceUrl = "";
      }
    }, { once: true });
  }

  function updateMobileAdSpace() {
    const anchor = $("#mobileHomeAdAnchor");
    if (!anchor) return;
    const slot = $("#homeAdSlot");
    const visible = Boolean(
      isMobile() &&
      slot &&
      slot.parentElement === anchor &&
      !slot.classList.contains("hidden") &&
      slot.getBoundingClientRect().height > 1
    );
    const height = visible ? Math.ceil(anchor.getBoundingClientRect().height) : 0;
    root.style.setProperty("--v54-mobile-ad-h", `${Math.min(118, Math.max(0, height))}px`);
    root.dataset.v54MobileAd = visible ? "1" : "0";
  }

  function observeMobileAd() {
    const anchor = $("#mobileHomeAdAnchor");
    if (!anchor) return;
    try { adResizeObserver?.disconnect?.(); } catch {}
    if (typeof ResizeObserver === "function") {
      adResizeObserver = new ResizeObserver(updateMobileAdSpace);
      adResizeObserver.observe(anchor);
      const slot = $("#homeAdSlot");
      if (slot) adResizeObserver.observe(slot);
    }
    new MutationObserver(updateMobileAdSpace).observe(anchor, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style"],
    });
    updateMobileAdSpace();
  }

  function observeChatSurface() {
    const chat = $("#chatView");
    if (!chat) return;
    try { chatObserver?.disconnect?.(); } catch {}
    chatObserver = new MutationObserver(() => {
      updateSurfaceState();
      requestAnimationFrame(updateMobileAdSpace);
    });
    chatObserver.observe(chat, { attributes: true, attributeFilter: ["class"] });
    updateSurfaceState();
  }

  function polishAvatarLabels() {
    const builder = $("#avatarBuilder");
    if (!builder || builder.dataset.v54Polished === "1") return;
    builder.dataset.v54Polished = "1";

    // Give range sliders live numeric feedback without adding another data model.
    $$(".avatar-feature-controls input[type='range']", builder).forEach((input) => {
      const label = input.closest("label");
      const text = label?.querySelector("span");
      if (!label || !text || label.querySelector(".v54-range-value")) return;
      const value = document.createElement("output");
      value.className = "v54-range-value";
      const update = () => {
        const n = Number(input.value || 100);
        value.textContent = n === 100 ? "Default" : `${n > 100 ? "+" : ""}${n - 100}`;
      };
      input.addEventListener("input", update, { passive: true });
      update();
      text.insertAdjacentElement("afterend", value);
    });
  }

  function boot() {
    root.dataset.uiRelease = "55";
    bindMobileShortcuts();
    bindEdgeBackGesture();
    bindReferencePhoto();
    observeMobileAd();
    observeChatSurface();
    polishAvatarLabels();

    window.addEventListener("silknex:conversation", updateSurfaceState);
    window.addEventListener("silknex:session", () => {
      updateSurfaceState();
      bindMobileShortcuts();
    });
    window.addEventListener("resize", () => {
      updateSurfaceState();
      updateMobileAdSpace();
    }, { passive: true });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        updateSurfaceState();
        updateMobileAdSpace();
      }
    });
  }

  if (window.SilknexApp) {
    boot();
  } else {
    window.addEventListener("silknex:core-ready", boot, { once: true });
  }
})();
} catch (error) { console.error("Silknex feature module 54:", error); }

;
/* Feature module 55 */
try {
(() => {
  "use strict";

  const VERSION = "55.0";
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const app = () => window.SilknexApp || null;
  const STORAGE_KEY = "silknex:v55:ui";

  const PRESETS = Object.freeze({
    chat: ["❤️", "😂", "👍", "🔥", "😭", "✨", "💀", "👀"],
    symbols: ["@", "#", "&", "—", "•", "→", "✓", "©", "™"],
    gaming: ["GG", "GLHF", "W", "L", "AFK", "BRB", "🎮", "🔥"],
  });

  function safeJson(value, fallback) {
    try {
      const parsed = JSON.parse(value);
      return parsed && typeof parsed === "object" ? parsed : fallback;
    } catch {
      return fallback;
    }
  }

  function loadSettings() {
    const stored = safeJson(window.SilknexStorage.getItem(STORAGE_KEY), {});
    return {
      keyboardEnabled: stored.keyboardEnabled !== false,
      keyboardPreset: ["chat", "symbols", "gaming", "custom"].includes(stored.keyboardPreset)
        ? stored.keyboardPreset
        : "chat",
      customKeys: Array.isArray(stored.customKeys)
        ? stored.customKeys.map((item) => String(item).slice(0, 16)).filter(Boolean).slice(0, 20)
        : ["❤️", "😂", "👍", "🔥", "✨"],
      compactComposer: Boolean(stored.compactComposer),
      // Start v55 with a flatter Discord/WhatsApp-like message shape while
      // keeping the preference reversible for users who prefer softer bubbles.
      squareBubbles: stored.squareBubbles === undefined ? true : Boolean(stored.squareBubbles),
    };
  }

  let settings = loadSettings();

  function saveSettings() {
    try {
      window.SilknexStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {}
    applyStyleSettings();
    renderKeyboard();
  }

  function applyStyleSettings() {
    const root = document.documentElement;
    root.dataset.v55CompactComposer = settings.compactComposer ? "1" : "0";
    root.dataset.v55SquareBubbles = settings.squareBubbles ? "1" : "0";
  }

  function currentKeys() {
    if (settings.keyboardPreset === "custom") return settings.customKeys;
    return PRESETS[settings.keyboardPreset] || PRESETS.chat;
  }

  function insertAtCaret(text) {
    const input = $("#messageInput");
    if (!input || input.disabled) return;

    input.focus({ preventScroll: true });
    const start = Number.isInteger(input.selectionStart) ? input.selectionStart : input.value.length;
    const end = Number.isInteger(input.selectionEnd) ? input.selectionEnd : start;
    const before = input.value.slice(0, start);
    const after = input.value.slice(end);
    const value = `${before}${text}${after}`.slice(0, Number(input.maxLength || 4000));
    input.value = value;
    const caret = Math.min(value.length, start + text.length);
    try { input.setSelectionRange(caret, caret); } catch {}
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function ensureKeyboardTray() {
    const form = $("#messageForm");
    if (!form) return null;
    let tray = $("#customKeyboardTray");
    if (!tray) {
      tray = document.createElement("div");
      tray.id = "customKeyboardTray";
      tray.className = "custom-keyboard-tray";
      tray.setAttribute("role", "toolbar");
      tray.setAttribute("aria-label", "Custom quick keyboard");
      form.insertAdjacentElement("beforebegin", tray);
    }
    return tray;
  }

  function renderKeyboard() {
    const tray = ensureKeyboardTray();
    if (!tray) return;
    tray.classList.toggle("hidden", !settings.keyboardEnabled);
    tray.replaceChildren();
    if (!settings.keyboardEnabled) return;

    for (const key of currentKeys()) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "custom-keyboard-key";
      button.textContent = key;
      button.setAttribute("aria-label", `Insert ${key}`);
      button.addEventListener("pointerdown", (event) => event.preventDefault());
      button.addEventListener("click", () => insertAtCaret(key));
      tray.appendChild(button);
    }
  }

  function addCheckboxRow(section, id, label, description, checked, onChange) {
    const row = document.createElement("div");
    row.className = "setting-row";
    row.innerHTML = `<div><b></b><small></small></div><label class="switch"><input type="checkbox"><span></span></label>`;
    $("b", row).textContent = label;
    $("small", row).textContent = description;
    const input = $("input", row);
    input.id = id;
    input.checked = checked;
    input.addEventListener("change", () => onChange(input.checked));
    section.appendChild(row);
  }

  function installSettings() {
    if ($("#v55PersonalizationSettings")) return;
    const host = $("#settingsModal .settings-stack, #settingsModal .modal-card");
    if (!host) return;

    const section = document.createElement("section");
    section.id = "v55PersonalizationSettings";
    section.className = "settings-section v55-settings-section";
    section.innerHTML = `
      <div class="section-title"><span>Personal style & keyboard</span></div>
      <label class="field">
        <span>Quick keyboard layout</span>
        <select id="v55KeyboardPreset">
          <option value="chat">Chat reactions</option>
          <option value="symbols">Symbols</option>
          <option value="gaming">Gaming</option>
          <option value="custom">Custom</option>
        </select>
      </label>
      <label class="field">
        <span>Custom keys · separate with commas</span>
        <input id="v55CustomKeys" class="v55-key-input" maxlength="240" placeholder="❤️,😂,👍,🔥,✨">
      </label>
    `;
    host.appendChild(section);

    addCheckboxRow(
      section,
      "v55KeyboardEnabled",
      "Custom quick keyboard",
      "Show your chosen keys directly above the chat composer.",
      settings.keyboardEnabled,
      (value) => { settings.keyboardEnabled = value; saveSettings(); }
    );
    addCheckboxRow(
      section,
      "v55CompactComposer",
      "Compact composer",
      "Use a tighter WhatsApp/Discord-style message bar.",
      settings.compactComposer,
      (value) => { settings.compactComposer = value; saveSettings(); }
    );
    addCheckboxRow(
      section,
      "v55SquareBubbles",
      "Sharper message bubbles",
      "Reduce the extra-rounded AI-chat look.",
      settings.squareBubbles,
      (value) => { settings.squareBubbles = value; saveSettings(); }
    );

    const preset = $("#v55KeyboardPreset");
    const custom = $("#v55CustomKeys");
    preset.value = settings.keyboardPreset;
    custom.value = settings.customKeys.join(",");
    custom.disabled = settings.keyboardPreset !== "custom";

    preset.addEventListener("change", () => {
      settings.keyboardPreset = preset.value;
      custom.disabled = settings.keyboardPreset !== "custom";
      saveSettings();
    });

    custom.addEventListener("change", () => {
      settings.customKeys = custom.value
        .split(",")
        .map((value) => value.trim().slice(0, 16))
        .filter(Boolean)
        .slice(0, 20);
      if (!settings.customKeys.length) settings.customKeys = ["❤️", "😂", "👍"];
      custom.value = settings.customKeys.join(",");
      settings.keyboardPreset = "custom";
      preset.value = "custom";
      saveSettings();
    });
  }

  function installQrActions() {
    const card = $("#profileQrModal .qr-profile-card");
    if (!card || $("#v55ShareProfileQrBtn")) return;
    const button = document.createElement("button");
    button.id = "v55ShareProfileQrBtn";
    button.type = "button";
    button.className = "secondary-btn wide";
    button.textContent = "Share profile link";
    const scan = $("#scanProfileQrBtn");
    scan?.insertAdjacentElement("beforebegin", button);

    button.addEventListener("click", async () => {
      const handle = String($("#profileQrHandle")?.textContent || "").replace(/^@/, "").trim();
      if (!handle) return;
      const url = new URL(`/@${encodeURIComponent(handle)}`, location.origin);
      try {
        if (navigator.share) {
          await navigator.share({ title: `@${handle} on Silknex`, url: url.toString() });
        } else {
          await navigator.clipboard.writeText(url.toString());
          app()?.toast?.("Profile link copied.");
        }
      } catch {}
    });
  }

  function tuneMediaNode(node) {
    if (node instanceof HTMLImageElement) {
      if (!node.loading) node.loading = "lazy";
      node.decoding = "async";
      node.fetchPriority = node.closest(".message") ? "auto" : (node.fetchPriority || "low");
    } else if (node instanceof HTMLVideoElement) {
      node.preload = node.closest(".message") ? "metadata" : (node.preload || "none");
      node.playsInline = true;
    }
  }

  function installMediaObserver() {
    document.querySelectorAll("img,video").forEach(tuneMediaNode);
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (node.matches("img,video")) tuneMediaNode(node);
          node.querySelectorAll?.("img,video").forEach(tuneMediaNode);
        }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function installComposerFocusGuard() {
    const input = $("#messageInput");
    if (!input) return;
    let stickToBottom = true;
    const nearBottom = () => {
      const messages = $("#messages");
      if (!messages) return true;
      return messages.scrollHeight - messages.scrollTop - messages.clientHeight < 220;
    };
    const keepVisible = () => {
      if (!stickToBottom) return;
      requestAnimationFrame(() => {
        const messages = $("#messages");
        if (messages) {
          messages.scrollTop = Math.max(0, messages.scrollHeight - messages.clientHeight);
        }
      });
    };
    input.addEventListener("focus", () => {
      // Do not yank somebody to the newest message when they intentionally
      // scrolled up to read or reply to older content before opening the keyboard.
      stickToBottom = nearBottom();
      keepVisible();
    });
    input.addEventListener("blur", () => { stickToBottom = true; });
    window.visualViewport?.addEventListener("resize", () => {
      if (document.activeElement === input) keepVisible();
    }, { passive: true });
  }

  function init() {
    if (!app()) {
      window.addEventListener("silknex:core-ready", init, { once: true });
      return;
    }
    applyStyleSettings();
    renderKeyboard();
    installSettings();
    installQrActions();
    installMediaObserver();
    installComposerFocusGuard();

    window.addEventListener("silknex:modal", () => {
      installSettings();
      installQrActions();
    });
    window.addEventListener("resize", renderKeyboard, { passive: true });
  }

  window.SilkNexV55 = Object.freeze({ version: VERSION, renderKeyboard });
  init();
})();
} catch (error) { console.error("Silknex feature module 55:", error); }

;
/* Feature module 56 */
try {
(() => {
  "use strict";

  const VERSION = "56.0";
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const app = () => window.SilknexApp || null;
  const root = document.documentElement;

  const runtime = {
    swipe: null,
    avatarAnalyzing: false,
    profileObserver: null,
  };

  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const isTouchLike = () => Boolean(
    window.matchMedia?.("(pointer: coarse)")?.matches ||
    navigator.maxTouchPoints > 0
  );

  function toast(message) {
    app()?.toast?.(message);
  }

  // ---------------------------------------------------------------------------
  // Native-feeling swipe-to-dismiss for sheets, dialogs and full-screen media.
  // ---------------------------------------------------------------------------
  function resetSwipe(animated = true) {
    const gesture = runtime.swipe;
    if (!gesture) return;
    const { card, modal } = gesture;
    if (animated) {
      card.classList.add("v56-swipe-return");
      requestAnimationFrame(() => {
        card.style.removeProperty("--v56-swipe-y");
        card.style.removeProperty("--v56-swipe-scale");
        modal?.style.removeProperty("--v56-swipe-opacity");
      });
      setTimeout(() => card.classList.remove("v56-swipe-return"), 210);
    } else {
      card.style.removeProperty("--v56-swipe-y");
      card.style.removeProperty("--v56-swipe-scale");
      modal?.style.removeProperty("--v56-swipe-opacity");
      card.classList.remove("v56-swipe-return");
    }
    root.removeAttribute("data-v56-swiping");
    runtime.swipe = null;
  }

  function dismissSwipeSurface(gesture) {
    if (!gesture) return;
    const { modal, card, fullscreen } = gesture;
    root.removeAttribute("data-v56-swiping");
    runtime.swipe = null;

    card.classList.add("v56-swipe-dismiss");
    card.style.setProperty("--v56-swipe-y", `${Math.max(180, window.innerHeight * .42)}px`);
    modal?.style.setProperty("--v56-swipe-opacity", "0");
    const finish = () => {
      card.classList.remove("v56-swipe-dismiss");
      card.style.removeProperty("--v56-swipe-y");
      card.style.removeProperty("--v56-swipe-scale");
      modal?.style.removeProperty("--v56-swipe-opacity");
      if (fullscreen) {
        $("#fullscreenMediaClose")?.click();
      } else {
        const close = modal?.querySelector?.(".close-modal, [data-swipe-close]");
        if (close instanceof HTMLElement) close.click();
        else app()?.closeModal?.();
      }
      try { navigator.vibrate?.(8); } catch {}
    };
    setTimeout(finish, 150);
  }

  function swipeInteractiveTarget(target) {
    return Boolean(target?.closest?.(
      "button,a,input,textarea,select,option,label,canvas,video,audio,[contenteditable='true'],[role='slider'],.sticker-grid,.giphy-grid,.people-results"
    ));
  }

  function bindSwipeDismiss() {
    if (document.body.dataset.v56SwipeBound === "1") return;
    document.body.dataset.v56SwipeBound = "1";

    document.addEventListener("pointerdown", (event) => {
      if (!isTouchLike() || event.pointerType === "mouse" || event.isPrimary === false) return;
      const target = event.target instanceof Element ? event.target : null;
      if (!target || swipeInteractiveTarget(target)) return;

      const fullscreen = target.closest("#fullscreenMediaModal:not(.hidden)");
      const modal = fullscreen || target.closest(".modal:not(.hidden)");
      if (!modal) return;

      const card = fullscreen
        ? $("#fullscreenMediaStage") || fullscreen
        : target.closest(".modal-card");
      if (!card) return;

      // A scrollable sheet only dismisses from its top edge; otherwise a normal
      // downward scroll should remain a normal scroll.
      const rect = card.getBoundingClientRect();
      const nearTop = event.clientY <= rect.top + Math.min(120, Math.max(66, rect.height * .16));
      if (!fullscreen && card.scrollTop > 2 && !nearTop) return;

      runtime.swipe = {
        id: event.pointerId,
        modal,
        card,
        fullscreen: Boolean(fullscreen),
        startX: event.clientX,
        startY: event.clientY,
        lastY: event.clientY,
        lastAt: performance.now(),
        velocityY: 0,
        locked: "",
        nearTop,
      };
    }, { passive: true, capture: true });

    document.addEventListener("pointermove", (event) => {
      const gesture = runtime.swipe;
      if (!gesture || gesture.id !== event.pointerId) return;

      const dx = event.clientX - gesture.startX;
      const dy = event.clientY - gesture.startY;
      const absX = Math.abs(dx);
      const absY = Math.abs(dy);

      if (!gesture.locked && Math.max(absX, absY) >= 10) {
        gesture.locked = absY > absX * 1.08 ? "vertical" : "other";
      }
      if (gesture.locked === "other") {
        resetSwipe(false);
        return;
      }
      if (gesture.locked !== "vertical" || dy <= 0) return;
      if (!gesture.fullscreen && gesture.card.scrollTop > 1 && !gesture.nearTop) {
        resetSwipe(false);
        return;
      }

      event.preventDefault();
      const now = performance.now();
      const dt = Math.max(8, now - gesture.lastAt);
      gesture.velocityY = (event.clientY - gesture.lastY) / dt;
      gesture.lastY = event.clientY;
      gesture.lastAt = now;

      const resistance = dy > 280 ? 280 + (dy - 280) * .35 : dy;
      const progress = clamp(resistance / Math.max(260, window.innerHeight * .45), 0, 1);
      gesture.card.style.setProperty("--v56-swipe-y", `${Math.max(0, resistance)}px`);
      gesture.card.style.setProperty("--v56-swipe-scale", String(1 - progress * .018));
      gesture.modal?.style.setProperty("--v56-swipe-opacity", String(1 - progress * .68));
      root.setAttribute("data-v56-swiping", "1");
    }, { passive: false, capture: true });

    const end = (event) => {
      const gesture = runtime.swipe;
      if (!gesture || (event.pointerId !== undefined && gesture.id !== event.pointerId)) return;
      const dy = event.clientY - gesture.startY;
      const elapsed = Math.max(1, performance.now() - (gesture.lastAt || performance.now()));
      const releaseVelocity = Math.max(gesture.velocityY, (dy / Math.max(60, elapsed)));
      const shouldDismiss =
        gesture.locked === "vertical" &&
        dy > 0 &&
        (dy >= Math.min(128, window.innerHeight * .16) || (dy >= 52 && releaseVelocity >= .55));

      if (shouldDismiss) dismissSwipeSurface(gesture);
      else resetSwipe(true);
    };

    document.addEventListener("pointerup", end, { passive: true, capture: true });
    document.addEventListener("pointercancel", () => resetSwipe(true), { passive: true, capture: true });
    window.addEventListener("orientationchange", () => resetSwipe(false), { passive: true });
    window.addEventListener("pageshow", () => resetSwipe(false), { passive: true });
  }

  // ---------------------------------------------------------------------------
  // Photo -> avatar. Analysis stays entirely on-device.
  // ---------------------------------------------------------------------------
  function rgbToHex(rgb) {
    if (!rgb) return "";
    return `#${rgb.map((value) => clamp(Math.round(value), 0, 255).toString(16).padStart(2, "0")).join("")}`;
  }

  function luminance([r, g, b]) {
    return (r * .2126 + g * .7152 + b * .0722) / 255;
  }

  function saturation([r, g, b]) {
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    return max === 0 ? 0 : (max - min) / max;
  }

  function distance(a, b) {
    const dr = a[0] - b[0];
    const dg = a[1] - b[1];
    const db = a[2] - b[2];
    return Math.sqrt(dr * dr * .30 + dg * dg * .52 + db * db * .18);
  }

  function medianColor(colors, fallback = [180, 135, 110]) {
    if (!colors.length) return fallback;
    const channels = [0, 1, 2].map((channel) =>
      colors.map((color) => color[channel]).sort((a, b) => a - b)[Math.floor(colors.length / 2)]
    );
    return channels;
  }

  function pixelsInRegion(imageData, box, region, predicate = null, stride = 3) {
    const { width, height, data } = imageData;
    const x0 = clamp(Math.floor(box.x + box.width * region[0]), 0, width - 1);
    const y0 = clamp(Math.floor(box.y + box.height * region[1]), 0, height - 1);
    const x1 = clamp(Math.ceil(box.x + box.width * region[2]), x0 + 1, width);
    const y1 = clamp(Math.ceil(box.y + box.height * region[3]), y0 + 1, height);
    const colors = [];
    for (let y = y0; y < y1; y += stride) {
      for (let x = x0; x < x1; x += stride) {
        const index = (y * width + x) * 4;
        if (data[index + 3] < 180) continue;
        const color = [data[index], data[index + 1], data[index + 2]];
        if (!predicate || predicate(color, x, y)) colors.push(color);
      }
    }
    return colors;
  }

  function nearestNamedColor(rgb, palette) {
    let best = palette[0][0];
    let score = Infinity;
    for (const [name, hex] of palette) {
      const clean = hex.replace("#", "");
      const candidate = [
        parseInt(clean.slice(0, 2), 16),
        parseInt(clean.slice(2, 4), 16),
        parseInt(clean.slice(4, 6), 16),
      ];
      const d = distance(rgb, candidate);
      if (d < score) {
        best = name;
        score = d;
      }
    }
    return best;
  }

  function setAvatarField(id, value) {
    const field = $(`#${id}`);
    if (!field || value === undefined || value === null) return;
    const text = String(value);
    if (field instanceof HTMLSelectElement && !Array.from(field.options).some((option) => option.value === text)) return;
    field.value = text;
    field.dispatchEvent(new Event(field.matches('input[type="range"],input[type="color"]') ? "input" : "change", { bubbles: true }));
  }

  function estimateSkinSpan(imageData, box, skin, yFraction) {
    const y = clamp(Math.round(box.y + box.height * yFraction), 0, imageData.height - 1);
    const start = clamp(Math.floor(box.x + box.width * .08), 0, imageData.width - 1);
    const end = clamp(Math.ceil(box.x + box.width * .92), start + 1, imageData.width);
    const center = Math.round((start + end) / 2);
    const isSkin = (x) => {
      const i = (y * imageData.width + x) * 4;
      const c = [imageData.data[i], imageData.data[i + 1], imageData.data[i + 2]];
      return imageData.data[i + 3] > 150 && distance(c, skin) < 58 && luminance(c) > .12;
    };

    let left = center;
    let misses = 0;
    for (let x = center; x >= start; x -= 1) {
      if (isSkin(x)) { left = x; misses = 0; }
      else if (++misses > 5) break;
    }
    let right = center;
    misses = 0;
    for (let x = center; x <= end; x += 1) {
      if (isSkin(x)) { right = x; misses = 0; }
      else if (++misses > 5) break;
    }
    return Math.max(1, right - left);
  }

  async function faceBoxForCanvas(canvas) {
    if ("FaceDetector" in window) {
      try {
        const detector = new FaceDetector({ fastMode: true, maxDetectedFaces: 3 });
        const faces = await detector.detect(canvas);
        if (faces?.length) {
          const largest = faces
            .map((face) => face.boundingBox)
            .filter(Boolean)
            .sort((a, b) => (b.width * b.height) - (a.width * a.height))[0];
          if (largest) {
            return {
              x: clamp(largest.x, 0, canvas.width - 1),
              y: clamp(largest.y, 0, canvas.height - 1),
              width: clamp(largest.width, 1, canvas.width),
              height: clamp(largest.height, 1, canvas.height),
              detected: true,
            };
          }
        }
      } catch {}
    }
    return {
      x: canvas.width * .20,
      y: canvas.height * .08,
      width: canvas.width * .60,
      height: canvas.height * .72,
      detected: false,
    };
  }

  async function analyzeAvatarPhoto() {
    if (runtime.avatarAnalyzing) return;
    const image = $("#avatarReferenceImage");
    const button = $("#avatarGenerateFromPhotoBtn");
    const status = $("#avatarPhotoAnalysisStatus");
    if (!image?.src) {
      toast("Choose a reference photo first.");
      return;
    }

    runtime.avatarAnalyzing = true;
    if (button) button.disabled = true;
    if (status) status.textContent = "Analyzing face on this device…";
    let analysisCanvas = null;

    try {
      if (!image.complete || !image.naturalWidth) {
        await new Promise((resolve, reject) => {
          image.addEventListener("load", resolve, { once: true });
          image.addEventListener("error", reject, { once: true });
        });
      }
      try { await image.decode?.(); } catch {}

      const memoryGb = Number(navigator.deviceMemory || 0);
      const maxSide = memoryGb > 0 && memoryGb <= 4 ? 384 : 512;
      const scale = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = analysisCanvas = document.createElement("canvas");
      canvas.width = Math.max(96, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(96, Math.round(image.naturalHeight * scale));
      const context = canvas.getContext("2d", { willReadFrequently: true });
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      const box = await faceBoxForCanvas(canvas);
      const pixels = context.getImageData(0, 0, canvas.width, canvas.height);

      const skinCandidates = pixelsInRegion(
        pixels,
        box,
        [.27, .34, .73, .72],
        (color) => {
          const light = luminance(color);
          const sat = saturation(color);
          const [r, g, b] = color;
          return light > .18 && light < .93 && sat < .72 && r > b * .92 && r > g * .82;
        },
        2
      );
      const skin = medianColor(skinCandidates);

      const hairCandidates = pixelsInRegion(
        pixels,
        box,
        [.12, -.06, .88, .28],
        (color) => {
          const light = luminance(color);
          return light < Math.min(.72, luminance(skin) + .14) && distance(color, skin) > 24;
        },
        2
      );
      let hair = medianColor(hairCandidates, [45, 35, 31]);
      if (hairCandidates.length < 16) hair = skin.map((value) => value * .72);

      const eyeCandidates = [
        ...pixelsInRegion(pixels, box, [.18, .35, .46, .53], (color) => luminance(color) < .62 && distance(color, skin) > 24, 1),
        ...pixelsInRegion(pixels, box, [.54, .35, .82, .53], (color) => luminance(color) < .62 && distance(color, skin) > 24, 1),
      ];
      // Ignore near-black pupils when enough colored iris candidates exist.
      const irisCandidates = eyeCandidates.filter((color) => luminance(color) > .08 && saturation(color) > .08);
      const eye = medianColor(irisCandidates.length > 8 ? irisCandidates : eyeCandidates, [92, 66, 48]);

      const lipCandidates = pixelsInRegion(
        pixels,
        box,
        [.32, .64, .68, .84],
        (color) => color[0] > color[1] * 1.03 && color[0] > color[2] * .98 && luminance(color) > .10,
        1
      );
      const lip = medianColor(lipCandidates, [
        Math.min(170, skin[0] * .55),
        Math.min(100, skin[1] * .42),
        Math.min(105, skin[2] * .48),
      ]);

      const midSpan = estimateSkinSpan(pixels, box, skin, .56);
      const jawSpan = estimateSkinSpan(pixels, box, skin, .78);
      const jawRatio = jawSpan / Math.max(1, midSpan);
      const boxRatio = box.width / Math.max(1, box.height);

      let faceShape = "oval";
      if (boxRatio < .68) faceShape = "long";
      else if (jawRatio < .76) faceShape = "heart";
      else if (jawRatio > .94 && boxRatio > .80) faceShape = "soft_square";
      else if (boxRatio > .86) faceShape = "round";

      const faceWidth = clamp(Math.round(100 + (boxRatio - .78) * 68), 84, 118);
      const faceLength = clamp(Math.round(100 + (.78 - boxRatio) * 52), 88, 115);
      const jawWidth = clamp(Math.round(100 + (jawRatio - .86) * 62), 84, 120);

      const topHair = pixelsInRegion(
        pixels, box, [.08, -.08, .92, .30],
        (color) => distance(color, hair) < 46 && distance(color, skin) > 20, 3
      ).length;
      const sideHair = pixelsInRegion(
        pixels, box, [-.02, .25, 1.02, .98],
        (color, x) => {
          const fx = (x - box.x) / Math.max(1, box.width);
          return (fx < .23 || fx > .77) && distance(color, hair) < 46 && distance(color, skin) > 20;
        },
        3
      ).length;
      const sampleArea = Math.max(1, (box.width * box.height) / 9);
      const topCoverage = topHair / sampleArea;
      const sideCoverage = sideHair / sampleArea;
      let hairStyle = "crop";
      if (topCoverage < .015) hairStyle = distance(hair, skin) < 35 ? "bald" : "buzz";
      else if (sideCoverage > .12) hairStyle = "long";
      else if (sideCoverage > .055) hairStyle = "bob";
      else if (topCoverage > .18) hairStyle = "curls";
      else hairStyle = "textured_crop";

      const skinPalette = [
        ["porcelain", "#f3d7c6"], ["fair", "#edc5aa"], ["warm", "#dca47f"], ["olive", "#c5926b"],
        ["tan", "#b97b56"], ["brown", "#8b5b3f"], ["deep", "#62412f"], ["ebony", "#402b22"],
      ];
      const hairPalette = [
        ["black", "#17181c"], ["espresso", "#2e211e"], ["brown", "#55372a"], ["auburn", "#7c3e2e"],
        ["blonde", "#d8b06a"], ["platinum", "#e4ded2"], ["silver", "#a8a7aa"], ["copper", "#a65b36"],
      ];
      const eyePalette = [
        ["dark_brown", "#3b281f"], ["brown", "#684b35"], ["hazel", "#887345"], ["green", "#52735a"],
        ["blue", "#4f7291"], ["gray", "#6d737a"], ["amber", "#a66f2e"],
      ];

      setAvatarField("avatarSkin", nearestNamedColor(skin, skinPalette));
      setAvatarField("avatarHairColor", nearestNamedColor(hair, hairPalette));
      setAvatarField("avatarEyeColor", nearestNamedColor(eye, eyePalette));
      setAvatarField("avatarSkinHex", rgbToHex(skin));
      setAvatarField("avatarHairHex", rgbToHex(hair));
      setAvatarField("avatarEyeHex", rgbToHex(eye));
      setAvatarField("avatarLipHex", rgbToHex(lip));
      setAvatarField("avatarFaceShape", faceShape);
      setAvatarField("avatarHair", hairStyle);
      setAvatarField("avatarEyes", "almond");
      setAvatarField("avatarBrows", "soft");
      setAvatarField("avatarNose", "soft");
      setAvatarField("avatarMouth", "soft");
      setAvatarField("avatarFaceWidth", faceWidth);
      setAvatarField("avatarFaceLength", faceLength);
      setAvatarField("avatarJawWidth", jawWidth);
      setAvatarField("avatarEyeScale", "100");
      setAvatarField("avatarEyeSpacing", "100");
      setAvatarField("avatarEyeTilt", "100");
      setAvatarField("avatarBrowThickness", "100");
      setAvatarField("avatarNoseScale", "100");
      setAvatarField("avatarNoseWidth", clamp(Math.round(96 + (faceWidth - 100) * .45), 86, 116));
      setAvatarField("avatarMouthWidth", "100");
      const lipRegionArea = Math.max(1, box.width * .36 * box.height * .20);
      const lipDensity = clamp(lipCandidates.length / lipRegionArea, 0, 1);
      setAvatarField("avatarLipFullness", clamp(Math.round(90 + lipDensity * 34), 82, 124));
      setAvatarField("avatarHairVolume", clamp(Math.round(92 + Math.min(.25, topCoverage) * 120), 88, 122));

      // Make sure the final field update has rendered before presenting success.
      await new Promise((resolve) => requestAnimationFrame(resolve));
      $("#avatarBuilderPreview")?.classList.add("v56-avatar-photo-result");
      setTimeout(() => $("#avatarBuilderPreview")?.classList.remove("v56-avatar-photo-result"), 700);

      if (status) {
        status.textContent = box.detected
          ? "Avatar matched to the detected face. Photo never left this device."
          : "Avatar matched with local image analysis. Face detection was unavailable on this browser.";
      }
      toast("Avatar generated from your photo. Fine-tune anything you want.");
    } catch {
      if (status) status.textContent = "Could not analyze that photo. Try a clear, front-facing image.";
      toast("Could not build an avatar from that photo.");
    } finally {
      if (analysisCanvas) {
        // Drop the decoded analysis backing store immediately instead of
        // waiting for a low-memory mobile browser to collect it later.
        analysisCanvas.width = 1;
        analysisCanvas.height = 1;
        analysisCanvas = null;
      }
      runtime.avatarAnalyzing = false;
      if (button) button.disabled = false;
    }
  }

  function bindAvatarPhotoGenerator() {
    const input = $("#avatarReferenceInput");
    const button = $("#avatarGenerateFromPhotoBtn");
    if (!input || !button || button.dataset.v56Bound === "1") return;
    button.dataset.v56Bound = "1";
    button.addEventListener("click", analyzeAvatarPhoto);
    input.addEventListener("change", async (event) => {
      const file = event.currentTarget.files?.[0];
      if (!file || !/^image\/(?:jpeg|png|webp)$/i.test(file.type)) return;
      // v54 owns the object URL/preview lifecycle. Wait one turn for its handler
      // to mount the preview, then automatically generate the first match.
      await new Promise((resolve) => setTimeout(resolve, 40));
      if ($("#avatarReferenceImage")?.src) analyzeAvatarPhoto();
    });
    $("#avatarReferenceClear")?.addEventListener("click", () => {
      const status = $("#avatarPhotoAnalysisStatus");
      if (status) status.textContent = "Photo stays on this device.";
    });
  }

  // ---------------------------------------------------------------------------
  // Small interaction fixes that make the app feel less fussy on phones.
  // ---------------------------------------------------------------------------
  function fixTransientUi() {
    // Native image dragging can steal a horizontal/vertical swipe on touch
    // browsers and leaves ghost previews on desktop.
    document.addEventListener("dragstart", (event) => {
      const target = event.target instanceof Element ? event.target : null;
      if (target?.matches?.(".avatar img,.message-media img,.public-profile-card img,.sticker-tile img")) {
        event.preventDefault();
      }
    });

    // A modal can be restored from bfcache with a stale transform if the page
    // was backgrounded during a gesture. Always normalize it on visibility.
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") resetSwipe(false);
    });

    // Keep profile content tabs sane when a profile rerenders asynchronously.
    runtime.profileObserver = new MutationObserver(() => {
      const profile = $("#publicProfileModal");
      if (!profile || profile.classList.contains("hidden")) return;
      const selected = profile.querySelector("[data-profile-tab][aria-selected='true']");
      if (!selected) profile.querySelector("[data-profile-tab='stories']")?.click();
    });
    const profile = $("#publicProfileModal");
    if (profile) runtime.profileObserver.observe(profile, { childList: true, subtree: true });
  }

  function init() {
    if (!app()) {
      window.addEventListener("silknex:core-ready", init, { once: true });
      return;
    }
    root.dataset.silknexVersion = VERSION;
    bindSwipeDismiss();
    bindAvatarPhotoGenerator();
    fixTransientUi();
  }

  window.SilkNexV56 = Object.freeze({
    version: VERSION,
    analyzeAvatarPhoto,
  });

  init();
})();
} catch (error) { console.error("Silknex feature module 56:", error); }

;
/* Feature module 57 */
try {
(() => {
  "use strict";

  const root = document.documentElement;
  const EFFICIENT = root.dataset.performance === "efficient";
  const MEMORY = Number(navigator.deviceMemory || 0);
  const LOW_MEMORY = EFFICIENT || (MEMORY > 0 && MEMORY <= 4);
  const reducedMotion = () =>
    root.dataset.reduceMotion === "true" ||
    Boolean(window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches);

  root.dataset.silknexVersion = "57.0";
  root.dataset.v57LowMemory = LOW_MEMORY ? "true" : "false";

  const mediaObserver = "IntersectionObserver" in window
    ? new IntersectionObserver((entries) => {
        for (const entry of entries) {
          const media = entry.target;
          if (!(media instanceof HTMLMediaElement)) continue;
          if (entry.isIntersecting) continue;
          if (document.pictureInPictureElement === media) continue;
          if (media.closest(".call-view,.call-stage,.story-viewer-card")) continue;
          if (!media.paused) {
            try { media.pause(); } catch {}
          }
        }
      }, {
        root: null,
        rootMargin: LOW_MEMORY ? "240px 0px" : "520px 0px",
        threshold: 0.01,
      })
    : null;

  const seenMedia = new WeakSet();
  const seenImages = new WeakSet();
  let enhanceRaf = 0;
  const queue = new Set();

  function tuneImage(image) {
    if (!(image instanceof HTMLImageElement) || seenImages.has(image)) return;
    seenImages.add(image);

    const critical = Boolean(
      image.closest(".chat-header,.me-bar,.call-view,.incoming-call,.profile-identity-card,.avatar-builder-stage")
    );
    if (!critical) image.loading = "lazy";
    image.decoding = "async";
    try { image.fetchPriority = critical ? "high" : "low"; } catch {}
    image.draggable = false;
  }

  function tuneMedia(media) {
    if (!(media instanceof HTMLMediaElement) || seenMedia.has(media)) return;
    seenMedia.add(media);
    if (!media.closest(".call-view,.call-stage,.story-viewer-card")) {
      media.preload = "metadata";
      mediaObserver?.observe(media);
    }
  }

  function tuneNode(node) {
    if (!(node instanceof Element)) return;
    if (node instanceof HTMLImageElement) tuneImage(node);
    if (node instanceof HTMLMediaElement) tuneMedia(node);
    node.querySelectorAll?.("img").forEach(tuneImage);
    node.querySelectorAll?.("video,audio").forEach(tuneMedia);
  }

  function flushEnhancements() {
    enhanceRaf = 0;
    const nodes = [...queue];
    queue.clear();
    for (const node of nodes) tuneNode(node);
  }

  function queueNode(node) {
    if (!(node instanceof Element)) return;
    queue.add(node);
    if (!enhanceRaf) enhanceRaf = requestAnimationFrame(flushEnhancements);
  }

  function pauseFeedMedia() {
    document
      .querySelectorAll("#messages video,#messages audio,.public-profile-stories video")
      .forEach((media) => {
        if (document.pictureInPictureElement === media) return;
        try { media.pause(); } catch {}
      });
  }

  function trimHeavyCaches(level = "idle") {
    const e2ee = window.SilknexE2EE;
    if (!e2ee?.trimMediaCache) return;

    if (level === "hidden") {
      e2ee.trimMediaCache({
        maxItems: LOW_MEMORY ? 4 : 8,
        maxBytes: LOW_MEMORY ? 16 * 1024 * 1024 : 48 * 1024 * 1024,
      });
      return;
    }

    e2ee.trimMediaCache({
      maxItems: LOW_MEMORY ? 8 : 18,
      maxBytes: LOW_MEMORY ? 40 * 1024 * 1024 : 96 * 1024 * 1024,
    });
  }

  function releaseClosedCreatorResources() {
    const gifModal = document.querySelector("#gifMakerModal");
    if (gifModal?.classList.contains("hidden")) {
      gifModal.querySelectorAll("video,audio").forEach((media) => {
        try { media.pause(); } catch {}
      });
    }

    const stickerModal = document.querySelector("#stickerMakerModal,#stickerCreatorModal");
    if (stickerModal?.classList.contains("hidden")) {
      stickerModal.querySelectorAll("video,audio").forEach((media) => {
        try { media.pause(); } catch {}
      });
    }
  }

  const messages = document.querySelector("#messages");
  const conversationList = document.querySelector("#conversationList");

  // Observe only high-churn feeds. A document-wide subtree observer creates
  // measurable allocation pressure in long chats and busy friend lists.
  [messages, conversationList].filter(Boolean).forEach((target) => {
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) queueNode(node);
      }
    });
    observer.observe(target, { childList: true, subtree: true });
  });

  // Creator cleanup needs only their visibility class, not the whole document.
  ["#gifMakerModal", "#stickerMakerModal", "#stickerCreatorModal"].forEach((selector) => {
    const modal = document.querySelector(selector);
    if (!modal) return;
    new MutationObserver(releaseClosedCreatorResources).observe(modal, {
      attributes: true,
      attributeFilter: ["class"],
    });
  });

  tuneNode(document.body);

  document.addEventListener("visibilitychange", () => {
    root.dataset.pageHidden = document.hidden ? "true" : "false";
    if (document.hidden) {
      pauseFeedMedia();
      trimHeavyCaches("hidden");
    } else {
      trimHeavyCaches("idle");
    }
  }, { passive: true });

  window.addEventListener("pagehide", (event) => {
    pauseFeedMedia();
    if (!event.persisted) {
      try { window.SilknexE2EE?.clearMediaUrls?.(); } catch {}
    } else {
      trimHeavyCaches("hidden");
    }
  }, { passive: true });

  // Chromium exposes this on a small set of platforms; harmless elsewhere.
  window.addEventListener("memorypressure", () => {
    pauseFeedMedia();
    try {
      window.SilknexE2EE?.trimMediaCache?.({
        maxItems: 2,
        maxBytes: 8 * 1024 * 1024,
      });
    } catch {}
  }, { passive: true });

  const idle = window.requestIdleCallback || ((callback) => setTimeout(() => callback({ timeRemaining: () => 0 }), 900));
  idle(() => {
    trimHeavyCaches("idle");
    root.classList.add("v57-idle-ready");
  }, { timeout: 1800 });

  // Avoid expensive smooth scrolling while the browser is under the efficient
  // tier, but keep micro-transitions so the app still feels animated.
  if (LOW_MEMORY && !reducedMotion()) {
    root.dataset.v57MotionTier = "lite";
  } else if (!reducedMotion()) {
    root.dataset.v57MotionTier = "full";
  } else {
    root.dataset.v57MotionTier = "none";
  }

  requestAnimationFrame(() => {
    requestAnimationFrame(() => root.classList.add("v57-ready"));
  });
})();

} catch (error) { console.error("Silknex feature module 57:", error); }

;
/* Feature module 58 */
try {
(() => {
  "use strict";

  const root = document.documentElement;
  const now = () => performance.now();
  const reducedMotion = () =>
    root.dataset.reduceMotion === "true" ||
    Boolean(window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches);

  root.dataset.silknexVersion = "58.0";

  const lowMemory =
    root.dataset.performance === "efficient" ||
    root.dataset.v57LowMemory === "true" ||
    (() => {
      const memory = Number(navigator.deviceMemory || 0);
      return memory > 0 && memory <= 4;
    })();

  const setMotionTier = (tier) => {
    const safe = reducedMotion() ? "none" : tier;
    root.dataset.v58MotionTier = safe;
  };

  setMotionTier(reducedMotion() ? "none" : (lowMemory ? "lite" : "full"));

  // -------------------------------------------------------------------------
  // Open-state motion
  // -------------------------------------------------------------------------
  const surfaces = [
    ...document.querySelectorAll(
      ".modal,.attachment-menu,.reply-bar,.attachment-preview,.recording-bar," +
      ".incoming-call,.toast,#chatView,#emptyState"
    ),
  ];

  const visibleState = new WeakMap();
  const openTimers = new WeakMap();

  function isVisibleSurface(element) {
    if (!(element instanceof HTMLElement)) return false;
    if (element.classList.contains("toast")) return element.classList.contains("show");
    if (element.hidden) return false;
    return !element.classList.contains("hidden");
  }

  function markSurfaceOpen(element) {
    if (!(element instanceof HTMLElement) || reducedMotion()) return;
    clearTimeout(openTimers.get(element));
    element.classList.remove("v58-open");
    // Force the class change into the next frame without forcing layout.
    requestAnimationFrame(() => {
      if (!isVisibleSurface(element)) return;
      element.classList.add("v58-open");
      const timer = setTimeout(() => {
        element.classList.remove("v58-open");
        openTimers.delete(element);
      }, 420);
      openTimers.set(element, timer);
    });
  }

  const surfaceObserver = new MutationObserver((records) => {
    for (const record of records) {
      const surface = record.target;
      if (!(surface instanceof HTMLElement)) continue;
      const wasVisible = visibleState.get(surface) === true;
      const isVisible = isVisibleSurface(surface);
      visibleState.set(surface, isVisible);
      if (!wasVisible && isVisible) markSurfaceOpen(surface);
    }
  });

  for (const surface of surfaces) {
    visibleState.set(surface, isVisibleSurface(surface));
    surfaceObserver.observe(surface, {
      attributes: true,
      attributeFilter: ["class", "hidden"],
    });
  }

  // -------------------------------------------------------------------------
  // Selection settle for navigation and filters
  // -------------------------------------------------------------------------
  const selectable = [
    ...document.querySelectorAll(".mobile-nav-item,.chat-filter,.avatar-builder-tab"),
  ];
  const selectedState = new WeakMap();

  function isSelected(element) {
    return (
      element.classList.contains("active") ||
      element.getAttribute("aria-selected") === "true" ||
      element.getAttribute("aria-current") === "page"
    );
  }

  function pulseSelected(element) {
    if (reducedMotion()) return;
    element.classList.remove("v58-selected");
    requestAnimationFrame(() => {
      element.classList.add("v58-selected");
      setTimeout(() => element.classList.remove("v58-selected"), 300);
    });
  }

  const selectionObserver = new MutationObserver((records) => {
    for (const record of records) {
      const item = record.target;
      if (!(item instanceof HTMLElement)) continue;
      const before = selectedState.get(item) === true;
      const after = isSelected(item);
      selectedState.set(item, after);
      if (!before && after) pulseSelected(item);
    }
  });

  for (const item of selectable) {
    selectedState.set(item, isSelected(item));
    selectionObserver.observe(item, {
      attributes: true,
      attributeFilter: ["class", "aria-selected", "aria-current"],
    });
  }

  // -------------------------------------------------------------------------
  // High-churn list protection
  // -------------------------------------------------------------------------
  let startupPhase = true;
  setTimeout(() => { startupPhase = false; }, 850);

  const messages = document.querySelector("#messages");
  if (messages) {
    let pendingMessages = [];
    let messageFrame = 0;

    const flushMessageMotion = () => {
      messageFrame = 0;
      const rows = pendingMessages;
      pendingMessages = [];
      if (!rows.length) return;

      // Initial history and large decrypt/render batches should appear
      // immediately. A handful of genuinely new messages still get motion.
      const suppressCount =
        startupPhase ? rows.length :
        rows.length > 6 ? Math.max(0, rows.length - 2) :
        root.dataset.v58MotionTier === "lite" && rows.length > 3
          ? rows.length - 1
          : 0;

      for (let index = 0; index < suppressCount; index += 1) {
        const row = rows[index];
        row.classList.add("v58-no-enter");
        // createMessageElement removes the entrance class on animationend.
        // Suppressed rows do not emit that event, so clean both classes here.
        requestAnimationFrame(() => {
          row.classList.remove("v57-message-enter", "v58-no-enter");
        });
      }
    };

    new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (node.matches(".message")) pendingMessages.push(node);
          node.querySelectorAll?.(".message").forEach((row) => pendingMessages.push(row));
        }
      }
      if (pendingMessages.length && !messageFrame) {
        messageFrame = requestAnimationFrame(flushMessageMotion);
      }
    }).observe(messages, { childList: true, subtree: false });
  }

  const conversationList = document.querySelector("#conversationList");
  if (conversationList) {
    let pendingRows = [];
    let rowFrame = 0;

    const flushRows = () => {
      rowFrame = 0;
      const rows = pendingRows;
      pendingRows = [];
      if (startupPhase || reducedMotion() || rows.length > 8) return;
      for (const row of rows) {
        row.classList.add("v58-item-enter");
        setTimeout(() => row.classList.remove("v58-item-enter"), 240);
      }
    };

    new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (node.matches(".conversation")) pendingRows.push(node);
          node.querySelectorAll?.(".conversation").forEach((row) => pendingRows.push(row));
        }
      }
      if (pendingRows.length && !rowFrame) {
        rowFrame = requestAnimationFrame(flushRows);
      }
    }).observe(conversationList, { childList: true, subtree: false });
  }

  // -------------------------------------------------------------------------
  // Short frame-health probe
  // -------------------------------------------------------------------------
  // If startup settles but the device still cannot sustain a comfortable frame
  // cadence, automatically use the lighter motion tier for this session.
  function probeFrameHealth() {
    if (
      reducedMotion() ||
      lowMemory ||
      document.hidden ||
      root.dataset.v58MotionTier !== "full"
    ) return;

    const deltas = [];
    let previous = 0;
    let frames = 0;

    const sample = (stamp) => {
      if (previous) {
        const delta = stamp - previous;
        if (delta > 0 && delta < 80) deltas.push(delta);
      }
      previous = stamp;
      frames += 1;

      if (frames < 48) {
        requestAnimationFrame(sample);
        return;
      }

      if (deltas.length < 24) return;
      const sorted = deltas.slice().sort((a, b) => a - b);
      const average = deltas.reduce((sum, value) => sum + value, 0) / deltas.length;
      const p90 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * .90))];

      if (average > 22 || p90 > 29) setMotionTier("lite");
    };

    requestAnimationFrame(sample);
  }

  setTimeout(probeFrameHealth, 1200);

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) return;
    if (reducedMotion()) setMotionTier("none");
  }, { passive: true });

  requestAnimationFrame(() => {
    requestAnimationFrame(() => root.classList.add("v58-ready"));
  });
})();
} catch (error) { console.error("Silknex feature module 58:", error); }

;
/* Feature module 59 */
try {
(() => {
  "use strict";

  const root = document.documentElement;
  const $ = (selector, scope = document) => scope.querySelector(selector);
  root.dataset.silknexVersion = "59.0";

  // Keep the discoverability hint out of the way once the user has learned the
  // vertical reel gesture. Session storage avoids replaying tutorial chrome on
  // every story while still showing it on a new browser session.
  const hint = $("#storySwipeHint");
  const learnedKey = "silknex:v59:story-reel-learned";
  const hideHint = () => {
    hint?.classList.add("hidden-hint");
    try { sessionStorage.setItem(learnedKey, "1"); } catch {}
  };

  try {
    if (sessionStorage.getItem(learnedKey) === "1") {
      hint?.classList.add("hidden-hint");
    }
  } catch {}

  const viewer = $("#storyViewerModal");

  // On phones the Stories navigation item opens straight into the first
  // unseen friend's story, turning the tab into an immersive reel instead of
  // making people tap the horizontal tray again. The tray remains available
  // when there are no other active stories.
  const openMobileStoryReel = async () => {
    if (!window.matchMedia?.("(max-width: 900px), (pointer: coarse)")?.matches) return;
    if (!viewer?.classList.contains("hidden")) return;

    const findStory = () =>
      $("#storiesRail .story-chip:not(.story-add-chip):not(.mine):not(.viewed)") ||
      $("#storiesRail .story-chip:not(.story-add-chip):not(.mine)");

    let target = findStory();
    if (!target) {
      try { await window.SilknexApp?.loadStories?.(); } catch {}
      target = findStory();
    }
    target?.click?.();
  };

  $("#mobileStoriesBtn")?.addEventListener("click", () => {
    setTimeout(openMobileStoryReel, 40);
  });

  viewer?.addEventListener("pointerup", (event) => {
    if (event.pointerType === "mouse") return;
    hideHint();
  }, { passive: true });
  viewer?.addEventListener("wheel", hideHint, { passive: true, once: true });

  // Pausing videos that belong to a hidden story surface keeps decoding work
  // from surviving a quick close/navigation gesture on mobile browsers.
  const observer = viewer && "MutationObserver" in window
    ? new MutationObserver(() => {
        if (!viewer.classList.contains("hidden")) return;
        viewer.querySelectorAll("video").forEach((video) => {
          try { video.pause(); } catch {}
        });
      })
    : null;
  observer?.observe(viewer, { attributes: true, attributeFilter: ["class"] });

  window.SilknexV59 = Object.freeze({
    version: "59.0",
    hideStoryGestureHint: hideHint,
  });
})();

} catch (error) { console.error("Silknex feature module 59:", error); }

;
/* Feature module 60 */
try {
(() => {
  "use strict";

  const root = document.documentElement;
  const VERSION = "60.0";
  const reducedMotion = () =>
    root.dataset.reduceMotion === "true" ||
    Boolean(window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches);

  root.dataset.silknexVersion = VERSION;

  const memory = Number(navigator.deviceMemory || 0);
  const constrained =
    root.dataset.performance === "efficient" ||
    root.dataset.v57LowMemory === "true" ||
    navigator.connection?.saveData === true ||
    (memory > 0 && memory <= 4);

  root.dataset.v60MotionTier = reducedMotion() ? "none" : constrained ? "lite" : "full";
  root.dataset.inputMode = window.matchMedia?.("(pointer: coarse)")?.matches ? "touch" : "pointer";

  // Keep version-specific styling from getting stuck after an interrupted swipe,
  // animation, page restore, or BFCache navigation.
  function clearTransientMotion() {
    document
      .querySelectorAll(".v56-swipe-return,.v56-swipe-dismiss,.v58-open,.v58-selected,.v58-item-enter,.story-dragging,.story-committing,.story-snap-in")
      .forEach((node) => {
        node.classList.remove(
          "v56-swipe-return",
          "v56-swipe-dismiss",
          "v58-open",
          "v58-selected",
          "v58-item-enter",
          "story-dragging",
          "story-committing",
          "story-snap-in"
        );
        if (node instanceof HTMLElement) {
          node.style.removeProperty("--v56-swipe-y");
          node.style.removeProperty("--v56-swipe-scale");
          node.style.removeProperty("--story-drag-y");
        }
      });
    document.querySelectorAll(".modal").forEach((modal) => {
      if (modal instanceof HTMLElement) {
        modal.style.removeProperty("--v56-swipe-opacity");
      }
    });
    root.removeAttribute("data-v56-swiping");
  }

  // Scroll chrome uses one tiny rAF update per container. This avoids permanent
  // gradients/shadows when content is already at an edge and improves visual
  // hierarchy without adding a document-wide observer.
  const scrollers = new Set();
  let scrollFrame = 0;

  function updateScroller(scroller) {
    if (!(scroller instanceof HTMLElement)) return;
    const max = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
    const top = scroller.scrollTop;
    scroller.dataset.scrollStart = top > 2 ? "true" : "false";
    scroller.dataset.scrollEnd = max - top > 2 ? "false" : "true";
  }

  function flushScrollers() {
    scrollFrame = 0;
    for (const scroller of scrollers) updateScroller(scroller);
  }

  function queueScroller(scroller) {
    if (!(scroller instanceof HTMLElement)) return;
    scrollers.add(scroller);
    if (!scrollFrame) scrollFrame = requestAnimationFrame(flushScrollers);
  }

  function bindScroller(scroller) {
    if (!(scroller instanceof HTMLElement) || scroller.dataset.v60ScrollBound === "1") return;
    scroller.dataset.v60ScrollBound = "1";
    scroller.addEventListener("scroll", () => queueScroller(scroller), { passive: true });
    queueScroller(scroller);
  }

  document
    .querySelectorAll(".conversation-list,.messages,.modal-card,.settings-card,.people-results,.stories-rail,.avatar-builder-tabs")
    .forEach(bindScroller);

  // Modal state previously relied mostly on a visual .hidden class. Keep ARIA
  // state synchronized as well so hidden sheets do not remain exposed to
  // assistive technology after rapid open/close gestures.
  const modalState = new WeakMap();

  function syncModal(modal) {
    if (!(modal instanceof HTMLElement)) return;
    const hidden = modal.classList.contains("hidden");
    modal.setAttribute("aria-hidden", hidden ? "true" : "false");
    const wasOpen = modalState.get(modal) === true;
    const isOpen = !hidden;
    modalState.set(modal, isOpen);

    if (wasOpen && !isOpen) {
      modal.querySelectorAll("video,audio").forEach((media) => {
        if (media instanceof HTMLMediaElement && document.pictureInPictureElement !== media) {
          try { media.pause(); } catch {}
        }
      });
    }
    if (!wasOpen && isOpen) {
      modal.querySelectorAll(".modal-card,.settings-card").forEach(bindScroller);
    }
  }

  const modalObserver = "MutationObserver" in window
    ? new MutationObserver((records) => {
        for (const record of records) syncModal(record.target);
      })
    : null;

  const observedModals = new WeakSet();

  function bindModal(modal) {
    if (!(modal instanceof HTMLElement) || observedModals.has(modal)) return;
    observedModals.add(modal);
    syncModal(modal);
    modalObserver?.observe(modal, { attributes: true, attributeFilter: ["class"] });
    modal.querySelectorAll(".modal-card,.settings-card").forEach(bindScroller);
  }

  document.querySelectorAll(".modal").forEach(bindModal);

  // Several feature modules create a small number of dialogs lazily. Watch only
  // direct body children so those sheets receive the same ARIA/scroll behavior
  // without paying for a document-wide subtree observer.
  const lazyModalObserver = "MutationObserver" in window
    ? new MutationObserver((records) => {
        for (const record of records) {
          for (const node of record.addedNodes) {
            if (node instanceof HTMLElement && node.matches(".modal")) bindModal(node);
          }
        }
      })
    : null;
  if (document.body) lazyModalObserver?.observe(document.body, { childList: true });

  window.addEventListener("silknex:modal", () => {
    document.querySelectorAll(".modal").forEach(bindModal);
  }, { passive: true });

  // A small, bounded long-task sampler lets overloaded devices fall back to the
  // lighter motion tier during this session. It disconnects quickly so the
  // performance safeguard does not itself become background work.
  let longTasks = 0;
  let longTaskMs = 0;
  let longTaskObserver = null;

  if (!constrained && !reducedMotion() && "PerformanceObserver" in window) {
    try {
      longTaskObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          longTasks += 1;
          longTaskMs += Number(entry.duration || 0);
        }
        if (longTasks >= 4 || longTaskMs >= 360) {
          root.dataset.v60MotionTier = "lite";
          root.dataset.v58MotionTier = "lite";
          longTaskObserver?.disconnect();
          longTaskObserver = null;
        }
      });
      longTaskObserver.observe({ type: "longtask", buffered: false });
      setTimeout(() => {
        longTaskObserver?.disconnect();
        longTaskObserver = null;
      }, 12000);
    } catch {}
  }

  function syncConnectivity() {
    root.dataset.network = navigator.onLine === false ? "offline" : "online";
  }
  syncConnectivity();
  window.addEventListener("online", syncConnectivity, { passive: true });
  window.addEventListener("offline", syncConnectivity, { passive: true });

  const pointerMode = window.matchMedia?.("(pointer: coarse)");
  const updatePointerMode = () => {
    root.dataset.inputMode = pointerMode?.matches ? "touch" : "pointer";
  };
  try { pointerMode?.addEventListener("change", updatePointerMode); } catch {}

  // Rapid orientation/BFCache restores can leave a focused invisible control,
  // stale transforms, or outdated scroll-edge chrome behind.
  window.addEventListener("pageshow", () => {
    clearTransientMotion();
    document.querySelectorAll(".conversation-list,.messages,.modal-card,.settings-card").forEach(queueScroller);
  }, { passive: true });
  window.addEventListener("orientationchange", () => {
    requestAnimationFrame(() => {
      clearTransientMotion();
      document.querySelectorAll(".conversation-list,.messages,.modal-card,.settings-card").forEach(queueScroller);
    });
  }, { passive: true });

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
      document.querySelectorAll(".conversation-list,.messages,.modal-card,.settings-card").forEach(queueScroller);
    }
  }, { passive: true });

  // Do not globally smooth-scroll the chat message list. Programmatic smooth
  // scrolling is still available where the app explicitly requests it, but
  // message history insertion no longer animates the entire scroll offset.
  root.dataset.v60Ready = "true";
  requestAnimationFrame(() => {
    requestAnimationFrame(() => root.classList.add("v60-ready"));
  });

  window.SilknexV60 = Object.freeze({
    version: VERSION,
    refreshScrollChrome() {
      document.querySelectorAll(".conversation-list,.messages,.modal-card,.settings-card").forEach(queueScroller);
    },
  });
})();
} catch (error) { console.error("Silknex feature module 60:", error); }

;
/* Feature module 61 */
try {
(() => {
  "use strict";

  const root = document.documentElement;
  const VERSION = "61.0";
  const MB = 1024 * 1024;
  const deviceMemory = Number(navigator.deviceMemory || 0);
  const cores = Number(navigator.hardwareConcurrency || 0);
  const saveData = navigator.connection?.saveData === true;
  const efficient = root.dataset.performance === "efficient";
  const tight =
    efficient ||
    saveData ||
    (deviceMemory > 0 && deviceMemory <= 4) ||
    (cores > 0 && cores <= 4);

  // This is an app-owned memory budget, not a promise about the browser process:
  // the browser, WebRTC stack, GPU surfaces and OS remain outside JS control.
  const budget = Object.freeze({
    mediaIdleBytes: tight ? 3 * MB : 6 * MB,
    mediaHiddenBytes: tight ? 1 * MB : 3 * MB,
    mediaPressureBytes: tight ? 768 * 1024 : 1 * MB,
    mediaIdleItems: tight ? 2 : 3,
    mediaHiddenItems: 1,
    mediaPressureItems: 1,
    heapSoftBytes: tight ? 26 * MB : 32 * MB,
    heapHardBytes: tight ? 36 * MB : 42 * MB,
  });

  root.dataset.silknexVersion = VERSION;
  root.dataset.memoryTier = tight ? "tight" : "balanced";
  root.dataset.v61Ready = "false";

  const isProtectedMedia = (media) =>
    Boolean(media.closest(".call-view,.call-stage,.incoming-call,.story-viewer-card")) ||
    document.pictureInPictureElement === media;

  function pauseOffscreenMedia() {
    document
      .querySelectorAll("#messages video,#messages audio,.public-profile-stories video,.stories-rail video")
      .forEach((media) => {
        if (!(media instanceof HTMLMediaElement) || isProtectedMedia(media)) return;
        const rect = media.getBoundingClientRect();
        const margin = tight ? 180 : 320;
        const offscreen =
          rect.bottom < -margin ||
          rect.top > window.innerHeight + margin ||
          document.hidden;
        if (offscreen && !media.paused) {
          try { media.pause(); } catch {}
        }
      });
  }

  function tuneMediaHints(scope = document) {
    scope.querySelectorAll?.("img").forEach((image) => {
      if (!(image instanceof HTMLImageElement)) return;
      const critical = Boolean(
        image.closest(".chat-header,.me-bar,.call-view,.incoming-call,.profile-identity-card,.avatar-builder-stage")
      );
      image.decoding = "async";
      image.draggable = false;
      if (!critical) {
        image.loading = "lazy";
        try { image.fetchPriority = "low"; } catch {}
      }
    });

    scope.querySelectorAll?.("video,audio").forEach((media) => {
      if (!(media instanceof HTMLMediaElement) || isProtectedMedia(media)) return;
      if (!media.hasAttribute("autoplay")) media.preload = "metadata";
    });
  }

  function trim(level = "idle") {
    const e2ee = window.SilknexE2EE;
    if (e2ee?.trimMediaCache) {
      if (level === "pressure") {
        e2ee.trimMediaCache({
          maxItems: budget.mediaPressureItems,
          maxBytes: budget.mediaPressureBytes,
        });
        try { e2ee.clearDeviceKeyCache?.(); } catch {}
      } else if (level === "hidden") {
        e2ee.trimMediaCache({
          maxItems: budget.mediaHiddenItems,
          maxBytes: budget.mediaHiddenBytes,
        });
      } else {
        e2ee.trimMediaCache({
          maxItems: budget.mediaIdleItems,
          maxBytes: budget.mediaIdleBytes,
        });
      }
    }

    pauseOffscreenMedia();

    if (level === "pressure") {
      root.dataset.memoryPressure = "high";
      // Expensive motion can keep extra compositor surfaces alive. Under
      // pressure, fall back to the existing lightweight motion tiers.
      root.dataset.v60MotionTier = "lite";
      root.dataset.v58MotionTier = "lite";
      root.dataset.v57MotionTier = "lite";
    }
  }

  function sampleHeap() {
    const memory = performance?.memory;
    if (!memory || !Number.isFinite(memory.usedJSHeapSize)) return;

    const used = Number(memory.usedJSHeapSize || 0);
    root.dataset.jsHeapMb = String(Math.round(used / MB));

    if (used >= budget.heapHardBytes) {
      trim("pressure");
      root.dataset.memoryPressure = "critical";
    } else if (used >= budget.heapSoftBytes) {
      trim("pressure");
    } else if (root.dataset.memoryPressure) {
      delete root.dataset.memoryPressure;
    }
  }

  let sampleTimer = 0;
  function scheduleHeapSampling() {
    clearInterval(sampleTimer);
    sampleTimer = 0;
    if (document.hidden || !performance?.memory || !Number.isFinite(performance.memory.usedJSHeapSize)) return;
    sampleTimer = setInterval(sampleHeap, tight ? 12000 : 18000);
  }

  const messages = document.getElementById("messages");
  const storySurfaces = document.querySelector(".stories-rail,.public-profile-stories");
  const observers = [];

  // Keep observers narrow: chat/story surfaces are the only high-churn areas
  // that materially benefit from dynamic media hints.
  for (const target of [messages, storySurfaces].filter(Boolean)) {
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of record.addedNodes) {
          if (node instanceof Element) tuneMediaHints(node);
        }
      }
    });
    observer.observe(target, { childList: true, subtree: true });
    observers.push(observer);
  }

  tuneMediaHints(document);

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      clearInterval(sampleTimer);
      sampleTimer = 0;
      trim("hidden");
    } else {
      tuneMediaHints(document);
      trim("idle");
      sampleHeap();
      scheduleHeapSampling();
    }
  }, { passive: true });

  window.addEventListener("memorypressure", () => trim("pressure"), { passive: true });
  window.addEventListener("pagehide", () => {
    clearInterval(sampleTimer);
    sampleTimer = 0;
    trim("hidden");
  }, { passive: true });

  window.addEventListener("pageshow", () => {
    trim("idle");
    scheduleHeapSampling();
  }, { passive: true });

  window.addEventListener("silknex:conversation", () => {
    requestAnimationFrame(() => {
      tuneMediaHints(document.getElementById("messages") || document);
      trim("idle");
    });
  }, { passive: true });

  const idle = window.requestIdleCallback ||
    ((callback) => setTimeout(() => callback({ timeRemaining: () => 0 }), 700));
  idle(() => {
    trim("idle");
    sampleHeap();
  }, { timeout: 1500 });

  scheduleHeapSampling();

  window.SilknexMemory = Object.freeze({
    version: VERSION,
    profile: tight ? "tight" : "balanced",
    budget,
    trim,
    sample: sampleHeap,
  });

  requestAnimationFrame(() => {
    root.dataset.v61Ready = "true";
  });
})();
} catch (error) { console.error("Silknex feature module 61:", error); }

;
/* Feature module 62 */
try {
(() => {
  "use strict";

  const VERSION = "62.0";
  const root = document.documentElement;
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const app = () => window.SilknexApp;
  const store = {
    boards: "silknex:v62:keyboards",
    mediaQuality: "silknex:v62:media-quality",
    keyboardEnabled: "silknex:v62:keyboard-enabled",
    activeBoard: "silknex:v62:keyboard-active",
  };

  const DEFAULT_BOARDS = Object.freeze([
    { id: "chat", name: "Chat", keys: ["😂", "❤️", "😭", "🔥", "👍", "👀", "✨", "💀"] },
    { id: "quick", name: "Quick", keys: ["On my way!", "Sounds good", "Thank you!", "One sec", "Yes", "No"] },
    { id: "marks", name: "Symbols", keys: ["@", "#", "&", "•", "→", "✓", "★", "…"] },
  ]);

  let boards = [];
  let activeBoard = "";
  let keyboardEnabled = true;
  let lastSelection = { start: 0, end: 0 };
  let suggestionRequest = 0;
  let settingsInstalled = false;
  let keyboardInstalled = false;
  let qrImageBusy = false;
  let deepLinkOpened = false;

  function toast(message) {
    app()?.toast?.(message);
  }

  function safeId(value) {
    return String(value || "").replace(/[^a-z0-9_-]/gi, "").slice(0, 40);
  }

  function usernameFromProfileValue(raw) {
    const value = String(raw || "").trim();
    if (!value) return "";
    const direct = value.match(/^silknex:([a-z0-9_.]{3,24})$/i);
    if (direct) return direct[1].toLowerCase();
    if (/^@?[a-z0-9_.]{3,24}$/i.test(value)) return value.replace(/^@/, "").toLowerCase();
    try {
      const url = new URL(value, location.href);
      if (url.origin !== location.origin) return "";
      const candidate = String(
        url.searchParams.get("profile") ||
        url.searchParams.get("u") ||
        url.pathname.match(/^\/@([a-z0-9_.-]{3,24})\/?$/i)?.[1] ||
        url.pathname.match(/\/(?:u|profile)\/([a-z0-9_.]{3,24})/i)?.[1] ||
        ""
      ).replace(/^@/, "").toLowerCase();
      return /^[a-z0-9_.]{3,24}$/.test(candidate) ? candidate : "";
    } catch {
      return "";
    }
  }

  function openProfileValue(value) {
    const username = usernameFromProfileValue(value);
    if (!username) {
      toast("That is not a valid Silknex profile code or username.");
      return false;
    }
    try { app()?.closeModal?.(); } catch {}
    window.SilkNexOpenPublicProfile?.(username);
    return true;
  }

  function normalizeKeys(values) {
    const source = Array.isArray(values) ? values : [];
    const out = [];
    for (const raw of source) {
      const key = String(raw ?? "").trim().replace(/\s+/g, " ");
      if (!key || key.length > 48 || out.includes(key)) continue;
      out.push(key);
      if (out.length >= 16) break;
    }
    return out;
  }

  function normalizeBoards(raw) {
    const source = Array.isArray(raw) ? raw : [];
    const result = [];
    const seen = new Set();
    for (const item of source) {
      if (!item || typeof item !== "object") continue;
      let id = safeId(item.id);
      if (!id || seen.has(id)) id = `keys-${crypto?.randomUUID?.().slice(0, 8) || Date.now().toString(36)}-${result.length}`;
      const name = String(item.name || "Keyboard").trim().slice(0, 24) || "Keyboard";
      const keys = normalizeKeys(item.keys);
      if (!keys.length) continue;
      seen.add(id);
      result.push({ id, name, keys });
      if (result.length >= 5) break;
    }
    return result.length ? result : DEFAULT_BOARDS.map((item) => ({ ...item, keys: [...item.keys] }));
  }

  function loadKeyboardState() {
    try {
      boards = normalizeBoards(JSON.parse(window.SilknexStorage.getItem(store.boards) || "[]"));
    } catch {
      boards = normalizeBoards([]);
    }
    keyboardEnabled = window.SilknexStorage.getItem(store.keyboardEnabled) !== "0";
    const requested = safeId(window.SilknexStorage.getItem(store.activeBoard) || "");
    activeBoard = boards.some((board) => board.id === requested) ? requested : boards[0].id;
  }

  function persistKeyboardState() {
    window.SilknexStorage.setItem(store.boards, JSON.stringify(boards));
    window.SilknexStorage.setItem(store.keyboardEnabled, keyboardEnabled ? "1" : "0");
    window.SilknexStorage.setItem(store.activeBoard, activeBoard);
  }

  function rememberSelection(input) {
    if (!(input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement)) return;
    lastSelection = {
      start: Number.isFinite(input.selectionStart) ? input.selectionStart : input.value.length,
      end: Number.isFinite(input.selectionEnd) ? input.selectionEnd : input.value.length,
    };
  }

  function insertQuickKey(text) {
    const input = $("#messageInput");
    if (!input) return;
    const value = String(text || "");
    const start = Math.max(0, Math.min(input.value.length, Number(lastSelection.start ?? input.selectionStart ?? input.value.length)));
    const end = Math.max(start, Math.min(input.value.length, Number(lastSelection.end ?? input.selectionEnd ?? start)));
    const before = input.value.slice(0, start);
    const needsSpace = value.length > 1 && before && !/\s$/.test(before) && !/^[,.:;!?)}\]]/.test(value);
    const after = input.value.slice(end);
    const trailingSpace = value.length > 1 && after && !/^\s|^[,.:;!?)}\]]/.test(after) ? " " : "";
    const insertion = `${needsSpace ? " " : ""}${value}${trailingSpace}`;

    try {
      if (typeof input.setRangeText === "function") {
        input.setRangeText(insertion, start, end, "end");
      } else {
        input.value = `${before}${insertion}${after}`;
        const caret = start + insertion.length;
        input.setSelectionRange?.(caret, caret);
      }
    } catch {
      input.value = `${before}${insertion}${after}`;
    }

    input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: insertion }));
    try { input.focus({ preventScroll: true }); } catch { input.focus(); }
    rememberSelection(input);
    requestAnimationFrame(() => {
      const messages = $("#messages");
      if (messages) messages.scrollTop = messages.scrollHeight;
    });
  }

  function renderKeyboardTray() {
    const tray = $("#v62CustomKeyboardTray");
    if (!tray) return;
    tray.classList.toggle("hidden", !keyboardEnabled);
    if (!keyboardEnabled) return;

    const active = boards.find((board) => board.id === activeBoard) || boards[0];
    if (!active) return;
    activeBoard = active.id;

    const tabs = $(".v62-keyboard-tabs", tray);
    const keys = $(".v62-keyboard-keys", tray);
    tabs.replaceChildren();
    keys.replaceChildren();

    for (const board of boards) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "v62-keyboard-tab";
      button.textContent = board.name;
      button.classList.toggle("active", board.id === active.id);
      button.setAttribute("aria-pressed", board.id === active.id ? "true" : "false");
      button.addEventListener("pointerdown", (event) => event.preventDefault());
      button.addEventListener("click", () => {
        activeBoard = board.id;
        persistKeyboardState();
        renderKeyboardTray();
        syncKeyboardSettings();
      });
      tabs.appendChild(button);
    }

    for (const value of active.keys) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "v62-keyboard-key";
      button.textContent = value;
      button.title = value;
      button.addEventListener("pointerdown", (event) => event.preventDefault());
      button.addEventListener("click", () => insertQuickKey(value));
      keys.appendChild(button);
    }
  }

  function installKeyboardTray() {
    if (keyboardInstalled) return;
    const form = $("#messageForm");
    if (!form?.parentElement) return;
    keyboardInstalled = true;
    root.dataset.v62Keyboards = "1";

    const tray = document.createElement("div");
    tray.id = "v62CustomKeyboardTray";
    tray.className = "v62-custom-keyboard";
    tray.setAttribute("aria-label", "Custom keyboard shortcuts");
    tray.innerHTML = `<div class="v62-keyboard-tabs" role="tablist" aria-label="Keyboard layouts"></div><div class="v62-keyboard-keys"></div>`;
    form.parentElement.insertBefore(tray, form);
    renderKeyboardTray();

    const input = $("#messageInput");
    for (const eventName of ["select", "keyup", "input", "pointerup", "focus"]) {
      input?.addEventListener(eventName, () => rememberSelection(input), { passive: true });
    }
  }

  function keyboardSettingsMarkup() {
    return `
      <section id="v62KeyboardSettings" class="settings-section v62-settings-section">
        <div class="section-title"><span>Custom keyboards</span></div>
        <div class="setting-row">
          <div><b>Quick-key keyboard</b><small>Show your own switchable key rows above the message box.</small></div>
          <label class="switch"><input id="v62KeyboardEnabled" type="checkbox" aria-label="Enable custom keyboard"><span></span></label>
        </div>
        <div class="v62-keyboard-editor">
          <label class="field"><span>Keyboard</span><select id="v62KeyboardBoardSelect"></select></label>
          <label class="field"><span>Name</span><input id="v62KeyboardName" maxlength="24" autocomplete="off"></label>
          <label class="field v62-keys-field"><span>Keys / phrases</span><textarea id="v62KeyboardKeys" rows="3" maxlength="600" placeholder="😂, ❤️, On my way!, Thank you!"></textarea><small>Separate keys with commas or new lines. Up to 16 per keyboard.</small></label>
          <div class="v62-settings-actions">
            <button id="v62KeyboardSave" class="secondary-btn" type="button">Save keyboard</button>
            <button id="v62KeyboardAdd" class="secondary-btn" type="button">New keyboard</button>
            <button id="v62KeyboardDelete" class="text-btn" type="button">Delete</button>
          </div>
        </div>
      </section>`;
  }

  function mediaSettingsMarkup() {
    return `
      <section id="v62MediaSettings" class="settings-section v62-settings-section">
        <div class="section-title"><span>Media & storage</span></div>
        <label class="setting-row v62-select-row">
          <div><b>Image upload quality</b><small>WebP compression keeps photos sharp while reducing storage and transfer size.</small></div>
          <select id="v62MediaQuality" aria-label="Image upload quality">
            <option value="saver">Data saver</option>
            <option value="balanced">Balanced</option>
            <option value="detail">Maximum detail</option>
          </select>
        </label>
      </section>`;
  }

  function syncKeyboardSettings() {
    const enabled = $("#v62KeyboardEnabled");
    const select = $("#v62KeyboardBoardSelect");
    if (!enabled || !select) return;
    enabled.checked = keyboardEnabled;
    select.replaceChildren();
    for (const board of boards) {
      const option = document.createElement("option");
      option.value = board.id;
      option.textContent = board.name;
      option.selected = board.id === activeBoard;
      select.appendChild(option);
    }
    const active = boards.find((board) => board.id === activeBoard) || boards[0];
    $("#v62KeyboardName").value = active?.name || "";
    $("#v62KeyboardKeys").value = active?.keys.join(", ") || "";
    $("#v62KeyboardDelete").disabled = boards.length <= 1;
  }

  function installSettings() {
    const card = $("#settingsModal .settings-stack, #settingsModal .modal-card");
    if (!card) return;
    if (!$("#v62KeyboardSettings")) card.insertAdjacentHTML("beforeend", keyboardSettingsMarkup());
    if (!$("#v62MediaSettings")) card.insertAdjacentHTML("beforeend", mediaSettingsMarkup());

    if (!settingsInstalled) {
      settingsInstalled = true;
      $("#v62KeyboardEnabled")?.addEventListener("change", (event) => {
        keyboardEnabled = Boolean(event.currentTarget.checked);
        persistKeyboardState();
        renderKeyboardTray();
      });
      $("#v62KeyboardBoardSelect")?.addEventListener("change", (event) => {
        activeBoard = safeId(event.currentTarget.value);
        persistKeyboardState();
        syncKeyboardSettings();
        renderKeyboardTray();
      });
      $("#v62KeyboardSave")?.addEventListener("click", () => {
        const board = boards.find((item) => item.id === activeBoard);
        if (!board) return;
        const keys = normalizeKeys(String($("#v62KeyboardKeys")?.value || "").split(/[,\n]+/));
        if (!keys.length) {
          toast("Add at least one key or phrase.");
          return;
        }
        board.name = String($("#v62KeyboardName")?.value || "").trim().slice(0, 24) || "Keyboard";
        board.keys = keys;
        persistKeyboardState();
        syncKeyboardSettings();
        renderKeyboardTray();
        toast("Keyboard saved.");
      });
      $("#v62KeyboardAdd")?.addEventListener("click", () => {
        if (boards.length >= 5) {
          toast("You can keep up to five custom keyboards.");
          return;
        }
        const id = `custom-${Date.now().toString(36)}`;
        boards.push({ id, name: `Keyboard ${boards.length + 1}`, keys: ["✨", "👍", "❤️"] });
        activeBoard = id;
        persistKeyboardState();
        syncKeyboardSettings();
        renderKeyboardTray();
      });
      $("#v62KeyboardDelete")?.addEventListener("click", () => {
        if (boards.length <= 1) return;
        boards = boards.filter((board) => board.id !== activeBoard);
        activeBoard = boards[0].id;
        persistKeyboardState();
        syncKeyboardSettings();
        renderKeyboardTray();
      });
      $("#v62MediaQuality")?.addEventListener("change", (event) => {
        const value = ["saver", "balanced", "detail"].includes(event.currentTarget.value)
          ? event.currentTarget.value : "balanced";
        window.SilknexStorage.setItem(store.mediaQuality, value);
        root.dataset.mediaQuality = value;
        toast("Media quality preference saved.");
      });
    }

    const quality = window.SilknexStorage.getItem(store.mediaQuality) || "balanced";
    if ($("#v62MediaQuality")) $("#v62MediaQuality").value = ["saver", "balanced", "detail"].includes(quality) ? quality : "balanced";
    root.dataset.mediaQuality = quality;
    syncKeyboardSettings();
    installBannerManager();
  }

  function installBannerManager() {
    const section = $("#v53PublicProfileSettings");
    if (!section || $("#v62BannerManager")) return;
    const manager = document.createElement("div");
    manager.id = "v62BannerManager";
    manager.className = "v62-banner-manager";
    manager.innerHTML = `
      <div id="v62BannerPreview" class="v62-banner-preview" role="img" aria-label="Current public profile banner"><span>No banner image</span></div>
      <div class="v62-settings-actions">
        <button id="v62ChangeBanner" class="secondary-btn" type="button">Change banner</button>
        <button id="v62RemoveBanner" class="text-btn" type="button">Remove banner</button>
      </div>`;
    section.appendChild(manager);

    $("#v62ChangeBanner")?.addEventListener("click", () => $("#v53BannerInput")?.click());
    $("#v62RemoveBanner")?.addEventListener("click", async () => {
      const button = $("#v62RemoveBanner");
      if (!app()?.state?.me?.profile_banner_url) return;
      button.disabled = true;
      try {
        const data = await app().api("public_profile_settings", {
          method: "POST",
          body: { remove_banner: true },
        });
        if (app()?.state?.me) app().state.me.profile_banner_url = data.profile_banner_url || "";
        syncBannerPreview();
        toast("Profile banner removed.");
      } catch (error) {
        toast(error?.message || "Could not remove the banner.");
      } finally {
        button.disabled = false;
      }
    });
    syncBannerPreview();
  }

  function syncBannerPreview() {
    const preview = $("#v62BannerPreview");
    const remove = $("#v62RemoveBanner");
    if (!preview) return;
    const url = String(app()?.state?.me?.profile_banner_url || "");
    preview.style.backgroundImage = url ? `url("${url.replace(/["\\]/g, "")}")` : "";
    preview.classList.toggle("has-image", Boolean(url));
    const label = $("span", preview);
    if (label) label.hidden = Boolean(url);
    if (remove) remove.disabled = !url;
  }

  async function loadFriendSuggestions() {
    const request = ++suggestionRequest;
    const section = $("#friendSuggestionsSection");
    const list = $("#friendSuggestionsList");
    if (!section || !list || !app()?.state?.me) return;
    try {
      const data = await app().api("friend_suggestions");
      if (request !== suggestionRequest) return;
      const suggestions = Array.isArray(data?.suggestions) ? data.suggestions : [];
      list.replaceChildren();
      section.classList.toggle("hidden", !suggestions.length);

      for (const person of suggestions) {
        const row = document.createElement("div");
        row.className = "friend-row v62-suggestion";
        const avatar = document.createElement("button");
        avatar.type = "button";
        avatar.className = "avatar avatar-md v62-suggestion-avatar";
        avatar.setAttribute("aria-label", `Open ${person.display_name || person.username}'s profile`);
        app().setAvatar?.(avatar, person.display_name || person.username, person.accent || "silver", person.avatar_url || "", person.avatar_style || null);
        avatar.onclick = () => window.SilkNexOpenPublicProfile?.(person.username, person);

        const copy = document.createElement("div");
        copy.className = "friend-copy";
        const name = document.createElement("b");
        name.textContent = person.display_name || person.username;
        const meta = document.createElement("small");
        const mutuals = Math.max(1, Number(person.mutual_count || 1));
        meta.textContent = `@${person.username} · ${mutuals} mutual friend${mutuals === 1 ? "" : "s"}`;
        copy.append(name, meta);

        const add = document.createElement("button");
        add.type = "button";
        add.className = "secondary-btn compact";
        add.textContent = "Add";
        add.onclick = async () => {
          add.disabled = true;
          try {
            await app().api("friend_request", { method: "POST", body: { user_id: Number(person.id) } });
            row.remove();
            if (!list.children.length) section.classList.add("hidden");
            app().loadFriends?.({ notify: false }).catch?.(() => {});
            toast(`Friend request sent to ${person.display_name || person.username}.`);
          } catch (error) {
            add.disabled = false;
            toast(error?.message || "Could not send friend request.");
          }
        };
        row.append(avatar, copy, add);
        list.appendChild(row);
      }
    } catch {
      section.classList.add("hidden");
    }
  }

  async function detectQrFromImage(file) {
    if (!file || !/^image\//i.test(file.type)) throw new Error("Choose a QR image.");
    if (typeof BarcodeDetector === "undefined") {
      throw new Error("This browser cannot read saved QR images yet. Paste the Silknex profile link or username below.");
    }
    const detector = new BarcodeDetector({ formats: ["qr_code"] });
    let source = null;
    let url = "";
    try {
      if (typeof createImageBitmap === "function") {
        source = await createImageBitmap(file);
      } else {
        url = URL.createObjectURL(file);
        source = await new Promise((resolve, reject) => {
          const image = new Image();
          image.onload = () => resolve(image);
          image.onerror = reject;
          image.src = url;
        });
      }
      const codes = await detector.detect(source);
      for (const code of codes || []) {
        const username = usernameFromProfileValue(code.rawValue);
        if (username) return username;
      }
      throw new Error("No Silknex profile QR was found in that image.");
    } finally {
      try { source?.close?.(); } catch {}
      if (url) URL.revokeObjectURL(url);
    }
  }

  function bindQrImprovements() {
    $("#scanProfileQrImageBtn")?.addEventListener("click", () => $("#qrImageInput")?.click());
    $("#qrImageInput")?.addEventListener("change", async (event) => {
      if (qrImageBusy) return;
      const file = event.currentTarget.files?.[0];
      event.currentTarget.value = "";
      if (!file) return;
      qrImageBusy = true;
      const button = $("#scanProfileQrImageBtn");
      if (button) button.disabled = true;
      try {
        const username = await detectQrFromImage(file);
        openProfileValue(username);
      } catch (error) {
        toast(error?.message || "Could not read that QR image.");
      } finally {
        qrImageBusy = false;
        if (button) button.disabled = false;
      }
    });

    $("#qrManualOpenBtn")?.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      openProfileValue($("#qrManualUsername")?.value);
    }, true);

    $("#qrManualUsername")?.addEventListener("keydown", (event) => {
      if (event.key !== "Enter") return;
      event.preventDefault();
      event.stopImmediatePropagation();
      openProfileValue(event.currentTarget.value);
    }, true);
  }

  function tryStartupProfileLink() {
    if (deepLinkOpened || !app()?.state?.me) return;
    const params = new URLSearchParams(location.search);
    const username = usernameFromProfileValue(location.pathname.match(/^\/@([a-z0-9_.-]{3,24})\/?$/i)?.[1] || params.get("profile") || params.get("u") || "");
    if (!username) return;
    deepLinkOpened = true;
    window.SilkNexOpenPublicProfile?.(username);
    try {
      const clean = new URL(location.href);
      clean.searchParams.delete("profile");
      clean.searchParams.delete("u");
      history.replaceState(history.state, "", clean);
    } catch {}
  }

  function updateReleaseState() {
    root.dataset.silknexVersion = VERSION;
    root.dataset.silknexRelease = VERSION;
    root.dataset.v62Ready = "true";
  }

  function init() {
    if (!app()) {
      window.addEventListener("silknex:core-ready", init, { once: true });
      return;
    }
    if (root.dataset.v62Booted === "1") return;
    root.dataset.v62Booted = "1";
    loadKeyboardState();
    installKeyboardTray();
    bindQrImprovements();
    installSettings();
    updateReleaseState();
    tryStartupProfileLink();

    window.addEventListener("silknex:session", (event) => {
      if (!event.detail?.signedIn) return;
      installSettings();
      installBannerManager();
      syncBannerPreview();
      tryStartupProfileLink();
    });

    window.addEventListener("silknex:modal", (event) => {
      if (!event.detail?.open) return;
      if (event.detail.id === "friendsModal") loadFriendSuggestions();
      if (event.detail.id === "settingsModal") {
        installSettings();
        syncBannerPreview();
      }
    });

    window.addEventListener("silknex:conversation", () => {
      renderKeyboardTray();
      requestAnimationFrame(() => {
        const input = $("#messageInput");
        if (input) input.style.scrollMarginBottom = "calc(var(--keyboard-height, 0px) + 16px)";
      });
    }, { passive: true });

    const v53BannerInput = $("#v53BannerInput");
    v53BannerInput?.addEventListener("change", () => {
      setTimeout(syncBannerPreview, 900);
    });

    if (!window.SilknexStorage.getItem(store.mediaQuality)) window.SilknexStorage.setItem(store.mediaQuality, "balanced");
    root.dataset.mediaQuality = window.SilknexStorage.getItem(store.mediaQuality) || "balanced";
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
} catch (error) { console.error("Silknex feature module 62:", error); }

/* Subscription and entitlement UI (original v63 module). */
try {
(() => {
  "use strict";

  const VERSION = "63.0";
  const root = document.documentElement;
  const $ = (s, scope = document) => scope.querySelector(s);
  const $$ = (s, scope = document) => [...scope.querySelectorAll(s)];
  const app = () => window.SilknexApp;

  const PLAN_ORDER = ["basic", "simple", "premium", "super-premium", "super-develop"];
  const FALLBACK_PLANS = [
    {id:"basic",name:"Basic",price_cents:199,features:{ad_free:true,custom_emojis:false,feature_requests:false,beta_access:false,dev_access:false}},
    {id:"simple",name:"Simple",price_cents:349,features:{ad_free:true,custom_emojis:true,feature_requests:false,beta_access:false,dev_access:false}},
    {id:"premium",name:"Premium",price_cents:499,features:{ad_free:true,custom_emojis:true,feature_requests:true,beta_access:false,dev_access:false}},
    {id:"super-premium",name:"Super-Premium",price_cents:649,features:{ad_free:true,custom_emojis:true,feature_requests:true,beta_access:true,dev_access:false}},
    {id:"super-develop",name:"Super-Develop",price_cents:999,features:{ad_free:true,custom_emojis:true,feature_requests:true,beta_access:true,dev_access:true}},
  ];
  const FEATURES = [
    ["ad_free","Fully ad-free"],
    ["custom_emojis","Custom emojis"],
    ["feature_requests","Feature requests"],
    ["beta_access","Beta access"],
    ["dev_access","Dev access"],
  ];

  let signedIn = false;
  let config = null;
  let status = null;
  let refreshPromise = null;
  let selectedStickerId = 0;
  let billingPending = false;

  function setBillingPending(pending) {
    billingPending = pending;
    for (const button of $$(".v63-plan-card button")) {
      if (pending) {
        button.dataset.billingWasDisabled = String(button.disabled);
        button.disabled = true;
        button.setAttribute("aria-busy", "true");
      } else {
        if (button.dataset.billingWasDisabled !== undefined) {
          button.disabled = button.dataset.billingWasDisabled === "true";
          delete button.dataset.billingWasDisabled;
        }
        button.removeAttribute("aria-busy");
      }
    }
  }

  function toast(message) { app()?.toast?.(String(message || "")); }
  function money(cents) { return `$${(Number(cents || 0) / 100).toFixed(2)}`; }
  function plans() {
    const server = Array.isArray(config?.subscription?.plans) ? config.subscription.plans : [];
    const normalized = server.filter((p) => p && PLAN_ORDER.includes(p.id));
    return normalized.length === 5 ? PLAN_ORDER.map((id) => normalized.find((p) => p.id === id)) : FALLBACK_PLANS;
  }
  function activePlan() { return String(status?.subscription_plan || ""); }
  function feature(name) { return Boolean(status?.subscription_active && status?.subscription_features?.[name]); }

  function installMarkup() {
    const attachmentMenu = $("#attachmentMenu");
    if (attachmentMenu && !$("#v63EmojiPickerBtn")) {
      const emojiButton = document.createElement("button");
      emojiButton.id = "v63EmojiPickerBtn";
      emojiButton.type = "button";
      emojiButton.setAttribute("role", "menuitem");
      emojiButton.className = "hidden";
      emojiButton.innerHTML = `<span aria-hidden="true">◉</span><b>Custom emojis</b>`;
      attachmentMenu.appendChild(emojiButton);
      emojiButton.addEventListener("click", openEmojiPicker);
    }

    if (!$("#v63SubscriptionSection")) {
      const target = $("#monetizationSettings");
      target?.insertAdjacentHTML("beforebegin", `
        <section id="v63SubscriptionSection" class="settings-section v63-subscription-settings">
          <div class="section-title"><span>Subscriptions</span><span id="v63PlanBadge" class="v63-plan-badge">Free</span></div>
          <div class="v63-plan-summary">
            <div><b id="v63PlanTitle">Choose your Silknex plan</b><small id="v63PlanCopy">Ad-free plans with optional emoji, feature request, beta, and developer access.</small></div>
            <button id="v63OpenPlans" class="primary" type="button">View plans</button>
          </div>
          <div id="v63EntitlementChips" class="v63-entitlement-chips" aria-label="Plan benefits"></div>
        </section>`);
    }

    if (!$("#v63PlansModal")) {
      document.body.insertAdjacentHTML("beforeend", `
        <section id="v63PlansModal" class="modal hidden v63-plans-modal" role="dialog" aria-modal="true" aria-labelledby="v63PlansTitle" aria-hidden="true">
          <div class="modal-card v63-plans-card">
            <header class="modal-head">
              <div><small>SILKNEX PLANS</small><h2 id="v63PlansTitle">Pick the access you want</h2><p>Every paid plan is fully ad-free. Upgrade only for the extras you use.</p></div>
              <button class="plain-btn icon-only v63-close" type="button" aria-label="Close">×</button>
            </header>
            <div id="v63PlanGrid" class="v63-plan-grid"></div>
            <div class="v63-plan-foot"><small>Monthly subscription. Billing is handled by secure Stripe Checkout when configured.</small></div>
          </div>
        </section>`);

      $("#v63PlansModal .v63-close")?.addEventListener("click", closePlans);
      $("#v63PlansModal")?.addEventListener("click", (event) => {
        if (event.target === event.currentTarget) closePlans();
      });
    }

    if (!$("#v63EmojiModal")) {
      document.body.insertAdjacentHTML("beforeend", `
        <section id="v63EmojiModal" class="modal hidden" role="dialog" aria-modal="true" aria-labelledby="v63EmojiTitle" aria-hidden="true">
          <div class="modal-card v63-small-card">
            <header class="modal-head"><div><small>SIMPLE+</small><h2 id="v63EmojiTitle">Custom emojis</h2><p>Turn any saved sticker into a named emoji shortcut.</p></div><button class="plain-btn icon-only v63-close" type="button" aria-label="Close">×</button></header>
            <div class="v63-emoji-create">
              <label class="field"><span>Emoji name</span><input id="v63EmojiName" maxlength="22" placeholder="party_blob" autocomplete="off"></label>
              <div><small>Choose one of your saved stickers</small><div id="v63EmojiStickerGrid" class="v63-emoji-sticker-grid"></div></div>
              <button id="v63EmojiCreate" class="primary" type="button" disabled>Create emoji</button>
            </div>
            <div id="v63EmojiList" class="v63-emoji-list"></div>
          </div>
        </section>`);
      $("#v63EmojiModal .v63-close")?.addEventListener("click", () => closeModal("#v63EmojiModal"));
      $("#v63EmojiCreate")?.addEventListener("click", createEmoji);
    }

    if (!$("#v63RequestModal")) {
      document.body.insertAdjacentHTML("beforeend", `
        <section id="v63RequestModal" class="modal hidden" role="dialog" aria-modal="true" aria-labelledby="v63RequestTitle" aria-hidden="true">
          <div class="modal-card v63-small-card">
            <header class="modal-head"><div><small>PREMIUM</small><h2 id="v63RequestTitle">Request a feature</h2></div><button class="plain-btn icon-only v63-close" type="button" aria-label="Close">×</button></header>
            <form id="v63RequestForm" class="v63-request-form">
              <label class="field"><span>Title</span><input id="v63RequestName" maxlength="100" required placeholder="What should Silknex add?"></label>
              <label class="field"><span>Details</span><textarea id="v63RequestDetails" rows="5" maxlength="2000" required placeholder="Explain how you would use it."></textarea></label>
              <button class="primary" type="submit">Submit request</button>
            </form>
            <div id="v63RequestHistory" class="v63-request-history"></div>
          </div>
        </section>`);
      $("#v63RequestModal .v63-close")?.addEventListener("click", () => closeModal("#v63RequestModal"));
      $("#v63RequestForm")?.addEventListener("submit", submitFeatureRequest);
    }

    if (!$("#v63AccessTools")) {
      $("#v63SubscriptionSection")?.insertAdjacentHTML("beforeend", `
        <div id="v63AccessTools" class="v63-access-tools">
          <button id="v63EmojiBtn" class="secondary-btn hidden" type="button">Custom emojis</button>
          <button id="v63FeatureRequestBtn" class="secondary-btn hidden" type="button">Request a feature</button>
          <button id="v63BetaBtn" class="secondary-btn hidden" type="button">Beta access</button>
          <button id="v63DevBtn" class="secondary-btn hidden" type="button">Developer access</button>
        </div>`);
      $("#v63EmojiBtn")?.addEventListener("click", openEmojiManager);
      $("#v63FeatureRequestBtn")?.addEventListener("click", openFeatureRequests);
      $("#v63BetaBtn")?.addEventListener("click", () => toast("Beta access is enabled for this account. Experimental builds can be enabled as they are published."));
      $("#v63DevBtn")?.addEventListener("click", showDevAccess);
    }

    $("#v63OpenPlans")?.addEventListener("click", openPlans);

    // The old ad-free button stays as a compatibility entry point, but v63
    // turns it into the complete plan chooser before the old click handler runs.
    $("#subscribeNoAdsBtn")?.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      openPlans();
    }, true);
  }

  function openModal(selector) {
    if (app()?.openModal) app().openModal(selector);
  }
  function closeModal() {
    app()?.closeModal?.();
  }
  function openPlans() { renderPlans(); openModal("#v63PlansModal"); }
  function closePlans() { closeModal("#v63PlansModal"); }

  function renderPlans() {
    const grid = $("#v63PlanGrid");
    if (!grid) return;
    grid.replaceChildren();
    const current = activePlan();
    const currentRank = PLAN_ORDER.indexOf(current);
    for (const plan of plans()) {
      const card = document.createElement("article");
      card.className = "v63-plan-card";
      if (plan.id === current && status?.subscription_active) card.classList.add("current");
      if (plan.id === "premium") card.classList.add("featured");
      const list = FEATURES.map(([key,label]) => `<li class="${plan.features?.[key] ? "yes" : "no"}"><span>${plan.features?.[key] ? "✓" : "—"}</span>${label}</li>`).join("");
      const rank = PLAN_ORDER.indexOf(plan.id);
      let label = "Choose plan";
      if (status?.subscription_active && plan.id === current) label = "Current plan";
      else if (status?.subscription_active && currentRank >= 0) label = "Manage billing";
      card.innerHTML = `
        <div class="v63-plan-card-head"><div><small>${plan.id === "premium" ? "POPULAR" : "MONTHLY"}</small><h3>${plan.name}</h3></div><div class="v63-price"><strong>${money(plan.price_cents)}</strong><span>/mo</span></div></div>
        <ul>${list}</ul>
        <button class="${plan.id === "premium" ? "primary" : "secondary-btn"}" type="button" ${status?.subscription_active && plan.id === current ? "disabled" : ""}>${label}</button>`;
      card.querySelector("button")?.addEventListener("click", () => checkout(plan.id));
      grid.appendChild(card);
    }
  }

  async function checkout(plan) {
    if (billingPending) return;
    const entry = plans().find((p) => p.id === plan);
    if (!entry) return;
    if (status?.subscription_active && activePlan() && activePlan() !== plan) {
      return manageBilling();
    }
    if (!config?.subscription?.checkout_ready) {
      toast("Subscription checkout needs the Stripe server keys configured first.");
      return;
    }
    setBillingPending(true);
    try {
      const data = await app().api("subscription_checkout", {method:"POST", body:{plan}, loadingLabel:`Opening ${entry.name} checkout…`});
      if (!/^https:\/\/checkout\.stripe\.com\//i.test(String(data.url || ""))) throw new Error("Secure checkout is unavailable.");
      location.assign(data.url);
    } catch (error) {
      toast(error?.message || "Could not open checkout.");
    } finally {
      setBillingPending(false);
    }
  }

  async function manageBilling() {
    if (billingPending) return;
    setBillingPending(true);
    try {
      const data = await app().api("subscription_manage", {method:"POST", body:{}, loadingLabel:"Opening billing…"});
      if (!/^https:\/\/billing\.stripe\.com\//i.test(String(data.url || ""))) throw new Error("Billing portal is unavailable.");
      location.assign(data.url);
    } catch (error) {
      toast(error?.message || "Could not open billing.");
    } finally {
      setBillingPending(false);
    }
  }

  function renderSummary() {
    const active = Boolean(status?.subscription_active);
    const name = String(status?.subscription_plan_name || "");
    const badge = $("#v63PlanBadge");
    const title = $("#v63PlanTitle");
    const copy = $("#v63PlanCopy");
    if (badge) badge.textContent = active ? (name || "Paid") : "Free";
    if (title) title.textContent = active ? `${name || "Silknex"} is active` : "Choose your Silknex plan";
    if (copy) copy.textContent = active
      ? "Your account benefits are verified by the server and apply on every signed-in device."
      : "Basic starts at $1.99/month and every paid tier is fully ad-free.";

    const chips = $("#v63EntitlementChips");
    if (chips) {
      chips.replaceChildren();
      for (const [key,label] of FEATURES) {
        const chip = document.createElement("span");
        chip.className = feature(key) ? "active" : "";
        chip.textContent = label;
        chips.appendChild(chip);
      }
    }

    $("#v63EmojiBtn")?.classList.toggle("hidden", !feature("custom_emojis"));
    $("#v63EmojiPickerBtn")?.classList.toggle("hidden", !feature("custom_emojis"));
    root.dataset.betaAccess = feature("beta_access") ? "1" : "0";
    root.dataset.devAccess = feature("dev_access") ? "1" : "0";
    $("#v63FeatureRequestBtn")?.classList.toggle("hidden", !feature("feature_requests"));
    $("#v63BetaBtn")?.classList.toggle("hidden", !feature("beta_access"));
    $("#v63DevBtn")?.classList.toggle("hidden", !feature("dev_access"));

    const oldButton = $("#subscribeNoAdsBtn");
    if (oldButton) {
      oldButton.disabled = false;
      oldButton.textContent = active ? `${name || "Plan"} · View plans` : "Plans from $1.99";
    }
    renderPlans();
  }

  async function refresh(force = false) {
    if (!signedIn || !app()) return;
    if (refreshPromise && !force) return refreshPromise;
    refreshPromise = (async () => {
      try {
        const data = await app().api("ad_config", {showLoader:false, timeoutMs:8000});
        config = data;
        status = data.status || null;
        window.SilknexEntitlements = Object.freeze({
          plan: activePlan(),
          active: Boolean(status?.subscription_active),
          features: Object.freeze({...status?.subscription_features}),
        });
        renderSummary();
      } catch {}
      finally { refreshPromise = null; }
    })();
    return refreshPromise;
  }

  async function openEmojiPicker() {
    if (!feature("custom_emojis")) return openPlans();
    $("#attachmentMenu")?.classList.add("hidden");
    try {
      const data = await app().api("custom_emojis", {showLoader:false});
      const items = Array.isArray(data.emojis) ? data.emojis : [];
      if (!items.length) {
        toast("Create a custom emoji from one of your stickers first.");
        return openEmojiManager();
      }
      // Reuse the manager as a compact picker. Clicking an emoji sends it as
      // its underlying sticker, so it remains E2EE-compatible with old clients.
      openModal("#v63EmojiModal");
      const list = $("#v63EmojiList");
      if (list) {
        list.replaceChildren();
        for (const item of items) {
          const button = document.createElement("button");
          button.type = "button";
          button.className = "v63-emoji-send";
          const img = document.createElement("img");
          img.src = item.url; img.alt = ""; img.loading = "lazy"; img.decoding = "async";
          const label = document.createElement("span");
          label.textContent = `:${item.shortcode}:`;
          button.append(img, label);
          button.addEventListener("click", async () => {
            const conversationId = Number(app()?.state?.activeId || 0);
            if (!conversationId || !item.sticker_id) return;
            button.disabled = true;
            const ok = await app().sendPreparedMessage?.({
              conversationId,
              stickerId: Number(item.sticker_id),
              optimisticMedia: {message_type:"sticker",attachment_url:item.url,attachment_name:`:${item.shortcode}:`},
              replyToId: app()?.state?.replyTo?.id || null,
            });
            if (ok) closeModal("#v63EmojiModal");
            else button.disabled = false;
          });
          list.appendChild(button);
        }
      }
      const createArea = $(".v63-emoji-create");
      createArea?.classList.add("v63-picker-collapsed");
    } catch (error) { toast(error?.message || "Could not load custom emojis."); }
  }

  async function openEmojiManager() {
    if (!feature("custom_emojis")) return openPlans();
    selectedStickerId = 0;
    $(".v63-emoji-create")?.classList.remove("v63-picker-collapsed");
    const create = $("#v63EmojiCreate");
    if (create) create.disabled = true;
    openModal("#v63EmojiModal");
    const stickerGrid = $("#v63EmojiStickerGrid");
    const emojiList = $("#v63EmojiList");
    if (stickerGrid) stickerGrid.innerHTML = "<small>Loading stickers…</small>";
    if (emojiList) emojiList.innerHTML = "<small>Loading emojis…</small>";
    try {
      const [stickersData, emojiData] = await Promise.all([
        app().api("stickers", {showLoader:false}),
        app().api("custom_emojis", {showLoader:false}),
      ]);
      const stickers = Array.isArray(stickersData.stickers) ? stickersData.stickers : [];
      const emojis = Array.isArray(emojiData.emojis) ? emojiData.emojis : [];
      if (stickerGrid) {
        stickerGrid.replaceChildren();
        if (!stickers.length) stickerGrid.innerHTML = "<small>Create a sticker first, then come back here.</small>";
        for (const item of stickers.slice(0,64)) {
          const button = document.createElement("button");
          button.type = "button";
          button.className = "v63-emoji-sticker";
          const image = document.createElement("img");
          image.src = item.url; image.alt = ""; image.loading = "lazy"; image.decoding = "async";
          button.appendChild(image);
          button.addEventListener("click", () => {
            selectedStickerId = Number(item.id || 0);
            $$(".v63-emoji-sticker", stickerGrid).forEach((node) => node.classList.toggle("active", node === button));
            if (create) create.disabled = !selectedStickerId;
          });
          stickerGrid.appendChild(button);
        }
      }
      renderEmojiList(emojis);
    } catch (error) {
      if (emojiList) emojiList.textContent = String(error?.message || "Could not load custom emojis.");
    }
  }

  function renderEmojiList(items) {
    const list = $("#v63EmojiList");
    if (!list) return;
    list.replaceChildren();
    if (!items.length) {
      list.innerHTML = "<small>No custom emojis yet.</small>";
      return;
    }
    for (const item of items) {
      const row = document.createElement("div");
      row.className = "v63-emoji-row";
      const img = document.createElement("img");
      img.src = item.url; img.alt = ""; img.loading = "lazy"; img.decoding = "async";
      const name = document.createElement("b");
      name.textContent = `:${item.shortcode}:`;
      const remove = document.createElement("button");
      remove.type = "button"; remove.className = "text-btn"; remove.textContent = "Remove";
      remove.addEventListener("click", async () => {
        try {
          await app().api("custom_emoji_delete", {method:"POST", body:{id:item.id}, showLoader:false});
          openEmojiManager();
        } catch (error) { toast(error?.message || "Could not remove emoji."); }
      });
      row.append(img, name, remove);
      list.appendChild(row);
    }
  }

  async function createEmoji() {
    const shortcode = String($("#v63EmojiName")?.value || "").trim().replace(/^:+|:+$/g, "");
    if (!selectedStickerId || !shortcode) return;
    try {
      await app().api("custom_emoji_create", {method:"POST", body:{sticker_id:selectedStickerId,shortcode}});
      if ($("#v63EmojiName")) $("#v63EmojiName").value = "";
      toast(`:${shortcode}: created.`);
      openEmojiManager();
    } catch (error) { toast(error?.message || "Could not create emoji."); }
  }

  async function openFeatureRequests() {
    if (!feature("feature_requests")) return openPlans();
    openModal("#v63RequestModal");
    const history = $("#v63RequestHistory");
    if (history) history.innerHTML = "<small>Loading your requests…</small>";
    try {
      const data = await app().api("feature_requests", {showLoader:false});
      const rows = Array.isArray(data.requests) ? data.requests : [];
      if (history) {
        history.replaceChildren();
        if (!rows.length) history.innerHTML = "<small>No requests submitted yet.</small>";
        for (const item of rows) {
          const row = document.createElement("div");
          row.className = "v63-request-row";
          row.innerHTML = `<div><b></b><small></small></div><span></span>`;
          row.querySelector("b").textContent = item.title || "Request";
          row.querySelector("small").textContent = item.details || "";
          row.querySelector("span").textContent = String(item.status || "submitted");
          history.appendChild(row);
        }
      }
    } catch (error) { if (history) history.textContent = String(error?.message || "Could not load requests."); }
  }

  async function submitFeatureRequest(event) {
    event.preventDefault();
    const title = String($("#v63RequestName")?.value || "").trim();
    const details = String($("#v63RequestDetails")?.value || "").trim();
    try {
      await app().api("feature_request_submit", {method:"POST", body:{title,details}});
      $("#v63RequestForm")?.reset();
      toast("Feature request submitted.");
      openFeatureRequests();
    } catch (error) { toast(error?.message || "Could not submit that request."); }
  }

  function showDevAccess() {
    if (!feature("dev_access")) return openPlans();
    const memory = window.SilknexMemory;
    const heap = root.dataset.jsHeapMb ? `${root.dataset.jsHeapMb} MB JS heap` : "Heap sampling unavailable";
    toast(`Developer access enabled · Silknex ${VERSION} · ${memory?.profile || "standard"} memory profile · ${heap}`);
  }

  function installMotionObserver() {
    if (!("IntersectionObserver" in window)) return;
    const observer = new IntersectionObserver((entries, obs) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        entry.target.classList.add("v63-visible");
        obs.unobserve(entry.target);
      }
    }, {rootMargin:"80px 0px", threshold:0.06});
    $$(".settings-section,.conversation-row,.friend-row,.story-card").slice(0,120).forEach((node) => {
      node.classList.add("v63-reveal");
      observer.observe(node);
    });
  }

  function memoryPolish() {
    // Keep live media inexpensive: only currently useful media should retain
    // decoder buffers. The encrypted media cache itself remains controlled by v61.
    const trim = () => {
      document.querySelectorAll("#messages video,#messages audio").forEach((media) => {
        const r = media.getBoundingClientRect();
        const far = r.bottom < -700 || r.top > innerHeight + 700 || document.hidden;
        if (far) {
          try { media.pause(); } catch {}
          if (media instanceof HTMLVideoElement && !media.currentTime) media.preload = "none";
        }
      });
      window.SilknexMemory?.trim?.(document.hidden ? "hidden" : "idle");
    };
    document.addEventListener("visibilitychange", trim, {passive:true});
    window.addEventListener("pagehide", trim, {passive:true});
    window.addEventListener("silknex:conversation", () => setTimeout(trim, 250), {passive:true});
  }

  function onSession(event) {
    signedIn = Boolean(event.detail?.signedIn);
    if (!signedIn) {
      config = status = null;
      window.SilknexEntitlements = Object.freeze({plan:"",active:false,features:Object.freeze({})});
      renderSummary();
      return;
    }
    refresh(true);
  }

  function boot() {
    root.dataset.silknexVersion = VERSION;
    root.dataset.v63Ready = "true";
    installMarkup();
    installMotionObserver();
    memoryPolish();
    window.addEventListener("silknex:session", onSession);
    if (app()?.state?.me) {
      signedIn = true;
      refresh(true);
    }
    const params = new URLSearchParams(location.search);
    if (params.get("subscription") === "success") {
      setTimeout(() => { signedIn = Boolean(app()?.state?.me); refresh(true); toast("Checking your subscription status…"); }, 700);
    }
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, {once:true});
  else boot();
})();

} catch (error) { console.error("Silknex subscription module failed to initialize", error); }
