(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const DEFAULT_QUIET = Object.freeze({
    quiet_enabled: false,
    quiet_start_minute: 22 * 60,
    quiet_end_minute: 7 * 60,
    timezone: "UTC",
  });

  const runtime = {
    signedIn: false,
    founder: false,
    preferences: { ...DEFAULT_QUIET },
    preferencesLoaded: false,
    dataSaver: false,
    mediaObserver: null,
    uiObserver: null,
    ownerObserver: null,
    ownerRefreshTimer: null,
    clearingUnread: new Set(),
    lastHealth: null,
  };

  function toast(message) {
    app()?.toast?.(String(message || ""));
  }

  function isFounder() {
    return Boolean(
      runtime.signedIn &&
      app()?.state?.me?.role === "founder_ceo"
    );
  }

  function activeConversationItem() {
    const id = Number(app()?.state?.activeId || 0);
    return app()?.state?.conversations?.find?.(
      (item) => Number(item.id) === id
    ) || null;
  }

  function userStorageKey(name) {
    const userId = Number(app()?.state?.me?.id || 0);
    return userId ? `silknex:v52:${name}:${userId}` : "";
  }

  function readBooleanSetting(name, fallback = false) {
    const key = userStorageKey(name);
    if (!key) return Boolean(fallback);

    try {
      const value = localStorage.getItem(key);
      if (value === "1") return true;
      if (value === "0") return false;
    } catch {}
    return Boolean(fallback);
  }

  function writeBooleanSetting(name, value) {
    const key = userStorageKey(name);
    if (!key) return;
    try {
      localStorage.setItem(key, value ? "1" : "0");
    } catch {}
  }

  function timezoneName() {
    try {
      return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
    } catch {
      return "UTC";
    }
  }

  function minuteToTime(value) {
    const minute = Math.max(0, Math.min(1439, Number(value || 0)));
    const hours = Math.floor(minute / 60);
    const minutes = minute % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
  }

  function timeToMinute(value, fallback) {
    const match = /^(\d{1,2}):(\d{2})$/.exec(String(value || ""));
    if (!match) return fallback;
    const hours = Number(match[1]);
    const minutes = Number(match[2]);
    if (
      !Number.isInteger(hours) ||
      !Number.isInteger(minutes) ||
      hours < 0 ||
      hours > 23 ||
      minutes < 0 ||
      minutes > 59
    ) {
      return fallback;
    }
    return hours * 60 + minutes;
  }

  function quietHoursActive(now = new Date()) {
    const prefs = runtime.preferences || DEFAULT_QUIET;
    if (!prefs.quiet_enabled) return false;

    const start = Math.max(0, Math.min(1439, Number(prefs.quiet_start_minute || 0)));
    const end = Math.max(0, Math.min(1439, Number(prefs.quiet_end_minute || 0)));
    if (start === end) return false;

    let minute;
    try {
      const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: String(prefs.timezone || "UTC"),
        hourCycle: "h23",
        hour: "2-digit",
        minute: "2-digit",
      }).formatToParts(now);
      const hour = Number(parts.find((part) => part.type === "hour")?.value || 0);
      const mins = Number(parts.find((part) => part.type === "minute")?.value || 0);
      minute = hour * 60 + mins;
    } catch {
      minute = now.getHours() * 60 + now.getMinutes();
    }

    return start < end
      ? minute >= start && minute < end
      : minute >= start || minute < end;
  }

  async function loadNotificationPreferences() {
    if (!runtime.signedIn || !app()?.api) return;

    try {
      const data = await app().api("notification_preferences", {
        showLoader: false,
        timeoutMs: 7000,
      });
      const prefs = data?.preferences || {};
      runtime.preferences = {
        quiet_enabled: Boolean(prefs.quiet_enabled),
        quiet_start_minute: Number(prefs.quiet_start_minute ?? DEFAULT_QUIET.quiet_start_minute),
        quiet_end_minute: Number(prefs.quiet_end_minute ?? DEFAULT_QUIET.quiet_end_minute),
        timezone: String(prefs.timezone || timezoneName()),
      };
      runtime.preferencesLoaded = true;
      syncPreferenceControls();
    } catch {
      runtime.preferences = {
        ...DEFAULT_QUIET,
        timezone: timezoneName(),
      };
      runtime.preferencesLoaded = false;
      syncPreferenceControls();
    }
  }

  async function saveNotificationPreferences() {
    if (!runtime.signedIn || !app()?.api) return;

    const toggle = $("#v52QuietHoursToggle");
    const startInput = $("#v52QuietStart");
    const endInput = $("#v52QuietEnd");
    const button = $("#v52QuietSaveBtn");

    const next = {
      quiet_enabled: Boolean(toggle?.checked),
      quiet_start_minute: timeToMinute(
        startInput?.value,
        runtime.preferences.quiet_start_minute
      ),
      quiet_end_minute: timeToMinute(
        endInput?.value,
        runtime.preferences.quiet_end_minute
      ),
      timezone: timezoneName(),
    };

    if (button) button.disabled = true;
    try {
      const data = await app().api("notification_preferences", {
        method: "POST",
        body: next,
        showLoader: false,
      });
      runtime.preferences = {
        ...next,
        ...(data?.preferences || {}),
        quiet_enabled: Boolean(data?.preferences?.quiet_enabled ?? next.quiet_enabled),
      };
      runtime.preferencesLoaded = true;
      syncPreferenceControls();
      button?.classList.remove("attention");
      toast(
        runtime.preferences.quiet_enabled
          ? "Quiet hours saved. Message alerts will stay silent during that window."
          : "Quiet hours turned off."
      );
    } catch (error) {
      toast(error?.message || "Could not save quiet hours.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function syncPreferenceControls() {
    const prefs = runtime.preferences || DEFAULT_QUIET;
    const toggle = $("#v52QuietHoursToggle");
    const start = $("#v52QuietStart");
    const end = $("#v52QuietEnd");
    const status = $("#v52QuietStatus");

    if (toggle) toggle.checked = Boolean(prefs.quiet_enabled);
    if (start) start.value = minuteToTime(prefs.quiet_start_minute);
    if (end) end.value = minuteToTime(prefs.quiet_end_minute);
    if (status) {
      if (!prefs.quiet_enabled) {
        status.textContent = "Off";
      } else {
        status.textContent = quietHoursActive()
          ? `Quiet now · ${minuteToTime(prefs.quiet_start_minute)}–${minuteToTime(prefs.quiet_end_minute)}`
          : `${minuteToTime(prefs.quiet_start_minute)}–${minuteToTime(prefs.quiet_end_minute)}`;
      }
    }

    const dataSaver = $("#v52DataSaverToggle");
    if (dataSaver) dataSaver.checked = runtime.dataSaver;
  }

  function optimizeMediaNode(node) {
    if (!(node instanceof Element)) return;

    const videos = node.matches("video")
      ? [node]
      : $$("video", node);
    for (const video of videos) {
      if (!video.closest("#messages, #storyViewer, .story-viewer")) continue;
      if (runtime.dataSaver) {
        video.preload = "metadata";
        if (!video.closest(".call-stage, #callModal")) {
          video.autoplay = false;
          video.removeAttribute("autoplay");
        }
      }
    }

    const images = node.matches("img")
      ? [node]
      : $$("img", node);
    for (const image of images) {
      if (!image.closest("#messages, #storyViewer, .story-viewer")) continue;
      image.loading = "lazy";
      image.decoding = "async";
    }
  }

  function applyDataSaver() {
    document.documentElement.classList.toggle("v52-data-saver", runtime.dataSaver);
    optimizeMediaNode(document.body);

    if (!runtime.mediaObserver) {
      runtime.mediaObserver = new MutationObserver((records) => {
        if (!runtime.dataSaver) return;
        for (const record of records) {
          for (const node of record.addedNodes) {
            if (node instanceof Element) optimizeMediaNode(node);
          }
        }
      });
      runtime.mediaObserver.observe(document.body, {
        childList: true,
        subtree: true,
      });
    }
  }

  function setDataSaver(enabled) {
    runtime.dataSaver = Boolean(enabled);
    writeBooleanSetting("data-saver", runtime.dataSaver);
    applyDataSaver();
    syncPreferenceControls();
    toast(runtime.dataSaver ? "Data Saver enabled." : "Data Saver disabled.");
  }

  async function setManualUnread(conversationId, unread) {
    const id = Number(conversationId || 0);
    if (!id || !runtime.signedIn || !app()?.api) return false;

    try {
      const data = await app().api("conversation_unread_set", {
        method: "POST",
        body: {
          conversation_id: id,
          unread: Boolean(unread),
        },
        showLoader: false,
      });

      const item = app()?.state?.conversations?.find?.(
        (conversation) => Number(conversation.id) === id
      );
      if (item) item.manual_unread = Boolean(data?.manual_unread ?? unread);

      await app()?.loadConversations?.();
      updateUnreadButton();
      return true;
    } catch (error) {
      toast(error?.message || "Could not update unread status.");
      return false;
    }
  }

  function updateUnreadButton() {
    const button = $("#v52MarkUnreadBtn");
    if (!button) return;

    const item = activeConversationItem();
    const marked = Boolean(item?.manual_unread);
    button.disabled = !item;
    button.classList.toggle("active", marked);
    button.textContent = marked ? "Marked unread" : "Mark as unread";
    button.setAttribute("aria-pressed", marked ? "true" : "false");
  }

  async function markCurrentUnread() {
    const item = activeConversationItem();
    if (!item) {
      toast("Open a chat first.");
      return;
    }

    const next = !Boolean(item.manual_unread);
    if (await setManualUnread(item.id, next)) {
      toast(next ? "Chat marked unread." : "Unread marker cleared.");
    }
  }

  async function clearManualUnreadOnOpen(conversation) {
    const id = Number(conversation?.id || 0);
    if (!id || runtime.clearingUnread.has(id)) return;

    const item = app()?.state?.conversations?.find?.(
      (candidate) => Number(candidate.id) === id
    );
    if (!item?.manual_unread) return;

    runtime.clearingUnread.add(id);
    try {
      await setManualUnread(id, false);
    } finally {
      runtime.clearingUnread.delete(id);
    }
  }

  function ensureGeneralUi() {
    const productivity = $("#v50ProductivitySettings");
    if (productivity && !$("#v52NotificationTools")) {
      const section = document.createElement("div");
      section.id = "v52NotificationTools";
      section.className = "v52-settings-tools";
      section.innerHTML = `
        <div class="section-title"><span>Notifications & data</span></div>

        <div class="v52-setting-row">
          <div class="v52-setting-copy">
            <strong>Quiet hours</strong>
            <small>Silence message notifications on every SilkNex device during a schedule. Incoming calls still alert.</small>
          </div>
          <label class="v52-switch">
            <input id="v52QuietHoursToggle" type="checkbox" aria-label="Enable quiet hours">
            <span aria-hidden="true"></span>
          </label>
        </div>

        <div class="v52-quiet-grid">
          <label class="field">
            <span>Starts</span>
            <input id="v52QuietStart" type="time" value="22:00">
          </label>
          <label class="field">
            <span>Ends</span>
            <input id="v52QuietEnd" type="time" value="07:00">
          </label>
          <button id="v52QuietSaveBtn" class="secondary-btn" type="button">Save quiet hours</button>
          <small id="v52QuietStatus" class="v52-inline-status">Off</small>
        </div>

        <div class="v52-setting-row">
          <div class="v52-setting-copy">
            <strong>Data Saver</strong>
            <small>Use less bandwidth and memory by reducing media preloading and nonessential motion on this device.</small>
          </div>
          <label class="v52-switch">
            <input id="v52DataSaverToggle" type="checkbox" aria-label="Enable Data Saver">
            <span aria-hidden="true"></span>
          </label>
        </div>
      `;
      productivity.appendChild(section);

      $("#v52QuietSaveBtn", section)?.addEventListener("click", saveNotificationPreferences);
      $("#v52QuietHoursToggle", section)?.addEventListener("change", () => {
        $("#v52QuietSaveBtn")?.classList.add("attention");
      });
      $("#v52QuietStart", section)?.addEventListener("change", () => {
        $("#v52QuietSaveBtn")?.classList.add("attention");
      });
      $("#v52QuietEnd", section)?.addEventListener("change", () => {
        $("#v52QuietSaveBtn")?.classList.add("attention");
      });
      $("#v52DataSaverToggle", section)?.addEventListener("change", (event) => {
        setDataSaver(Boolean(event.currentTarget.checked));
      });
      syncPreferenceControls();
    }

    const organize = $("#v50ChatTools .v50-organize-grid");
    if (organize && !$("#v52MarkUnreadBtn")) {
      const button = document.createElement("button");
      button.id = "v52MarkUnreadBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Mark as unread";
      button.addEventListener("click", markCurrentUnread);
      organize.appendChild(button);
      updateUnreadButton();
    }
  }

  function formatInteger(value) {
    const number = Number(value || 0);
    try {
      return new Intl.NumberFormat().format(Number.isFinite(number) ? number : 0);
    } catch {
      return String(Number.isFinite(number) ? number : 0);
    }
  }

  function formatBytes(value) {
    let bytes = Math.max(0, Number(value || 0));
    const units = ["B", "KB", "MB", "GB"];
    let unit = 0;
    while (bytes >= 1024 && unit < units.length - 1) {
      bytes /= 1024;
      unit += 1;
    }
    return `${bytes >= 10 || unit === 0 ? bytes.toFixed(0) : bytes.toFixed(1)} ${units[unit]}`;
  }

  function healthMetric(label, value, note = "") {
    const card = document.createElement("div");
    card.className = "v52-health-card";

    const small = document.createElement("small");
    small.textContent = label;
    const strong = document.createElement("strong");
    strong.textContent = String(value ?? "—");
    card.append(small, strong);

    if (note) {
      const span = document.createElement("span");
      span.textContent = note;
      card.appendChild(span);
    }

    return card;
  }

  function ensureFounderUi() {
    if (!isFounder()) return;

    const card = $("#v49OwnerModal .v49-owner-card");
    if (!card || $("#v52FounderOps", card)) return;

    const section = document.createElement("section");
    section.id = "v52FounderOps";
    section.className = "v52-founder-ops";
    section.innerHTML = `
      <section class="v49-owner-block">
        <div class="v52-founder-head">
          <div class="section-title"><span>Service controls</span></div>
          <button id="v52HealthRefreshBtn" class="plain-btn" type="button">Refresh health</button>
        </div>
        <div class="v52-founder-control-grid">
          <div class="v52-founder-control">
            <div>
              <strong>Media uploads</strong>
              <small>Pause new user uploads during storage, CPU, or bandwidth incidents. Text messaging stays online.</small>
            </div>
            <button id="v52UploadsBtn" class="secondary-btn" type="button">Loading…</button>
          </div>
          <div class="v52-founder-control">
            <div>
              <strong>New calls</strong>
              <small>Pause new call starts if realtime calling is degraded. Existing messaging remains available.</small>
            </div>
            <button id="v52CallsBtn" class="secondary-btn" type="button">Loading…</button>
          </div>
        </div>
      </section>

      <section class="v49-owner-block">
        <div class="v52-founder-head">
          <div class="section-title"><span>System health</span></div>
          <small id="v52HealthUpdated">Loading…</small>
        </div>
        <div id="v52HealthGrid" class="v52-health-grid" aria-live="polite"></div>
        <div class="v52-health-actions">
          <button id="v52CopyHealthBtn" class="secondary-btn" type="button">Copy health snapshot</button>
        </div>
      </section>
    `;

    card.appendChild(section);
    $("#v52HealthRefreshBtn", section)?.addEventListener("click", refreshFounderHealth);
    $("#v52UploadsBtn", section)?.addEventListener("click", () => toggleFounderService("uploads"));
    $("#v52CallsBtn", section)?.addEventListener("click", () => toggleFounderService("calls"));
    $("#v52CopyHealthBtn", section)?.addEventListener("click", copyFounderHealth);

    refreshFounderHealth();
  }

  function renderFounderHealth(health) {
    runtime.lastHealth = health || null;

    const flags = health?.feature_flags || {};
    const uploads = $("#v52UploadsBtn");
    const calls = $("#v52CallsBtn");

    if (uploads) {
      const paused = Boolean(flags.uploads_paused);
      uploads.dataset.paused = paused ? "true" : "false";
      uploads.textContent = paused ? "Resume uploads" : "Pause uploads";
      uploads.classList.toggle("active", paused);
    }

    if (calls) {
      const paused = Boolean(flags.calls_paused);
      calls.dataset.paused = paused ? "true" : "false";
      calls.textContent = paused ? "Resume calls" : "Pause calls";
      calls.classList.toggle("active", paused);
    }

    const grid = $("#v52HealthGrid");
    if (grid) {
      grid.replaceChildren(
        healthMetric("Active users", formatInteger(health?.active_users_5m), "last 5 min"),
        healthMetric("Accounts", `~${formatInteger(health?.accounts_estimate)}`, "database estimate"),
        healthMetric("Active calls", formatInteger(health?.active_calls)),
        healthMetric("Ringing", formatInteger(health?.ringing_calls)),
        healthMetric("Push queue", formatInteger(health?.pending_push_jobs)),
        healthMetric("Request RAM", formatBytes(health?.request_memory_bytes)),
        healthMetric("Peak RAM", formatBytes(health?.request_peak_memory_bytes)),
        healthMetric("Schema", `v${String(health?.schema_version || "—")}`)
      );
    }

    const updated = $("#v52HealthUpdated");
    if (updated) {
      updated.textContent = `PHP ${String(health?.php_version || "—")} · refreshed ${new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}`;
    }
  }

  async function refreshFounderHealth() {
    if (!isFounder() || !app()?.api) return;

    try {
      const data = await app().api("owner_system_health", {
        showLoader: false,
        timeoutMs: 8000,
      });
      renderFounderHealth(data?.health || {});
    } catch (error) {
      const grid = $("#v52HealthGrid");
      if (grid) grid.textContent = error?.message || "Could not load system health.";
    }
  }

  async function toggleFounderService(kind) {
    if (!isFounder()) return;

    const isUploads = kind === "uploads";
    const button = isUploads ? $("#v52UploadsBtn") : $("#v52CallsBtn");
    const paused = button?.dataset.paused === "true";
    if (button) button.disabled = true;
    try {
      const request = isUploads
        ? app().api("owner_uploads_set", {
            method: "POST",
            body: { paused: !paused },
            showLoader: false,
          })
        : app().api("owner_calls_set", {
            method: "POST",
            body: { paused: !paused },
            showLoader: false,
          });
      await request;
      toast(
        isUploads
          ? (!paused ? "New media uploads paused." : "Media uploads resumed.")
          : (!paused ? "New calls paused." : "New calls resumed.")
      );
      await Promise.allSettled([
        refreshFounderHealth(),
        window.SilknexV51?.refreshFounderOps?.(),
        window.SilknexV50?.refreshFounderExtras?.(),
      ]);
    } catch (error) {
      toast(error?.message || "Could not update service controls.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function copyFounderHealth() {
    if (!isFounder()) return;
    if (!runtime.lastHealth) await refreshFounderHealth();
    if (!runtime.lastHealth) return;

    const payload = {
      generated_at: new Date().toISOString(),
      release: "52.0",
      ...runtime.lastHealth,
    };

    try {
      await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
      toast("System health copied.");
    } catch {
      toast("Could not copy system health.");
    }
  }

  function scheduleFounderRefresh() {
    clearTimeout(runtime.ownerRefreshTimer);
    runtime.ownerRefreshTimer = null;
    if (!runtime.founder) return;

    runtime.ownerRefreshTimer = setTimeout(async () => {
      if (
        document.visibilityState === "visible" &&
        !$("#v49OwnerModal")?.classList.contains("hidden")
      ) {
        await refreshFounderHealth();
      }
      scheduleFounderRefresh();
    }, 45000);
  }

  function bindUiObserver() {
    if (runtime.uiObserver) return;
    runtime.uiObserver = new MutationObserver(() => {
      if (!runtime.signedIn) return;
      ensureGeneralUi();
      if (runtime.founder) ensureFounderUi();
    });
    runtime.uiObserver.observe(document.body, { childList: true, subtree: false });
  }

  function initializeDeviceSettings() {
    const key = userStorageKey("data-saver");
    let hasStored = false;
    if (key) {
      try {
        hasStored = localStorage.getItem(key) !== null;
      } catch {}
    }
    const connectionSaveData = Boolean(navigator.connection?.saveData);
    runtime.dataSaver = readBooleanSetting(
      "data-saver",
      !hasStored && connectionSaveData
    );
    applyDataSaver();
  }

  function setSignedIn(value) {
    runtime.signedIn = Boolean(value);
    runtime.founder = isFounder();

    if (!runtime.signedIn) {
      clearTimeout(runtime.ownerRefreshTimer);
      runtime.ownerRefreshTimer = null;
      runtime.preferencesLoaded = false;
      runtime.preferences = { ...DEFAULT_QUIET };
      runtime.lastHealth = null;
      document.documentElement.classList.remove("v52-data-saver");
      return;
    }

    initializeDeviceSettings();
    ensureGeneralUi();
    loadNotificationPreferences();

    if (runtime.founder) {
      ensureFounderUi();
      scheduleFounderRefresh();
    }
  }

  function boot() {
    bindUiObserver();
    setSignedIn(Boolean(app()?.state?.me));

    window.addEventListener("silknex:session", (event) => {
      setTimeout(() => setSignedIn(Boolean(event.detail?.signedIn)), 0);
    });

    window.addEventListener("silknex:conversation", (event) => {
      setTimeout(() => {
        ensureGeneralUi();
        updateUnreadButton();
        if (event.detail?.conversation) {
          clearManualUnreadOnOpen(event.detail.conversation);
        }
      }, 0);
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        syncPreferenceControls();
      }
    });
  }

  function start() {
    if (window.SilknexApp) boot();
    else window.addEventListener("silknex:core-ready", boot, { once: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }

  window.SilknexV52 = Object.freeze({
    quietHoursActive,
    refreshFounderHealth,
    setDataSaver,
    markCurrentUnread,
  });
})();
