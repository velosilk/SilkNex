/* v77 retains the settings/navigation repairs alongside Account & spaces. */
(() => {
  'use strict';

  const root = document.documentElement;
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const app = () => window.SilknexApp;
  const categories = [
    ['all', 'All'], ['profile', 'Profile'], ['appearance', 'Appearance'],
    ['chat', 'Chat & media'], ['privacy', 'Privacy'], ['account', 'Account'],
  ];
  let category = 'profile';
  let query = '';
  let settingsFrame = 0;

  function categoryFor(section) {
    const title = ($('.section-title', section)?.textContent || '').toLowerCase();
    if (/profile|banner|avatar/.test(title)) return 'profile';
    if (/appearance|motion|theme|performance|accessibility/.test(title)) return 'appearance';
    if (/security|passkey|kid|privacy|blocked/.test(title)) return 'privacy';
    if (/subscription|advertis|billing|founder|owner|developer/.test(title)) return 'account';
    return 'chat';
  }

  function filterSettings() {
    settingsFrame = 0;
    const card = $('#settingsModal .settings-card');
    if (!card) return;
    let matches = 0;
    const terms = query.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
    for (const section of card.children) {
      if (!section.classList.contains('settings-section')) continue;
      const group = categoryFor(section);
      const content = section.textContent.toLocaleLowerCase();
      // Searching covers all sections, so a result cannot be hidden by a tab.
      const visible = terms.length ? terms.every(term => content.includes(term)) : category === 'all' || group === category;
      const value = visible ? 'false' : 'true';
      if (section.dataset.settingsFiltered !== value) section.dataset.settingsFiltered = value;
      if (visible && !section.classList.contains('hidden')) matches += 1;
    }
    for (const button of card.querySelectorAll('[data-settings-category]')) {
      const active = button.dataset.settingsCategory === (terms.length ? 'all' : category);
      button.setAttribute('aria-pressed', String(active));
    }
    $('#settingsNoResults', card)?.classList.toggle('hidden', matches > 0);
    const summary = $('#settingsResultCount', card);
    if (summary) summary.textContent = terms.length ? `${matches} matching ${matches === 1 ? 'section' : 'sections'}` : '';
  }

  function scheduleSettings() {
    if (!settingsFrame) settingsFrame = requestAnimationFrame(filterSettings);
  }

  function installSettingsNavigation() {
    const card = $('#settingsModal .settings-card');
    if (!card || $('#settingsTools')) return;
    const tools = document.createElement('div');
    tools.id = 'settingsTools';
    tools.className = 'settings-tools';
    const search = document.createElement('label');
    search.className = 'settings-search';
    const input = document.createElement('input');
    input.id = 'settingsSearch';
    input.type = 'search';
    input.placeholder = 'Search settings';
    input.autocomplete = 'off';
    input.setAttribute('aria-label', 'Search all settings');
    input.addEventListener('input', () => { query = input.value; scheduleSettings(); });
    input.addEventListener('keydown', event => {
      if (event.key === 'Escape' && input.value) {
        event.preventDefault(); event.stopPropagation();
        input.value = query = ''; filterSettings();
      }
    });
    search.append(input);
    const nav = document.createElement('nav');
    nav.className = 'settings-nav';
    nav.setAttribute('aria-label', 'Settings categories');
    for (const [id, label] of categories) {
      const button = document.createElement('button');
      button.type = 'button'; button.textContent = label;
      button.dataset.settingsCategory = id;
      button.addEventListener('click', () => {
        category = id; input.value = query = ''; filterSettings();
      });
      nav.append(button);
    }
    const count = document.createElement('span');
    count.id = 'settingsResultCount'; count.className = 'sr-only';
    count.setAttribute('role', 'status'); count.setAttribute('aria-live', 'polite');
    tools.append(search, nav, count);
    card.querySelector('.modal-head').after(tools);
    const empty = document.createElement('p');
    empty.id = 'settingsNoResults'; empty.className = 'settings-no-results hidden';
    empty.textContent = 'No settings found. Try a different word or choose All.';
    card.append(empty);
    // Older modules add settings lazily. Observe direct additions, not typing or
    // every attribute mutation throughout the entire application.
    new MutationObserver(scheduleSettings).observe(card, { childList: true });
    filterSettings();
  }

  function repairControlNames(scope = document) {
    // SVG hydration is shared with the core, including lazily created dialogs.
    app()?.hydrateIcons?.(scope);
    for (const input of scope.querySelectorAll('.switch input[type="checkbox"]')) {
      if (input.getAttribute('aria-label') || input.getAttribute('aria-labelledby')) continue;
      const label = input.closest('.setting-row')?.querySelector('b');
      if (label) input.setAttribute('aria-label', label.textContent.trim());
    }
  }

  function installModalSupport() {
    const watched = new WeakSet();
    const openers = new WeakMap();
    const previous = new WeakMap();
    function sync(modal) {
      const open = !modal.classList.contains('hidden');
      if (previous.get(modal) === open) return;
      previous.set(modal, open);
      modal.setAttribute('aria-hidden', String(!open));
      if (open) {
        if (!modal.contains(document.activeElement)) openers.set(modal, document.activeElement);
        repairControlNames(modal);
        if (modal.id === 'settingsModal') filterSettings();
        requestAnimationFrame(() => {
          if (modal.classList.contains('hidden') || modal.contains(document.activeElement)) return;
          const close = modal.querySelector('.close-modal, [data-close], button[aria-label="Close"]');
          close?.focus({ preventScroll: true });
        });
      } else {
        const opener = openers.get(modal);
        if (modal.contains(document.activeElement) && opener?.isConnected && opener.getClientRects().length) opener.focus({ preventScroll: true });
      }
    }
    const observer = new MutationObserver(records => records.forEach(record => sync(record.target)));
    function watch(modal) {
      if (watched.has(modal)) return;
      watched.add(modal); sync(modal);
      observer.observe(modal, { attributes: true, attributeFilter: ['class'] });
    }
    document.querySelectorAll('.modal').forEach(watch);
    new MutationObserver(records => {
      for (const record of records) for (const node of record.addedNodes) {
        if (!(node instanceof Element)) continue;
        if (node.matches('.modal')) watch(node);
        repairControlNames(node);
      }
    }).observe(document.body, { childList: true });
  }

  function installNavigation() {
    const stories = $('.stories-panel');
    $('#mobileStoriesBtn')?.addEventListener('click', () => {
      stories?.classList.add('ui-stories-open');
      stories?.scrollIntoView({ block: 'nearest', behavior: 'auto' });
    });
    $('#mobileChatsBtn')?.addEventListener('click', () => stories?.classList.remove('ui-stories-open'));
    const navLabels = { mobileChatsBtn: 'Chats', mobileStoriesBtn: 'Stories', mobileNewChatBtn: 'New chat', mobileFriendsBtn: 'Friends', mobileSettingsBtn: 'Settings' };
    for (const [id, label] of Object.entries(navLabels)) {
      const button = document.getElementById(id);
      if (!button) continue;
      let text = Array.from(button.children).find(child => child.tagName === 'SPAN');
      if (!text) { text = document.createElement('span'); button.append(text); }
      text.textContent = label;
      button.setAttribute('aria-label', label);
      button.title = label;
    }
  }

  function boot() {
    root.dataset.interface = 'clean';
    root.dataset.silknexVersion = '75.0';
    installSettingsNavigation();
    repairControlNames();
    installNavigation();
    installModalSupport();
    window.addEventListener('silknex:modal', event => {
      if (event.detail?.open && event.detail.id === 'settingsModal') { scheduleSettings(); repairControlNames($('#settingsModal')); }
    });
    window.addEventListener('silknex:session', () => {
      category = 'profile'; query = '';
      const input = $('#settingsSearch'); if (input) input.value = '';
      scheduleSettings();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();

(() => {
  'use strict';
  function boot() {
    document.documentElement.dataset.silknexVersion = '75.0';
    const list = document.getElementById('conversationList');
    if (!list || document.getElementById('connectionNotice')) return;
    const notice = document.createElement('div');
    notice.id = 'connectionNotice';
    notice.className = 'connection-notice hidden';
    const text = document.createElement('span');
    text.setAttribute('role', 'status');
    text.setAttribute('aria-live', 'polite');
    const retry = document.createElement('button');
    retry.type = 'button';
    retry.className = 'secondary-btn';
    retry.textContent = 'Retry';
    notice.append(text, retry);
    list.before(notice);
    let busy = false;
    function update() {
      const offline = navigator.onLine === false;
      const state = window.SilknexApp?.state;
      const failed = Number(state?.globalPollFailures || 0) > 0;
      notice.classList.toggle('hidden', !state?.me || (!offline && !failed));
      text.textContent = offline ? 'You’re offline. Reconnect to send.' : 'Connection interrupted. Trying again…';
      retry.disabled = busy || offline;
    }
    retry.addEventListener('click', async () => {
      if (busy || navigator.onLine === false) return;
      busy = true;
      retry.textContent = 'Retrying…';
      retry.setAttribute('aria-busy', 'true');
      update();
      try { await window.SilknexApp.retryConnection(); }
      catch (error) { window.SilknexApp.toast(error?.message || 'Could not reconnect.'); }
      finally {
        busy = false;
        retry.textContent = 'Retry';
        retry.removeAttribute('aria-busy');
        update();
      }
    });
    ['online', 'offline', 'silknex:session', 'silknex:connection'].forEach(name => window.addEventListener(name, update));
    update();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();
