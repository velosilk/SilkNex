/* Small, dependency-free fallbacks. Keep this file parseable by older browsers. */
(function () {
  'use strict';
  var fallback = Object.create(null);
  var own = Object.prototype.hasOwnProperty;
  window.SilknexStorage = Object.freeze({
    getItem: function (key) {
      key = String(key);
      if (own.call(fallback, key)) return fallback[key];
      try { return window.localStorage.getItem(key); } catch (error) { return null; }
    },
    setItem: function (key, value) {
      key = String(key); value = String(value);
      try { window.localStorage.setItem(key, value); delete fallback[key]; }
      catch (error) { fallback[key] = value; }
    },
    removeItem: function (key) {
      key = String(key);
      try { window.localStorage.removeItem(key); delete fallback[key]; }
      catch (error) { fallback[key] = null; }
    }
  });
  if (!Element.prototype.replaceChildren) {
    var replaceChildren = function () {
      var fragment = document.createDocumentFragment();
      for (var i = 0; i < arguments.length; i++) {
        fragment.appendChild(arguments[i] instanceof Node ? arguments[i] : document.createTextNode(String(arguments[i])));
      }
      while (this.firstChild) this.removeChild(this.firstChild);
      this.appendChild(fragment);
    };
    [Element.prototype, Document.prototype, DocumentFragment.prototype].forEach(function (prototype) {
      if (!prototype.replaceChildren) Object.defineProperty(prototype, 'replaceChildren', { value: replaceChildren, configurable: true, writable: true });
    });
  }
  if (window.Promise && !Promise.allSettled) {
    Promise.allSettled = function (values) {
      return Promise.all(Array.from(values, function (value) {
        return Promise.resolve(value).then(function (result) { return { status: 'fulfilled', value: result }; },
          function (reason) { return { status: 'rejected', reason: reason }; });
      }));
    };
  }
  if (window.matchMedia) {
    // Safari versions with the old MediaQueryList listener interface.
    var probe = window.matchMedia('(prefers-color-scheme: dark)');
    var prototype = Object.getPrototypeOf(probe);
    if (prototype && !probe.addEventListener && probe.addListener) {
      prototype.addEventListener = function (type, listener) { if (type === 'change') this.addListener(listener); };
      prototype.removeEventListener = function (type, listener) { if (type === 'change') this.removeListener(listener); };
    }
  }
})();
