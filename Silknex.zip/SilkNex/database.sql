-- SilkNex v80.0 fresh-install schema
-- Import this file into the database already assigned to your hosting account.
-- It intentionally does NOT run CREATE DATABASE or USE, which are commonly
-- blocked on shared hosting. Select the SilkNex database in phpMyAdmin first.
--
-- Existing SilkNex installations are migrated automatically by api.php.
-- This file is safe for a fresh/empty database.

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
username VARCHAR(24) NOT NULL,
display_name VARCHAR(40) NOT NULL,
password_hash VARCHAR(255) NOT NULL,
username_changed_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
about VARCHAR(160) NOT NULL DEFAULT '',
accent VARCHAR(16) NOT NULL DEFAULT 'silver',
avatar_url VARCHAR(255) NOT NULL DEFAULT '',
avatar_style TEXT NULL,
profile_banner_url VARCHAR(255) NOT NULL DEFAULT '',
public_profile TINYINT(1) NOT NULL DEFAULT 1,
theme ENUM('system','dark','light','amoled') NOT NULL DEFAULT 'dark',
app_icon_style ENUM('auto','dark','light') NOT NULL DEFAULT 'auto',
wallpaper VARCHAR(24) NOT NULL DEFAULT 'neo',
wallpaper_url VARCHAR(255) NOT NULL DEFAULT '',
font_scale ENUM('small','normal','large') NOT NULL DEFAULT 'normal',
font_family ENUM('system','rounded','serif','mono','humanist','condensed','book') NOT NULL DEFAULT 'system',
ui_accent ENUM('silver','blue','green','purple','orange') NOT NULL DEFAULT 'silver',
bubble_style ENUM('rounded','soft','square') NOT NULL DEFAULT 'rounded',
message_density ENUM('compact','normal','spacious') NOT NULL DEFAULT 'normal',
chat_width ENUM('narrow','normal','wide') NOT NULL DEFAULT 'normal',
reduce_motion TINYINT(1) NOT NULL DEFAULT 0,
easy_mode TINYINT(1) NOT NULL DEFAULT 0,
notifications_enabled TINYINT(1) NOT NULL DEFAULT 0,
kid_mode TINYINT(1) NOT NULL DEFAULT 0,
kid_pin_hash VARCHAR(255) NULL,
kid_blocked_words TEXT NULL,
passkey_user_handle CHAR(64) NULL,
created_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
last_seen_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
online_until BIGINT UNSIGNED NOT NULL DEFAULT 0,
session_version INT UNSIGNED NOT NULL DEFAULT 1,
account_role VARCHAR(24) NOT NULL DEFAULT 'member',
disabled_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
UNIQUE KEY uq_users_username (username),
KEY idx_users_last_seen (last_seen_at, id),
KEY idx_users_online (online_until, id),
KEY idx_users_created (created_at, id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_realtime_state (
user_id BIGINT UNSIGNED NOT NULL,
inbox_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
friend_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
call_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
updated_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
PRIMARY KEY (user_id),
KEY idx_realtime_updated (updated_at),
CONSTRAINT fk_realtime_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversations (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
kind ENUM('dm','group') NOT NULL,
direct_key VARCHAR(64) NULL,
name VARCHAR(60) NULL,
created_by BIGINT UNSIGNED NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
change_seq BIGINT UNSIGNED NOT NULL DEFAULT 0,
disappearing_seconds INT UNSIGNED NOT NULL DEFAULT 0,
avatar_url VARCHAR(255) NOT NULL DEFAULT '',
PRIMARY KEY (id),
UNIQUE KEY uq_conversations_direct_key (direct_key),
KEY idx_conversations_updated (updated_at),
CONSTRAINT fk_conversations_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversation_members (
conversation_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
joined_at BIGINT UNSIGNED NOT NULL,
hidden_at BIGINT UNSIGNED NULL,
cleared_before_message_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
pinned_at BIGINT UNSIGNED NULL,
favorite_at BIGINT UNSIGNED NULL,
archived_at BIGINT UNSIGNED NULL,
muted_until BIGINT UNSIGNED NULL,
manual_unread TINYINT(1) NOT NULL DEFAULT 0,
PRIMARY KEY (conversation_id, user_id),
KEY idx_members_user (user_id, conversation_id),
KEY idx_members_user_pinned (user_id, pinned_at, conversation_id),
KEY idx_members_user_favorite (user_id, favorite_at, conversation_id),
KEY idx_members_user_archived (user_id, archived_at, conversation_id),
KEY idx_members_user_hidden (user_id, hidden_at, conversation_id),
CONSTRAINT fk_members_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_members_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS messages (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
conversation_id BIGINT UNSIGNED NOT NULL,
sender_id BIGINT UNSIGNED NOT NULL,
body TEXT NOT NULL,
body_encrypted TINYINT(1) NOT NULL DEFAULT 1,
body_compact MEDIUMBLOB NULL,
body_format TINYINT UNSIGNED NOT NULL DEFAULT 0,
repeat_count SMALLINT UNSIGNED NOT NULL DEFAULT 1,
e2ee_payload MEDIUMTEXT NULL,
reply_to_id BIGINT UNSIGNED NULL,
created_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
client_nonce CHAR(32) NULL,
message_type ENUM('text','image','gif','video','audio','video_note','sticker') NOT NULL DEFAULT 'text',
attachment_url VARCHAR(1200) NULL,
attachment_token CHAR(48) NULL,
attachment_mime VARCHAR(100) NULL,
attachment_name VARCHAR(180) NULL,
attachment_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
duration_ms INT UNSIGNED NOT NULL DEFAULT 0,
expires_at BIGINT UNSIGNED NULL,
edited_at BIGINT UNSIGNED NULL,
deleted_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
UNIQUE KEY uq_messages_sender_nonce (sender_id, client_nonce),
KEY idx_messages_conversation (conversation_id, id),
KEY idx_messages_feed_cover (conversation_id, id, deleted_at, expires_at, sender_id),
KEY idx_messages_updated (conversation_id, updated_at, id),
KEY idx_messages_created (created_at, id),
KEY idx_messages_sender_created (sender_id, created_at, id),
KEY idx_messages_sender (sender_id, id),
KEY idx_messages_reply (reply_to_id),
KEY idx_messages_attachment_token (attachment_token),
KEY idx_messages_expires (expires_at, conversation_id, id),
CONSTRAINT fk_messages_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_messages_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_messages_reply FOREIGN KEY (reply_to_id) REFERENCES messages(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversation_reads (
conversation_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
last_read_message_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
read_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (conversation_id, user_id),
CONSTRAINT fk_reads_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_reads_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
ip_hash CHAR(64) NOT NULL,
action_name VARCHAR(32) NOT NULL,
attempts INT UNSIGNED NOT NULL DEFAULT 0,
window_started_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (ip_hash, action_name),
KEY idx_rate_window (window_started_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS auth_tokens (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
selector CHAR(24) NOT NULL,
token_hash CHAR(64) NOT NULL,
client_hash CHAR(64) NULL,
created_at BIGINT UNSIGNED NOT NULL,
last_used_at BIGINT UNSIGNED NOT NULL,
expires_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (id),
UNIQUE KEY uq_auth_tokens_selector (selector),
KEY idx_auth_tokens_user (user_id),
KEY idx_auth_tokens_expiry (expires_at),
CONSTRAINT fk_auth_tokens_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversation_settings (
conversation_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
wallpaper VARCHAR(24) NOT NULL DEFAULT 'default',
wallpaper_url VARCHAR(255) NOT NULL DEFAULT '',
ringtone VARCHAR(24) NOT NULL DEFAULT 'classic',
bubble_style ENUM('default','rounded','soft','square') NOT NULL DEFAULT 'default',
density ENUM('default','compact','normal','spacious') NOT NULL DEFAULT 'default',
chat_font_scale ENUM('default','small','normal','large') NOT NULL DEFAULT 'default',
call_banner_text VARCHAR(80) NOT NULL DEFAULT '',
call_banner_style ENUM('glass','dark','light','accent') NOT NULL DEFAULT 'glass',
PRIMARY KEY (conversation_id, user_id),
CONSTRAINT fk_chat_settings_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_chat_settings_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversation_deliveries (
conversation_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
last_delivered_message_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
delivered_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (conversation_id, user_id),
CONSTRAINT fk_delivery_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_delivery_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS uploads (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
token CHAR(48) NOT NULL,
purpose ENUM('message','message_e2ee','avatar','wallpaper','banner','story','sticker','ad') NOT NULL,
media_type ENUM('image','gif','video','audio','video_note','sticker') NOT NULL,
file_url VARCHAR(255) NOT NULL,
mime_type VARCHAR(100) NOT NULL,
original_name VARCHAR(180) NOT NULL,
file_size BIGINT UNSIGNED NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
used_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
UNIQUE KEY uq_upload_token (token),
KEY idx_upload_user (user_id, created_at),
CONSTRAINT fk_upload_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS push_subscriptions (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
endpoint_hash CHAR(64) NOT NULL,
endpoint TEXT NOT NULL,
p256dh VARCHAR(255) NOT NULL,
auth VARCHAR(255) NOT NULL,
user_agent VARCHAR(255) NOT NULL DEFAULT '',
icon_style ENUM('dark','light') NOT NULL DEFAULT 'dark',
created_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
last_success_at BIGINT UNSIGNED NULL,
fail_count INT UNSIGNED NOT NULL DEFAULT 0,
PRIMARY KEY (id),
UNIQUE KEY uq_push_endpoint_hash (endpoint_hash),
KEY idx_push_user (user_id, id),
CONSTRAINT fk_push_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS push_jobs (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
actor_id BIGINT UNSIGNED NOT NULL,
conversation_id BIGINT UNSIGNED NOT NULL,
event_type ENUM('message','call') NOT NULL,
message_id BIGINT UNSIGNED NULL,
call_id BIGINT UNSIGNED NULL,
created_at BIGINT UNSIGNED NOT NULL,
attempts INT UNSIGNED NOT NULL DEFAULT 0,
locked_until BIGINT UNSIGNED NOT NULL DEFAULT 0,
PRIMARY KEY (id),
KEY idx_push_jobs_actor (actor_id, id),
KEY idx_push_jobs_claim (actor_id, locked_until, id),
KEY idx_push_jobs_created (created_at),
CONSTRAINT fk_push_jobs_actor FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_push_jobs_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS passkeys (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
credential_id VARCHAR(512) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
public_key_cose TEXT NOT NULL,
sign_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
transports VARCHAR(255) NOT NULL DEFAULT '',
created_at BIGINT UNSIGNED NOT NULL,
last_used_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
PRIMARY KEY (id),
UNIQUE KEY uq_passkey_credential (credential_id),
KEY idx_passkey_user (user_id),
CONSTRAINT fk_passkey_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS calls (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
conversation_id BIGINT UNSIGNED NOT NULL,
caller_id BIGINT UNSIGNED NOT NULL,
callee_id BIGINT UNSIGNED NOT NULL,
call_type ENUM('audio','video') NOT NULL,
status ENUM('ringing','active','ended','declined') NOT NULL DEFAULT 'ringing',
created_at BIGINT UNSIGNED NOT NULL,
answered_at BIGINT UNSIGNED NULL,
ended_at BIGINT UNSIGNED NULL,
caller_heartbeat BIGINT UNSIGNED NOT NULL DEFAULT 0,
callee_heartbeat BIGINT UNSIGNED NOT NULL DEFAULT 0,
PRIMARY KEY (id),
KEY idx_calls_callee_status (callee_id, status, created_at),
KEY idx_calls_callee_status_id (callee_id, status, created_at, id),
KEY idx_calls_caller_status (caller_id, status, created_at),
KEY idx_calls_status_created (status, created_at, id),
KEY idx_calls_conversation (conversation_id, created_at),
CONSTRAINT fk_calls_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_calls_caller FOREIGN KEY (caller_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_calls_callee FOREIGN KEY (callee_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS call_signals (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
call_id BIGINT UNSIGNED NOT NULL,
sender_id BIGINT UNSIGNED NOT NULL,
signal_type ENUM('offer','answer','ice','restart') NOT NULL,
payload TEXT NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (id),
KEY idx_call_signals_call (call_id, id),
CONSTRAINT fk_call_signals_call FOREIGN KEY (call_id) REFERENCES calls(id) ON DELETE CASCADE,
CONSTRAINT fk_call_signals_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS stories (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
media_token CHAR(48) NOT NULL,
media_type ENUM('image','gif','video') NOT NULL,
caption VARCHAR(500) NOT NULL DEFAULT '',
visibility ENUM('public','friends','custom') NOT NULL DEFAULT 'friends',
audience_json TEXT NULL,
created_at BIGINT UNSIGNED NOT NULL,
expires_at BIGINT UNSIGNED NOT NULL,
deleted_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
KEY idx_stories_user_expiry (user_id, expires_at, id),
KEY idx_stories_expiry (expires_at),
KEY idx_stories_visibility_expiry (visibility, expires_at, user_id, id),
KEY idx_stories_live (deleted_at, expires_at, visibility, user_id, id),
KEY idx_stories_media (media_token),
CONSTRAINT fk_stories_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS story_views (
story_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
viewed_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (story_id, user_id),
KEY idx_story_views_user (user_id, viewed_at),
CONSTRAINT fk_story_views_story FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
CONSTRAINT fk_story_views_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS friendships (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
pair_key VARCHAR(64) NOT NULL,
requester_id BIGINT UNSIGNED NOT NULL,
addressee_id BIGINT UNSIGNED NOT NULL,
status ENUM('pending','accepted','declined') NOT NULL DEFAULT 'pending',
created_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
responded_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
UNIQUE KEY uq_friendships_pair (pair_key),
KEY idx_friendships_requester (requester_id, status, updated_at),
KEY idx_friendships_addressee (addressee_id, status, updated_at),
CONSTRAINT fk_friendships_requester FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_friendships_addressee FOREIGN KEY (addressee_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS friend_nicknames (
viewer_id BIGINT UNSIGNED NOT NULL,
friend_id BIGINT UNSIGNED NOT NULL,
nickname VARCHAR(40) NOT NULL DEFAULT '',
updated_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (viewer_id, friend_id),
KEY idx_friend_nicknames_friend (friend_id, viewer_id),
CONSTRAINT fk_nickname_viewer FOREIGN KEY (viewer_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_nickname_friend FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS scheduled_messages (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
conversation_id BIGINT UNSIGNED NOT NULL,
sender_id BIGINT UNSIGNED NOT NULL,
body MEDIUMBLOB NOT NULL,
e2ee_payload MEDIUMTEXT NULL,
reply_to_id BIGINT UNSIGNED NULL,
scheduled_at BIGINT UNSIGNED NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
status ENUM('pending','sent','cancelled') NOT NULL DEFAULT 'pending',
sent_message_id BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
KEY idx_scheduled_due (status, scheduled_at, id),
KEY idx_scheduled_sender (sender_id, status, scheduled_at),
CONSTRAINT fk_scheduled_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_scheduled_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_scheduled_reply FOREIGN KEY (reply_to_id) REFERENCES messages(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS group_change_proposals (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
conversation_id BIGINT UNSIGNED NOT NULL,
proposed_by BIGINT UNSIGNED NOT NULL,
change_type ENUM('name','avatar') NOT NULL,
proposed_name VARCHAR(60) NULL,
proposed_avatar_token CHAR(48) NULL,
status ENUM('open','approved','rejected','expired') NOT NULL DEFAULT 'open',
created_at BIGINT UNSIGNED NOT NULL,
expires_at BIGINT UNSIGNED NOT NULL,
resolved_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
KEY idx_group_proposals_open (conversation_id, status, expires_at),
CONSTRAINT fk_group_proposal_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_group_proposal_user FOREIGN KEY (proposed_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS group_change_votes (
proposal_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
vote ENUM('yes','no') NOT NULL,
voted_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (proposal_id, user_id),
CONSTRAINT fk_group_vote_proposal FOREIGN KEY (proposal_id) REFERENCES group_change_proposals(id) ON DELETE CASCADE,
CONSTRAINT fk_group_vote_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS message_reactions (
message_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
reaction VARCHAR(16) NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (message_id, user_id),
KEY idx_message_reactions_user (user_id, updated_at),
CONSTRAINT fk_message_reaction_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
CONSTRAINT fk_message_reaction_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS saved_messages (
user_id BIGINT UNSIGNED NOT NULL,
message_id BIGINT UNSIGNED NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (user_id, message_id),
KEY idx_saved_messages_user_created (user_id, created_at, message_id),
KEY idx_saved_messages_message (message_id, user_id),
CONSTRAINT fk_saved_messages_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_saved_messages_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS message_pins (
conversation_id BIGINT UNSIGNED NOT NULL,
message_id BIGINT UNSIGNED NOT NULL,
pinned_by BIGINT UNSIGNED NOT NULL,
pinned_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (conversation_id, message_id),
KEY idx_message_pins_conversation (conversation_id, pinned_at, message_id),
KEY idx_message_pins_user (pinned_by, pinned_at),
CONSTRAINT fk_message_pins_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_message_pins_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
CONSTRAINT fk_message_pins_user FOREIGN KEY (pinned_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS message_stars (
user_id BIGINT UNSIGNED NOT NULL,
message_id BIGINT UNSIGNED NOT NULL,
conversation_id BIGINT UNSIGNED NOT NULL,
starred_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (user_id, message_id),
KEY idx_message_stars_user (user_id, starred_at, message_id),
KEY idx_message_stars_conversation (conversation_id, user_id, starred_at),
CONSTRAINT fk_message_stars_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_message_stars_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
CONSTRAINT fk_message_stars_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS message_reminders (
user_id BIGINT UNSIGNED NOT NULL,
message_id BIGINT UNSIGNED NOT NULL,
conversation_id BIGINT UNSIGNED NOT NULL,
remind_at BIGINT UNSIGNED NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (user_id, message_id),
KEY idx_message_reminders_due (user_id, remind_at, message_id),
KEY idx_message_reminders_conversation (conversation_id, user_id, remind_at),
CONSTRAINT fk_message_reminders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_message_reminders_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
CONSTRAINT fk_message_reminders_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_notification_preferences (
user_id BIGINT UNSIGNED NOT NULL,
quiet_enabled TINYINT(1) NOT NULL DEFAULT 0,
quiet_start_minute SMALLINT UNSIGNED NOT NULL DEFAULT 1320,
quiet_end_minute SMALLINT UNSIGNED NOT NULL DEFAULT 420,
timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
updated_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (user_id),
CONSTRAINT fk_notification_preferences_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS message_repeat_nonces (
sender_id BIGINT UNSIGNED NOT NULL,
client_nonce CHAR(32) NOT NULL,
message_id BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (sender_id, client_nonce),
KEY idx_repeat_message (message_id),
CONSTRAINT fk_repeat_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_repeat_message FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS profile_posts (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
media_token CHAR(48) NULL,
media_type VARCHAR(16) NOT NULL DEFAULT 'text',
body TEXT NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (id),
KEY idx_profile_posts_user (user_id, id),
CONSTRAINT fk_profile_post_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS owner_access_blocks (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
starts_at BIGINT UNSIGNED NOT NULL,
ends_at BIGINT UNSIGNED NOT NULL,
note VARCHAR(120) NOT NULL DEFAULT '',
created_by BIGINT UNSIGNED NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (id),
KEY idx_access_blocks_time (starts_at, ends_at),
CONSTRAINT fk_access_blocks_owner FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS owner_audit_log (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
owner_user_id BIGINT UNSIGNED NOT NULL,
action VARCHAR(64) NOT NULL,
target VARCHAR(120) NOT NULL DEFAULT '',
details_json TEXT NULL,
created_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (id),
KEY idx_owner_audit_created (created_at, id),
KEY idx_owner_audit_owner (owner_user_id, created_at, id),
CONSTRAINT fk_owner_audit_user FOREIGN KEY (owner_user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS saved_stickers (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
upload_token CHAR(48) NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (id),
UNIQUE KEY uq_saved_sticker_user_token (user_id, upload_token),
KEY idx_saved_stickers_user (user_id, created_at, id),
CONSTRAINT fk_saved_stickers_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS custom_emojis (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  upload_token CHAR(48) NOT NULL,
  shortcode VARCHAR(24) NOT NULL,
  created_at BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_custom_emoji_user_shortcode (user_id, shortcode),
  UNIQUE KEY uq_custom_emoji_user_token (user_id, upload_token),
  KEY idx_custom_emoji_user (user_id, created_at, id),
  CONSTRAINT fk_custom_emoji_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_custom_emoji_upload FOREIGN KEY (upload_token) REFERENCES uploads(token) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS feature_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(100) NOT NULL,
  details TEXT NOT NULL,
  status ENUM('submitted','reviewing','planned','closed') NOT NULL DEFAULT 'submitted',
  created_at BIGINT UNSIGNED NOT NULL,
  updated_at BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  KEY idx_feature_requests_user (user_id, created_at, id),
  KEY idx_feature_requests_status (status, updated_at, id),
  CONSTRAINT fk_feature_requests_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS e2ee_devices (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
device_id CHAR(32) NOT NULL,
public_key_jwk TEXT NOT NULL,
label VARCHAR(80) NOT NULL DEFAULT '',
created_at BIGINT UNSIGNED NOT NULL,
last_seen_at BIGINT UNSIGNED NOT NULL,
revoked_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
UNIQUE KEY uq_e2ee_user_device (user_id, device_id),
KEY idx_e2ee_user_active (user_id, revoked_at, last_seen_at),
CONSTRAINT fk_e2ee_device_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS typing_state (
conversation_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
expires_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (conversation_id, user_id),
KEY idx_typing_expiry (expires_at),
CONSTRAINT fk_typing_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_typing_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_ad_state (
user_id BIGINT UNSIGNED NOT NULL,
rewarded_count TINYINT UNSIGNED NOT NULL DEFAULT 0,
ad_pass_until BIGINT UNSIGNED NOT NULL DEFAULT 0,
subscription_status VARCHAR(24) NOT NULL DEFAULT 'inactive',
subscription_plan VARCHAR(32) NOT NULL DEFAULT '',
subscription_started_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
subscription_current_period_end BIGINT UNSIGNED NOT NULL DEFAULT 0,
stripe_customer_id VARCHAR(255) NULL,
stripe_subscription_id VARCHAR(255) NULL,
story_view_counter INT UNSIGNED NOT NULL DEFAULT 0,
last_interstitial_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
updated_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
PRIMARY KEY (user_id),
UNIQUE KEY uq_ad_stripe_subscription (stripe_subscription_id),
CONSTRAINT fk_ad_state_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_reward_sessions (
id CHAR(48) NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
started_at BIGINT UNSIGNED NOT NULL,
complete_after BIGINT UNSIGNED NOT NULL,
expires_at BIGINT UNSIGNED NOT NULL,
completed_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
KEY idx_ad_reward_user (user_id, expires_at),
CONSTRAINT fk_ad_reward_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_events (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NULL,
provider VARCHAR(24) NOT NULL DEFAULT 'adsense',
placement VARCHAR(40) NOT NULL,
event_type VARCHAR(32) NOT NULL,
client_key CHAR(32) NOT NULL,
created_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (id),
KEY idx_ad_events_user_time (user_id, created_at),
KEY idx_ad_events_placement_time (placement, created_at),
CONSTRAINT fk_ad_events_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_campaigns (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED NOT NULL,
upload_token CHAR(48) NOT NULL,
headline VARCHAR(60) NOT NULL,
destination_url VARCHAR(1000) NOT NULL,
days TINYINT UNSIGNED NOT NULL,
price_cents INT UNSIGNED NOT NULL,
status ENUM('pending','active','expired','cancelled') NOT NULL DEFAULT 'pending',
stripe_checkout_session_id VARCHAR(255) NULL,
stripe_payment_intent_id VARCHAR(255) NULL,
created_at BIGINT UNSIGNED NOT NULL,
paid_at BIGINT UNSIGNED NULL,
starts_at BIGINT UNSIGNED NULL,
ends_at BIGINT UNSIGNED NULL,
PRIMARY KEY (id),
UNIQUE KEY uq_ad_campaign_checkout (stripe_checkout_session_id),
UNIQUE KEY uq_ad_campaign_payment (stripe_payment_intent_id),
KEY idx_ad_campaign_user (user_id, created_at, id),
KEY idx_ad_campaign_active (status, ends_at, starts_at, id),
KEY idx_ad_campaign_serving (status, starts_at, ends_at, id, user_id),
KEY idx_ad_campaign_upload (upload_token),
CONSTRAINT fk_ad_campaign_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_ad_campaign_upload FOREIGN KEY (upload_token) REFERENCES uploads(token) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS conversation_board_items (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
conversation_id BIGINT UNSIGNED NOT NULL,
created_by BIGINT UNSIGNED NOT NULL,
kind ENUM('note','task','decision') NOT NULL DEFAULT 'note',
payload_e2ee MEDIUMTEXT NOT NULL,
payload_nonce VARCHAR(96) NOT NULL,
status ENUM('open','done','archived') NOT NULL DEFAULT 'open',
priority ENUM('low','normal','high') NOT NULL DEFAULT 'normal',
due_at BIGINT UNSIGNED NULL,
assigned_user_id BIGINT UNSIGNED NULL,
created_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (id),
KEY idx_board_conversation (conversation_id, status, updated_at, id),
KEY idx_board_assignee (assigned_user_id, status, due_at),
CONSTRAINT fk_board_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_board_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE,
CONSTRAINT fk_board_assignee FOREIGN KEY (assigned_user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversation_canvas (
conversation_id BIGINT UNSIGNED NOT NULL,
revision BIGINT UNSIGNED NOT NULL DEFAULT 0,
payload_e2ee MEDIUMTEXT NOT NULL,
payload_nonce VARCHAR(96) NOT NULL,
updated_by BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (conversation_id),
CONSTRAINT fk_canvas_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_canvas_user FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS conversation_pulses (
conversation_id BIGINT UNSIGNED NOT NULL,
user_id BIGINT UNSIGNED NOT NULL,
payload_e2ee MEDIUMTEXT NOT NULL,
payload_nonce VARCHAR(96) NOT NULL,
expires_at BIGINT UNSIGNED NOT NULL,
updated_at BIGINT UNSIGNED NOT NULL,
PRIMARY KEY (conversation_id, user_id),
KEY idx_pulses_expiry (expires_at),
CONSTRAINT fk_pulse_conversation FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
CONSTRAINT fk_pulse_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS app_meta (
meta_key VARCHAR(64) NOT NULL,
meta_value MEDIUMTEXT NOT NULL,
PRIMARY KEY (meta_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sn_schools(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,domain VARCHAR(190) NOT NULL UNIQUE,seats INT UNSIGNED NOT NULL,extras TEXT NOT NULL,created_at BIGINT UNSIGNED NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sn_accounts(user_id BIGINT UNSIGNED PRIMARY KEY,email VARCHAR(190) NULL UNIQUE,verified_at BIGINT UNSIGNED NULL,school_id BIGINT UNSIGNED NULL,school_role VARCHAR(16) NOT NULL DEFAULT 'student',pending_email VARCHAR(190) NULL,token_hash CHAR(64) NULL,token_expires BIGINT UNSIGNED NULL,KEY idx_school(school_id,user_id),CONSTRAINT fk_sn_account_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sn_spaces(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,owner_id BIGINT UNSIGNED NOT NULL,school_id BIGINT UNSIGNED NULL,invite_hash CHAR(64) NULL UNIQUE,rank_names TEXT NOT NULL,created_at BIGINT UNSIGNED NOT NULL,KEY idx_space_school(school_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sn_space_members(space_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,rank_level INT NOT NULL DEFAULT 10,PRIMARY KEY(space_id,user_id),KEY idx_member_user(user_id,space_id),FOREIGN KEY(space_id) REFERENCES sn_spaces(id) ON DELETE CASCADE,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sn_channels(conversation_id BIGINT UNSIGNED PRIMARY KEY,space_id BIGINT UNSIGNED NOT NULL,archived TINYINT NOT NULL DEFAULT 0,FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,FOREIGN KEY(space_id) REFERENCES sn_spaces(id) ON DELETE CASCADE,KEY idx_channel_space(space_id,archived)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sn_flags(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,school_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,conversation_id BIGINT UNSIGNED NOT NULL,client_nonce CHAR(32) NOT NULL,categories VARCHAR(200) NOT NULL,status VARCHAR(16) NOT NULL DEFAULT 'open',created_at BIGINT UNSIGNED NOT NULL,reviewed_by BIGINT UNSIGNED NULL,UNIQUE KEY uq_flag(user_id,client_nonce),KEY idx_school_flags(school_id,status,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sn_room_members(conversation_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,token_hash CHAR(64) NOT NULL,seen_at BIGINT UNSIGNED NOT NULL,PRIMARY KEY(conversation_id,user_id),KEY idx_room_seen(seen_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS sn_room_signals(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,conversation_id BIGINT UNSIGNED NOT NULL,sender_id BIGINT UNSIGNED NOT NULL,target_id BIGINT UNSIGNED NOT NULL,target_token CHAR(64) NOT NULL,payload TEXT NOT NULL,created_at BIGINT UNSIGNED NOT NULL,KEY idx_room_target(conversation_id,target_id,id),KEY idx_signal_expiry(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO app_meta (meta_key, meta_value)
VALUES ('schema_version', '59')
ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value);

SET FOREIGN_KEY_CHECKS = 1;
