(()=>{"use strict";
const $=(s,r=document)=>r.querySelector(s),root=document.documentElement;
root.dataset.silknexVersion="67.0";
const core=()=>window.SilknexApp||null;
function safeUrl(u){return String(u||"").replace(/["\\\n\r]/g,"")}
/* Mobile auth keyboard: size the auth page to VisualViewport without touching chat layout. */
function authViewport(){
 const auth=$("#authView");if(!auth)return;
 const vv=window.visualViewport;
 const active=document.activeElement;
 const editing=auth.contains(active)&&/^(INPUT|TEXTAREA|SELECT)$/.test(active?.tagName||"");
 auth.classList.toggle("v67-keyboard-open",editing);
 if(vv&&editing){
   if (Number(vv.scale || 1) > 1.05) return;
   auth.style.height=Math.max(1,Math.round(vv.height))+"px";
   auth.style.minHeight="0";
 }else{
   auth.style.height="";
   auth.style.minHeight="";
 }
}
window.visualViewport?.addEventListener("resize",authViewport,{passive:true});
window.visualViewport?.addEventListener("scroll",authViewport,{passive:true});
document.addEventListener("focusin",e=>{if(e.target?.closest?.("#authView"))requestAnimationFrame(authViewport)});
document.addEventListener("focusout",e=>{if(e.target?.closest?.("#authView"))setTimeout(authViewport,60)});

/* Banner cropper, deliberately isolated so failure can never break messaging. */
let crop=null, cropGeneration=0, cropSaving=false, drawFrame=0;
function scheduleDraw(){if(!drawFrame)drawFrame=requestAnimationFrame(()=>{drawFrame=0;draw()})}
function ensureCrop(){
 if($("#v67BannerCrop"))return;
 const d=document.createElement("div");d.id="v67BannerCrop";d.className="v66-banner-crop hidden";
 d.innerHTML=`<div class="v66-banner-card" role="dialog" aria-modal="true"><b>Adjust banner</b><small>Drag to reposition and zoom.</small><div id="v67BannerStage" class="v66-banner-stage"><canvas id="v67BannerCanvas" width="1200" height="400"></canvas></div><label>Zoom <input id="v67BannerZoom" type="range" min="1" max="3" step=".01" value="1"></label><div class="v66-banner-actions"><button id="v67BannerCancel" class="secondary-btn" type="button">Cancel</button><button id="v67BannerSave" class="primary" type="button">Use banner</button></div></div>`;
 document.body.append(d);
 $("#v67BannerCancel").onclick=()=>{if(!cropSaving)closeCrop()};$("#v67BannerSave").onclick=saveCrop;
 $("#v67BannerZoom").oninput=e=>{if(crop&&!cropSaving){crop.zoom=+e.target.value||1;scheduleDraw()}};
 const st=$("#v67BannerStage");
 st.tabIndex=0;st.setAttribute("aria-label","Banner preview. Use arrow keys to reposition.");
 st.onkeydown=e=>{if(!crop||cropSaving||!["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"].includes(e.key))return;e.preventDefault();e.stopPropagation();const step=e.shiftKey?40:10;crop.x+=(e.key==="ArrowRight"?step:e.key==="ArrowLeft"?-step:0);crop.y+=(e.key==="ArrowDown"?step:e.key==="ArrowUp"?-step:0);scheduleDraw()};
 st.onpointerdown=e=>{if(!crop||cropSaving)return;e.preventDefault();crop.drag={x:e.clientX,y:e.clientY,ox:crop.x,oy:crop.y};try{st.setPointerCapture(e.pointerId)}catch{}};
 st.onpointermove=e=>{if(!crop?.drag)return;const r=st.getBoundingClientRect();crop.x=crop.drag.ox+(e.clientX-crop.drag.x)*(1200/Math.max(1,r.width));crop.y=crop.drag.oy+(e.clientY-crop.drag.y)*(400/Math.max(1,r.height));scheduleDraw()};
 st.onpointerup=st.onpointercancel=()=>{if(crop)crop.drag=null};
 if(!("PointerEvent" in window)){
  const point=e=>e.touches?.[0]||e.changedTouches?.[0]||e;
  const start=e=>{if(!crop||cropSaving)return;e.preventDefault();const p=point(e);crop.drag={x:p.clientX,y:p.clientY,ox:crop.x,oy:crop.y}};
  const move=e=>{if(!crop?.drag||cropSaving)return;e.preventDefault();const p=point(e),r=st.getBoundingClientRect();crop.x=crop.drag.ox+(p.clientX-crop.drag.x)*(1200/Math.max(1,r.width));crop.y=crop.drag.oy+(p.clientY-crop.drag.y)*(400/Math.max(1,r.height));scheduleDraw()};
  st.addEventListener("mousedown",start);window.addEventListener("mousemove",move);window.addEventListener("mouseup",st.onpointerup);
  st.addEventListener("touchstart",start,{passive:false});st.addEventListener("touchmove",move,{passive:false});st.addEventListener("touchend",st.onpointerup);st.addEventListener("touchcancel",st.onpointerup);
 }
}
function draw(){
 const c=$("#v67BannerCanvas"),ctx=c?.getContext("2d"),im=crop?.img;if(!c||!ctx||!im)return;
 ctx.clearRect(0,0,c.width,c.height);const s=Math.max(c.width/(im.naturalWidth||im.width),c.height/(im.naturalHeight||im.height))*crop.zoom,w=(im.naturalWidth||im.width)*s,h=(im.naturalHeight||im.height)*s;
 const mx=Math.max(0,(w-c.width)/2),my=Math.max(0,(h-c.height)/2);crop.x=Math.max(-mx,Math.min(mx,crop.x));crop.y=Math.max(-my,Math.min(my,crop.y));
 ctx.drawImage(im,(c.width-w)/2+crop.x,(c.height-h)/2+crop.y,w,h);
}
function closeCrop(){
 cropGeneration++;
 if(drawFrame)cancelAnimationFrame(drawFrame);drawFrame=0;
 crop?.decoded?.dispose();crop=null;
 const canvas=$("#v67BannerCanvas");if(canvas){canvas.width=1;canvas.height=1}
 $("#v67BannerCrop")?.classList.add("hidden");
}
async function openCrop(file){
 if(!file||!/^image\//i.test(file.type)||cropSaving)return;
 if(file.size>20*1024*1024){core()?.toast?.("Choose a banner smaller than 20 MB.");return}
 ensureCrop();closeCrop();const generation=cropGeneration;
 try {
  const decoded=await window.SilknexMedia.decodeImage(file);
  if(generation!==cropGeneration){decoded.dispose();return}
  crop={decoded,img:decoded.source,zoom:1,x:0,y:0,drag:null};
  const canvas=$("#v67BannerCanvas");canvas.width=1200;canvas.height=400;
  $("#v67BannerZoom").value="1";$("#v67BannerCrop").classList.remove("hidden");draw();
  $("#v67BannerCancel").focus({preventScroll:true});
 }catch(error){core()?.toast?.(error?.message||"Could not open banner.")}
}
async function saveCrop(){
 const a=core();if(!crop||!a?.api||cropSaving)return;
 const session=a.state?.me,generation=cropGeneration;
 const b=$("#v67BannerSave"),cancel=$("#v67BannerCancel");
 cropSaving=true;b.disabled=cancel.disabled=true;b.textContent="Saving…";b.setAttribute("aria-busy","true");
 try{
  draw();const blob=await window.SilknexMedia.encodeCanvas($("#v67BannerCanvas"),"image/webp",.88);
  if(!blob)throw Error("Could not prepare banner.");
  if(a.state?.me!==session||generation!==cropGeneration)return;
  const fd=new FormData();fd.append("purpose","banner");fd.append("file",blob,"banner."+window.SilknexMedia.extension(blob.type));
  const up=await a.api("upload",{method:"POST",body:fd});
  if(a.state?.me!==session||generation!==cropGeneration)return;
  const res=await a.api("public_profile_settings",{method:"POST",body:{banner_token:up.token}});
  if(a.state?.me!==session||generation!==cropGeneration)return;
  session.profile_banner_url=res.profile_banner_url||"";closeCrop();syncOwn();a.toast?.("Banner updated.");
 }catch(e){a.toast?.(e?.message||"Could not update banner.")}
 finally{cropSaving=false;b.disabled=cancel.disabled=false;b.textContent="Use banner";b.removeAttribute("aria-busy")}
}
function hookBanner(){
 const i=$("#v53BannerInput");if(!i||i.dataset.v67)return;i.dataset.v67="1";
 i.onchange=null;
 i.addEventListener("change",e=>{e.stopImmediatePropagation();const f=e.currentTarget.files?.[0];e.currentTarget.value="";openCrop(f)},{capture:true});
 const choose=$("#chooseProfileBannerBtn"),remove=$("#removeProfileBannerBtn");
 if(choose)choose.onclick=()=>i.click();
 if(remove)remove.onclick=async()=>{
  const a=core(),session=a?.state?.me;if(!session||remove.disabled||cropSaving)return;remove.disabled=true;
  try{const res=await a.api("public_profile_settings",{method:"POST",body:{remove_banner:true}});if(a.state.me===session){session.profile_banner_url=res.profile_banner_url||"";syncOwn();a.toast?.("Profile banner removed.")}}
  catch(error){a.toast?.(error?.message||"Could not remove banner.")}
  finally{remove.disabled=!a?.state?.me?.profile_banner_url}
 };
}
function syncOwn(){
 const bar=$(".me-bar"),u=safeUrl(core()?.state?.me?.profile_banner_url);if(!bar)return;
 bar.classList.toggle("v66-own-banner",!!u);u?bar.style.setProperty("--v66-own-banner",`url("${u}")`):bar.style.removeProperty("--v66-own-banner");
 const preview=$("#v62BannerPreview");if(preview){preview.style.backgroundImage=u?`url("${u}")`:"";preview.classList.toggle("has-image",!!u);const label=$("span",preview);if(label)label.hidden=!!u}
 const remove=$("#v62RemoveBanner");if(remove)remove.disabled=!u;
 const primaryRemove=$("#removeProfileBannerBtn");if(primaryRemove)primaryRemove.disabled=!u;
}
let req=0, peerController=null;
async function syncPeer(conv){
 const id=++req;peerController?.abort();peerController=null;
 const h=$(".chat-header");if(!h)return;h.classList.remove("v66-peer-banner");h.style.removeProperty("--v66-peer-banner");
 const a=core();if(!a||!conv||conv.kind!=="dm")return;
 const other=conv.members?.find(m=>Number(m.id)!==Number(a.state?.me?.id));if(!other?.username)return;
 peerController=a.createAbortController();const signal=peerController.signal;
 try{const d=await a.api("public_profile",{signal,showLoader:false,timeoutMs:8000}, {username:other.username});if(id!==req||signal?.aborted)return;const u=safeUrl(d?.profile?.profile_banner_url);if(u){h.style.setProperty("--v66-peer-banner",`url("${u}")`);h.classList.add("v66-peer-banner")}}catch{}
}
window.addEventListener("silknex:conversation",e=>syncPeer(e.detail?.conversation));
window.addEventListener("silknex:session",()=>{req++;peerController?.abort();closeCrop();setTimeout(()=>{hookBanner();syncOwn()},0)});
window.addEventListener("keydown",e=>{
 if(!crop)return;
 if(e.key==="Escape"){e.preventDefault();e.stopImmediatePropagation();if(!cropSaving)closeCrop();return}
 if(e.key!=="Tab")return;
 const dialog=$("#v67BannerCrop"),controls=[...dialog.querySelectorAll("button:not(:disabled),input:not(:disabled),[tabindex='0']")];
 if(!controls.length)return;
 const index=controls.indexOf(document.activeElement);
 e.preventDefault();e.stopImmediatePropagation();
 controls[(index+(e.shiftKey?-1:1)+controls.length)%controls.length].focus({preventScroll:true});
},{capture:true});
function init(){authViewport();ensureCrop();hookBanner();syncOwn()}
document.readyState==="loading"?document.addEventListener("DOMContentLoaded",init,{once:true}):init();
})();
/* v69 public-profile bridge: restores the rich profile UI that remained in the
   shell after older upgrade scripts were retired. */
(() => {
  "use strict";
  if (window.SilkNexOpenPublicProfile) return;

  const $ = (selector, root = document) => root.querySelector(selector);
  const core = () => window.SilknexApp || null;
  let current = null;
  let requestId = 0;
  let bound = false;

  function text(node, value) {
    if (node) node.textContent = String(value ?? "");
  }

  function setBanner(url) {
    const banner = $("#publicProfileBanner");
    if (!banner) return;
    const value = String(url || "").trim();
    banner.classList.toggle("has-image", Boolean(value));
    banner.style.backgroundImage = value ? `url("${value.replace(/["\\\n\r]/g, "")}")` : "";
  }

  function renderAvatar(profile) {
    const target = $("#publicProfileAvatar");
    if (!target) return;
    target.replaceChildren();
    const avatar = document.createElement("div");
    avatar.className = "avatar avatar-xl";
    core()?.setAvatar?.(
      avatar,
      profile.display_name || profile.username || "S",
      profile.accent || "silver",
      profile.avatar_url || "",
      profile.avatar_style || null
    );
    target.appendChild(avatar);
  }

  function addEmpty(container, message) {
    const empty = document.createElement("div");
    empty.className = "public-profile-empty";
    empty.textContent = message;
    container.appendChild(empty);
  }

  function renderStories(stories, profile) {
    const container = $("#publicProfileStories");
    if (!container) return;
    container.replaceChildren();

    const list = Array.isArray(stories) ? stories : [];
    if (!list.length) {
      addEmpty(container, "No active stories.");
      return;
    }

    for (const story of list) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "public-story-tile";
      button.setAttribute("aria-label", `Open ${profile.display_name || profile.username}'s story`);

      const type = String(story.media_type || "");
      const mediaUrl = String(story.media_url || "");
      if (mediaUrl) {
        if (type === "video") {
          const video = document.createElement("video");
          video.src = mediaUrl;
          video.muted = true;
          video.playsInline = true;
          video.preload = "metadata";
          button.appendChild(video);
        } else {
          const image = document.createElement("img");
          image.src = mediaUrl;
          image.alt = "";
          image.loading = "lazy";
          image.decoding = "async";
          button.appendChild(image);
        }
      }

      if (story.caption) {
        const caption = document.createElement("span");
        caption.textContent = String(story.caption).slice(0, 80);
        button.appendChild(caption);
      }

      button.addEventListener("click", () => {
        if (!mediaUrl) return;
        core()?.openFullscreenMedia?.(
          mediaUrl,
          type === "video" ? "video" : "image",
          `${profile.display_name || profile.username} story`
        );
      });
      container.appendChild(button);
    }
  }

  function renderAbout(data) {
    const panel = $("#publicProfileAboutPanel");
    if (!panel) return;
    panel.replaceChildren();

    const profile = data.profile || {};
    const rows = [
      ["Username", `@${profile.username || ""}`],
      ["Status", profile.online ? "Online" : "Offline"],
      ["Friends", String(Number(data.friend_count || 0))],
      ["Mutual friends", String((data.mutual_friends || []).length)],
    ];

    for (const [label, value] of rows) {
      const row = document.createElement("div");
      row.className = "public-profile-about-row";
      const small = document.createElement("small");
      small.textContent = label;
      const strong = document.createElement("b");
      strong.textContent = value;
      row.append(small, strong);
      panel.appendChild(row);
    }

    const about = String(profile.about || "").trim();
    if (about) {
      const bio = document.createElement("p");
      bio.className = "public-profile-about-bio";
      bio.textContent = about;
      panel.appendChild(bio);
    }

    const mutuals = Array.isArray(data.mutual_friends) ? data.mutual_friends : [];
    if (mutuals.length) {
      const wrap = document.createElement("div");
      wrap.className = "public-profile-mutuals";
      const title = document.createElement("small");
      title.textContent = "Mutual friends";
      wrap.appendChild(title);

      for (const person of mutuals.slice(0, 12)) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "secondary-btn public-profile-mutual";
        button.textContent = person.display_name || `@${person.username}`;
        button.addEventListener("click", () => window.SilkNexOpenPublicProfile?.(person.username, person));
        wrap.appendChild(button);
      }
      panel.appendChild(wrap);
    }
  }

  function setTab(name) {
    document.querySelectorAll("#publicProfileModal [data-profile-tab]").forEach((button) => {
      const active = button.dataset.profileTab === name;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
    });
    $("#publicProfileStories")?.classList.toggle("hidden", name !== "stories");
    $("#publicProfileAboutPanel")?.classList.toggle("hidden", name !== "about");
  }

  function bind() {
    if (bound) return;
    bound = true;

    document.querySelectorAll("#publicProfileModal [data-profile-tab]").forEach((button) => {
      button.addEventListener("click", () => setTab(button.dataset.profileTab || "stories"));
    });

    $("#publicProfileAvatarBtn")?.addEventListener("click", () => {
      const profile = current?.profile;
      if (!profile) return;
      const url = String(profile.avatar_url || "");
      if (url) {
        core()?.openFullscreenMedia?.(
          url,
          "image",
          `${profile.display_name || profile.username || "User"} profile picture`
        );
      }
    });

    $("#publicProfileMessageBtn")?.addEventListener("click", async () => {
      const a = core();
      const profile = current?.profile;
      if (!a?.api || !profile?.username) return;
      const button = $("#publicProfileMessageBtn");
      if (button?.disabled) return;
      if (button) button.disabled = true;
      try {
        const data = await a.api("create_conversation", {
          method: "POST",
          body: { usernames: [profile.username], name: null },
        });
        a.closeModal?.();
        await a.loadConversations?.().catch?.(() => {});
        if (data?.conversation_id) await a.openConversation?.(Number(data.conversation_id));
      } catch (error) {
        a.toast?.(error?.message || "Could not open that conversation.");
      } finally {
        if (button) button.disabled = false;
      }
    });

    $("#publicProfileEditBtn")?.addEventListener("click", () => {
      core()?.closeModal?.();
      ($("#settingsBtn") || $("#mobileSettingsBtn"))?.click();
    });

    // QR generation previously depended on a retired runtime file. Until the
    // local QR generator is present, make this control useful instead of dead.
    const qr = $("#publicProfileQrBtn");
    if (qr) {
      qr.textContent = "Copy handle";
      qr.addEventListener("click", async () => {
        const username = current?.profile?.username;
        if (!username) return;
        const value = `@${username}`;
        try {
          if (navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(value);
          } else {
            throw new Error("clipboard_unavailable");
          }
          core()?.toast?.("Profile handle copied.");
        } catch {
          const area = document.createElement("textarea");
          area.value = value;
          area.readOnly = true;
          area.style.position = "fixed";
          area.style.opacity = "0";
          document.body.appendChild(area);
          area.select();
          try { document.execCommand("copy"); core()?.toast?.("Profile handle copied."); }
          catch { core()?.toast?.(value); }
          finally { area.remove(); }
        }
      });
    }
  }

  async function openPublicProfile(username, hint = null) {
    const a = core();
    const handle = String(username || hint?.username || "").trim().replace(/^@/, "").toLowerCase();
    if (!a?.api || !handle) {
      if (hint) a?.openUserProfile?.(hint);
      return;
    }

    bind();
    const id = ++requestId;
    a.openModal?.("#publicProfileModal");
    setTab("stories");
    text($("#publicProfileName"), hint?.display_name || "Loading profile…");
    text($("#publicProfileHandle"), `@${handle}`);
    text($("#publicProfileBio"), "");
    setBanner(hint?.profile_banner_url || "");
    $("#publicProfileStories")?.replaceChildren();
    if ($("#publicProfileStories")) addEmpty($("#publicProfileStories"), "Loading…");

    try {
      const data = await a.api("public_profile", { showLoader: false, timeoutMs: 12000 }, { username: handle });
      if (id !== requestId) return;
      current = data;
      const profile = data.profile || {};

      text($("#publicProfileName"), profile.display_name || profile.username || "Profile");
      text($("#publicProfileHandle"), profile.username ? `@${profile.username}` : "");
      text($("#publicProfileBio"), String(profile.about || "").trim() || "No bio yet.");
      text($("#publicProfileFriendCount"), Number(data.friend_count || 0));
      text($("#publicProfileMutualCount"), (data.mutual_friends || []).length);
      text($("#publicProfileStoryCount"), (data.stories || []).length);

      const founder = $("#publicProfileFounderBadge");
      founder?.classList.toggle("hidden", profile.role !== "founder_ceo");
      setBanner(profile.profile_banner_url || "");
      renderAvatar(profile);
      renderStories(data.stories, profile);
      renderAbout(data);

      const own = Number(profile.id || 0) === Number(a.state?.me?.id || 0);
      $("#publicProfileMessageBtn")?.classList.toggle("hidden", own);
      $("#publicProfileEditBtn")?.classList.toggle("hidden", !own);
    } catch (error) {
      if (id !== requestId) return;
      current = null;
      text($("#publicProfileName"), "Profile unavailable");
      text($("#publicProfileBio"), error?.message || "This profile could not be loaded.");
      setBanner("");
      const stories = $("#publicProfileStories");
      stories?.replaceChildren();
      if (stories) addEmpty(stories, "Profile unavailable.");
    }
  }

  window.SilkNexOpenPublicProfile = openPublicProfile;

  const startupProfile = new URLSearchParams(location.search).get("profile");
  if (startupProfile) {
    if (core()?.state?.me) {
      setTimeout(() => openPublicProfile(startupProfile), 0);
    } else {
      const onSession = (event) => {
        if (!event.detail?.signedIn) return;
        window.removeEventListener("silknex:session", onSession);
        setTimeout(() => openPublicProfile(startupProfile), 0);
      };
      window.addEventListener("silknex:session", onSession);
    }
  }

  document.readyState === "loading"
    ? document.addEventListener("DOMContentLoaded", bind, { once: true })
    : bind();
})();
