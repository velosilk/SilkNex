(() => {
  "use strict";

  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));
  const root = document.documentElement;

  const app = () => window.SilknexApp || null;
  let referenceUrl = "";
  let adResizeObserver = null;
  let chatObserver = null;
  let gesturePointer = null;

  function isMobile() {
    return Boolean(window.matchMedia?.("(max-width: 900px), (pointer: coarse) and (max-height: 540px)")?.matches);
  }

  function chatOpen() {
    return Boolean(
      Number(app()?.state?.activeId || 0) > 0 &&
      !$("#chatView")?.classList.contains("hidden")
    );
  }

  function updateSurfaceState() {
    const open = chatOpen();
    root.dataset.v54ChatOpen = open ? "1" : "0";
    $("#appView")?.classList.toggle("desktop-chat-active", open && !isMobile());

    if (!isMobile()) {
      $("#mobileNav")?.querySelectorAll(".mobile-nav-item")
        .forEach((button) => button.removeAttribute("data-v54-active"));
    }
  }

  function setMobileShortcutActive(id) {
    if (!isMobile()) return;
    $$("#mobileNav .mobile-nav-item").forEach((button) => {
      const active = button.id === id;
      button.classList.toggle("active", active);
      button.toggleAttribute("data-v54-active", active);
      if (active) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
  }

  function bindMobileShortcuts() {
    const nav = $("#mobileNav");
    if (!nav || nav.dataset.v54Bound === "1") return;
    nav.dataset.v54Bound = "1";

    const stories = $("#mobileStoriesBtn");
    if (stories) {
      stories.addEventListener("click", () => {
        if (!isMobile()) return;
        setMobileShortcutActive("mobileStoriesBtn");
        const panel = $(".stories-panel");
        panel?.classList.add("v54-stories-attention");
        panel?.scrollIntoView?.({ behavior: "smooth", block: "start" });
        setTimeout(() => panel?.classList.remove("v54-stories-attention"), 700);
        const target = $("#storiesRail button, #storiesRail [role='button']");
        target?.focus?.({ preventScroll: true });
      });
    }

    $("#mobileChatsBtn")?.addEventListener("click", () => setMobileShortcutActive("mobileChatsBtn"));
    $("#mobileFriendsBtn")?.addEventListener("click", () => setMobileShortcutActive("mobileFriendsBtn"));
    $("#mobileNewChatBtn")?.addEventListener("click", () => setMobileShortcutActive("mobileNewChatBtn"));
    $("#mobileSettingsBtn")?.addEventListener("click", () => setMobileShortcutActive("mobileSettingsBtn"));
  }

  function bindEdgeBackGesture() {
    const view = $("#chatView");
    if (!view || view.dataset.v54GestureBound === "1") return;
    view.dataset.v54GestureBound = "1";

    const cancel = () => {
      gesturePointer = null;
      view.style.removeProperty("--v54-edge-progress");
      view.classList.remove("v54-edge-back");
    };

    view.addEventListener("pointerdown", (event) => {
      if (!isMobile() || !chatOpen()) return;
      if (event.pointerType === "mouse") return;
      if (event.clientX > 26) return;
      gesturePointer = {
        id: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        x: event.clientX,
      };
    }, { passive: true });

    view.addEventListener("pointermove", (event) => {
      if (!gesturePointer || gesturePointer.id !== event.pointerId) return;
      const dx = event.clientX - gesturePointer.startX;
      const dy = event.clientY - gesturePointer.startY;
      if (Math.abs(dy) > Math.max(20, dx * .65)) {
        cancel();
        return;
      }
      if (dx <= 0) return;
      gesturePointer.x = event.clientX;
      const progress = Math.max(0, Math.min(1, dx / 110));
      view.style.setProperty("--v54-edge-progress", progress.toFixed(3));
      view.classList.toggle("v54-edge-back", progress > .05);
    }, { passive: true });

    view.addEventListener("pointerup", (event) => {
      if (!gesturePointer || gesturePointer.id !== event.pointerId) return;
      const dx = event.clientX - gesturePointer.startX;
      const dy = Math.abs(event.clientY - gesturePointer.startY);
      const shouldClose = dx >= 72 && dy <= 56;
      cancel();
      if (shouldClose) {
        try { navigator.vibrate?.(10); } catch {}
        app()?.closeMobileChat?.();
      }
    });

    view.addEventListener("pointercancel", cancel);
  }

  function bindReferencePhoto() {
    const input = $("#avatarReferenceInput");
    const button = $("#avatarReferenceBtn");
    const preview = $("#avatarReferencePreview");
    const image = $("#avatarReferenceImage");
    const clear = $("#avatarReferenceClear");
    if (!input || !button || !preview || !image || button.dataset.v54Bound === "1") return;
    button.dataset.v54Bound = "1";

    const reset = () => {
      if (referenceUrl) {
        try { URL.revokeObjectURL(referenceUrl); } catch {}
      }
      referenceUrl = "";
      input.value = "";
      image.removeAttribute("src");
      preview.classList.add("hidden");
      button.classList.remove("hidden");
    };

    button.addEventListener("click", () => input.click());
    clear?.addEventListener("click", reset);
    input.addEventListener("change", () => {
      const file = input.files?.[0];
      if (!file || !/^image\/(?:jpeg|png|webp)$/i.test(file.type)) {
        reset();
        if (file) app()?.toast?.("Choose a JPEG, PNG, or WebP reference photo.");
        return;
      }
      if (file.size > 16 * 1024 * 1024) {
        reset();
        app()?.toast?.("Reference photos must be 16 MB or smaller.");
        return;
      }
      if (referenceUrl) {
        try { URL.revokeObjectURL(referenceUrl); } catch {}
      }
      referenceUrl = URL.createObjectURL(file);
      image.src = referenceUrl;
      preview.classList.remove("hidden");
      button.classList.add("hidden");
    });

    window.addEventListener("pagehide", () => {
      if (referenceUrl) {
        try { URL.revokeObjectURL(referenceUrl); } catch {}
        referenceUrl = "";
      }
    }, { once: true });
  }

  function updateMobileAdSpace() {
    const anchor = $("#mobileHomeAdAnchor");
    if (!anchor) return;
    const slot = $("#homeAdSlot");
    const visible = Boolean(
      isMobile() &&
      slot &&
      slot.parentElement === anchor &&
      !slot.classList.contains("hidden") &&
      slot.getBoundingClientRect().height > 1
    );
    const height = visible ? Math.ceil(anchor.getBoundingClientRect().height) : 0;
    root.style.setProperty("--v54-mobile-ad-h", `${Math.min(118, Math.max(0, height))}px`);
    root.dataset.v54MobileAd = visible ? "1" : "0";
  }

  function observeMobileAd() {
    const anchor = $("#mobileHomeAdAnchor");
    if (!anchor) return;
    try { adResizeObserver?.disconnect?.(); } catch {}
    if (typeof ResizeObserver === "function") {
      adResizeObserver = new ResizeObserver(updateMobileAdSpace);
      adResizeObserver.observe(anchor);
      const slot = $("#homeAdSlot");
      if (slot) adResizeObserver.observe(slot);
    }
    new MutationObserver(updateMobileAdSpace).observe(anchor, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style"],
    });
    updateMobileAdSpace();
  }

  function observeChatSurface() {
    const chat = $("#chatView");
    if (!chat) return;
    try { chatObserver?.disconnect?.(); } catch {}
    chatObserver = new MutationObserver(() => {
      updateSurfaceState();
      requestAnimationFrame(updateMobileAdSpace);
    });
    chatObserver.observe(chat, { attributes: true, attributeFilter: ["class"] });
    updateSurfaceState();
  }

  function polishAvatarLabels() {
    const builder = $("#avatarBuilder");
    if (!builder || builder.dataset.v54Polished === "1") return;
    builder.dataset.v54Polished = "1";

    // Give range sliders live numeric feedback without adding another data model.
    $$(".avatar-feature-controls input[type='range']", builder).forEach((input) => {
      const label = input.closest("label");
      const text = label?.querySelector("span");
      if (!label || !text || label.querySelector(".v54-range-value")) return;
      const value = document.createElement("output");
      value.className = "v54-range-value";
      const update = () => {
        const n = Number(input.value || 100);
        value.textContent = n === 100 ? "Default" : `${n > 100 ? "+" : ""}${n - 100}`;
      };
      input.addEventListener("input", update, { passive: true });
      update();
      text.insertAdjacentElement("afterend", value);
    });
  }

  function boot() {
    root.dataset.uiRelease = "55";
    bindMobileShortcuts();
    bindEdgeBackGesture();
    bindReferencePhoto();
    observeMobileAd();
    observeChatSurface();
    polishAvatarLabels();

    window.addEventListener("silknex:conversation", updateSurfaceState);
    window.addEventListener("silknex:session", () => {
      updateSurfaceState();
      bindMobileShortcuts();
    });
    window.addEventListener("resize", () => {
      updateSurfaceState();
      updateMobileAdSpace();
    }, { passive: true });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        updateSurfaceState();
        updateMobileAdSpace();
      }
    });
  }

  if (window.SilknexApp) {
    boot();
  } else {
    window.addEventListener("silknex:core-ready", boot, { once: true });
  }
})();