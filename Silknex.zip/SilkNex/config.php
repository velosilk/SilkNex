<?php
if (
    isset($_SERVER['SCRIPT_FILENAME']) &&
    realpath((string)$_SERVER['SCRIPT_FILENAME']) === __FILE__
) {
    http_response_code(404);
    exit;
}

/*
|--------------------------------------------------------------------------
| SilkNex database settings
|--------------------------------------------------------------------------
| This package is preconfigured for the SilkNex MySQL database.
| GIPHY uses the official Web SDK and the Web SDK key configured below.
| Environment variables can override database credentials and optional security services.
|--------------------------------------------------------------------------
*/
return [
    // Environment variables take priority in production so database credentials
    // can live outside the web root. The packaged values remain as a compatible
    // fallback for the existing SilkNex hosting account.
    'host' => getenv('SILKNEX_DB_HOST') ?: 'sql206.hstn.me',
    'name' => getenv('SILKNEX_DB_NAME') ?: 'mseet_42665732_Chummyhill428',
    'user' => getenv('SILKNEX_DB_USER') ?: 'mseet_42665732',
    'pass' => getenv('SILKNEX_DB_PASS') ?: 'Chummyhill428',


    /*
    |--------------------------------------------------------------------------
    | Optional deployment security settings
    |--------------------------------------------------------------------------
    | SILKNEX_APP_ORIGIN pins browser-origin checks to your real public origin
    | (for example https://chat.example.com) instead of trusting Host alone.
    |
    | SilkNex derives a password pepper from its private install key by default.
    | SILKNEX_PASSWORD_PEPPER can override it with a dedicated server-only
    | secret. SILKNEX_PASSWORD_PEPPER_PREVIOUS can be retained during a secret
    | rotation. Existing hashes upgrade after login; password length is unchanged.
    |
    | If (and only if) the PHP origin is reachable exclusively through a trusted
    | reverse proxy that terminates HTTPS, set SILKNEX_TRUST_FORWARDED_PROTO=1.
    | Direct deployments should leave it unset so spoofed forwarding headers
    | can never make an HTTP request look secure.
    */
    'app_origin' => getenv('SILKNEX_APP_ORIGIN') ?: '',
    'password_pepper' => getenv('SILKNEX_PASSWORD_PEPPER') ?: '',
    'password_pepper_previous' => getenv('SILKNEX_PASSWORD_PEPPER_PREVIOUS') ?: '',

    // Optional explicit 32-byte master key (base64/base64url/64-hex). Normally
    // leave this empty: SilkNex stores private/neochat-key.php when possible and
    // also keeps an AES-GCM-wrapped recovery copy in app_meta. This override is
    // useful when restoring an older encrypted deployment whose key was backed
    // up outside the web root.
    'master_encryption_key' => getenv('SILKNEX_MASTER_KEY') ?: '',

    // Public GIPHY Web SDK key. The browser uses the official @giphy/js-fetch-api
    // SDK for Search/Trending. Override per deployment with GIPHY_SDK_KEY.
    'giphy_sdk_key' => getenv('GIPHY_SDK_KEY') ?: '2SBypsap68TGTMlohNFJfdG9lTypVuWo',

    /*
    |--------------------------------------------------------------------------
    | Advertising
    |--------------------------------------------------------------------------
    | AdSense is OFF until you supply a real publisher ID and home ad-unit slot.
    | These identifiers are public by design; never put an AdSense login, API
    | secret, or payment credential here.
    |
    | Google AdSense does not permit display ads on screens where private
    | communication is the primary focus, so SilkNex intentionally never requests
    | AdSense units inside an active private chat/call. The home placement is the
    | manual responsive unit. Keep Auto Ads/vignettes disabled so account-level
    | automation cannot place ads on private chat/call surfaces.
    |
    | Recommended production environment variables:
    | SILKNEX_ADSENSE_CLIENT=ca-pub-1234567890123456
    | SILKNEX_ADSENSE_HOME_SLOT=1234567890
    | SILKNEX_ADSENSE_AUTO_ADS=0
    | SILKNEX_ADSENSE_CHANNEL=1234567890
    */
    'adsense_enabled' => (getenv('SILKNEX_ADSENSE_ENABLED') ?: '1') !== '0',
    'adsense_client' => getenv('SILKNEX_ADSENSE_CLIENT') ?: '',
    'adsense_home_slot' => getenv('SILKNEX_ADSENSE_HOME_SLOT') ?: '',
    'adsense_auto_ads' => (getenv('SILKNEX_ADSENSE_AUTO_ADS') ?: '0') === '1',
    'adsense_channel' => getenv('SILKNEX_ADSENSE_CHANNEL') ?: '',

    // Optional Google Ad Manager rewarded unit. AdSense itself does not provide
    // a general-purpose rewarded web unit for a messaging app. If configured,
    // the existing "5 ads = 30 minute pass" flow uses Google Publisher Tag and
    // credits only after Google fires RewardedSlotGrantedEvent.
    // Example path: /1234567/silknex_rewarded
    'gam_rewarded_ad_unit' => getenv('SILKNEX_GAM_REWARDED_AD_UNIT') ?: '',

    // Optional Google Ad Manager WEB_INTERSTITIAL reactive unit. SilkNex only
    // registers it while the user is on the home surface, never in a chat/call.
    // Google still controls whether an eligible trigger actually shows an ad.
    'gam_interstitial_ad_unit' => getenv('SILKNEX_GAM_INTERSTITIAL_AD_UNIT') ?: '',
    'ad_interstitial_min_seconds' => max(
        900,
        (int)(getenv('SILKNEX_INTERSTITIAL_MIN_SECONDS') ?: 1200)
    ),

    // Enable only on a staging domain while validating AdSense layout. This
    // adds Google's data-adtest flag to manual home units.
    'adsense_test_mode' => (getenv('SILKNEX_ADSENSE_TEST_MODE') ?: '0') === '1',

    // Stripe powers the optional $2.50/month ad-free subscription. Keep these
    // server-side environment variables secret. No checkout endpoint is enabled
    // unless both Stripe secret and webhook secret are configured.
    'stripe_secret_key' => getenv('SILKNEX_STRIPE_SECRET_KEY') ?: '',
    'stripe_webhook_secret' => getenv('SILKNEX_STRIPE_WEBHOOK_SECRET') ?: '',

    /*
    |--------------------------------------------------------------------------
    | Optional TURN relay for reliable calls across Wi-Fi/cellular networks
    |--------------------------------------------------------------------------
    | STUN-only WebRTC can fail behind carrier-grade NAT or restrictive routers.
    | Point these at your coturn/TURN service. Prefer turn_secret with coturn's
    | REST API mode because SilkNex then generates short-lived credentials.
    |
    | Example:
    | 'turn_urls' => ['turn:turn.example.com:3478?transport=udp',
    |                 'turn:turn.example.com:3478?transport=tcp',
    |                 'turns:turn.example.com:5349?transport=tcp'],
    | 'turn_secret' => getenv('TURN_SECRET') ?: '',
    |
    | Or use a fixed TURN account:
    | 'turn_username' => getenv('TURN_USERNAME') ?: '',
    | 'turn_credential' => getenv('TURN_CREDENTIAL') ?: '',
    */
    // Comma-separated TURN/TURNS URLs can be supplied without editing this file.
    // Example SILKNEX_TURN_URLS:
    // turn:turn.example.com:3478?transport=udp,turn:turn.example.com:3478?transport=tcp,turns:turn.example.com:5349?transport=tcp
    'turn_urls' => array_values(array_filter(array_map(
        'trim',
        explode(',', getenv('SILKNEX_TURN_URLS') ?: (getenv('TURN_URLS') ?: ''))
    ))),
    'turn_secret' => getenv('SILKNEX_TURN_SECRET') ?: (getenv('TURN_SECRET') ?: ''),
    'turn_username' => getenv('SILKNEX_TURN_USERNAME') ?: (getenv('TURN_USERNAME') ?: ''),
    'turn_credential' => getenv('SILKNEX_TURN_CREDENTIAL') ?: (getenv('TURN_CREDENTIAL') ?: ''),
];
