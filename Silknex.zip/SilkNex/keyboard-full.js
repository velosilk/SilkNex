(() => {
  'use strict';
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const store = window.SilknexStorage;
  const key = () => `silknex:v79:keyboard:${window.SilknexApp?.state?.me?.id || 0}`;
  const defaults = { enabled: false, background: '#171b29', keyColor: '#30394d', font: 'system-ui', overrides: {} };
  let settings = defaults, shift = false;
  const rows = ['1234567890', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm,.;?!'];
  const fonts = { system: 'system-ui', serif: 'Georgia,serif', mono: 'ui-monospace,monospace', rounded: 'Trebuchet MS,system-ui' };
  function load() {
    try { const value = JSON.parse(store.getItem(key()) || '{}'); settings = { ...defaults, ...value, overrides: value.overrides && typeof value.overrides === 'object' ? value.overrides : {} }; }
    catch { settings = { ...defaults }; }
    render();
  }
  function save() { store.setItem(key(), JSON.stringify(settings)); render(); }
  function inputText(text, remove = false) {
    const input = $('#messageInput');
    if (!input || input.disabled) return;
    let start = input.selectionStart ?? input.value.length, end = input.selectionEnd ?? start;
    if (remove && start === end) start = Math.max(0, start - 1);
    input.setRangeText(remove ? '' : text, start, end, 'end');
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.focus({ preventScroll: true });
  }
  function button(label, action, className = '') {
    const el = document.createElement('button');
    el.type = 'button'; el.textContent = label; el.className = `v79-key ${className}`;
    el.setAttribute('aria-label', label === '⌫' ? 'Backspace' : label === '↵' ? 'New line' : label);
    el.style.backgroundColor = settings.overrides[label] || settings.keyColor;
    el.addEventListener('pointerdown', event => event.preventDefault());
    el.addEventListener('click', action);
    return el;
  }
  function render() {
    const tray = $('#v79FullKeyboard');
    if (!tray) return;
    document.documentElement.dataset.fullKeyboard = settings.enabled ? 'true' : 'false';
    tray.hidden = !settings.enabled;
    if (!settings.enabled) return;
    tray.style.background = settings.background;
    tray.style.fontFamily = fonts[settings.font] || fonts.system;
    tray.replaceChildren();
    for (let index = 0; index < rows.length; index++) {
      const row = document.createElement('div'); row.className = 'v79-key-row';
      if (index === 3) row.append(button(shift ? '⇧' : '↑', () => { shift = !shift; render(); }, 'v79-wide-key'));
      for (const character of rows[index]) {
        const label = shift ? character.toUpperCase() : character;
        row.append(button(label, () => { inputText(label); if (shift) { shift = false; render(); } }));
      }
      if (index === 3) row.append(button('⌫', () => inputText('', true), 'v79-wide-key'));
      tray.append(row);
    }
    const bottom = document.createElement('div'); bottom.className = 'v79-key-row';
    bottom.append(button('@', () => inputText('@')), button('Space', () => inputText(' '), 'v79-space'), button('↵', () => inputText('\n'), 'v79-wide-key'));
    tray.append(bottom);
  }
  function install() {
    if ($('#v79FullKeyboard')) return;
    const form = $('#messageForm'), host = $('#settingsModal .settings-stack, #settingsModal .modal-card');
    if (!form || !host) return;
    const tray = document.createElement('div'); tray.id = 'v79FullKeyboard'; tray.className = 'v79-full-keyboard'; tray.hidden = true;
    tray.setAttribute('aria-label', 'Full custom keyboard'); form.before(tray);
    const panel = document.createElement('section'); panel.className = 'settings-section'; panel.innerHTML = `
      <div class="section-title"><span>Full keyboard</span></div>
      <p>Use a complete on-screen keyboard in chat. Customize its background, keys, font, and each key color on this device.</p>
      <label class="field"><span>Show full keyboard</span><input id="v79KeyboardEnabled" type="checkbox"></label>
      <label class="field"><span>Keyboard background</span><input id="v79KeyboardBackground" type="color"></label>
      <label class="field"><span>Default key color</span><input id="v79KeyboardKeyColor" type="color"></label>
      <label class="field"><span>Keyboard font</span><select id="v79KeyboardFont"><option value="system">System</option><option value="serif">Serif</option><option value="mono">Monospace</option><option value="rounded">Rounded</option></select></label>
      <label class="field"><span>Customize one key</span><select id="v79KeyPicker"></select></label>
      <label class="field"><span>Selected key color</span><input id="v79IndividualColor" type="color"></label>
      <button id="v79KeyReset" class="secondary-btn" type="button">Reset selected key</button>`;
    host.append(panel);
    const picker = $('#v79KeyPicker', panel);
    for (const label of [...new Set([...rows.join(''), '↑', '⇧', '⌫', '@', 'Space', '↵'])]) {
      const option = document.createElement('option'); option.value = label; option.textContent = label; picker.append(option);
    }
    const sync = () => {
      $('#v79KeyboardEnabled').checked = settings.enabled;
      $('#v79KeyboardBackground').value = settings.background;
      $('#v79KeyboardKeyColor').value = settings.keyColor;
      $('#v79KeyboardFont').value = fonts[settings.font] ? settings.font : 'system';
      $('#v79IndividualColor').value = settings.overrides[picker.value] || settings.keyColor;
    };
    $('#v79KeyboardEnabled').addEventListener('change', event => { settings.enabled = event.target.checked; save(); });
    $('#v79KeyboardBackground').addEventListener('input', event => { settings.background = event.target.value; save(); });
    $('#v79KeyboardKeyColor').addEventListener('input', event => { settings.keyColor = event.target.value; save(); sync(); });
    $('#v79KeyboardFont').addEventListener('change', event => { settings.font = event.target.value; save(); });
    picker.addEventListener('change', sync);
    $('#v79IndividualColor').addEventListener('input', event => { settings.overrides[picker.value] = event.target.value; save(); });
    $('#v79KeyReset').addEventListener('click', () => { delete settings.overrides[picker.value]; save(); sync(); });
    load(); sync();
    window.addEventListener('silknex:session', load);
  }
  if (window.SilknexApp) install(); else window.addEventListener('silknex:core-ready', install, { once: true });
})();
