(() => {
 'use strict';
 const $=(s,r=document)=>r.querySelector(s), app=()=>window.SilknexApp;
 let wordPromise=Promise.resolve(),wordRequested=false;
 let account=null, accountUser=0, accountPromise=null, words={}, wordIndex=new Map(), wordMax=1, pane='account', generation=0, openSpace=0, room=null, joining=0, flagBefore=0;
 const labels={harassment:'Harassment',threats:'Threatening language',sexual_content:'Sexual content',self_harm:'Possible need for support',substances:'Substances',personal_information:'Personal information'};
 const node=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
 const button=(text,fn,cls='secondary-btn')=>{const b=node('button',text,cls);b.type='button';b.addEventListener('click',fn);return b;};
 function field(label,type='text',value=''){const l=node('label',undefined,'sn-field'),i=node(type==='textarea'?'textarea':'input');if(type!=='textarea')i.type=type;i.value=value;l.append(node('span',label),i);return {label:l,input:i};}
 const api=(action,data={},read=false)=>app().api('community_'+action,read?{showLoader:false}:{method:'POST',body:data,showLoader:false},read?data:{});
 function report(error){const n=$('#snError');if(n)n.textContent=error?.message||String(error);}
 async function busy(b,fn){if(b.disabled)return;b.disabled=true;try{$('#snError').textContent='';await fn();}catch(e){report(e);}finally{b.disabled=false;}}
 async function boot(){
  const id=Number(app()?.state.me?.id||0);if(!id){account=null;accountUser=0;return null;}
  if(id===accountUser&&account)return account;
  if(accountPromise?.id===id)return accountPromise.task;
  const task=api('boot',{},true).then(data=>{if(Number(app()?.state.me?.id)!==id)return null;account=data.account;accountUser=id;document.documentElement.dataset.schoolAccount=account.school_id?'true':'false';if(account.school_id)loadWords();return account;}).finally(()=>{if(accountPromise?.task===task)accountPromise=null;});
  accountPromise={id,task};return task;
 }
 const normalizeSchool=(value)=>String(value||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[\u200b-\u200f\ufeff]/g,'').replace(/[^\p{L}\p{N}]+/gu,' ').replace(/\s+/g,' ').trim();
 function compileWords(data){
  words=data;wordIndex=new Map();wordMax=1;
  for(const [category,terms] of Object.entries(data)){
   if(!Array.isArray(terms)||!labels[category])continue;
   for(const term of terms){
    const key=normalizeSchool(term);if(key.length<3)continue;
    wordMax=Math.max(wordMax,Math.min(22,key.split(' ').length));
    const found=wordIndex.get(key)||new Set();found.add(category);wordIndex.set(key,found);
   }
  }
 }
 function loadWords(){if(wordRequested)return;wordRequested=true;wordPromise=fetch('school-words.json?v=80.0',{cache:'force-cache'}).then(r=>{if(!r.ok)throw Error();return r.json();}).then(compileWords).catch(()=>compileWords({threats:['kill you','shoot you'],self_harm:['kill myself','hurt myself'],harassment:['kill yourself']}));}
 function scanText(text){
  if(!account?.school_id||!wordIndex.size)return [];
  const raw=String(text||'').slice(0,4000),found=new Set();
  const leet=raw.replace(/[a-zA-Z][a-zA-Z01345@$]*/g,token=>token.replace(/[01345@$]/g,c=>({'0':'o','1':'i','3':'e','4':'a','5':'s','@':'a','$':'s'}[c]||c)));
  for(const candidate of [raw,leet]){
   const tokens=normalizeSchool(candidate).split(' ').filter(Boolean);
   for(let i=0;i<tokens.length;i++){
    let phrase='';
    for(let j=i;j<Math.min(tokens.length,i+wordMax);j++){
     phrase+=(j===i?'':' ')+tokens[j];
     const categories=wordIndex.get(phrase);
     if(categories)for(const category of categories)found.add(category);
    }
   }
  }
  return Object.keys(labels).filter(category=>found.has(category));
 }
 function note(text){return node('p',text,'sn-note');}
 function formBox(title){const section=node('section',undefined,'sn-card');section.append(node('h3',title));return section;}
 function show(tab='account'){$('#snModal').hidden=false;pane=tab;render();$('#snClose').focus();}
 function hide(){generation++;joining++;$('#snModal').hidden=true;$('#snOpen')?.focus();}
 function install(){
  if(!app()||$('#snModal'))return;
  const modal=node('div',undefined,'sn-modal');modal.id='snModal';modal.hidden=true;modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-labelledby','snTitle');
  modal.innerHTML='<div class="sn-shell"><header><div><small>YOUR SILKNEX</small><h2 id="snTitle">Account & spaces</h2></div><button id="snClose" class="secondary-btn" type="button" aria-label="Close account and spaces">Close</button></header><nav id="snTabs" aria-label="Workspace sections"></nav><p id="snError" role="alert"></p><main id="snBody"></main></div>';
  document.body.append(modal);$('#snClose').addEventListener('click',hide);
  modal.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();hide();}if(event.key==='Tab'){const all=[...modal.querySelectorAll('button,input,select,textarea,a[href]')].filter(x=>!x.disabled&&!x.closest('[hidden]'));if(!all.length)return;const first=all[0],last=all.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}});
  const entry=button('Spaces',()=>show('spaces'),'sn-entry');entry.id='snOpen';entry.setAttribute('aria-label','Open spaces, servers and classes');entry.setAttribute('title','Spaces');const listHeader=$('#sidebar .list-header'),headerActions=$('#sidebar .header-actions');if(listHeader)listHeader.insertBefore(entry,headerActions||null);
  const settings=formBox('Account, schools & spaces');settings.classList.add('settings-section');settings.append(note('Verify email, open a server, manage class spaces or personalize this device.'),button('Open workspace',()=>show()));$('#settingsModal .settings-card')?.append(settings);
  const callEntry=button('Group call',()=>show('call'),'sn-group-call');callEntry.id='snGroupCall';$('#chatView .chat-actions')?.append(callEntry);
  $('#messageInput')?.addEventListener('input',()=>{clearTimeout(install.scanTimer);install.scanTimer=setTimeout(()=>{let n=$('#snTypingNotice');if(!n){n=node('small',undefined,'sn-typing-note');n.id='snTypingNotice';n.setAttribute('aria-live','polite');$('#messageForm').before(n);}const flags=scanText($('#messageInput').value);n.textContent=flags.length?'School review: '+flags.map(x=>labels[x]).join(', ')+'. Draft text stays on this device.':'';},240);});
  let prior=0;const sync=()=>{if(!window.document?.documentElement||!$('#snGroupCall'))return;const id=Number(app()?.state.me?.id||0);if(id!==prior){prior=id;account=null;accountUser=0;generation++;if(!id){document.documentElement.dataset.schoolAccount='false';document.documentElement.dataset.communityAppearance='false';hide();leaveRoom();}else boot().then(()=>applyAppearance()).catch(()=>{});}$('#snGroupCall').hidden=app()?.state.activeConversation?.kind!=='group'&&app()?.state.conversations?.find(c=>Number(c.id)===Number(app()?.state.activeId))?.kind!=='group';};
  window.addEventListener('silknex:conversation',sync);window.addEventListener('silknex:startup-ready',sync);window.addEventListener('silknex:session',sync);sync();
 }
 async function render(){const version=++generation, user=app()?.state.me;$('#snBody').replaceChildren(note('Loading…'));$('#snError').textContent='';try{await boot();if(version!==generation||app()?.state.me!==user)return;if(!account){$('#snBody').replaceChildren(note('Sign in to open your workspace.'));return;}
  const tabs=[['account','Account'],['spaces','Servers & classes'],['appearance','Appearance'],['call','Group call']];if(account.school_id)tabs.push(['school','School']);if(account.founder)tabs.push(['ceo','CEO']);
  $('#snTabs').replaceChildren(...tabs.map(([id,text])=>{const b=button(text,()=>{pane=id;render();});b.setAttribute('aria-pressed',String(pane===id));return b;}));
  const body=$('#snBody');body.replaceChildren();
  if(pane==='account')renderAccount(body);if(pane==='appearance')renderAppearance(body);if(pane==='spaces')await renderSpaces(body,version);if(pane==='school')await renderSchool(body,version);if(pane==='ceo')await renderCEO(body,version);if(pane==='call')renderCall(body);if($('#snMediaHost'))$('#snMediaHost').hidden=pane!=='call'||!room;
 }catch(e){if(version===generation){$('#snBody').replaceChildren(note('This section could not load.'));report(e);}}}
 function renderAccount(body){const card=formBox(account.school_id?'Managed school account':account.verified||account.founder?'Full account':'Limited account');card.append(note(account.school_id?`${account.school_name} · ${account.school_role}. Text-only class messaging. No GIFs, image uploads or stickers. School flags are indicators for human review, not proof of wrongdoing.`:account.founder?'Founder access is enabled. Email verification adds a contact identity.':account.verified?'Your email is verified. Messaging, media, servers and calls are unlocked.':'Without a verified email, you can read existing chats and send up to 25 text messages daily. Verify email to unlock media, new conversations, servers and calls.'));if(account.email)card.append(note(account.email));
  if(!account.school_id){const email=field('Email address','email',account.email||'');email.input.autocomplete='email';const send=button('Send verification email',()=>busy(send,async()=>{await api('email_request',{email:email.input.value});report('Email sent. Enter its code below.');}));card.append(email.label,send);}
  if(!account.school_id){const code=field('Verification code');code.input.autocomplete='one-time-code';const verify=button('Verify email',()=>busy(verify,async()=>{await api('email_verify',{code:code.input.value});account=null;await render();}));card.append(code.label,verify);}
  const me=app()?.state?.me;
  if(me&&!['founder_ceo','cofounder_ceo'].includes(me.role)){
   const handle=field('Your @username (change once every 7 days)','text',me.username||'');handle.input.maxLength=24;
   const link=note('Profile link: '+location.origin+'/@'+me.username);
   const change=button('Change username',()=>busy(change,async()=>{
    const result=await app().api('username_change',{method:'POST',body:{username:handle.input.value},showLoader:false});
    report('Username updated to @'+result.username+'. Refreshing your account…');
    location.reload();
   }));
   card.append(node('h4','Public handle'),handle.label,link,change);
  }
  body.append(card);
 }
 async function renderSpaces(body,version){
  if(!account.verified&&!account.founder){body.append(note('Verify your email in Account to create or join a server.'));return;}
  const data=await api('spaces',{},true);if(version!==generation)return;
  const list=formBox('Your spaces');for(const s of data.spaces){const b=button(s.name,()=>{openSpace=Number(s.id);render();},'sn-space-link');b.append(node('small',s.school_id?'School class':'Server'));list.append(b);}if(!data.spaces.length)list.append(note('Your servers and classes will appear here.'));body.append(list);
  if(!account.school_id){const create=formBox('Create or join a server'),name=field('Server name'),invite=field('Invite code');name.input.maxLength=100;const cb=button('Create server',()=>busy(cb,async()=>{const d=await api('space_create',{name:name.input.value});openSpace=d.space_id;await render();report('Share this invite code: '+d.invite);}));const jb=button('Join server',()=>busy(jb,async()=>{const d=await api('space_join',{invite:invite.input.value});openSpace=d.space_id;await app().loadConversations();await render();}));create.append(name.label,cb,invite.label,jb,note('Servers support 30 members and 12 active channels. Invite codes can be rotated by admins.'));body.append(create);}
  if(openSpace&&data.spaces.some(s=>Number(s.id)===openSpace)){const d=await api('space',{space_id:openSpace},true);if(version!==generation)return;renderSpace(body,d);}
 }
 function renderSpace(body,data){const s=data.space,card=formBox(s.name);let names={};try{names=JSON.parse(s.rank_names);}catch{}card.append(note('Your rank: '+(names[s.rank_level]||s.rank_level)));
  for(const channel of data.channels){const row=node('div',undefined,'sn-row');row.append(button('# '+channel.name,async()=>{try{await app().loadConversations();await app().openConversation(Number(channel.conversation_id));hide();}catch(e){report(e);}}));if(Number(s.rank_level)>=30){const del=button('Delete channel',()=>busy(del,async()=>{await api('channel_delete',{conversation_id:channel.conversation_id});await render();}));row.append(del);}card.append(row);}
  if(Number(s.rank_level)>=30){const name=field('New channel name');const add=button('Create channel',()=>busy(add,async()=>{await api('channel_create',{space_id:s.id,name:name.input.value});await render();}));card.append(name.label,add);if(!s.school_id){const invite=button('Create new invite code',()=>busy(invite,async()=>{const result=await api('invite_rotate',{space_id:s.id});report('New invite code: '+result.invite);}));card.append(invite);}}
  const roster=formBox('Members & ranks');for(const member of data.members){const row=node('div',undefined,'sn-row');row.append(node('span',`${member.display_name} · ${names[member.rank_level]||member.rank_level}`));if(Number(s.rank_level)===40&&!s.school_id&&Number(member.id)!==Number(s.owner_id)){const select=node('select');select.setAttribute('aria-label','Rank for '+member.display_name);for(const rank of [10,20,30]){const o=node('option',names[rank]);o.value=rank;select.append(o);}select.value=member.rank_level;const save=button('Save',()=>busy(save,async()=>{await api('rank_set',{space_id:s.id,user_id:member.id,rank:Number(select.value)});await render();}));row.append(select,save);}if(Number(s.rank_level)>=20&&Number(member.rank_level)<Number(s.rank_level)){const remove=button('Remove',()=>busy(remove,async()=>{await api('member_remove',{space_id:s.id,user_id:member.id});await render();}));row.append(remove);}roster.append(row);}
  if(Number(s.rank_level)===40){const fields=[10,20,30,40].map(rank=>({rank,...field('Rank '+rank+' label','text',names[rank]||'Rank')}));const save=button('Save rank names',()=>busy(save,async()=>{await api('rank_names',{space_id:s.id,names:Object.fromEntries(fields.map(x=>[x.rank,x.input.value]))});await render();}));roster.append(...fields.map(x=>x.label),save,note('Owners assign ranks. Admins manage channels and invites. Moderators can remove lower-ranked members. Members can participate. Labels never grant additional permissions.'));}
  body.append(card,roster);
 }
 async function renderSchool(body,version){body.append(note('Text-only school spaces. Draft checks stay on your device; only category flags attached to sent messages reach your school reviewers. Phrase matching can miss harmful content or flag harmless context.'));
  if(account.school_role!=='teacher'){body.append(note('Your teacher enrolls you in class spaces. Open Servers & classes to participate.'));return;}
  const card=formBox('Class project workspace'),name=field('Project name'),students=field('Student usernames, separated by commas','textarea');const create=button('Create class project',()=>busy(create,async()=>{const result=await api('class_create',{name:name.input.value,usernames:students.input.value});openSpace=result.space_id;pane='spaces';await render();}));card.append(name.label,students.label,create,note('Requires the $2-per-student class-project extra. All participants must belong to this school. Delete a project channel from its workspace to archive it.'));body.append(card);
  const data=await api('flags',{before:flagBefore},true);if(version!==generation)return;const flags=formBox('Student support review');flags.append(note('Review context with the student. Flags are not disciplinary decisions; this view does not expose message text.'));
  for(const f of data.flags){const row=node('div',undefined,'sn-row');row.append(node('span',f.username+' · '+f.categories.split(',').map(x=>labels[x]||x).join(', ')));const done=button('Mark reviewed',()=>busy(done,async()=>{await api('flag_review',{id:f.id});await render();}));row.append(done);flags.append(row);}if(!data.flags.length)flags.append(note('No open flags on this page.'));if(data.flags.length===50)flags.append(button('Older flags',()=>{flagBefore=Number(data.flags.at(-1).id);render();}));if(flagBefore)flags.append(button('Newest flags',()=>{flagBefore=0;render();}));body.append(flags);
 }
 async function renderCEO(body,version){
  const [data,schoolData]=await Promise.all([api('stats',{},true),api('schools',{},true)]);if(version!==generation)return;
  const card=formBox('Live platform statistics'),grid=node('div',undefined,'sn-metrics');const titles={verified_accounts:'Verified accounts',school_accounts:'School accounts',servers:'Servers & classes',schools:'Schools',open_review_flags:'Open review flags',active_group_participants:'Group-call participants',online_now:'Actively online'};
  for(const [key,title] of Object.entries(titles)){const tile=node('div');tile.append(node('strong',String(data.stats[key])),node('small',title));grid.append(tile);}card.append(grid,note('Sampled '+new Date(data.stats.sampled_at*1000).toLocaleString()),note('School contract quote: $'+(data.stats.school_quote_cents/100).toFixed(2)+' per contracted period. This is a quote, not collected revenue.'));const refresh=button('Refresh statistics',()=>render());const exportBtn=button('Export statistics JSON',()=>{const blob=new Blob([JSON.stringify(data.stats,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=node('a');a.href=url;a.download='silknex-stats.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});card.append(refresh,exportBtn);body.append(card);
  const diagnostics=await app().api('owner_database_diagnostics',{showLoader:false}).catch(error=>({error:error?.message||'Diagnostics unavailable.'}));
  if(version!==generation)return;
  const dbCard=formBox('Database & platform diagnostics');
  if(diagnostics.database){const d=diagnostics.database,items=[['Connected database',d.connected_database],['Configured host',d.configured_host],['Configured user',d.configured_user],['Schema version',d.schema_version],['All accounts',d.accounts],['Active accounts',d.active_accounts],['New accounts (24h)',d.new_24h],['Last user ID',d.last_user_id],['Stored messages',d.messages],['Persistent profile posts',d.posts]];
   const grid=node('div',undefined,'sn-metrics');for(const [label,value] of items){const tile=node('div');tile.append(node('strong',String(value)),node('small',label));grid.append(tile);}dbCard.append(grid);
   dbCard.append(note('If this database shows only built-in CEO accounts, older accounts are in a different database and need a database export/import.'));
  }else dbCard.append(note(diagnostics.error));body.append(dbCard);
  const dashboard=await app().api('owner_dashboard',{showLoader:false}).then(d=>d.dashboard||{}).catch(()=>({}));
  if(version!==generation)return;
  const traffic=formBox('Traffic & capacity');const trafficGrid=node('div',undefined,'sn-metrics');
  for(const [label,value] of [['Messages (1h)',dashboard.messages_1h],['Messages (24h)',dashboard.messages_24h],['Messages (7d)',dashboard.messages_7d],['Active calls',dashboard.active_calls],['Conversations',dashboard.conversations_total],['Uploads',dashboard.uploads_total],['Scheduled messages',dashboard.scheduled_pending],['PHP memory limit',dashboard.php_memory_limit]]){const tile=node('div');tile.append(node('strong',value===undefined?'—':String(value)),node('small',label));trafficGrid.append(tile);}traffic.append(trafficGrid);body.append(traffic);
  const ops=formBox('Content controls');const paused=Boolean(dashboard.feature_flags?.posting_paused);
  const toggle=button(paused?'Resume profile posts':'Pause new profile posts',()=>busy(toggle,async()=>{await app().api('owner_posting_set',{method:'POST',body:{paused:!paused},showLoader:false});await render();}));ops.append(note('Control new persistent profile posts without deleting existing posts.'),toggle);body.append(ops);
  await renderAccessBlocks(body,version);
  const school=formBox('School administration');school.append(note('Verify that the institution owns its domain before enrolling it. Existing verified accounts on that domain become managed school accounts. No payment is charged here.'));const name=field('School name'),domain=field('Exact school email domain'),seats=field('Licensed student seats','number','1'),extra=field('Enable teacher class projects (+$2 per student)','checkbox');seats.input.min='1';const quote=node('p');const update=()=>quote.textContent='Contract quote: $'+(Math.max(1,Number(seats.input.value)||1)*(15+(extra.input.checked?2:0))).toFixed(2)+' per agreed billing period';seats.input.addEventListener('input',update);extra.input.addEventListener('change',update);update();const save=button('Save school configuration',()=>busy(save,async()=>{await api('school_save',{name:name.input.value,domain:domain.input.value,seats:Number(seats.input.value),extras:extra.input.checked?['class_projects']:[]});await render();}));school.append(name.label,domain.label,seats.label,extra.label,quote,save);
  const select=node('select');select.setAttribute('aria-label','School for teacher assignment');for(const s of schoolData.schools){const o=node('option',s.name+' · '+s.domain);o.value=s.id;select.append(o);}const username=field('Verified school username');const teacher=field('Teacher permissions','checkbox');const assign=button('Save school role',()=>busy(assign,async()=>{await api('teacher_set',{school_id:Number(select.value),username:username.input.value,teacher:teacher.input.checked});report('School role updated.');}));school.append(node('h4','Teacher permissions'),select,username.label,teacher.label,assign);body.append(school);
 }
 async function renderAccessBlocks(body,version){
  const data=await app().api('owner_access_blocks',{showLoader:false});if(version!==generation)return;
  const card=formBox('Scheduled app access blocks');
  card.append(note('All accounts lose app access during a block, including CEO accounts. The CEO or co-founder can cancel a block from the lock screen. Times shown below use your device time zone.'));
  const start=field('Start (your local time)','datetime-local'),end=field('End (your local time)','datetime-local'),reason=field('Short notice (optional)','text');reason.input.maxLength=120;
  const create=button('Schedule block',()=>busy(create,async()=>{
   const from=new Date(start.input.value).getTime(),to=new Date(end.input.value).getTime();
   if(!Number.isFinite(from)||!Number.isFinite(to)||to<=from){report('Choose a valid start and end time.');return;}
   await app().api('owner_access_block_create',{method:'POST',body:{starts_at:Math.floor(from/1000),ends_at:Math.floor(to/1000),note:reason.input.value},showLoader:false});
   await render();
  }));card.append(start.label,end.label,reason.label,create);
  for(const item of data.blocks||[]){const row=node('div',undefined,'sn-row');const from=new Date(Number(item.starts_at)*1000).toLocaleString(),to=new Date(Number(item.ends_at)*1000).toLocaleString();row.append(node('span',from+' – '+to+(item.note?' · '+item.note:'')));const remove=button('Cancel',()=>busy(remove,async()=>{await app().api('owner_access_block_delete',{method:'POST',body:{id:Number(item.id)},showLoader:false});await render();}));row.append(remove);card.append(row);}
  if(!data.blocks?.length)card.append(note('No scheduled blocks.'));body.append(card);
 }
 const preferenceKey=()=>`silknex-appearance-v77:${app()?.state.me?.id||0}`;
 function appearance(){try{return JSON.parse(window.SilknexStorage.getItem(preferenceKey())||'{}');}catch{return {};}}
 function applyAppearance(){const p=appearance(),r=document.documentElement;r.dataset.communityAppearance=Object.keys(p).length?'true':'false';const defaults={radius:18,gap:8,wallpaperOpacity:100,wallpaperSize:100};for(const [key,defaultValue] of Object.entries(defaults)){const ranges={radius:[0,32],gap:[2,24],wallpaperOpacity:[0,100],wallpaperSize:[50,200]};const value=Math.min(ranges[key][1],Math.max(ranges[key][0],Number(p[key]??defaultValue)));r.style.setProperty('--sn-'+key,Number.isFinite(value)?String(value):String(defaultValue));}r.dataset.wallpaperPattern=['none','dots','grid'].includes(p.pattern)?p.pattern:'none';}
 function renderAppearance(body){const card=formBox('Personalize this device');card.append(note('These controls work alongside your saved theme, wallpaper image, message density and accessibility settings.'));const values=appearance(),controls={};for(const [key,label,min,max,initial] of [['radius','Message corner radius',0,32,18],['gap','Message spacing',2,24,8],['wallpaperOpacity','Wallpaper visibility',0,100,100],['wallpaperSize','Wallpaper image size',50,200,100]]){const f=field(label,'range',values[key]??initial);f.input.min=min;f.input.max=max;controls[key]=f.input;card.append(f.label);}const pattern=node('select');pattern.setAttribute('aria-label','Wallpaper pattern');for(const key of ['none','dots','grid']){const option=node('option',key);option.value=key;pattern.append(option);}pattern.value=values.pattern||'none';const save=button('Save appearance',()=>{try{window.SilknexStorage.setItem(preferenceKey(),JSON.stringify({...Object.fromEntries(Object.entries(controls).map(([k,v])=>[k,Number(v.value)])),pattern:pattern.value}));applyAppearance();report('Appearance saved on this device.');}catch(e){report(e);}});const reset=button('Reset these controls',()=>{window.SilknexStorage.removeItem(preferenceKey());applyAppearance();render();});card.append(pattern,save,reset);body.append(card);}
 function renderCall(body){const card=formBox('Group call');card.append(note('Up to six participants. Audio is the default; optional video uses a modest resolution to reduce memory and upload bandwidth. Everyone joins from the same group chat.'));
  if(room){card.append(note('Connected to group '+room.cid),button(room.muted?'Unmute microphone':'Mute microphone',()=>{room.muted=!room.muted;room.stream.getAudioTracks().forEach(t=>t.enabled=!room.muted);render();}),button('Leave group call',()=>{leaveRoom();render();},'danger-btn'));}
  else{const video=field('Use camera','checkbox');const join=button('Join current group call',()=>busy(join,()=>joinRoom(video.input.checked)));card.append(video.label,join);}body.append(card);const host=$('#snMediaHost');if(host)host.hidden=!room;
 }
 async function joinRoom(video){
  if(room)return;const attempt=++joining;if(app().state.call)throw Error('End your current direct call first.');if(!navigator.mediaDevices?.getUserMedia||!window.RTCPeerConnection)throw Error('Group calls need HTTPS, microphone permission and WebRTC support.');
  const cid=Number(app().state.activeId||0),me=app().state.me;if(!cid)throw Error('Open a group chat first.');
  let stream, lease;
  try{stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:video?{width:{ideal:640},height:{ideal:360},frameRate:{ideal:15,max:24}}:false});if(app().state.me!==me||attempt!==joining||app().state.call)throw Error('Call join cancelled.');const data=await api('room_join',{conversation_id:cid});lease=data.token;
   if(app().state.me!==me||attempt!==joining||app().state.call)throw Error('Call join cancelled.');
   room={cid,me,token:data.token,ice:data.ice_servers,stream,peers:new Map(),after:0,timer:null,closed:false,muted:false,failures:0};
   let host=$('#snMediaHost');if(!host){host=node('div',undefined,'sn-call-grid');host.id='snMediaHost';$('#snModal .sn-shell').append(host);}host.replaceChildren();host.hidden=false;
   const local=node('video');local.autoplay=true;local.muted=true;local.playsInline=true;local.srcObject=stream;local.setAttribute('aria-label','Your camera preview');if(video)host.append(local);
   $('#snOpen').textContent='Spaces · call';await pollRoom(room);render();
  }catch(e){stream?.getTracks().forEach(t=>t.stop());if(room?.token===lease)leaveRoom();else if(lease)app()?.api('community_room_leave',{method:'POST',body:{conversation_id:cid,token:lease},showLoader:false,keepalive:true}).catch(()=>{});throw e;}
 }
 async function signal(r,id,payload){if(r.closed)return;await api('room_signal',{conversation_id:r.cid,token:r.token,target_id:id,payload});}
 function peer(r,entry){const id=Number(entry.user_id),pc=new RTCPeerConnection({iceServers:r.ice}),tile=node('div',undefined,'sn-call-tile'),media=node('video');media.autoplay=true;media.playsInline=true;tile.append(media,node('span',entry.display_name));$('#snMediaHost').append(tile);
  const p={pc,session:entry.session,media,tile,candidates:[],offering:false};r.peers.set(id,p);
  r.stream.getTracks().forEach(t=>pc.addTrack(t,r.stream));if(!r.stream.getVideoTracks().length)pc.addTransceiver('video',{direction:'recvonly'});
  pc.onicecandidate=event=>{if(event.candidate)signal(r,id,{type:'candidate',candidate:event.candidate.toJSON()}).catch(()=>{});};
  pc.ontrack=event=>{media.srcObject=event.streams[0]||new MediaStream([event.track]);media.play().catch(()=>{if(!tile.querySelector('button'))tile.append(button('Enable call audio',()=>media.play().catch(report)));});};
  pc.onconnectionstatechange=()=>{tile.dataset.connection=pc.connectionState;if(pc.connectionState==='failed')tile.append(note('Connection failed. Leave and rejoin; this network may need a TURN relay.'));};
  return p;
 }
 async function pollRoom(r){if(r.closed||room!==r)return;try{
  if(app().state.me!==r.me){leaveRoom();return;}
  const data=await app().api('community_room_poll',{method:'POST',body:{conversation_id:r.cid,token:r.token,after:r.after},showLoader:false,timeoutMs:10000});if(r.closed||room!==r)return;r.failures=0;
  const current=new Map(data.peers.filter(x=>Number(x.user_id)!==Number(r.me.id)).map(x=>[Number(x.user_id),x]));
  for(const [id,p] of r.peers){if(!current.has(id)||current.get(id).session!==p.session){p.pc.close();p.media.srcObject=null;p.tile.remove();r.peers.delete(id);}}
  for(const [id,entry] of current){if(r.peers.has(id))continue;const p=peer(r,entry);if(Number(r.me.id)<id){p.offering=true;await p.pc.setLocalDescription(await p.pc.createOffer());await signal(r,id,{type:'offer',sdp:p.pc.localDescription.sdp});p.offering=false;}}
  for(const item of data.signals){const id=Number(item.sender_id),p=r.peers.get(id);let payload;try{payload=JSON.parse(item.payload);}catch{r.after=Math.max(r.after,Number(item.id));continue;}
   if(p&&payload.session===p.session){try{
    if(payload.type==='candidate'){if(p.pc.remoteDescription)await p.pc.addIceCandidate(payload.candidate);else if(p.candidates.length<50)p.candidates.push(payload.candidate);}
    else{await p.pc.setRemoteDescription({type:payload.type,sdp:payload.sdp});for(const candidate of p.candidates.splice(0))await p.pc.addIceCandidate(candidate);if(payload.type==='offer'){await p.pc.setLocalDescription(await p.pc.createAnswer());await signal(r,id,{type:'answer',sdp:p.pc.localDescription.sdp});}}
   }catch(e){p.tile.dataset.connection='error';report('One participant could not connect. Rejoin the call if it continues.');}}
   r.after=Math.max(r.after,Number(item.id));
  }
 }catch(e){if(r.closed)return;r.failures++;if([401,403,409].includes(Number(e.status))||r.failures>=5){leaveRoom();report(e);return;}}
 finally{if(!r.closed&&room===r)r.timer=setTimeout(()=>pollRoom(r),Math.min(8000,2000*(1+r.failures)));}}
 function leaveRoom(){joining++;const r=room;if(!r)return;room=null;r.closed=true;clearTimeout(r.timer);r.stream.getTracks().forEach(t=>t.stop());for(const p of r.peers.values()){p.pc.close();p.media.srcObject=null;p.tile.remove();}r.peers.clear();const host=$('#snMediaHost');if(host){host.querySelectorAll('video').forEach(v=>v.srcObject=null);host.replaceChildren();host.hidden=true;}if($('#snOpen'))$('#snOpen').textContent='Spaces';app()?.api('community_room_leave',{method:'POST',body:{conversation_id:r.cid,token:r.token},showLoader:false,keepalive:true}).catch(()=>{});}
 window.addEventListener('pagehide',leaveRoom);
 window.SilknexCommunity=Object.freeze({scanText,boot,async prepareText(text){await boot();await wordPromise;return scanText(text);},open:show,leaveRoom,get inCall(){return !!room;}});
 if(app())install();else window.addEventListener('silknex:core-ready',install,{once:true});
})();
