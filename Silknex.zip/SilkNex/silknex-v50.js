(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const runtime = {
    signedIn: false,
    founder: false,
    reminderTimer: null,
    reminderObserver: null,
    reminderIds: new Set(),
    reminderMessageId: 0,
    nextReminderAt: 0,
    ownerRefreshTimer: null,
  };


  function toast(message) {
    app()?.toast?.(String(message || ""));
  }


  function icon(name) {
    const paths = {
      bell: ["M6 17h12", "M8 17V10a4 4 0 0 1 8 0v7", "M10 20h4"],
      search: ["M11 18a7 7 0 1 1 0-14 7 7 0 0 1 0 14Z", "m16 16 4 4"],
      command: ["M9 6H6a3 3 0 1 0 3 3V6Zm0 0v12m0 0H6a3 3 0 1 1 3-3v3Zm6-12h3a3 3 0 1 1-3 3V6Zm0 0v12m0 0h3a3 3 0 1 0-3-3v3Z"],
      download: ["M12 3v12", "m8 11 4 4 4-4", "M5 20h14"],
      activity: ["M3 12h4l2-6 4 12 2-6h6"],
      shield: ["M12 3 5 6v5c0 4.5 2.8 8 7 10 4.2-2 7-5.5 7-10V6l-7-3Z", "m9 12 2 2 4-5"],
      user: ["M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z", "M4 21a8 8 0 0 1 16 0"],
      pause: ["M8 6v12", "M16 6v12"],
      play: ["m9 6 9 6-9 6Z"],
      list: ["M8 6h13", "M8 12h13", "M8 18h13", "M3 6h.01", "M3 12h.01", "M3 18h.01"],
      export: ["M12 3v12", "m8 11 4 4 4-4", "M5 20h14"],
      focus: ["M8 3H3v5", "M16 3h5v5", "M8 21H3v-5", "M16 21h5v-5"],
    };
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    svg.classList.add("v50-icon");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "1.8");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    for (const d of paths[name] || paths.command) {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", d);
      svg.appendChild(path);
    }
    return svg;
  }

  function isFounder() {
    return Boolean(
      app()?.state?.me &&
      app()?.state?.me?.role === "founder_ceo"
    );
  }

  function formatDate(timestamp) {
    const seconds = Number(timestamp || 0);
    if (!seconds) return "—";
    try {
      return new Intl.DateTimeFormat(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(seconds * 1000));
    } catch {
      return new Date(seconds * 1000).toLocaleString();
    }
  }

  function formatInteger(value) {
    const number = Number(value || 0);
    try {
      return new Intl.NumberFormat().format(Number.isFinite(number) ? number : 0);
    } catch {
      return String(Number.isFinite(number) ? number : 0);
    }
  }

  function money(cents) {
    try {
      return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency: "USD",
      }).format(Number(cents || 0) / 100);
    } catch {
      return `$${(Number(cents || 0) / 100).toFixed(2)}`;
    }
  }

  function localDateTimeValue(timestamp) {
    const date = new Date(timestamp);
    const offsetMs = date.getTimezoneOffset() * 60000;
    return new Date(date.getTime() - offsetMs).toISOString().slice(0, 16);
  }

  /* ------------------------------------------------------------------ */
  /* Connectivity + focus mode                                           */
  /* ------------------------------------------------------------------ */

  function ensureConnectivityChip() {
    let chip = $("#v50Connectivity");
    if (chip) return chip;

    chip = document.createElement("button");
    chip.id = "v50Connectivity";
    chip.className = "v50-connectivity";
    chip.type = "button";
    chip.setAttribute("aria-live", "polite");
    chip.title = "Connection status";
    chip.append(icon("activity"), document.createElement("span"));

    const target = $("#syncStatus")?.parentElement || $("#chatHeader") || $(".sidebar-header");
    target?.appendChild(chip);
    chip.addEventListener("click", () => {
      if (!navigator.onLine) {
        toast("SilkNex is offline. Messages will sync again when your connection returns.");
      } else {
        toast("Connected. SilkNex is syncing normally.");
      }
    });
    return chip;
  }

  function updateConnectivity() {
    const chip = ensureConnectivityChip();
    if (!chip) return;
    const online = navigator.onLine;
    chip.classList.toggle("offline", !online);
    const label = $("span", chip);
    if (label) label.textContent = online ? "Online" : "Offline";
    chip.setAttribute("aria-label", online ? "SilkNex is online" : "SilkNex is offline");
  }

  /* ------------------------------------------------------------------ */
  /* Message reminders                                                   */
  /* ------------------------------------------------------------------ */

  function messageFallback(item) {
    return {
      image: "Photo",
      gif: "GIF",
      video: "Video",
      audio: "Voice message",
      video_note: "Video message",
      sticker: "Sticker",
    }[String(item?.message_type || "text")] || "Encrypted message";
  }

  async function reminderPreview(item) {
    const loaded = app()?.state?.messages?.get?.(Number(item?.message_id || 0));
    if (loaded && String(loaded.body || "").trim()) {
      return String(loaded.body).trim();
    }

    const serverPreview = String(item?.preview || "").trim();
    if (serverPreview) return serverPreview;
    if (!item?.e2ee_payload) return messageFallback(item);

    try {
      const decrypted = await window.SilknexE2EE?.decryptMessage?.({
        id: Number(item.message_id || 0),
        conversation_id: Number(item.conversation_id || 0),
        sender_id: Number(item.sender_id || 0),
        e2ee_payload: String(item.e2ee_payload || ""),
        message_type: String(item.message_type || "text"),
        body: "",
      });
      return String(decrypted?.body || "").trim() || messageFallback(item);
    } catch {
      return messageFallback(item);
    }
  }

  function ensureReminderModal() {
    if ($("#v50ReminderModal")) return;

    const modal = document.createElement("section");
    modal.id = "v50ReminderModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v50ReminderTitle");
    modal.innerHTML = `
      <div class="modal-card v50-reminder-card">
        <header class="modal-head">
          <div><small>REMINDERS</small><h2 id="v50ReminderTitle">Message reminders</h2></div>
          <button id="v50ReminderClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <div id="v50ReminderList" class="v50-reminder-list" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(modal);
    $("#v50ReminderClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
  }

  function ensureReminderPicker() {
    if ($("#v50ReminderPicker")) return;

    const modal = document.createElement("section");
    modal.id = "v50ReminderPicker";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v50ReminderPickerTitle");
    modal.innerHTML = `
      <div class="modal-card v50-reminder-picker-card">
        <header class="modal-head">
          <div><small>MESSAGE</small><h2 id="v50ReminderPickerTitle">Remind me</h2></div>
          <button id="v50ReminderPickerClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <div class="v50-reminder-presets">
          <button type="button" data-reminder-offset="600">In 10 minutes</button>
          <button type="button" data-reminder-offset="3600">In 1 hour</button>
          <button type="button" data-reminder-preset="tomorrow">Tomorrow at 9:00 AM</button>
          <button type="button" data-reminder-offset="604800">In 1 week</button>
        </div>
        <form id="v50ReminderCustomForm" class="v50-reminder-custom">
          <label class="field">
            <span>Custom date and time</span>
            <input id="v50ReminderCustomTime" type="datetime-local" required>
          </label>
          <button class="primary" type="submit">Set reminder</button>
        </form>
      </div>
    `;
    document.body.appendChild(modal);

    $("#v50ReminderPickerClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
    $$("[data-reminder-offset]", modal).forEach((button) => {
      button.addEventListener("click", () => {
        const offset = Number(button.dataset.reminderOffset || 0);
        setMessageReminder(runtime.reminderMessageId, Math.floor(Date.now() / 1000) + offset);
      });
    });
    $("[data-reminder-preset='tomorrow']", modal)?.addEventListener("click", () => {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(9, 0, 0, 0);
      setMessageReminder(runtime.reminderMessageId, Math.floor(tomorrow.getTime() / 1000));
    });
    $("#v50ReminderCustomForm", modal)?.addEventListener("submit", (event) => {
      event.preventDefault();
      const value = $("#v50ReminderCustomTime")?.value;
      const timestamp = value ? Math.floor(new Date(value).getTime() / 1000) : 0;
      if (!timestamp || timestamp <= Math.floor(Date.now() / 1000) + 30) {
        toast("Choose a future time.");
        return;
      }
      setMessageReminder(runtime.reminderMessageId, timestamp);
    });
  }

  function openReminderPicker(messageId) {
    const id = Number(messageId || 0);
    const cid = Number(app()?.state?.activeId || 0);
    if (!id || !cid) return;

    runtime.reminderMessageId = id;
    ensureReminderPicker();
    const input = $("#v50ReminderCustomTime");
    if (input) {
      input.min = localDateTimeValue(Date.now() + 60000);
      input.value = localDateTimeValue(Date.now() + 3600000);
    }
    app()?.openModal?.("#v50ReminderPicker");
  }

  async function setMessageReminder(messageId, remindAt) {
    const cid = Number(app()?.state?.activeId || 0);
    const id = Number(messageId || 0);
    if (!cid || !id || !app()?.api) return;

    try {
      await app().api("message_reminder_set", {
        method: "POST",
        body: {
          conversation_id: cid,
          message_id: id,
          remind_at: Number(remindAt || 0),
        },
        showLoader: false,
      });
      runtime.reminderIds.add(id);
      updateReminderButtons();
      app()?.closeModal?.();
      toast(`Reminder set for ${formatDate(remindAt)}.`);
      scheduleReminderRefresh(2000);
    } catch (error) {
      toast(error?.message || "Could not set the reminder.");
    }
  }

  async function deleteReminder(messageId, quiet = false) {
    const id = Number(messageId || 0);
    if (!id || !app()?.api) return;
    try {
      await app().api("message_reminder_delete", {
        method: "POST",
        body: { message_id: id },
        showLoader: false,
      });
      runtime.reminderIds.delete(id);
      updateReminderButtons();
      if (!quiet) toast("Reminder removed.");
    } catch (error) {
      if (!quiet) toast(error?.message || "Could not remove the reminder.");
    }
  }

  async function loadReminders({ render = false, processDue = false } = {}) {
    if (!runtime.signedIn || !app()?.api) return [];
    try {
      const data = await app().api("message_reminders", {
        showLoader: false,
        timeoutMs: 7000,
      });
      const items = Array.isArray(data?.reminders) ? data.reminders : [];
      runtime.reminderIds = new Set(items.map((item) => Number(item.message_id || 0)).filter(Boolean));
      runtime.nextReminderAt = items.reduce((earliest, item) => {
        const at = Number(item?.remind_at || 0);
        if (!at) return earliest;
        return earliest === 0 ? at : Math.min(earliest, at);
      }, 0);
      updateReminderButtons();
      if (processDue) await processDueReminders(items, Number(data?.server_time || 0));
      if (render) await renderReminders(items);
      return items;
    } catch (error) {
      if (render) {
        const list = $("#v50ReminderList");
        if (list) list.textContent = error?.message || "Could not load reminders.";
      }
      return [];
    }
  }

  async function renderReminders(items) {
    ensureReminderModal();
    const list = $("#v50ReminderList");
    if (!list) return;
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "v50-reminder-empty";
      empty.textContent = "No upcoming message reminders.";
      list.appendChild(empty);
      return;
    }

    for (const item of items) {
      const row = document.createElement("article");
      row.className = "v50-reminder-row";

      const head = document.createElement("div");
      head.className = "v50-reminder-row-head";
      const title = document.createElement("strong");
      title.textContent = String(item.conversation_title || "Conversation");
      const when = document.createElement("time");
      when.textContent = formatDate(item.remind_at);
      head.append(title, when);

      const copy = document.createElement("p");
      copy.textContent = "Decrypting preview…";

      const actions = document.createElement("div");
      actions.className = "v50-reminder-row-actions";
      const open = document.createElement("button");
      open.type = "button";
      open.className = "secondary-btn";
      open.textContent = "Open chat";
      open.addEventListener("click", () => {
        app()?.closeModal?.();
        app()?.openConversation?.(Number(item.conversation_id || 0));
      });
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "plain-btn";
      remove.textContent = "Remove";
      remove.addEventListener("click", async () => {
        await deleteReminder(item.message_id);
        await loadReminders({ render: true });
      });
      actions.append(open, remove);
      row.append(head, copy, actions);
      list.appendChild(row);

      reminderPreview(item).then((text) => {
        copy.textContent = text.slice(0, 260);
      });
    }
  }

  async function processDueReminders(items, serverNow) {
    const now = serverNow || Math.floor(Date.now() / 1000);
    const due = items.filter((item) => Number(item.remind_at || 0) <= now);
    for (const item of due) {
      const id = Number(item.message_id || 0);
      if (!id) continue;
      const preview = await reminderPreview(item);
      toast(`Reminder · ${String(item.conversation_title || "Chat")}: ${preview.slice(0, 140)}`);

      if (
        document.visibilityState === "hidden" &&
        "Notification" in window &&
        Notification.permission === "granted"
      ) {
        try {
          const notification = new Notification("SilkNex reminder", {
            body: `${String(item.conversation_title || "Chat")}: ${preview.slice(0, 180)}`,
            icon: "app-icon-black.png",
            tag: `silknex-reminder-${id}`,
          });
          notification.onclick = () => {
            window.focus();
            app()?.openConversation?.(Number(item.conversation_id || 0));
            notification.close();
          };
        } catch {}
      }

      await deleteReminder(id, true);
    }
  }

  function scheduleReminderRefresh(delay = null) {
    clearTimeout(runtime.reminderTimer);
    runtime.reminderTimer = null;
    if (!runtime.signedIn) return;

    let nextDelay = Number(delay);
    if (!Number.isFinite(nextDelay) || nextDelay < 0) {
      const now = Math.floor(Date.now() / 1000);
      const untilDue = runtime.nextReminderAt > now
        ? (runtime.nextReminderAt - now) * 1000
        : 0;
      nextDelay = untilDue > 0
        ? Math.min(300000, Math.max(15000, untilDue + 750))
        : 300000;
      if (
        document.visibilityState === "hidden" &&
        !(untilDue > 0 && untilDue <= 300000)
      ) {
        nextDelay = Math.max(nextDelay, 300000);
      }
    }

    runtime.reminderTimer = setTimeout(async () => {
      if (navigator.onLine) {
        await loadReminders({ processDue: true });
      }
      scheduleReminderRefresh();
    }, Math.max(1000, nextDelay));
  }

  function reminderButton(messageId) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "message-action icon-action v50-reminder-action";
    button.dataset.reminderMessageId = String(messageId);
    button.title = "Remind me";
    button.setAttribute("aria-label", "Remind me about this message");
    button.appendChild(icon("bell"));
    button.addEventListener("click", () => {
      if (runtime.reminderIds.has(Number(messageId))) {
        deleteReminder(messageId);
      } else {
        openReminderPicker(messageId);
      }
    });
    return button;
  }

  function decorateReminderButtons() {
    $$("#messages .message[data-message-id]").forEach((row) => {
      const id = Number(row.dataset.messageId || 0);
      const actions = $(".message-actions", row);
      if (!id || !actions || $(".v50-reminder-action", actions)) return;
      actions.appendChild(reminderButton(id));
    });
    updateReminderButtons();
  }

  function updateReminderButtons() {
    $$("[data-reminder-message-id]").forEach((button) => {
      const id = Number(button.dataset.reminderMessageId || 0);
      const active = runtime.reminderIds.has(id);
      button.classList.toggle("selected", active);
      button.setAttribute("aria-pressed", active ? "true" : "false");
      button.title = active ? "Remove reminder" : "Remind me";
      button.setAttribute(
        "aria-label",
        active ? "Remove reminder for this message" : "Remind me about this message"
      );
    });
  }

  function bindReminderObserver() {
    const box = $("#messages");
    if (!box || runtime.reminderObserver) return;
    runtime.reminderObserver = new MutationObserver(() => {
      requestAnimationFrame(decorateReminderButtons);
    });
    runtime.reminderObserver.observe(box, { childList: true, subtree: true });
    decorateReminderButtons();
  }

  function openReminders() {
    ensureReminderModal();
    app()?.openModal?.("#v50ReminderModal");
    loadReminders({ render: true, processDue: true });
  }

  /* ------------------------------------------------------------------ */
  /* Local decrypted export                                              */
  /* ------------------------------------------------------------------ */

  function safeFilename(value) {
    return String(value || "conversation")
      .normalize("NFKD")
      .replace(/[^\w.-]+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 80) || "conversation";
  }

  function exportMessageBody(message) {
    const body = String(message?.body || "").trim();
    if (body) return body;
    return messageFallback(message);
  }

  function exportCurrentChat() {
    const state = app()?.state;
    if (!state?.activeId || !(state.messages instanceof Map)) {
      toast("Open a conversation first.");
      return;
    }

    const title = String(state.activeConversation?.title || "SilkNex chat");
    const messages = [...state.messages.values()]
      .filter((message) => !message?.deleted_at)
      .sort((a, b) => Number(a.id || 0) - Number(b.id || 0));

    if (!messages.length) {
      toast("There are no loaded messages to export.");
      return;
    }

    const meId = Number(state.me?.id || 0);
    const lines = [
      `SilkNex conversation export`,
      `Conversation: ${title}`,
      `Exported: ${new Date().toLocaleString()}`,
      `Scope: messages currently loaded on this device`,
      "",
    ];

    for (const message of messages) {
      const when = Number(message.created_at || 0)
        ? new Date(Number(message.created_at) * 1000).toLocaleString()
        : "";
      const sender = Number(message.sender_id || 0) === meId
        ? String(state.me?.display_name || state.me?.username || "You")
        : String(message.sender_display_name || message.sender_name || "Participant");
      lines.push(`[${when}] ${sender}: ${exportMessageBody(message)}`);
    }

    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${safeFilename(title)}-${new Date().toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("Loaded chat exported.");
  }

  function activeConversationListItem() {
    const id = Number(app()?.state?.activeId || 0);
    return (app()?.state?.conversations || []).find((item) => Number(item.id) === id) || null;
  }

  function updateChatOrganizationButtons() {
    const item = activeConversationListItem();
    const pin = $("#v50PinChatBtn");
    const favorite = $("#v50FavoriteChatBtn");
    const archive = $("#v50ArchiveChatBtn");

    if (!item) {
      for (const button of [pin, favorite, archive]) {
        if (button) button.disabled = true;
      }
      return;
    }

    if (pin) {
      pin.disabled = false;
      pin.textContent = item.pinned ? "Unpin chat" : "Pin chat";
      pin.classList.toggle("active", Boolean(item.pinned));
    }
    if (favorite) {
      favorite.disabled = false;
      favorite.textContent = item.favorite ? "Unfavorite" : "Favorite";
      favorite.classList.toggle("active", Boolean(item.favorite));
    }
    if (archive) {
      archive.disabled = false;
      archive.textContent = item.archived ? "Unarchive" : "Archive";
      archive.classList.toggle("active", Boolean(item.archived));
    }
  }

  async function setActiveConversationListState(changes) {
    const item = activeConversationListItem();
    if (!item || !app()?.api) return;

    const next = {
      favorite: changes.favorite ?? Boolean(item.favorite),
      archived: changes.archived ?? Boolean(item.archived),
    };

    try {
      await app().api("conversation_list_state", {
        method: "POST",
        body: {
          conversation_id: Number(item.id),
          favorite: Boolean(next.favorite),
          archived: Boolean(next.archived),
        },
        showLoader: false,
      });
      item.favorite = Boolean(next.favorite);
      item.archived = Boolean(next.archived);
      if (item.archived) {
        item.pinned = false;
        item.pinned_at = null;
      }
      await app()?.loadConversations?.();
      updateChatOrganizationButtons();
      toast(item.archived
        ? "Chat archived."
        : changes.favorite !== undefined
          ? (item.favorite ? "Added to favorites." : "Removed from favorites.")
          : "Chat restored.");
    } catch (error) {
      toast(error?.message || "Could not update the chat.");
    }
  }

  async function toggleActivePin() {
    const item = activeConversationListItem();
    if (!item || !app()?.api) return;

    try {
      await app().api("pin_conversation", {
        method: "POST",
        body: {
          conversation_id: Number(item.id),
          pinned: !Boolean(item.pinned),
        },
        showLoader: false,
      });
      item.pinned = !Boolean(item.pinned);
      await app()?.loadConversations?.();
      updateChatOrganizationButtons();
      toast(item.pinned ? "Chat pinned." : "Chat unpinned.");
    } catch (error) {
      toast(error?.message || "Could not update the pin.");
    }
  }

  function ensureGeneralTools() {
    const modal = $("#chatSettingsModal .modal-card");
    if (modal && !$("#v50ChatTools")) {
      const section = document.createElement("section");
      section.id = "v50ChatTools";
      section.className = "settings-section v50-chat-tools";
      section.innerHTML = `
        <div class="section-title"><span>More tools</span></div>
        <div class="v50-tool-grid">
          <button id="v50ExportChatBtn" class="secondary-btn" type="button">Export loaded chat</button>
          <button id="v50OpenRemindersBtn" class="secondary-btn" type="button">Message reminders</button>
        </div>
        <div class="section-title v50-organize-title"><span>Organize chat</span></div>
        <div class="v50-tool-grid v50-organize-grid">
          <button id="v50PinChatBtn" class="secondary-btn" type="button">Pin chat</button>
          <button id="v50FavoriteChatBtn" class="secondary-btn" type="button">Favorite</button>
          <button id="v50ArchiveChatBtn" class="secondary-btn" type="button">Archive</button>
        </div>
      `;
      const utility = $("#v49ChatUtilities", modal);
      if (utility) utility.insertAdjacentElement("afterend", section);
      else $(".modal-head", modal)?.insertAdjacentElement("afterend", section);
      $("#v50ExportChatBtn", section)?.addEventListener("click", exportCurrentChat);
      $("#v50OpenRemindersBtn", section)?.addEventListener("click", openReminders);
      $("#v50PinChatBtn", section)?.addEventListener("click", toggleActivePin);
      $("#v50FavoriteChatBtn", section)?.addEventListener("click", () => {
        const item = activeConversationListItem();
        if (item) setActiveConversationListState({ favorite: !Boolean(item.favorite) });
      });
      $("#v50ArchiveChatBtn", section)?.addEventListener("click", () => {
        const item = activeConversationListItem();
        if (item) setActiveConversationListState({ archived: !Boolean(item.archived) });
      });
      updateChatOrganizationButtons();
    }

    const settings = $("#settingsModal .settings-card");
    if (settings && !$("#v50ProductivitySettings")) {
      const section = document.createElement("section");
      section.id = "v50ProductivitySettings";
      section.className = "settings-section v50-productivity-settings";
      section.innerHTML = `
        <div class="section-title"><span>Productivity</span></div>
        <div class="v50-setting-actions">
          <button id="v50CommandSettingsBtn" class="secondary-btn" type="button">Open command palette</button>
          <button id="v50ReminderSettingsBtn" class="secondary-btn" type="button">Message reminders</button>
          <button id="v50FocusSettingsBtn" class="secondary-btn" type="button">Toggle Focus mode</button>
        </div>
        <small class="v50-setting-note">Tip: press Ctrl+K or ⌘K anywhere in SilkNex to jump to a chat or feature.</small>
      `;
      const monetization = $("#monetizationSettings");
      if (monetization) monetization.insertAdjacentElement("beforebegin", section);
      else settings.appendChild(section);
      $("#v50CommandSettingsBtn", section)?.addEventListener("click", () => {
        $("#quickSwitcherHomeBtn")?.click();
      });
      $("#v50ReminderSettingsBtn", section)?.addEventListener("click", openReminders);
      $("#v50FocusSettingsBtn", section)?.addEventListener("click", () => {
        $("#focusModeHomeBtn")?.click();
      });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Founder v50 operations                                              */
  /* ------------------------------------------------------------------ */

  function founderMetric(label, value, sub = "") {
    const card = document.createElement("div");
    card.className = "v50-founder-metric";
    const small = document.createElement("small");
    small.textContent = label;
    const strong = document.createElement("strong");
    strong.textContent = String(value ?? "—");
    card.append(small, strong);
    if (sub) {
      const note = document.createElement("span");
      note.textContent = sub;
      card.appendChild(note);
    }
    return card;
  }

  function ensureFounderExtras() {
    if (!isFounder()) return;
    const modal = $("#v49OwnerModal .v49-owner-card");
    if (!modal || $("#v50FounderExtras", modal)) return;

    const section = document.createElement("section");
    section.id = "v50FounderExtras";
    section.className = "v50-founder-extras";
    section.innerHTML = `
      <section class="v49-owner-block">
        <div class="section-title"><span>Traffic & health</span></div>
        <div id="v50FounderMetrics" class="v50-founder-metrics" aria-live="polite"></div>
      </section>

      <section class="v49-owner-block">
        <div class="section-title"><span>Ad serving</span></div>
        <div class="v50-founder-control-row">
          <div>
            <b id="v50AdsPauseTitle">Loading…</b>
            <small id="v50AdsPauseCopy">Pause SilkNex-served campaign inventory globally without deleting campaigns.</small>
          </div>
          <button id="v50AdsPauseBtn" class="secondary-btn" type="button">Loading…</button>
        </div>
      </section>

      <section class="v49-owner-block">
        <div class="section-title"><span>User operations</span></div>
        <form id="v50FounderLookupForm" class="v50-founder-user-form">
          <label class="field">
            <span>Username</span>
            <input id="v50FounderUsername" maxlength="24" autocomplete="off" placeholder="username">
          </label>
          <button class="secondary-btn" type="submit">Look up</button>
        </form>
        <div id="v50FounderUserResult" class="v50-founder-user-result hidden"></div>
        <div class="v50-founder-grant">
          <label class="field">
            <span>Complimentary ad-free hours</span>
            <input id="v50FounderGrantHours" type="number" min="1" max="720" value="24">
          </label>
          <button id="v50FounderGrantBtn" class="secondary-btn" type="button">Grant ad-free</button>
        </div>
      </section>

      <section class="v49-owner-block">
        <div class="v50-founder-audit-head">
          <div class="section-title"><span>Founder audit log</span></div>
          <button id="v50AuditRefreshBtn" class="plain-btn" type="button">Refresh</button>
        </div>
        <div id="v50FounderAudit" class="v50-founder-audit" aria-live="polite"></div>
      </section>
    `;
    modal.appendChild(section);

    $("#v50AdsPauseBtn", section)?.addEventListener("click", toggleGlobalAds);
    $("#v50FounderLookupForm", section)?.addEventListener("submit", lookupFounderUser);
    $("#v50FounderGrantBtn", section)?.addEventListener("click", grantFounderAdFree);
    $("#v50AuditRefreshBtn", section)?.addEventListener("click", loadFounderAudit);
  }

  function renderFounderDashboard(dashboard) {
    const metrics = $("#v50FounderMetrics");
    if (metrics) {
      metrics.replaceChildren(
        founderMetric("Online", formatInteger(dashboard.online_now), "last 2 min"),
        founderMetric("New users", formatInteger(dashboard.new_users_24h), "24 hours"),
        founderMetric("Messages", formatInteger(dashboard.messages_1h), "last hour"),
        founderMetric("Messages", formatInteger(dashboard.messages_24h), "24 hours"),
        founderMetric("Messages", formatInteger(dashboard.messages_7d), "7 days"),
        founderMetric("Active calls", formatInteger(dashboard.active_calls)),
        founderMetric("Paid ads", money(dashboard.paid_ad_revenue_cents), "collected"),
        founderMetric("Campaigns", formatInteger(dashboard.active_ad_campaigns), "active")
      );
    }

    const paused = Boolean(dashboard.feature_flags?.ads_paused);
    const title = $("#v50AdsPauseTitle");
    const copy = $("#v50AdsPauseCopy");
    const button = $("#v50AdsPauseBtn");
    if (title) title.textContent = paused ? "Campaign ads are paused" : "Campaign ads are serving";
    if (copy) {
      copy.textContent = paused
        ? "Paid campaigns remain scheduled, but SilkNex is not serving campaign inventory."
        : "Campaign inventory can appear on eligible home/desktop ad surfaces.";
    }
    if (button) {
      button.textContent = paused ? "Resume ads" : "Pause ads";
      button.dataset.paused = paused ? "true" : "false";
    }
  }

  async function refreshFounderExtras() {
    if (!isFounder() || !app()?.api || !$("#v49OwnerModal")) return;
    ensureFounderExtras();
    try {
      const data = await app().api("owner_dashboard", {
        showLoader: false,
        timeoutMs: 8000,
      });
      renderFounderDashboard(data?.dashboard || {});
    } catch {}
    loadFounderAudit();
  }

  async function toggleGlobalAds() {
    if (!isFounder()) return;
    const button = $("#v50AdsPauseBtn");
    const paused = button?.dataset.paused === "true";
    if (button) button.disabled = true;
    try {
      const data = await app().api("owner_ads_pause_set", {
        method: "POST",
        body: { paused: !paused },
        showLoader: false,
      });
      toast(!paused ? "Global campaign ads paused." : "Global campaign ads resumed.");
      await refreshFounderExtras();
    } catch (error) {
      toast(error?.message || "Could not update ad serving.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function renderFounderUser(user) {
    const box = $("#v50FounderUserResult");
    if (!box) return;
    box.classList.remove("hidden");
    box.replaceChildren();

    const heading = document.createElement("div");
    heading.className = "v50-founder-user-heading";
    const strong = document.createElement("strong");
    strong.textContent = String(user.display_name || user.username || "User");
    const handle = document.createElement("span");
    handle.textContent = `@${String(user.username || "")}`;
    heading.append(strong, handle);

    const grid = document.createElement("div");
    grid.className = "v50-founder-user-grid";
    const fields = [
      ["Role", user.account_role || "member"],
      ["Last seen", formatDate(user.last_seen_at)],
      ["Joined", formatDate(user.created_at)],
      ["Friends", formatInteger(user.friends)],
      ["Chats", formatInteger(user.conversations)],
      ["Messages / 24h", formatInteger(user.messages_24h)],
      ["Ad-free until", Number(user.ad_pass_until || 0) > Math.floor(Date.now() / 1000)
        ? formatDate(user.ad_pass_until)
        : "No active pass"],
      ["Subscription", user.subscription_status || "inactive"],
    ];
    for (const [label, value] of fields) {
      grid.appendChild(founderMetric(label, value));
    }
    box.append(heading, grid);
    box.dataset.username = String(user.username || "");
  }

  async function lookupFounderUser(event) {
    event.preventDefault();
    if (!isFounder()) return;
    const input = $("#v50FounderUsername");
    const username = String(input?.value || "").trim();
    if (!username) {
      toast("Enter a username.");
      return;
    }
    try {
      const data = await app().api(
        "owner_user_lookup",
        { showLoader: false, timeoutMs: 7000 },
        { username }
      );
      renderFounderUser(data?.user || {});
    } catch (error) {
      $("#v50FounderUserResult")?.classList.add("hidden");
      toast(error?.message || "Could not find that user.");
    }
  }

  async function grantFounderAdFree() {
    if (!isFounder()) return;
    const username = String(
      $("#v50FounderUserResult")?.dataset.username ||
      $("#v50FounderUsername")?.value ||
      ""
    ).trim();
    const hours = Math.min(720, Math.max(1, Number($("#v50FounderGrantHours")?.value || 24)));
    if (!username) {
      toast("Look up a user first.");
      return;
    }
    const button = $("#v50FounderGrantBtn");
    if (button) button.disabled = true;
    try {
      const data = await app().api("owner_ad_free_grant", {
        method: "POST",
        body: { username, hours },
        showLoader: false,
      });
      toast(`Ad-free access granted to @${String(data?.username || username)}.`);
      $("#v50FounderUsername").value = username;
      await lookupFounderUser({ preventDefault() {} });
      await loadFounderAudit();
    } catch (error) {
      toast(error?.message || "Could not grant ad-free access.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function auditLabel(action) {
    const labels = {
      "announcement.publish": "Published announcement",
      "announcement.clear": "Cleared announcement",
      "registration.open": "Opened registration",
      "registration.pause": "Paused registration",
      "security.revoke_sessions": "Revoked sessions",
      "ads.pause": "Paused campaign ads",
      "ads.resume": "Resumed campaign ads",
      "ads.grant_pass": "Granted ad-free access",
      "ads.sales_pause": "Paused new ad campaign sales",
      "ads.sales_resume": "Resumed new ad campaign sales",
      "security.protection_enable": "Enabled traffic protection",
      "security.protection_disable": "Disabled traffic protection",
    };
    return labels[action] || String(action || "Founder action").replace(/[._:-]+/g, " ");
  }

  async function loadFounderAudit() {
    if (!isFounder() || !app()?.api) return;
    const list = $("#v50FounderAudit");
    if (!list) return;
    try {
      const data = await app().api("owner_audit", {
        showLoader: false,
        timeoutMs: 7000,
      });
      const items = Array.isArray(data?.audit) ? data.audit : [];
      list.replaceChildren();
      if (!items.length) {
        const empty = document.createElement("small");
        empty.textContent = "No Founder actions have been recorded yet.";
        list.appendChild(empty);
        return;
      }
      for (const item of items.slice(0, 40)) {
        const row = document.createElement("div");
        row.className = "v50-audit-row";
        const copy = document.createElement("div");
        const strong = document.createElement("strong");
        strong.textContent = auditLabel(item.action);
        const target = document.createElement("small");
        target.textContent = item.target ? String(item.target) : "SilkNex";
        copy.append(strong, target);
        const time = document.createElement("time");
        time.textContent = formatDate(item.created_at);
        row.append(copy, time);
        list.appendChild(row);
      }
    } catch (error) {
      list.textContent = error?.message || "Could not load the audit log.";
    }
  }

  function scheduleFounderRefresh() {
    clearTimeout(runtime.ownerRefreshTimer);
    runtime.ownerRefreshTimer = null;
    if (!runtime.founder) return;
    runtime.ownerRefreshTimer = setTimeout(async () => {
      if (
        document.visibilityState === "visible" &&
        !$("#v49OwnerModal")?.classList.contains("hidden")
      ) {
        await refreshFounderExtras();
      }
      scheduleFounderRefresh();
    }, 60000);
  }

  /* ------------------------------------------------------------------ */
  /* Wiring                                                              */
  /* ------------------------------------------------------------------ */

  function setSignedIn(value) {
    runtime.signedIn = Boolean(value);
    runtime.founder = runtime.signedIn && isFounder();

    if (runtime.signedIn) {
      ensureGeneralTools();
      ensureReminderModal();
      ensureReminderPicker();
      bindReminderObserver();
      scheduleReminderRefresh(1500);
      if (runtime.founder) {
        setTimeout(() => {
          ensureFounderExtras();
          scheduleFounderRefresh();
        }, 50);
      }
    } else {
      clearTimeout(runtime.reminderTimer);
      runtime.reminderTimer = null;
      clearTimeout(runtime.ownerRefreshTimer);
      runtime.ownerRefreshTimer = null;
      runtime.reminderIds.clear();
    }
  }

  function boot() {
    ensureConnectivityChip();
    updateConnectivity();
    ensureReminderModal();
    ensureReminderPicker();
    ensureGeneralTools();
    bindReminderObserver();

    setSignedIn(Boolean(app()?.state?.me));

    window.addEventListener("online", updateConnectivity);
    window.addEventListener("offline", updateConnectivity);

    window.addEventListener("silknex:session", (event) => {
      setTimeout(() => setSignedIn(Boolean(event.detail?.signedIn)), 0);
    });

    window.addEventListener("silknex:conversation", () => {
      setTimeout(() => {
        decorateReminderButtons();
        updateChatOrganizationButtons();
      }, 0);
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible" && runtime.signedIn) {
        scheduleReminderRefresh(800);
      }
    });

    // v49 creates its Founder modal lazily when authenticated. Observe only
    // direct body additions so this does not become a hot full-document observer.
    const bodyObserver = new MutationObserver((records) => {
      if (!runtime.founder) return;
      for (const record of records) {
        if ([...record.addedNodes].some((node) =>
          node instanceof Element &&
          (node.id === "v49OwnerModal" || node.querySelector?.("#v49OwnerModal"))
        )) {
          ensureFounderExtras();
          break;
        }
      }
    });
    bodyObserver.observe(document.body, { childList: true });
  }

  function start() {
    if (window.SilknexApp) boot();
    else window.addEventListener("silknex:core-ready", boot, { once: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }

  window.SilknexV50 = Object.freeze({
    openReminders,
    exportCurrentChat,
    refreshFounderExtras,
  });
})();
