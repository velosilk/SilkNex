(() => {
  'use strict';
  let current = null;
  let polling = false;
  const $ = (s) => document.querySelector(s);
  function roleCanCancel() {
    return ['founder_ceo', 'cofounder_ceo'].includes(window.SilknexApp?.state?.me?.role);
  }
  function ensurePanel() {
    let panel = $('#snAccessBlock');
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = 'snAccessBlock';
    panel.hidden = true;
    panel.setAttribute('role', 'alertdialog');
    panel.setAttribute('aria-modal', 'true');
    panel.setAttribute('aria-labelledby', 'snAccessBlockTitle');
    panel.innerHTML = '<div class="sn-access-card"><h1 id="snAccessBlockTitle">SilkNex is temporarily closed</h1><p id="snAccessBlockMessage"></p><p id="snAccessBlockEnds"></p><button id="snAccessBlockCancel" type="button" hidden>Cancel this block</button><button id="snAccessBlockSwitch" type="button" hidden>Switch to CEO account</button></div>';
    document.body.append(panel);
    $('#snAccessBlockCancel').addEventListener('click', async (event) => {
      const button = event.currentTarget;
      if (!current || !roleCanCancel()) return;
      button.disabled = true;
      try {
        await window.SilknexApp.api('owner_access_block_delete', {
          method: 'POST', body: { id: Number(current.id) }, showLoader: false
        });
        await refresh();
      } catch (error) {
        $('#snAccessBlockMessage').textContent = error?.message || 'Could not cancel the block.';
      } finally { button.disabled = false; }
    });
    $('#snAccessBlockSwitch').addEventListener('click', async (event) => {
      event.currentTarget.disabled = true;
      try {
        await window.SilknexApp.api('logout', {method: 'POST', body: {}, showLoader: false});
        window.location.reload();
      } catch (error) {
        $('#snAccessBlockMessage').textContent = error?.message || 'Could not sign out.';
        event.currentTarget.disabled = false;
      }
    });
    return panel;
  }
  function render(block) {
    const newlyBlocked = Boolean(block) && !current;
    current = block || null;
    const panel = ensurePanel();
    panel.hidden = !current;
    document.documentElement.classList.toggle('sn-access-blocked', Boolean(current));
    if (!current) return;
    if (newlyBlocked) {
      window.SilknexCommunity?.leaveRoom?.();
      window.SilknexApp?.endCall?.();
      document.querySelectorAll('audio, video').forEach(media => { try { media.pause(); } catch {} });
    }
    $('#snAccessBlockMessage').textContent = current.note || 'Access will resume when the scheduled block ends.';
    $('#snAccessBlockEnds').textContent = 'Scheduled to reopen: ' + new Date(Number(current.ends_at) * 1000).toLocaleString();
    $('#snAccessBlockCancel').hidden = !roleCanCancel();
    $('#snAccessBlockSwitch').hidden = !window.SilknexApp?.state?.me || roleCanCancel();
    panel.focus?.();
  }
  async function refresh() {
    if (polling) return;
    polling = true;
    try {
      const response = await fetch('api.php?action=access_block_status', {credentials: 'same-origin', cache: 'no-store'});
      if (!response.ok) return;
      const data = await response.json();
      render(data.active || null);
    } catch {} finally { polling = false; }
  }
  window.SilknexAccessBlock = Object.freeze({refresh, render});
  document.addEventListener('DOMContentLoaded', () => {
    ensurePanel();
    refresh();
    setInterval(refresh, 15000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
    window.addEventListener('silknex:session', refresh);
  });
})();
