(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const runtime = {
    signedIn: false,
    founder: false,
    conversationObserver: null,
    ownerObserver: null,
    ownerRefreshTimer: null,
    ownerDashboard: null,
    ownerTimeseries: [],
    starredIds: new Set(),
    starConversationId: 0,
    messageObserver: null,
  };

  function toast(message) {
    app()?.toast?.(String(message || ""));
  }

  function isFounder() {
    return Boolean(
      runtime.signedIn &&
      app()?.state?.me?.role === "founder_ceo"
    );
  }

  function activeConversationItem() {
    const id = Number(app()?.state?.activeId || 0);
    return app()?.state?.conversations?.find?.(
      (item) => Number(item.id) === id
    ) || null;
  }

  function formatTime(epochSeconds) {
    const value = Number(epochSeconds || 0);
    if (!value) return "—";

    try {
      return new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      }).format(new Date(value * 1000));
    } catch {
      return new Date(value * 1000).toLocaleString();
    }
  }

  function formatNumber(value) {
    const number = Number(value || 0);
    try {
      return new Intl.NumberFormat().format(Number.isFinite(number) ? number : 0);
    } catch {
      return String(Number.isFinite(number) ? number : 0);
    }
  }

  function downloadBlob(filename, type, body) {
    const blob = new Blob([body], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.rel = "noopener";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  /* ------------------------------------------------------------------ */
  /* Per-conversation notification mute                                 */
  /* ------------------------------------------------------------------ */

  function ensureMuteModal() {
    if ($("#v51MuteModal")) return;

    const modal = document.createElement("section");
    modal.id = "v51MuteModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v51MuteTitle");
    modal.innerHTML = `
      <div class="modal-card v51-mute-card">
        <header class="modal-head">
          <div>
            <small>NOTIFICATIONS</small>
            <h2 id="v51MuteTitle">Mute this chat</h2>
          </div>
          <button id="v51MuteClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <p id="v51MuteCopy" class="v51-muted-copy">
          Message notifications will be silenced. Incoming call alerts still work.
        </p>
        <div class="v51-mute-grid">
          <button type="button" data-v51-mute="3600">1 hour</button>
          <button type="button" data-v51-mute="28800">8 hours</button>
          <button type="button" data-v51-mute="86400">1 day</button>
          <button type="button" data-v51-mute="604800">1 week</button>
          <button type="button" data-v51-mute="2592000">30 days</button>
          <button type="button" data-v51-mute="-1">Until I turn it off</button>
        </div>
        <button id="v51UnmuteBtn" class="secondary-btn v51-unmute-btn hidden" type="button">
          Turn notifications back on
        </button>
      </div>
    `;
    document.body.appendChild(modal);

    $("#v51MuteClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
    $$("#v51MuteModal [data-v51-mute]").forEach((button) => {
      button.addEventListener("click", () => {
        setConversationMute(
          Number(app()?.state?.activeId || 0),
          Number(button.dataset.v51Mute || 0)
        );
      });
    });
    $("#v51UnmuteBtn", modal)?.addEventListener("click", () => {
      setConversationMute(Number(app()?.state?.activeId || 0), 0);
    });
  }

  function updateMuteUi() {
    const item = activeConversationItem();
    const mutedUntil = Number(item?.muted_until || 0);
    const muted = Boolean(item?.muted && mutedUntil > Math.floor(Date.now() / 1000));

    const button = $("#v51MuteChatBtn");
    if (button) {
      button.textContent = muted ? "Unmute notifications" : "Mute notifications";
      button.classList.toggle("active", muted);
      button.setAttribute("aria-pressed", muted ? "true" : "false");
    }

    const unmute = $("#v51UnmuteBtn");
    unmute?.classList.toggle("hidden", !muted);

    const copy = $("#v51MuteCopy");
    if (copy) {
      copy.textContent = muted
        ? `Muted until ${formatTime(mutedUntil)}. Incoming call alerts still work.`
        : "Message notifications will be silenced. Incoming call alerts still work.";
    }
  }

  function openMuteModal() {
    const item = activeConversationItem();
    if (!item) {
      toast("Open a chat first.");
      return;
    }
    ensureMuteModal();
    updateMuteUi();
    app()?.openModal?.("#v51MuteModal");
  }

  async function setConversationMute(conversationId, durationSeconds) {
    const id = Number(conversationId || 0);
    if (!id || !app()?.api) return;

    const allowed = new Set([0, 3600, 28800, 86400, 604800, 2592000, -1]);
    if (!allowed.has(Number(durationSeconds))) return;

    try {
      const data = await app().api("conversation_mute", {
        method: "POST",
        body: {
          conversation_id: id,
          duration_seconds: Number(durationSeconds),
        },
        showLoader: false,
      });

      const item = app()?.state?.conversations?.find?.(
        (conversation) => Number(conversation.id) === id
      );
      if (item) {
        item.muted = Boolean(data?.muted);
        item.muted_until = data?.muted_until ? Number(data.muted_until) : null;
      }

      app()?.closeModal?.();
      await app()?.loadConversations?.();
      decorateMutedConversations();
      updateMuteUi();
      toast(data?.muted ? "Message notifications muted." : "Notifications turned back on.");
    } catch (error) {
      toast(error?.message || "Could not change notification settings.");
    }
  }

  function decorateMutedConversations() {
    const now = Math.floor(Date.now() / 1000);
    const conversations = new Map(
      (app()?.state?.conversations || []).map(
        (item) => [Number(item.id), item]
      )
    );

    $$("#conversationList [data-conversation-id]").forEach((button) => {
      const id = Number(button.dataset.conversationId || 0);
      const item = conversations.get(id);
      const muted = Boolean(
        item?.muted &&
        Number(item?.muted_until || 0) > now
      );

      button.closest(".conversation-wrap")?.classList.toggle("v51-muted", muted);
      button.classList.toggle("v51-muted", muted);

      const name = $(".conversation-name", button);
      if (!name) return;

      let mark = $(".v51-mute-mark", name);
      if (!muted) {
        mark?.remove();
        return;
      }

      if (!mark) {
        mark = document.createElement("span");
        mark.className = "v51-mute-mark";
        mark.textContent = "Muted";
        mark.title = "Message notifications muted";
        name.appendChild(mark);
      }
    });
  }

  function bindConversationObserver() {
    const list = $("#conversationList");
    if (!list || runtime.conversationObserver) return;

    runtime.conversationObserver = new MutationObserver(() => {
      requestAnimationFrame(decorateMutedConversations);
    });
    runtime.conversationObserver.observe(list, { childList: true, subtree: true });
    decorateMutedConversations();
  }

  /* ------------------------------------------------------------------ */
  /* Quick replies                                                      */
  /* ------------------------------------------------------------------ */

  function quickReplyStorageKey() {
    const userId = Number(app()?.state?.me?.id || 0);
    return userId ? `silknex:v51:quick-replies:${userId}` : "";
  }

  function loadQuickReplies() {
    const key = quickReplyStorageKey();
    if (!key) return [];

    try {
      const parsed = JSON.parse(localStorage.getItem(key) || "[]");
      if (!Array.isArray(parsed)) return [];
      return parsed
        .map((item) => String(item || "").trim().slice(0, 300))
        .filter(Boolean)
        .slice(0, 12);
    } catch {
      return [];
    }
  }

  function saveQuickReplies(items) {
    const key = quickReplyStorageKey();
    if (!key) return;

    const clean = [...new Set(
      items
        .map((item) => String(item || "").trim().slice(0, 300))
        .filter(Boolean)
    )].slice(0, 12);

    try {
      localStorage.setItem(key, JSON.stringify(clean));
    } catch {
      toast("Quick replies could not be saved on this device.");
    }
  }

  function ensureQuickReplyModal() {
    if ($("#v51QuickReplyModal")) return;

    const modal = document.createElement("section");
    modal.id = "v51QuickReplyModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v51QuickReplyTitle");
    modal.innerHTML = `
      <div class="modal-card v51-quick-card">
        <header class="modal-head">
          <div>
            <small>COMPOSER</small>
            <h2 id="v51QuickReplyTitle">Quick replies</h2>
          </div>
          <button id="v51QuickReplyClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <p class="v51-muted-copy">
          Save up to 12 reusable replies on this device. They are never sent until you press Send.
        </p>
        <form id="v51QuickReplyForm" class="v51-quick-form">
          <label class="field">
            <span>New quick reply</span>
            <textarea id="v51QuickReplyInput" rows="2" maxlength="300" placeholder="Type a reusable reply"></textarea>
          </label>
          <button class="primary" type="submit">Add</button>
        </form>
        <div id="v51QuickReplyList" class="v51-quick-list" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(modal);

    $("#v51QuickReplyClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
    $("#v51QuickReplyForm", modal)?.addEventListener("submit", (event) => {
      event.preventDefault();
      const input = $("#v51QuickReplyInput", modal);
      const value = String(input?.value || "").trim();
      if (!value) return;

      const items = loadQuickReplies();
      if (items.length >= 12) {
        toast("Quick replies are full. Remove one before adding another.");
        return;
      }

      items.unshift(value);
      saveQuickReplies(items);
      if (input) input.value = "";
      renderQuickReplies();
    });
  }

  function insertQuickReply(text) {
    const input = $("#messageInput");
    if (!input || !app()?.state?.activeId) {
      toast("Open a chat before using a quick reply.");
      return;
    }

    const value = String(text || "").trim();
    if (!value) return;

    const start = Number.isFinite(input.selectionStart)
      ? input.selectionStart
      : input.value.length;
    const end = Number.isFinite(input.selectionEnd)
      ? input.selectionEnd
      : start;
    const prefix = start > 0 && !/\s$/.test(input.value.slice(0, start)) ? " " : "";
    const suffix = end < input.value.length && !/^\s/.test(input.value.slice(end)) ? " " : "";

    input.setRangeText(`${prefix}${value}${suffix}`, start, end, "end");
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.focus({ preventScroll: true });
    app()?.closeModal?.();
  }

  function renderQuickReplies() {
    const list = $("#v51QuickReplyList");
    if (!list) return;

    const items = loadQuickReplies();
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "v51-quick-empty";
      empty.textContent = "No quick replies yet.";
      list.appendChild(empty);
      return;
    }

    items.forEach((text, index) => {
      const row = document.createElement("div");
      row.className = "v51-quick-row";

      const copy = document.createElement("p");
      copy.textContent = text;

      const actions = document.createElement("div");
      actions.className = "v51-quick-actions";

      const use = document.createElement("button");
      use.type = "button";
      use.className = "primary compact";
      use.textContent = "Use";
      use.addEventListener("click", () => insertQuickReply(text));

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "secondary-btn compact";
      remove.textContent = "Delete";
      remove.addEventListener("click", () => {
        const next = loadQuickReplies();
        next.splice(index, 1);
        saveQuickReplies(next);
        renderQuickReplies();
      });

      actions.append(use, remove);
      row.append(copy, actions);
      list.appendChild(row);
    });
  }

  function openQuickReplies() {
    ensureQuickReplyModal();
    renderQuickReplies();
    app()?.openModal?.("#v51QuickReplyModal");
  }

  /* ------------------------------------------------------------------ */
  /* Personal starred messages                                         */
  /* ------------------------------------------------------------------ */

  function messageFallback(item) {
    return {
      image: "Photo",
      gif: "GIF",
      video: "Video",
      audio: "Voice message",
      video_note: "Video message",
      sticker: "Sticker",
    }[String(item?.message_type || "text")] || "Encrypted message";
  }

  async function starredPreview(item) {
    const loaded = app()?.state?.messages?.get?.(Number(item?.message_id || 0));
    if (loaded && String(loaded.body || "").trim()) {
      return String(loaded.body).trim();
    }

    const serverPreview = String(item?.preview || "").trim();
    if (serverPreview) return serverPreview;
    if (!item?.e2ee_payload) return messageFallback(item);

    try {
      const decrypted = await window.SilknexE2EE?.decryptMessage?.({
        id: Number(item.message_id || 0),
        conversation_id: Number(item.conversation_id || 0),
        sender_id: Number(item.sender_id || 0),
        e2ee_payload: String(item.e2ee_payload || ""),
        message_type: String(item.message_type || "text"),
        body: "",
      });
      return String(decrypted?.body || "").trim() || messageFallback(item);
    } catch {
      return messageFallback(item);
    }
  }

  function ensureStarredModal() {
    if ($("#v51StarredModal")) return;

    const modal = document.createElement("section");
    modal.id = "v51StarredModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v51StarredTitle");
    modal.innerHTML = `
      <div class="modal-card v51-starred-card">
        <header class="modal-head">
          <div>
            <small>PERSONAL</small>
            <h2 id="v51StarredTitle">Starred messages</h2>
          </div>
          <button id="v51StarredClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <p class="v51-muted-copy">Stars are private to your account and sync across your SilkNex devices.</p>
        <div id="v51StarredList" class="v51-starred-list" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(modal);
    $("#v51StarredClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
  }

  async function renderStarredMessages(items) {
    ensureStarredModal();
    const list = $("#v51StarredList");
    if (!list) return;
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "v51-starred-empty";
      empty.textContent = "Star a message from its message actions and it will appear here.";
      list.appendChild(empty);
      return;
    }

    for (const item of items) {
      const row = document.createElement("article");
      row.className = "v51-starred-row";

      const body = document.createElement("button");
      body.type = "button";
      body.className = "v51-starred-open";

      const meta = document.createElement("div");
      meta.className = "v51-starred-meta";
      const sender = document.createElement("strong");
      sender.textContent = String(item.sender_display_name || "SilkNex user");
      const time = document.createElement("small");
      time.textContent = formatTime(item.created_at);
      meta.append(sender, time);

      const preview = document.createElement("p");
      preview.textContent = (await starredPreview(item)).slice(0, 500);
      body.append(meta, preview);

      body.addEventListener("click", async () => {
        app()?.closeModal?.();
        await app()?.openConversation?.(Number(item.conversation_id || 0));
        setTimeout(() => {
          const message = document.querySelector(
            `#messages .message[data-message-id="${Number(item.message_id || 0)}"]`
          );
          message?.scrollIntoView?.({ block: "center", behavior: "smooth" });
          message?.classList.add("v51-star-highlight");
          setTimeout(() => message?.classList.remove("v51-star-highlight"), 1600);
        }, 350);
      });

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "plain-btn v51-starred-remove";
      remove.textContent = "Unstar";
      remove.addEventListener("click", async () => {
        await toggleStar(
          Number(item.message_id || 0),
          Number(item.conversation_id || 0),
          remove
        );
        await openStarredMessages({ reopen: false });
      });

      row.append(body, remove);
      list.appendChild(row);
    }
  }

  async function refreshStars({ render = false, all = false } = {}) {
    if (!runtime.signedIn || !app()?.api) return [];

    const cid = all ? 0 : Number(app()?.state?.activeId || 0);
    if (!all && !cid) {
      runtime.starConversationId = 0;
      runtime.starredIds.clear();
      updateStarButtons();
      if (render) await renderStarredMessages([]);
      return [];
    }

    try {
      const query = cid > 0 ? { conversation_id: cid } : {};
      const data = await app().api(
        "message_stars",
        { showLoader: false, timeoutMs: 7000 },
        query
      );
      const items = Array.isArray(data?.stars) ? data.stars : [];

      if (!all && cid === Number(app()?.state?.activeId || 0)) {
        runtime.starConversationId = cid;
        runtime.starredIds = new Set(
          items.map((item) => Number(item.message_id || 0)).filter(Boolean)
        );
        updateStarButtons();
      }

      if (render) await renderStarredMessages(items);
      return items;
    } catch (error) {
      if (render) {
        ensureStarredModal();
        const list = $("#v51StarredList");
        if (list) list.textContent = error?.message || "Could not load starred messages.";
      }
      return [];
    }
  }

  async function toggleStar(messageId, conversationId, button) {
    const id = Number(messageId || 0);
    const cid = Number(conversationId || app()?.state?.activeId || 0);
    if (!id || !cid || !app()?.api || button?.disabled) return;

    if (button) button.disabled = true;
    try {
      const data = await app().api("message_star_toggle", {
        method: "POST",
        body: {
          conversation_id: cid,
          message_id: id,
        },
        showLoader: false,
      });

      if (cid === Number(app()?.state?.activeId || 0)) {
        if (data?.starred) runtime.starredIds.add(id);
        else runtime.starredIds.delete(id);
        runtime.starConversationId = cid;
        updateStarButtons();
      }
      toast(data?.starred ? "Message starred." : "Message unstarred.");
    } catch (error) {
      toast(error?.message || "Could not update the star.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function starButtonFor(messageId) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "message-action icon-action v51-star-action";
    button.dataset.starMessageId = String(messageId);
    button.title = "Star message";
    button.setAttribute("aria-label", "Star message");
    button.textContent = "☆";
    button.addEventListener("click", () => {
      toggleStar(messageId, Number(app()?.state?.activeId || 0), button);
    });
    return button;
  }

  function updateStarButtons() {
    const activeId = Number(app()?.state?.activeId || 0);
    $$("[data-star-message-id]").forEach((button) => {
      const id = Number(button.dataset.starMessageId || 0);
      const starred =
        runtime.starConversationId === activeId &&
        runtime.starredIds.has(id);
      button.classList.toggle("selected", starred);
      button.textContent = starred ? "★" : "☆";
      button.title = starred ? "Unstar message" : "Star message";
      button.setAttribute("aria-label", starred ? "Unstar message" : "Star message");
      button.setAttribute("aria-pressed", starred ? "true" : "false");
    });
  }

  function decorateStarActions() {
    $$("#messages .message[data-message-id]").forEach((row) => {
      const id = Number(row.dataset.messageId || 0);
      if (!id) return;
      const actions = $(".message-actions", row);
      if (!actions || $(".v51-star-action", actions)) return;
      actions.appendChild(starButtonFor(id));
    });
    updateStarButtons();
  }

  function bindMessageObserver() {
    const messages = $("#messages");
    if (!messages || runtime.messageObserver) return;

    let queued = false;
    runtime.messageObserver = new MutationObserver(() => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => {
        queued = false;
        decorateStarActions();
      });
    });
    runtime.messageObserver.observe(messages, { childList: true, subtree: true });
    decorateStarActions();
  }

  async function openStarredMessages({ reopen = true } = {}) {
    ensureStarredModal();
    if (reopen) app()?.openModal?.("#v51StarredModal");
    const list = $("#v51StarredList");
    if (list) list.textContent = "Loading starred messages…";
    await refreshStars({ render: true, all: true });
  }

  /* ------------------------------------------------------------------ */
  /* General UI                                                         */
  /* ------------------------------------------------------------------ */

  function ensureGeneralUi() {
    ensureMuteModal();
    ensureQuickReplyModal();
    ensureStarredModal();

    const organize = $("#v50ChatTools .v50-organize-grid");
    if (organize && !$("#v51MuteChatBtn")) {
      const button = document.createElement("button");
      button.id = "v51MuteChatBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Mute notifications";
      button.addEventListener("click", () => {
        const item = activeConversationItem();
        const muted = Boolean(
          item?.muted &&
          Number(item?.muted_until || 0) > Math.floor(Date.now() / 1000)
        );
        if (muted) setConversationMute(item.id, 0);
        else openMuteModal();
      });
      organize.appendChild(button);
    }

    const tools = $("#v50ChatTools .v50-tool-grid");
    if (tools && !$("#v51QuickRepliesBtn")) {
      const button = document.createElement("button");
      button.id = "v51QuickRepliesBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Quick replies";
      button.addEventListener("click", openQuickReplies);
      tools.appendChild(button);
    }

    if (tools && !$("#v51StarredMessagesBtn")) {
      const button = document.createElement("button");
      button.id = "v51StarredMessagesBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Starred messages";
      button.addEventListener("click", () => openStarredMessages());
      tools.appendChild(button);
    }

    const productivity = $("#v50ProductivitySettings .v50-setting-actions");
    if (productivity && !$("#v51QuickRepliesSettingsBtn")) {
      const button = document.createElement("button");
      button.id = "v51QuickRepliesSettingsBtn";
      button.className = "secondary-btn";
      button.type = "button";
      button.textContent = "Manage quick replies";
      button.addEventListener("click", openQuickReplies);
      productivity.appendChild(button);
    }

    updateMuteUi();
    bindConversationObserver();
    bindMessageObserver();
    decorateStarActions();
  }

  /* ------------------------------------------------------------------ */
  /* Founder / CEO operations                                           */
  /* ------------------------------------------------------------------ */

  function ensureFounderOps() {
    if (!isFounder()) return;

    const card = $("#v49OwnerModal .v49-owner-card");
    if (!card || $("#v51FounderOps", card)) return;

    const section = document.createElement("section");
    section.id = "v51FounderOps";
    section.className = "v51-founder-ops";
    section.innerHTML = `
      <section class="v49-owner-block">
        <div class="section-title"><span>Founder traffic shield</span></div>
        <div class="v51-founder-grid">
          <div class="v51-founder-control">
            <div>
              <strong>Protection mode</strong>
              <small>Temporarily lowers per-account send burst limits during abuse or traffic spikes.</small>
            </div>
            <button id="v51ProtectionBtn" class="secondary-btn" type="button">Loading…</button>
          </div>
          <div class="v51-founder-control">
            <div>
              <strong>New ad campaign sales</strong>
              <small>Pause new $5/day campaign checkouts without stopping campaigns that are already paid and active.</small>
            </div>
            <button id="v51AdSalesBtn" class="secondary-btn" type="button">Loading…</button>
          </div>
        </div>
      </section>

      <section class="v49-owner-block">
        <div class="v51-founder-chart-head">
          <div class="section-title"><span>24-hour message activity</span></div>
          <small id="v51FounderChartSummary">Loading…</small>
        </div>
        <div id="v51FounderChart" class="v51-founder-chart" aria-label="Messages per hour for the last 24 hours"></div>
      </section>

      <section class="v49-owner-block">
        <div class="section-title"><span>Founder diagnostics</span></div>
        <div class="v51-diagnostic-row">
          <div>
            <strong>Download operational snapshot</strong>
            <small>Exports aggregate platform health, feature flags, and browser diagnostics. Private message contents are never included.</small>
          </div>
          <button id="v51FounderDiagnosticsBtn" class="secondary-btn" type="button">Download JSON</button>
        </div>
      </section>
    `;

    const extras = $("#v50FounderExtras", card);
    if (extras) extras.insertAdjacentElement("afterend", section);
    else card.appendChild(section);

    $("#v51ProtectionBtn", section)?.addEventListener("click", toggleProtectionMode);
    $("#v51AdSalesBtn", section)?.addEventListener("click", toggleAdSales);
    $("#v51FounderDiagnosticsBtn", section)?.addEventListener("click", downloadFounderDiagnostics);

    refreshFounderOps();
  }

  function renderFounderFlags(dashboard) {
    const flags = dashboard?.feature_flags || {};

    const protection = $("#v51ProtectionBtn");
    if (protection) {
      const enabled = Boolean(flags.protection_mode);
      protection.dataset.enabled = enabled ? "true" : "false";
      protection.textContent = enabled ? "Turn off protection" : "Turn on protection";
      protection.classList.toggle("active", enabled);
    }

    const sales = $("#v51AdSalesBtn");
    if (sales) {
      const paused = Boolean(flags.ad_sales_paused);
      sales.dataset.paused = paused ? "true" : "false";
      sales.textContent = paused ? "Resume ad sales" : "Pause ad sales";
      sales.classList.toggle("active", paused);
    }
  }

  function renderFounderTimeseries(hours) {
    const chart = $("#v51FounderChart");
    if (!chart) return;

    const items = Array.isArray(hours) ? hours.slice(-24) : [];
    chart.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("small");
      empty.textContent = "No activity data is available yet.";
      chart.appendChild(empty);
      return;
    }

    const maxMessages = Math.max(1, ...items.map((item) => Number(item.messages || 0)));
    let totalMessages = 0;
    let peakMessages = 0;

    for (const item of items) {
      const count = Number(item.messages || 0);
      totalMessages += count;
      peakMessages = Math.max(peakMessages, count);

      const column = document.createElement("div");
      column.className = "v51-chart-column";

      const bar = document.createElement("div");
      bar.className = "v51-chart-bar";
      bar.style.setProperty("--v51-bar", `${Math.max(4, Math.round((count / maxMessages) * 100))}%`);
      bar.title = `${formatTime(item.bucket)} · ${formatNumber(count)} messages · ${formatNumber(item.active_senders)} active senders`;

      const label = document.createElement("span");
      const date = new Date(Number(item.bucket || 0) * 1000);
      label.textContent = Number.isFinite(date.getTime())
        ? date.toLocaleTimeString([], { hour: "numeric" })
        : "";

      column.append(bar, label);
      chart.appendChild(column);
    }

    const summary = $("#v51FounderChartSummary");
    if (summary) {
      summary.textContent = `${formatNumber(totalMessages)} messages · peak ${formatNumber(peakMessages)}/hr`;
    }
  }

  async function refreshFounderOps() {
    if (!isFounder() || !app()?.api) return;

    try {
      const [dashboardData, seriesData] = await Promise.all([
        app().api("owner_dashboard", {
          showLoader: false,
          timeoutMs: 8000,
        }),
        app().api("owner_timeseries", {
          showLoader: false,
          timeoutMs: 8000,
        }),
      ]);

      runtime.ownerDashboard = dashboardData?.dashboard || {};
      runtime.ownerTimeseries = Array.isArray(seriesData?.hours) ? seriesData.hours : [];
      renderFounderFlags(runtime.ownerDashboard);
      renderFounderTimeseries(runtime.ownerTimeseries);
    } catch (error) {
      $("#v51FounderChartSummary")?.replaceChildren(
        document.createTextNode(error?.message || "Could not refresh analytics.")
      );
    }
  }

  async function toggleProtectionMode() {
    if (!isFounder()) return;

    const button = $("#v51ProtectionBtn");
    const enabled = button?.dataset.enabled === "true";
    if (button) button.disabled = true;

    try {
      await app().api("owner_protection_set", {
        method: "POST",
        body: { enabled: !enabled },
        showLoader: false,
      });
      toast(!enabled ? "Founder Protection Mode enabled." : "Founder Protection Mode disabled.");
      await refreshFounderOps();
      await window.SilknexV50?.refreshFounderExtras?.();
    } catch (error) {
      toast(error?.message || "Could not change protection mode.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function toggleAdSales() {
    if (!isFounder()) return;

    const button = $("#v51AdSalesBtn");
    const paused = button?.dataset.paused === "true";
    if (button) button.disabled = true;

    try {
      await app().api("owner_ad_sales_set", {
        method: "POST",
        body: { paused: !paused },
        showLoader: false,
      });
      toast(!paused ? "New ad campaign sales paused." : "New ad campaign sales resumed.");
      await refreshFounderOps();
      await window.SilknexV50?.refreshFounderExtras?.();
    } catch (error) {
      toast(error?.message || "Could not change ad sales.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function downloadFounderDiagnostics() {
    if (!isFounder()) return;

    if (!runtime.ownerDashboard || !runtime.ownerTimeseries.length) {
      await refreshFounderOps();
    }

    const payload = {
      generated_at: new Date().toISOString(),
      release: "52.0",
      dashboard: runtime.ownerDashboard || {},
      activity_24h: runtime.ownerTimeseries || [],
      browser: {
        user_agent: navigator.userAgent,
        language: navigator.language,
        online: navigator.onLine,
        visibility: document.visibilityState,
        screen: {
          width: window.screen?.width || 0,
          height: window.screen?.height || 0,
          pixel_ratio: window.devicePixelRatio || 1,
        },
        viewport: {
          width: window.innerWidth,
          height: window.innerHeight,
        },
        service_worker: Boolean(navigator.serviceWorker),
        installed_display_mode: window.matchMedia?.("(display-mode: standalone)")?.matches || false,
      },
    };

    downloadBlob(
      `silknex-founder-diagnostics-${new Date().toISOString().slice(0, 10)}.json`,
      "application/json;charset=utf-8",
      JSON.stringify(payload, null, 2)
    );
    toast("Founder diagnostics downloaded.");
  }

  function scheduleFounderRefresh() {
    clearTimeout(runtime.ownerRefreshTimer);
    runtime.ownerRefreshTimer = null;
    if (!runtime.founder) return;

    runtime.ownerRefreshTimer = setTimeout(async () => {
      if (
        document.visibilityState === "visible" &&
        !$("#v49OwnerModal")?.classList.contains("hidden")
      ) {
        await refreshFounderOps();
      }
      scheduleFounderRefresh();
    }, 60000);
  }

  function bindOwnerObserver() {
    if (runtime.ownerObserver) return;

    runtime.ownerObserver = new MutationObserver((records) => {
      if (!runtime.founder) return;

      for (const record of records) {
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (
            node.id === "v49OwnerModal" ||
            node.matches?.("#v49OwnerModal") ||
            node.querySelector?.("#v49OwnerModal")
          ) {
            ensureFounderOps();
            return;
          }
        }
      }
    });
    runtime.ownerObserver.observe(document.body, { childList: true });
  }

  /* ------------------------------------------------------------------ */
  /* Wiring                                                             */
  /* ------------------------------------------------------------------ */

  function setSignedIn(value) {
    runtime.signedIn = Boolean(value);
    runtime.founder = isFounder();

    if (!runtime.signedIn) {
      clearTimeout(runtime.ownerRefreshTimer);
      runtime.ownerRefreshTimer = null;
      runtime.ownerDashboard = null;
      runtime.ownerTimeseries = [];
      runtime.starConversationId = 0;
      runtime.starredIds.clear();
      updateStarButtons();
      return;
    }

    ensureGeneralUi();
    refreshStars({ render: false, all: false });

    if (runtime.founder) {
      ensureFounderOps();
      bindOwnerObserver();
      scheduleFounderRefresh();
    }
  }

  function boot() {
    setSignedIn(Boolean(app()?.state?.me));

    window.addEventListener("silknex:session", (event) => {
      setTimeout(() => setSignedIn(Boolean(event.detail?.signedIn)), 0);
    });

    window.addEventListener("silknex:conversation", () => {
      setTimeout(() => {
        ensureGeneralUi();
        updateMuteUi();
        decorateMutedConversations();
        refreshStars({ render: false, all: false });
      }, 0);
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        decorateMutedConversations();
      }
    });

    // v50/v49 add parts of Settings after initial app bootstrap.
    const uiObserver = new MutationObserver(() => {
      if (!runtime.signedIn) return;
      ensureGeneralUi();
      if (runtime.founder) ensureFounderOps();
    });
    uiObserver.observe(document.body, { childList: true, subtree: false });
  }

  function start() {
    if (window.SilknexApp) boot();
    else window.addEventListener("silknex:core-ready", boot, { once: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }

  window.SilknexV51 = Object.freeze({
    openQuickReplies,
    openMuteModal,
    setConversationMute,
    openStarredMessages,
    refreshFounderOps,
  });
})();
