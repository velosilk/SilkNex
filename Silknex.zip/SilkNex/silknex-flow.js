
(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;
  const e2ee = () => window.SilknexE2EE || null;

  const flow = {
    conversationId: 0,
    activeTab: "board",
    boardItems: [],
    boardMembers: [],
    boardFilter: "open",
    boardEditingId: 0,
    boardLoading: false,
    canvasRevision: 0,
    canvasStrokes: [],
    canvasDirty: false,
    canvasTool: "draw",
    canvasDrawing: false,
    canvasStroke: null,
    canvasRemoteRevision: 0,
    canvasLoading: false,
    pulseEmoji: "🎯",
    pulses: [],
    pulseTimer: null,
    canvasPollTimer: null,
    boardPollTimer: null,
    quickIndex: 0,
    quickResults: [],
    focusUntil: 0,
    focusTimer: null,
    mounted: false,
  };

  function state() {
    return app()?.state || null;
  }

  function toast(message) {
    app()?.toast?.(message);
  }

  function randomHex(bytes = 10) {
    const data = new Uint8Array(bytes);
    crypto.getRandomValues(data);
    return [...data].map((n) => n.toString(16).padStart(2, "0")).join("");
  }

  function safeInt(value, fallback = 0) {
    const n = Number(value);
    return Number.isFinite(n) ? Math.trunc(n) : fallback;
  }

  function formatRelative(unix) {
    const seconds = Math.max(0, safeInt(unix) - Math.floor(Date.now() / 1000));
    if (seconds < 60) return "under 1m";
    if (seconds < 3600) return `${Math.ceil(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.ceil(seconds / 3600)}h`;
    return `${Math.ceil(seconds / 86400)}d`;
  }

  function formatDue(unix) {
    if (!unix) return "";
    const date = new Date(Number(unix) * 1000);
    if (Number.isNaN(date.getTime())) return "";
    return new Intl.DateTimeFormat(undefined, {
      month: "short",
      day: "numeric",
      ...(date.getFullYear() !== new Date().getFullYear() ? { year: "numeric" } : {}),
      hour: "numeric",
      minute: "2-digit",
    }).format(date);
  }

  function localDateTimeValue(unix) {
    if (!unix) return "";
    const d = new Date(Number(unix) * 1000);
    if (Number.isNaN(d.getTime())) return "";
    const pad = (v) => String(v).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  async function concurrentMap(items, limit, mapper) {
    const results = new Array(items.length);
    let next = 0;

    async function worker() {
      while (true) {
        const index = next++;
        if (index >= items.length) return;
        try {
          results[index] = await mapper(items[index], index);
        } catch (error) {
          results[index] = { error };
        }
      }
    }

    await Promise.all(
      Array.from({ length: Math.min(limit, Math.max(1, items.length)) }, () => worker())
    );
    return results;
  }

  async function encryptFlowPayload(conversationId, type, data) {
    if (!e2ee()?.encryptPayload || !app()?.api) {
      throw new Error("Secure Flow tools are still initializing.");
    }
    const nonce = `flow:${type}:${Date.now().toString(36)}:${randomHex(8)}`;
    return e2ee().encryptPayload(
      app().api,
      conversationId,
      nonce,
      {
        flow_type: type,
        flow_version: 1,
        ...data,
      }
    );
  }

  async function decryptFlowPayload(envelope, conversationId, expectedType) {
    if (!envelope) return null;
    const payload = await e2ee().decryptEnvelope(envelope, conversationId);
    if (!payload || payload.flow_type !== expectedType) {
      throw new Error("Unsupported secure Flow content.");
    }
    return payload;
  }

  function activeConversationId() {
    return safeInt(state()?.activeId);
  }

  function setWorkspaceTitle() {
    const conversation = state()?.activeConversation;
    const heading = $("#flowWorkspaceHeading");
    const subtitle = $("#flowWorkspaceSubtitle");
    if (heading) heading.textContent = conversation?.title
      ? `${conversation.title} · Flow`
      : "Shared workspace";
    if (subtitle) {
      subtitle.textContent =
        "Plan, draw, and share a temporary pulse without leaving the conversation.";
    }
  }

  function openWorkspace(tab = "board") {
    const cid = activeConversationId();
    if (!cid || !state()?.activeConversation) {
      toast("Open a conversation first.");
      return;
    }

    flow.conversationId = cid;
    setWorkspaceTitle();
    selectFlowTab(tab);
    app()?.openModal?.("#flowWorkspaceModal");
  }

  function selectFlowTab(tab) {
    if (!["board", "canvas", "pulse"].includes(tab)) tab = "board";
    flow.activeTab = tab;

    $$(".flow-tab").forEach((button) => {
      const active = button.dataset.flowTab === tab;
      button.classList.toggle("active", active);
      button.setAttribute("aria-selected", active ? "true" : "false");
    });

    $("#flowBoardPanel")?.classList.toggle("hidden", tab !== "board");
    $("#flowCanvasPanel")?.classList.toggle("hidden", tab !== "canvas");
    $("#flowPulsePanel")?.classList.toggle("hidden", tab !== "pulse");

    clearInterval(flow.canvasPollTimer);
    flow.canvasPollTimer = null;
    clearInterval(flow.boardPollTimer);
    flow.boardPollTimer = null;

    if (!flow.conversationId) return;

    if (tab === "board") {
      loadBoard().catch(handleFlowError);
      flow.boardPollTimer = setInterval(() => {
        if (
          document.visibilityState === "visible" &&
          flow.activeTab === "board" &&
          !$("#flowWorkspaceModal")?.classList.contains("hidden")
        ) {
          loadBoard({ quiet: true }).catch(() => {});
        }
      }, 20000);
    } else if (tab === "canvas") {
      loadCanvas({ force: !flow.canvasDirty }).catch(handleFlowError);
      flow.canvasPollTimer = setInterval(() => {
        if (
          document.visibilityState === "visible" &&
          flow.activeTab === "canvas" &&
          !$("#flowWorkspaceModal")?.classList.contains("hidden")
        ) {
          checkCanvasRevision().catch(() => {});
        }
      }, 12000);
    } else {
      loadPulses().catch(handleFlowError);
    }
  }

  function handleFlowError(error) {
    if (error?.name === "AbortError") return;
    toast(error?.message || "Flow could not update.");
  }

  /* ------------------------------------------------------------------ */
  /* SilkBoard                                                           */
  /* ------------------------------------------------------------------ */

  async function decryptBoardItem(item, cid) {
    try {
      const payload = await decryptFlowPayload(item.payload_e2ee, cid, "board");
      return {
        ...item,
        title: String(payload?.title || "").slice(0, 160),
        body: String(payload?.body || "").slice(0, 2000),
        locked: false,
      };
    } catch (error) {
      return {
        ...item,
        title: "Encrypted on another device",
        body: "Open or edit this card from a device that has its encryption key.",
        locked: true,
        decryptError: error?.message || "Unable to decrypt",
      };
    }
  }

  async function loadBoard({ quiet = false } = {}) {
    const cid = flow.conversationId || activeConversationId();
    if (!cid || flow.boardLoading) return;
    flow.boardLoading = true;
    const list = $("#boardList");
    if (!quiet && list) list.setAttribute("aria-busy", "true");

    try {
      const data = await app().api("board_items", { showLoader: false }, {
        conversation_id: cid,
        include_archived: 0,
      });

      if (cid !== (flow.conversationId || activeConversationId())) return;

      flow.boardMembers = Array.isArray(data.members) ? data.members : [];
      const raw = Array.isArray(data.items) ? data.items : [];
      flow.boardItems = await concurrentMap(raw, 6, (item) => decryptBoardItem(item, cid));
      populateBoardAssignees();
      renderBoard();
    } finally {
      flow.boardLoading = false;
      list?.removeAttribute("aria-busy");
    }
  }

  function populateBoardAssignees() {
    const select = $("#boardAssignee");
    if (!select) return;
    const selected = select.value;
    const fragment = document.createDocumentFragment();

    const anyone = document.createElement("option");
    anyone.value = "";
    anyone.textContent = "Anyone";
    fragment.appendChild(anyone);

    for (const member of flow.boardMembers) {
      const option = document.createElement("option");
      option.value = String(member.id || "");
      option.textContent = String(member.display_name || member.username || "Member");
      fragment.appendChild(option);
    }

    select.replaceChildren(fragment);
    if ([...select.options].some((option) => option.value === selected)) {
      select.value = selected;
    }
  }

  function boardVisibleItems() {
    if (flow.boardFilter === "done") {
      return flow.boardItems.filter((item) => item.status === "done");
    }
    if (flow.boardFilter === "all") {
      return flow.boardItems.filter((item) => item.status !== "archived");
    }
    return flow.boardItems.filter((item) => item.status === "open");
  }

  function boardCard(item) {
    const card = document.createElement("article");
    card.className = "board-card";
    card.dataset.status = String(item.status || "open");

    const top = document.createElement("div");
    top.className = "board-card-top";

    const kind = document.createElement("span");
    kind.className = "board-kind";
    kind.textContent = String(item.kind || "note");

    const priority = document.createElement("span");
    priority.className = "board-priority";
    priority.dataset.priority = String(item.priority || "normal");
    priority.textContent = String(item.priority || "normal");

    const menu = document.createElement("div");
    menu.className = "board-card-menu";

    if (!item.locked) {
      const done = document.createElement("button");
      done.type = "button";
      done.title = item.status === "done" ? "Reopen" : "Mark done";
      done.setAttribute("aria-label", done.title);
      done.textContent = item.status === "done" ? "↶" : "✓";
      done.addEventListener("click", () => {
        updateBoardMetadata(item.id, {
          status: item.status === "done" ? "open" : "done",
        }).catch(handleFlowError);
      });

      const edit = document.createElement("button");
      edit.type = "button";
      edit.title = "Edit card";
      edit.setAttribute("aria-label", "Edit card");
      edit.textContent = "✎";
      edit.addEventListener("click", () => editBoardItem(item));

      const archive = document.createElement("button");
      archive.type = "button";
      archive.title = "Archive card";
      archive.setAttribute("aria-label", "Archive card");
      archive.textContent = "–";
      archive.addEventListener("click", () => {
        updateBoardMetadata(item.id, { status: "archived" }).catch(handleFlowError);
      });

      menu.append(done, edit, archive);
    }

    top.append(kind, priority, menu);

    const title = document.createElement("h3");
    title.className = "board-card-title";
    title.textContent = item.title || "Untitled";

    card.append(top, title);

    if (item.body) {
      const body = document.createElement("p");
      body.className = "board-card-body";
      body.textContent = item.body;
      card.appendChild(body);
    }

    const meta = document.createElement("div");
    meta.className = "board-card-meta";

    const creator = document.createElement("span");
    creator.textContent = `By ${item.creator_name || "member"}`;
    meta.appendChild(creator);

    if (item.assignee_name) {
      const assignee = document.createElement("span");
      assignee.textContent = `Assigned ${item.assignee_name}`;
      meta.appendChild(assignee);
    }

    if (item.due_at) {
      const due = document.createElement("span");
      due.textContent = `Due ${formatDue(item.due_at)}`;
      if (Number(item.due_at) < Date.now() / 1000 && item.status !== "done") {
        due.title = "Overdue";
      }
      meta.appendChild(due);
    }

    card.appendChild(meta);
    return card;
  }

  function renderBoard() {
    const list = $("#boardList");
    const empty = $("#boardEmpty");
    if (!list || !empty) return;

    const visible = boardVisibleItems();
    const fragment = document.createDocumentFragment();
    visible.forEach((item) => fragment.appendChild(boardCard(item)));
    list.replaceChildren(fragment);
    empty.classList.toggle("hidden", visible.length > 0);

    $$(".board-filter").forEach((button) => {
      button.classList.toggle("active", button.dataset.boardFilter === flow.boardFilter);
    });
  }

  function resetBoardComposer() {
    flow.boardEditingId = 0;
    $("#boardComposer")?.classList.add("hidden");
    const title = $("#boardTitle");
    const body = $("#boardBody");
    const kind = $("#boardKind");
    const priority = $("#boardPriority");
    const assignee = $("#boardAssignee");
    const due = $("#boardDueAt");
    if (title) title.value = "";
    if (body) body.value = "";
    if (kind) kind.value = "task";
    if (priority) priority.value = "normal";
    if (assignee) assignee.value = "";
    if (due) due.value = "";
    if ($("#boardSaveBtn")) $("#boardSaveBtn").textContent = "Add to board";
  }

  function showBoardComposer() {
    resetBoardComposer();
    $("#boardComposer")?.classList.remove("hidden");
    setTimeout(() => $("#boardTitle")?.focus({ preventScroll: true }), 0);
  }

  function editBoardItem(item) {
    if (!item || item.locked) return;
    flow.boardEditingId = Number(item.id);
    $("#boardComposer")?.classList.remove("hidden");
    $("#boardKind").value = item.kind || "note";
    $("#boardPriority").value = item.priority || "normal";
    $("#boardTitle").value = item.title || "";
    $("#boardBody").value = item.body || "";
    $("#boardAssignee").value = item.assigned_user_id ? String(item.assigned_user_id) : "";
    $("#boardDueAt").value = localDateTimeValue(item.due_at);
    $("#boardSaveBtn").textContent = "Save changes";
    setTimeout(() => $("#boardTitle")?.focus({ preventScroll: true }), 0);
  }

  async function saveBoardComposer() {
    const cid = flow.conversationId;
    if (!cid) return;

    const title = String($("#boardTitle")?.value || "").trim();
    const body = String($("#boardBody")?.value || "").trim();
    const kind = String($("#boardKind")?.value || "note");
    const priority = String($("#boardPriority")?.value || "normal");
    const assignedUserId = safeInt($("#boardAssignee")?.value);
    const dueRaw = String($("#boardDueAt")?.value || "");
    const dueAt = dueRaw ? Math.floor(new Date(dueRaw).getTime() / 1000) : 0;

    if (!title) {
      toast("Give the card a title.");
      $("#boardTitle")?.focus();
      return;
    }
    if (dueRaw && (!Number.isFinite(dueAt) || dueAt <= 0)) {
      toast("Choose a valid due date.");
      return;
    }

    const button = $("#boardSaveBtn");
    if (button) button.disabled = true;

    try {
      const payload = await encryptFlowPayload(cid, "board", { title, body });

      if (flow.boardEditingId) {
        await app().api("board_update", {
          method: "POST",
          body: {
            id: flow.boardEditingId,
            kind,
            priority,
            assigned_user_id: assignedUserId || 0,
            due_at: dueAt || 0,
            payload_e2ee: payload,
          },
          loadingLabel: "Saving secure card…",
        });
        toast("SilkBoard card updated.");
      } else {
        await app().api("board_create", {
          method: "POST",
          body: {
            conversation_id: cid,
            kind,
            priority,
            assigned_user_id: assignedUserId || 0,
            due_at: dueAt || 0,
            payload_e2ee: payload,
          },
          loadingLabel: "Adding secure card…",
        });
        toast("Added to SilkBoard.");
      }

      resetBoardComposer();
      await loadBoard({ quiet: true });
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function updateBoardMetadata(id, fields) {
    await app().api("board_update", {
      method: "POST",
      body: { id, ...fields },
      showLoader: false,
    });

    const item = flow.boardItems.find((entry) => Number(entry.id) === Number(id));
    if (item) Object.assign(item, fields, { updated_at: Math.floor(Date.now() / 1000) });
    renderBoard();
  }

  /* ------------------------------------------------------------------ */
  /* SilkCanvas                                                          */
  /* ------------------------------------------------------------------ */

  function sanitizedStrokes(value) {
    const source = Array.isArray(value) ? value : [];
    const strokes = [];
    let pointCount = 0;

    for (const raw of source.slice(0, 250)) {
      if (!raw || !Array.isArray(raw.points) || raw.points.length < 1) continue;
      const mode = raw.mode === "erase" ? "erase" : "draw";
      const color = /^#[0-9a-f]{6}$/i.test(String(raw.color || ""))
        ? String(raw.color)
        : "#7c6cff";
      const size = Math.max(1, Math.min(40, Number(raw.size) || 5));
      const points = [];

      for (const point of raw.points) {
        if (!Array.isArray(point) || point.length < 2) continue;
        const x = Math.max(0, Math.min(1, Number(point[0]) || 0));
        const y = Math.max(0, Math.min(1, Number(point[1]) || 0));
        points.push([Math.round(x * 10000) / 10000, Math.round(y * 10000) / 10000]);
        pointCount += 1;
        if (pointCount >= 8000) break;
      }

      if (points.length) strokes.push({ mode, color, size, points });
      if (pointCount >= 8000) break;
    }

    return strokes;
  }

  function drawStroke(ctx, stroke, width, height) {
    const points = stroke.points || [];
    if (!points.length) return;

    ctx.save();
    ctx.globalCompositeOperation = stroke.mode === "erase"
      ? "destination-out"
      : "source-over";
    ctx.strokeStyle = stroke.color || "#7c6cff";
    ctx.fillStyle = stroke.color || "#7c6cff";
    ctx.lineWidth = Math.max(1, Number(stroke.size) || 5);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    if (points.length === 1) {
      const [x, y] = points[0];
      ctx.beginPath();
      ctx.arc(x * width, y * height, ctx.lineWidth / 2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.beginPath();
      points.forEach(([x, y], index) => {
        const px = x * width;
        const py = y * height;
        if (index === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      ctx.stroke();
    }

    ctx.restore();
  }

  function renderCanvas() {
    const canvas = $("#silkCanvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const stroke of flow.canvasStrokes) {
      drawStroke(ctx, stroke, canvas.width, canvas.height);
    }
    if (flow.canvasStroke) {
      drawStroke(ctx, flow.canvasStroke, canvas.width, canvas.height);
    }
  }

  function canvasPoint(event) {
    const canvas = $("#silkCanvas");
    const rect = canvas.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (event.clientX - rect.left) / Math.max(1, rect.width)));
    const y = Math.max(0, Math.min(1, (event.clientY - rect.top) / Math.max(1, rect.height)));
    return [Math.round(x * 10000) / 10000, Math.round(y * 10000) / 10000];
  }

  function beginCanvasStroke(event) {
    if (event.button !== undefined && event.button !== 0 && event.pointerType === "mouse") return;
    const canvas = $("#silkCanvas");
    if (!canvas) return;
    event.preventDefault();
    canvas.setPointerCapture?.(event.pointerId);
    flow.canvasDrawing = true;
    flow.canvasStroke = {
      mode: flow.canvasTool,
      color: String($("#canvasColor")?.value || "#7c6cff"),
      size: Math.max(2, Math.min(32, Number($("#canvasSize")?.value || 5))),
      points: [canvasPoint(event)],
    };
    renderCanvas();
  }

  function moveCanvasStroke(event) {
    if (!flow.canvasDrawing || !flow.canvasStroke) return;
    event.preventDefault();
    const point = canvasPoint(event);
    const points = flow.canvasStroke.points;
    const last = points[points.length - 1];

    const dx = point[0] - last[0];
    const dy = point[1] - last[1];
    if ((dx * dx + dy * dy) < 0.000006) return;

    if (points.length < 800) points.push(point);
    renderCanvas();
  }

  function endCanvasStroke(event) {
    if (!flow.canvasDrawing || !flow.canvasStroke) return;
    event?.preventDefault?.();
    const canvas = $("#silkCanvas");
    try { canvas?.releasePointerCapture?.(event.pointerId); } catch {}

    flow.canvasDrawing = false;
    flow.canvasStrokes.push(flow.canvasStroke);
    flow.canvasStroke = null;
    flow.canvasDirty = true;

    if (flow.canvasStrokes.length > 250) {
      flow.canvasStrokes.splice(0, flow.canvasStrokes.length - 250);
    }
    renderCanvas();
    updateCanvasStatus();
  }

  function updateCanvasStatus(message = "") {
    const status = $("#canvasStatus");
    if (!status) return;
    if (message) {
      status.textContent = message;
      return;
    }
    if (flow.canvasDirty) {
      status.textContent = `Unsaved changes · shared revision ${flow.canvasRevision}`;
    } else if (flow.canvasRevision > 0) {
      status.textContent = `Shared revision ${flow.canvasRevision} · up to date`;
    } else {
      status.textContent = "A shared encrypted sketchpad.";
    }
  }

  async function loadCanvas({ force = false } = {}) {
    const cid = flow.conversationId || activeConversationId();
    if (!cid || flow.canvasLoading) return;
    flow.canvasLoading = true;

    try {
      const data = await app().api("canvas_get", { showLoader: false }, {
        conversation_id: cid,
      });
      const canvas = data.canvas || {};
      const revision = safeInt(canvas.revision);

      if (flow.canvasDirty && revision !== flow.canvasRevision && !force) {
        flow.canvasRemoteRevision = revision;
        $("#canvasRemoteNotice")?.classList.remove("hidden");
        updateCanvasStatus(`Shared revision ${revision} is newer than your local sketch.`);
        return;
      }

      let strokes = [];
      if (canvas.payload_e2ee) {
        try {
          const payload = await decryptFlowPayload(canvas.payload_e2ee, cid, "canvas");
          strokes = sanitizedStrokes(payload?.strokes);
        } catch (error) {
          updateCanvasStatus("This canvas was encrypted on another device.");
          toast(error?.message || "Unable to decrypt shared canvas.");
          return;
        }
      }

      flow.canvasRevision = revision;
      flow.canvasRemoteRevision = revision;
      flow.canvasStrokes = strokes;
      flow.canvasDirty = false;
      $("#canvasRemoteNotice")?.classList.add("hidden");
      renderCanvas();
      updateCanvasStatus();
    } finally {
      flow.canvasLoading = false;
    }
  }

  async function checkCanvasRevision() {
    const cid = flow.conversationId;
    if (!cid) return;

    const data = await app().api("canvas_get", { showLoader: false, timeoutMs: 8000 }, {
      conversation_id: cid,
    });
    const revision = safeInt(data.canvas?.revision);

    if (revision <= flow.canvasRevision) return;
    if (flow.canvasDirty) {
      flow.canvasRemoteRevision = revision;
      $("#canvasRemoteNotice")?.classList.remove("hidden");
      return;
    }

    await loadCanvas({ force: true });
  }

  async function saveCanvas() {
    const cid = flow.conversationId;
    if (!cid) return;

    const strokes = sanitizedStrokes(flow.canvasStrokes);
    const pointCount = strokes.reduce((sum, stroke) => sum + stroke.points.length, 0);
    if (pointCount >= 8000) {
      toast("Canvas is full. Undo or clear some drawing before saving.");
      return;
    }

    const button = $("#canvasSaveBtn");
    if (button) button.disabled = true;

    try {
      const payload = await encryptFlowPayload(cid, "canvas", { strokes });
      const data = await app().api("canvas_save", {
        method: "POST",
        body: {
          conversation_id: cid,
          expected_revision: flow.canvasRevision,
          payload_e2ee: payload,
        },
        loadingLabel: "Saving encrypted canvas…",
      });

      flow.canvasRevision = safeInt(data.canvas?.revision, flow.canvasRevision + 1);
      flow.canvasRemoteRevision = flow.canvasRevision;
      flow.canvasStrokes = strokes;
      flow.canvasDirty = false;
      $("#canvasRemoteNotice")?.classList.add("hidden");
      updateCanvasStatus();
      toast("Shared canvas saved.");
    } catch (error) {
      if (Number(error?.status) === 409) {
        flow.canvasRemoteRevision = flow.canvasRevision + 1;
        $("#canvasRemoteNotice")?.classList.remove("hidden");
      }
      throw error;
    } finally {
      if (button) button.disabled = false;
    }
  }

  /* ------------------------------------------------------------------ */
  /* Conversation Pulse                                                  */
  /* ------------------------------------------------------------------ */

  async function decryptPulse(row, cid) {
    try {
      const payload = await decryptFlowPayload(row.payload_e2ee, cid, "pulse");
      return {
        ...row,
        emoji: String(payload?.emoji || "◉").slice(0, 8),
        label: String(payload?.label || "").slice(0, 80),
        locked: false,
      };
    } catch {
      return {
        ...row,
        emoji: "🔒",
        label: "Encrypted on another device",
        locked: true,
      };
    }
  }

  async function loadPulses({ stripOnly = false } = {}) {
    const cid = stripOnly ? activeConversationId() : (flow.conversationId || activeConversationId());
    if (!cid) {
      renderPulseStrip([]);
      return;
    }

    const data = await app().api("pulse_list", { showLoader: false, timeoutMs: 8000 }, {
      conversation_id: cid,
    });
    const rows = Array.isArray(data.pulses) ? data.pulses : [];
    const pulses = await concurrentMap(rows, 5, (row) => decryptPulse(row, cid));

    if (cid === activeConversationId()) {
      renderPulseStrip(pulses);
      schedulePulseRefresh(pulses, cid);
    }

    if (!stripOnly && cid === flow.conversationId) {
      flow.pulses = pulses;
      renderPulseList();
    }
  }

  function schedulePulseRefresh(pulses, conversationId) {
    clearTimeout(flow.pulseTimer);
    flow.pulseTimer = null;

    const now = Math.floor(Date.now() / 1000);
    const expiries = (Array.isArray(pulses) ? pulses : [])
      .map((pulse) => safeInt(pulse?.expires_at))
      .filter((expiresAt) => expiresAt > now)
      .sort((a, b) => a - b);
    if (!expiries.length) return;

    const waitMs = Math.max(1000, Math.min(30 * 60 * 1000, (expiries[0] - now) * 1000 + 500));
    flow.pulseTimer = setTimeout(() => {
      if (activeConversationId() !== conversationId) return;
      const workspaceOpen = !$("#flowWorkspaceModal")?.classList.contains("hidden");
      const showFull = workspaceOpen && flow.activeTab === "pulse" && flow.conversationId === conversationId;
      loadPulses({ stripOnly: !showFull }).catch(() => {});
    }, waitMs);
  }

  function renderPulseStrip(pulses) {
    const strip = $("#conversationPulseStrip");
    if (!strip) return;
    const visible = (Array.isArray(pulses) ? pulses : []).filter((pulse) => !pulse?.error);
    strip.classList.toggle("hidden", visible.length === 0);
    const fragment = document.createDocumentFragment();

    visible.slice(0, 6).forEach((pulse) => {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "pulse-strip-chip";
      chip.title = "Open Conversation Pulse";
      chip.addEventListener("click", () => openWorkspace("pulse"));

      const emoji = document.createElement("span");
      emoji.textContent = pulse.emoji || "◉";
      const name = document.createElement("b");
      name.textContent = pulse.user?.display_name || pulse.user?.username || "Member";
      const label = document.createElement("span");
      label.textContent = pulse.label || "Here now";

      chip.append(emoji, name, label);
      fragment.appendChild(chip);
    });

    strip.replaceChildren(fragment);
  }

  function renderPulseList() {
    const list = $("#pulseList");
    const empty = $("#pulseEmpty");
    if (!list || !empty) return;

    const valid = flow.pulses.filter((pulse) => !pulse?.error);
    const fragment = document.createDocumentFragment();

    for (const pulse of valid) {
      const card = document.createElement("article");
      card.className = "pulse-card";

      const emoji = document.createElement("div");
      emoji.className = "pulse-card-emoji";
      emoji.textContent = pulse.emoji || "◉";

      const copy = document.createElement("div");
      copy.className = "pulse-card-copy";
      const name = document.createElement("b");
      name.textContent = pulse.user?.display_name || pulse.user?.username || "Member";
      const label = document.createElement("span");
      label.textContent = pulse.label || "Here now";
      copy.append(name, label);

      const time = document.createElement("span");
      time.className = "pulse-card-time";
      time.textContent = `${formatRelative(pulse.expires_at)} left`;

      card.append(emoji, copy, time);
      fragment.appendChild(card);
    }

    list.replaceChildren(fragment);
    empty.classList.toggle("hidden", valid.length > 0);
  }

  async function submitPulse(event) {
    event.preventDefault();
    const cid = flow.conversationId;
    if (!cid) return;

    const label = String($("#pulseLabel")?.value || "").trim();
    const ttl = Math.max(15, Math.min(1440, safeInt($("#pulseTtl")?.value, 120)));

    const payload = await encryptFlowPayload(cid, "pulse", {
      emoji: flow.pulseEmoji,
      label,
    });

    await app().api("pulse_set", {
      method: "POST",
      body: {
        conversation_id: cid,
        ttl_minutes: ttl,
        payload_e2ee: payload,
      },
      loadingLabel: "Sharing encrypted pulse…",
    });

    if ($("#pulseLabel")) $("#pulseLabel").value = "";
    await loadPulses();
    toast("Conversation Pulse shared.");
  }

  async function clearPulse() {
    const cid = flow.conversationId;
    if (!cid) return;
    await app().api("pulse_clear", {
      method: "POST",
      body: { conversation_id: cid },
      showLoader: false,
    });
    await loadPulses();
    toast("Your pulse was cleared.");
  }

  /* ------------------------------------------------------------------ */
  /* Quick switcher                                                      */
  /* ------------------------------------------------------------------ */

  function quickAction(label, subtitle, icon, run, keywords = "") {
    return { type: "action", label, subtitle, icon, run, keywords };
  }

  function buildQuickResults(query = "") {
    const normalized = String(query).trim().toLowerCase();
    const s = state();
    if (!s?.me) return [];

    const actions = [
      quickAction("New conversation", "Message someone or create a group", "＋", () => {
        ($("#newChatBtn") || $("#mobileNewChatBtn"))?.click();
      }, "compose new chat group"),
      quickAction("Friends", "Requests and people you know", "◎", () => {
        ($("#friendsBtn") || $("#mobileFriendsBtn"))?.click();
      }, "people contacts requests"),
      quickAction("Settings", "Profile, appearance, privacy and ads", "⚙", () => {
        ($("#settingsBtn") || $("#mobileSettingsBtn"))?.click();
      }, "preferences profile security privacy"),
      quickAction("Saved messages", "Open your private saved-message list", "◆", () => {
        $("#openSavedMessagesBtn")?.click();
      }, "bookmarks saved"),
      quickAction("Install SilkNex", "Optional app installation", "⇩", () => {
        ($("#installAppSettingsBtn") || $("#installAppHomeBtn"))?.click();
      }, "pwa download app"),
      quickAction("Focus mode", "Quiet the interface for a timed session", "◌", openFocusModal, "timer quiet"),
    ];

    if (activeConversationId()) {
      actions.unshift(
        quickAction("Open Flow workspace", "Board, Canvas and Conversation Pulse", "✦", () => {
          openWorkspace("board");
        }, "board canvas pulse tasks draw")
      );
    }

    const conversations = (Array.isArray(s.conversations) ? s.conversations : [])
      .map((conversation) => ({
        type: "conversation",
        id: Number(conversation.id),
        label: String(conversation.title || "Conversation"),
        subtitle:
          String(conversation.last_message?.body || conversation.subtitle || "Open conversation"),
        icon: conversation.kind === "group" ? "◫" : "○",
        keywords: `${conversation.title || ""} ${conversation.subtitle || ""}`,
        updated_at: Number(conversation.updated_at || 0),
      }))
      .sort((a, b) => b.updated_at - a.updated_at);

    const all = [...actions, ...conversations];
    if (!normalized) return all.slice(0, 18);

    const words = normalized.split(/\s+/).filter(Boolean);
    return all
      .map((item) => {
        const hay = `${item.label} ${item.subtitle} ${item.keywords || ""}`.toLowerCase();
        let score = 0;
        for (const word of words) {
          if (!hay.includes(word)) return null;
          if (item.label.toLowerCase().startsWith(word)) score += 6;
          else if (item.label.toLowerCase().includes(word)) score += 4;
          else score += 1;
        }
        return { ...item, score };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score || Number(b.updated_at || 0) - Number(a.updated_at || 0))
      .slice(0, 24);
  }

  function renderQuickSwitcher() {
    const input = $("#quickSwitcherInput");
    const list = $("#quickSwitcherResults");
    if (!input || !list) return;

    flow.quickResults = buildQuickResults(input.value);
    flow.quickIndex = Math.max(0, Math.min(flow.quickIndex, flow.quickResults.length - 1));
    const fragment = document.createDocumentFragment();

    flow.quickResults.forEach((item, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `quick-result${index === flow.quickIndex ? " active" : ""}`;
      button.setAttribute("role", "option");
      button.setAttribute("aria-selected", index === flow.quickIndex ? "true" : "false");

      const icon = document.createElement("span");
      icon.className = "quick-result-icon";
      icon.textContent = item.icon || "○";

      const copy = document.createElement("span");
      copy.className = "quick-result-copy";
      const title = document.createElement("b");
      title.textContent = item.label;
      const subtitle = document.createElement("small");
      subtitle.textContent = item.subtitle || "";
      copy.append(title, subtitle);

      const hint = document.createElement("span");
      hint.className = "quick-result-hint";
      hint.textContent = item.type === "conversation" ? "Chat" : "Action";

      button.append(icon, copy, hint);
      button.addEventListener("pointermove", () => {
        if (flow.quickIndex !== index) {
          flow.quickIndex = index;
          $$(".quick-result", list).forEach((node, nodeIndex) => {
            node.classList.toggle("active", nodeIndex === index);
            node.setAttribute("aria-selected", nodeIndex === index ? "true" : "false");
          });
        }
      });
      button.addEventListener("click", () => runQuickItem(item));
      fragment.appendChild(button);
    });

    if (!flow.quickResults.length) {
      const empty = document.createElement("div");
      empty.className = "flow-empty";
      const text = document.createElement("small");
      text.textContent = "No chats or actions match that search.";
      empty.appendChild(text);
      fragment.appendChild(empty);
    }

    list.replaceChildren(fragment);
    list.querySelector(".quick-result.active")?.scrollIntoView({ block: "nearest" });
  }

  function runQuickItem(item) {
    if (!item) return;
    app()?.closeModal?.();

    if (item.type === "conversation" && item.id) {
      app()?.openConversation?.(item.id);
      return;
    }

    try {
      item.run?.();
    } catch (error) {
      toast(error?.message || "Could not open that action.");
    }
  }

  function openQuickSwitcher() {
    if (!state()?.me) return;
    flow.quickIndex = 0;
    const input = $("#quickSwitcherInput");
    if (input) input.value = "";
    renderQuickSwitcher();
    app()?.openModal?.("#quickSwitcherModal");
    setTimeout(() => input?.focus({ preventScroll: true }), 0);
  }

  function quickKeydown(event) {
    if ($("#quickSwitcherModal")?.classList.contains("hidden")) return;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      if (flow.quickResults.length) {
        flow.quickIndex = (flow.quickIndex + 1) % flow.quickResults.length;
        renderQuickSwitcher();
      }
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      if (flow.quickResults.length) {
        flow.quickIndex =
          (flow.quickIndex - 1 + flow.quickResults.length) % flow.quickResults.length;
        renderQuickSwitcher();
      }
    } else if (event.key === "Enter") {
      event.preventDefault();
      runQuickItem(flow.quickResults[flow.quickIndex]);
    }
  }

  /* ------------------------------------------------------------------ */
  /* Focus mode                                                          */
  /* ------------------------------------------------------------------ */

  function readFocusUntil() {
    try {
      return Math.max(0, Number(localStorage.getItem("silknex-focus-until") || 0));
    } catch {
      return 0;
    }
  }

  function writeFocusUntil(value) {
    flow.focusUntil = Math.max(0, Number(value) || 0);
    try {
      if (flow.focusUntil > Date.now()) {
        localStorage.setItem("silknex-focus-until", String(flow.focusUntil));
      } else {
        localStorage.removeItem("silknex-focus-until");
      }
    } catch {}
    updateFocusUi();
  }

  function updateFocusUi() {
    const remaining = Math.max(0, flow.focusUntil - Date.now());
    const active = remaining > 0;
    document.body.classList.toggle("silknex-focus-mode", active);
    $("#focusPill")?.classList.toggle("hidden", !active);
    $("#focusStopBtn")?.classList.toggle("hidden", !active);

    const homeState = $("#homeFocusState");
    if (homeState) homeState.textContent = active ? "Active" : "Off";

    if (active) {
      const total = Math.ceil(remaining / 1000);
      const minutes = Math.floor(total / 60);
      const seconds = total % 60;
      const label = `${minutes}:${String(seconds).padStart(2, "0")}`;
      if ($("#focusPillTime")) $("#focusPillTime").textContent = label;
    }

    if (!active) {
      clearInterval(flow.focusTimer);
      flow.focusTimer = null;
      return;
    }

    if (!flow.focusTimer) {
      flow.focusTimer = setInterval(() => {
        if (flow.focusUntil <= Date.now()) {
          writeFocusUntil(0);
          toast("Focus session finished.");
        } else {
          updateFocusUi();
        }
      }, 1000);
    }
  }

  function startFocus(minutes) {
    const duration = Math.max(5, Math.min(240, Number(minutes) || 25));
    writeFocusUntil(Date.now() + duration * 60 * 1000);
    app()?.closeModal?.();
    toast(`Focus mode started for ${duration} minutes.`);
  }

  function stopFocus() {
    writeFocusUntil(0);
    app()?.closeModal?.();
    toast("Focus mode ended.");
  }

  function openFocusModal() {
    if (!state()?.me) return;
    app()?.openModal?.("#focusModeModal");
  }

  /* ------------------------------------------------------------------ */
  /* Conversation lifecycle + responsive helpers                         */
  /* ------------------------------------------------------------------ */

  function onConversationChanged(event) {
    const id = safeInt(event.detail?.id);
    flow.conversationId = id;
    flow.boardItems = [];
    flow.boardMembers = [];
    flow.boardEditingId = 0;
    flow.canvasRevision = 0;
    flow.canvasRemoteRevision = 0;
    flow.canvasStrokes = [];
    flow.canvasStroke = null;
    flow.canvasDirty = false;
    flow.pulses = [];
    $("#conversationPulseStrip")?.classList.add("hidden");
    $("#conversationPulseStrip")?.replaceChildren();
    resetBoardComposer();
    renderCanvas();

    clearInterval(flow.canvasPollTimer);
    flow.canvasPollTimer = null;
    clearInterval(flow.boardPollTimer);
    flow.boardPollTimer = null;
    clearTimeout(flow.pulseTimer);
    flow.pulseTimer = null;

    if (id > 0) {
      // Pulse is deliberately lightweight. Load it after the conversation
      // itself is already interactive so Flow never slows opening a chat.
      const load = () => loadPulses({ stripOnly: true }).catch(() => {});
      if ("requestIdleCallback" in window) {
        requestIdleCallback(load, { timeout: 1200 });
      } else {
        setTimeout(load, 180);
      }
    }
  }

  function resizeCanvasBackingStore() {
    const canvas = $("#silkCanvas");
    if (!canvas) return;
    // A fixed logical drawing resolution makes normalized strokes deterministic
    // across phones, tablets and desktops. Rendering scales through CSS.
    if (canvas.width !== 960) canvas.width = 960;
    if (canvas.height !== 600) canvas.height = 600;
    renderCanvas();
  }

  function lightHaptic(event) {
    const target = event.target?.closest?.(
      "button.primary,.send-btn,.flow-tab,.board-filter,.mobile-nav-item"
    );
    if (!target || target.disabled) return;
    if (document.documentElement.dataset.performance === "efficient") return;
    try { navigator.vibrate?.(7); } catch {}
  }

  function bind() {
    if (flow.mounted) return;
    flow.mounted = true;

    ["flowBtn", "quickSwitcherHomeBtn", "focusModeHomeBtn"].forEach((id) => {
      const control = document.getElementById(id);
      if (!control) return;
      control.disabled = false;
      control.removeAttribute("aria-busy");
    });

    $("#flowBtn")?.addEventListener("click", () => openWorkspace("board"));
    $("#quickSwitcherHomeBtn")?.addEventListener("click", openQuickSwitcher);
    $("#focusModeHomeBtn")?.addEventListener("click", openFocusModal);
    $("#focusPill")?.addEventListener("click", openFocusModal);

    $$(".flow-tab").forEach((button) => {
      button.addEventListener("click", () => selectFlowTab(button.dataset.flowTab));
    });

    $("#boardNewBtn")?.addEventListener("click", showBoardComposer);
    $("#boardComposerCancel")?.addEventListener("click", resetBoardComposer);
    $("#boardSaveBtn")?.addEventListener("click", () => saveBoardComposer().catch(handleFlowError));
    $$(".board-filter").forEach((button) => {
      button.addEventListener("click", () => {
        flow.boardFilter = button.dataset.boardFilter || "open";
        renderBoard();
      });
    });

    const canvas = $("#silkCanvas");
    canvas?.addEventListener("pointerdown", beginCanvasStroke);
    canvas?.addEventListener("pointermove", moveCanvasStroke);
    canvas?.addEventListener("pointerup", endCanvasStroke);
    canvas?.addEventListener("pointercancel", endCanvasStroke);
    canvas?.addEventListener("contextmenu", (event) => event.preventDefault());

    $("#canvasPenBtn")?.addEventListener("click", () => {
      flow.canvasTool = "draw";
      $("#canvasPenBtn")?.classList.add("active");
      $("#canvasEraseBtn")?.classList.remove("active");
    });
    $("#canvasEraseBtn")?.addEventListener("click", () => {
      flow.canvasTool = "erase";
      $("#canvasEraseBtn")?.classList.add("active");
      $("#canvasPenBtn")?.classList.remove("active");
    });
    $("#canvasUndoBtn")?.addEventListener("click", () => {
      if (!flow.canvasStrokes.length) return;
      flow.canvasStrokes.pop();
      flow.canvasDirty = true;
      renderCanvas();
      updateCanvasStatus();
    });
    $("#canvasClearBtn")?.addEventListener("click", () => {
      if (!flow.canvasStrokes.length) return;
      if (!window.confirm("Clear your local canvas? It will not affect the shared version until you save.")) return;
      flow.canvasStrokes = [];
      flow.canvasDirty = true;
      renderCanvas();
      updateCanvasStatus();
    });
    $("#canvasSaveBtn")?.addEventListener("click", () => saveCanvas().catch(handleFlowError));
    $("#canvasRefreshBtn")?.addEventListener("click", async () => {
      if (flow.canvasDirty && !window.confirm("Discard local unsaved canvas changes and load the shared version?")) {
        return;
      }
      flow.canvasDirty = false;
      await loadCanvas({ force: true }).catch(handleFlowError);
    });
    $("#canvasRemoteNotice")?.addEventListener("click", async () => {
      if (flow.canvasDirty && !window.confirm("A newer shared canvas exists. Discard your local unsaved changes and load it?")) {
        return;
      }
      flow.canvasDirty = false;
      await loadCanvas({ force: true }).catch(handleFlowError);
    });

    $$(".pulse-emoji-grid button").forEach((button) => {
      button.addEventListener("click", () => {
        flow.pulseEmoji = String(button.dataset.pulseEmoji || "🎯");
        $$(".pulse-emoji-grid button").forEach((candidate) => {
          const active = candidate === button;
          candidate.classList.toggle("active", active);
          candidate.setAttribute("aria-pressed", active ? "true" : "false");
        });
      });
    });
    $("#pulseForm")?.addEventListener("submit", (event) => {
      submitPulse(event).catch(handleFlowError);
    });
    $("#pulseClearBtn")?.addEventListener("click", () => clearPulse().catch(handleFlowError));

    $("#quickSwitcherInput")?.addEventListener("input", () => {
      flow.quickIndex = 0;
      renderQuickSwitcher();
    });
    $("#quickSwitcherInput")?.addEventListener("keydown", quickKeydown);

    $$("[data-focus-minutes]").forEach((button) => {
      button.addEventListener("click", () => startFocus(button.dataset.focusMinutes));
    });
    $("#focusStopBtn")?.addEventListener("click", stopFocus);

    window.addEventListener("silknex:conversation", onConversationChanged);
    window.addEventListener("silknex:session", (event) => {
      if (!event.detail?.signedIn) {
        flow.conversationId = 0;
        flow.boardItems = [];
        flow.pulses = [];
        clearInterval(flow.canvasPollTimer);
        clearInterval(flow.boardPollTimer);
        clearTimeout(flow.pulseTimer);
        flow.canvasPollTimer = null;
        flow.boardPollTimer = null;
        flow.pulseTimer = null;
        renderPulseStrip([]);
      } else {
        updateFocusUi();
      }
    });

    window.addEventListener("resize", () => {
      if (flow.activeTab === "canvas") requestAnimationFrame(resizeCanvasBackingStore);
    }, { passive: true });

    document.addEventListener("keydown", (event) => {
      const modifier = event.ctrlKey || event.metaKey;
      if (modifier && String(event.key).toLowerCase() === "k") {
        event.preventDefault();
        if ($("#quickSwitcherModal")?.classList.contains("hidden")) openQuickSwitcher();
        else app()?.closeModal?.();
      }
    });

    document.addEventListener("pointerdown", lightHaptic, { passive: true });

    const workspaceModal = $("#flowWorkspaceModal");
    if (workspaceModal && typeof MutationObserver !== "undefined") {
      new MutationObserver(() => {
        if (workspaceModal.classList.contains("hidden")) {
          clearInterval(flow.canvasPollTimer);
          flow.canvasPollTimer = null;
          clearInterval(flow.boardPollTimer);
          flow.boardPollTimer = null;
          flow.canvasDrawing = false;
          flow.canvasStroke = null;
        }
      }).observe(workspaceModal, { attributes: true, attributeFilter: ["class"] });
    }

    flow.focusUntil = readFocusUntil();
    updateFocusUi();
    resizeCanvasBackingStore();

    if (state()?.me && activeConversationId()) {
      onConversationChanged({ detail: { id: activeConversationId() } });
    }
  }

  let readyAttempts = 0;
  function initWhenReady() {
    if (flow.mounted) return;
    if (app() && e2ee()) {
      bind();
      return;
    }

    readyAttempts += 1;
    if (readyAttempts > 250) {
      // Do not spin forever if a core script was blocked by an extension,
      // network filter, or partial deployment. Leave the rest of SilkNex usable.
      ["flowBtn", "quickSwitcherHomeBtn", "focusModeHomeBtn"].forEach((id) => {
        const control = document.getElementById(id);
        if (!control) return;
        control.disabled = true;
        control.removeAttribute("aria-busy");
        control.title = "Flow tools are unavailable until SilkNex finishes loading.";
      });
      return;
    }
    setTimeout(initWhenReady, Math.min(250, 35 + readyAttempts));
  }

  window.addEventListener("silknex:core-ready", initWhenReady, { once: true });
  initWhenReady();

  window.SilknexFlow = Object.freeze({
    open: openWorkspace,
    quick: openQuickSwitcher,
    focus: openFocusModal,
    refreshBoard: () => loadBoard({ quiet: true }),
    refreshPulse: () => loadPulses({ stripOnly: true }),
  });
})();
