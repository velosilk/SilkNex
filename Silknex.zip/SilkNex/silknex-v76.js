/* Silknex v76 preserves the merged customization layer and saved preferences. */
(() => {
  "use strict";

  const root = document.documentElement;
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const getCore = () => window.SilknexApp || null;
  const STORAGE_KEY = "silknex:v70:ui";

  root.dataset.silknexVersion = "77.0";

  // v68 viewport/capability fixes are folded into v70 so only the newest two
  // upgrade scripts need to ship.
  const setViewportUnit = () => {
    const viewport = window.visualViewport;
    if (Number(viewport?.scale || 1) > 1.05) return;
    const height = Math.max(
      1,
      Math.round(viewport?.height || window.innerHeight || root.clientHeight || 1)
    );
    root.style.setProperty("--sn-vh", `${height * 0.01}px`);
  };

  let viewportFrame = 0;
  const scheduleViewport = () => {
    if (viewportFrame) cancelAnimationFrame(viewportFrame);
    viewportFrame = requestAnimationFrame(() => {
      viewportFrame = 0;
      setViewportUnit();
    });
  };

  setViewportUnit();
  window.addEventListener("resize", scheduleViewport, { passive: true });
  window.addEventListener("orientationchange", scheduleViewport, { passive: true });
  window.visualViewport?.addEventListener("resize", scheduleViewport, { passive: true });
  window.addEventListener("pageshow", (event) => {
    if (event.persisted) scheduleViewport();
  });

  root.classList.toggle(
    "sn-no-hover",
    Boolean(window.matchMedia?.("(hover: none)")?.matches)
  );
  root.classList.toggle(
    "sn-coarse-pointer",
    Boolean(window.matchMedia?.("(pointer: coarse)")?.matches)
  );
  root.classList.toggle(
    "sn-reduced-motion",
    Boolean(window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches)
  );

  window.addEventListener("appinstalled", () => {
    document.querySelectorAll(".install-app-action").forEach((node) => {
      node.classList.add("hidden");
    });
  });

  document.addEventListener("error", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLImageElement)) return;
    if (!target.hasAttribute("decoding")) target.decoding = "async";
    target.classList.add("sn-media-error");
  }, true);

  // Extra user customization is intentionally local to the device. Existing
  // account-synced theme/font/chat preferences continue to work unchanged.
  const defaults = Object.freeze({
    roundness: "balanced",
    controlSize: "normal",
    mediaQuality: "auto",
  });

  function safeReadCustomization() {
    try {
      const parsed = JSON.parse(window.SilknexStorage.getItem(STORAGE_KEY) || "{}");
      return {
        roundness: ["balanced", "soft", "sharp"].includes(parsed.roundness)
          ? parsed.roundness
          : defaults.roundness,
        controlSize: ["normal", "compact", "large"].includes(parsed.controlSize)
          ? parsed.controlSize
          : defaults.controlSize,
        mediaQuality: ["auto", "quality", "efficient"].includes(parsed.mediaQuality)
          ? parsed.mediaQuality
          : defaults.mediaQuality,
      };
    } catch {
      return { ...defaults };
    }
  }

  function shouldUseEfficientMode(preference) {
    if (preference === "efficient") return true;
    if (preference === "quality") return false;

    const memory = Number(navigator.deviceMemory || 0);
    const cores = Number(navigator.hardwareConcurrency || 0);
    const saveData = Boolean(
      navigator.connection?.saveData ||
      navigator.mozConnection?.saveData ||
      navigator.webkitConnection?.saveData
    );
    return saveData || (memory > 0 && memory <= 4) || (cores > 0 && cores <= 4);
  }

  function applyCustomization(settings = safeReadCustomization()) {
    root.dataset.uiRoundness = settings.roundness;
    root.dataset.uiControlSize = settings.controlSize;
    root.dataset.mediaQuality = settings.mediaQuality;
    root.dataset.performance = shouldUseEfficientMode(settings.mediaQuality)
      ? "efficient"
      : "quality";

    const roundness = $("#uiRoundnessV70");
    const controlSize = $("#uiControlSizeV70");
    const mediaQuality = $("#uiMediaQualityV70");
    if (roundness) roundness.value = settings.roundness;
    if (controlSize) controlSize.value = settings.controlSize;
    if (mediaQuality) mediaQuality.value = settings.mediaQuality;
    return settings;
  }

  function saveCustomization() {
    const settings = {
      roundness: $("#uiRoundnessV70")?.value || defaults.roundness,
      controlSize: $("#uiControlSizeV70")?.value || defaults.controlSize,
      mediaQuality: $("#uiMediaQualityV70")?.value || defaults.mediaQuality,
    };
    try {
      window.SilknexStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {}
    applyCustomization(settings);
  }

  applyCustomization();

  for (const id of ["uiRoundnessV70", "uiControlSizeV70", "uiMediaQualityV70"]) {
    document.addEventListener("change", (event) => {
      if (event.target?.id === id) saveCustomization();
    });
  }

  window.addEventListener("storage", (event) => {
    if (event.key === STORAGE_KEY) applyCustomization();
  });

  // Release nonessential generated caches after a tab has remained hidden. This
  // reduces RAM pressure on phones without discarding message state.
  let hiddenCleanupTimer = 0;
  document.addEventListener("visibilitychange", () => {
    clearTimeout(hiddenCleanupTimer);
    if (document.visibilityState !== "hidden") return;
    hiddenCleanupTimer = window.setTimeout(() => {
      const state = getCore()?.state;
      state?.avatarDataUrlCache?.clear?.();

      // Sticker undo snapshots are the largest short-lived canvas allocation.
      if (Array.isArray(state?.stickerDrawHistory) && state.stickerDrawHistory.length > 2) {
        state.stickerDrawHistory.splice(0, state.stickerDrawHistory.length - 2);
      }
    }, 15000);
  });

})();

window.addEventListener("DOMContentLoaded",()=>{document.documentElement.dataset.silknexVersion="77.0"},{once:true});
