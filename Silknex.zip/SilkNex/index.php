<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

$cfg = require __DIR__ . '/config.php';
if (!is_array($cfg)) {
    http_response_code(500);
    exit('SilkNex configuration error.');
}

$nonce = rtrim(strtr(base64_encode(random_bytes(24)), '+/', '-_'), '=');
$client = trim((string)($cfg['adsense_client'] ?? ''));
$adsenseEnabled =
    !empty($cfg['adsense_enabled']) &&
    preg_match('/^ca-pub-\d{8,32}$/i', $client) === 1;

$csp = implode(' ', [
    "default-src 'self';",
    "object-src 'none';",
    "base-uri 'none';",
    "frame-ancestors 'none';",
    "form-action 'self';",
    "script-src 'nonce-{$nonce}' 'unsafe-inline' 'strict-dynamic' https:;",
    "style-src 'self' 'unsafe-inline';",
    "img-src 'self' data: blob: https:;",
    "media-src 'self' blob: https:;",
    "connect-src 'self' https: wss:;",
    "worker-src 'self' blob:;",
    "manifest-src 'self';",
    "frame-src https:;",
]);

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
header('Content-Security-Policy: ' . $csp);
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Cross-Origin-Opener-Policy: same-origin');
header('Cross-Origin-Resource-Policy: same-origin');
header('Permissions-Policy: camera=(self), microphone=(self), speaker-selection=(self), picture-in-picture=(self), display-capture=(self), geolocation=(), accelerometer=(), gyroscope=(), magnetometer=(), payment=(), usb=(), browsing-topics=(), interest-cohort=()');
header('X-Permitted-Cross-Domain-Policies: none');
header('X-DNS-Prefetch-Control: off');
header('Origin-Agent-Cluster: ?1');

$https = (
    (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') ||
    (int)($_SERVER['SERVER_PORT'] ?? 0) === 443
);
if ($https) {
    header('Strict-Transport-Security: max-age=63072000; includeSubDomains');
}

$templatePath = __DIR__ . '/index.html';
$template = @file_get_contents($templatePath);
if (!is_string($template) || $template === '') {
    http_response_code(500);
    exit('SilkNex interface template is missing.');
}

$adsMeta = '';
$adsHead = '';
if ($adsenseEnabled) {
    $safeClient = htmlspecialchars($client, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $adsMeta = '<meta name="google-adsense-account" content="' . $safeClient . '">';

    // The actual AdSense library is loaded lazily by silknex-features.js only
    // after an authenticated account is confirmed to be ad-enabled and is on
    // the home surface. This avoids spending startup bandwidth on ad-free users
    // and prevents the app from knowingly requesting an ad inside private chat.
    // Keep Auto Ads disabled for the app URL when account-level ad suppression
    // is required; SilkNex uses explicit responsive units by default.
}

$template = str_replace(
    ['__SILKNEX_CSP_NONCE__', '__SILKNEX_ADSENSE_META__', '__SILKNEX_ADSENSE_HEAD__'],
    [htmlspecialchars($nonce, ENT_QUOTES, 'UTF-8'), $adsMeta, $adsHead],
    $template
);

echo $template;
