/* Browser media adapters shared by chat, stories and image uploads. */
(() => {
  'use strict';
  async function decodeImage(file) {
    if (typeof createImageBitmap === 'function') {
      let bitmap;
      try { bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
      catch { try { bitmap = await createImageBitmap(file); } catch {} }
      if (bitmap) return { source: bitmap, dispose: () => bitmap.close?.() };
    }
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.decoding = 'async';
    try {
      await new Promise((resolve, reject) => {
        const timer = setTimeout(() => finish(new Error('That image took too long to open.')), 15000);
        let settled = false;
        function finish(error) {
          if (settled) return;
          settled = true;
          clearTimeout(timer);
          image.onload = image.onerror = null;
          if (error) reject(error); else resolve();
        }
        image.onload = () => finish();
        image.onerror = () => finish(new Error('This browser could not open that image.'));
        image.src = url;
      });
      return { source: image, dispose: () => { image.removeAttribute('src'); URL.revokeObjectURL(url); } };
    } catch (error) {
      image.removeAttribute('src');
      URL.revokeObjectURL(url);
      throw error;
    }
  }

  function encodeCanvas(canvas, type, quality) {
    return new Promise(resolve => {
      let settled = false;
      const timer = setTimeout(() => finish(null), 15000);
      function finish(blob) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(blob && ['image/webp', 'image/jpeg', 'image/png'].includes(blob.type) ? blob : null);
      }
      try { canvas.toBlob(finish, type, quality); }
      catch { finish(null); }
    });
  }

  function extension(type) {
    return { 'image/webp': 'webp', 'image/jpeg': 'jpg', 'image/png': 'png' }[type] || '';
  }
  window.SilknexMedia = Object.freeze({ decodeImage, encodeCanvas, extension });
})();
