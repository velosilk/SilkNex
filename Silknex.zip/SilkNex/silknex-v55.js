(() => {
  "use strict";

  const VERSION = "55.0";
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const app = () => window.SilknexApp || null;
  const STORAGE_KEY = "silknex:v55:ui";

  const PRESETS = Object.freeze({
    chat: ["❤️", "😂", "👍", "🔥", "😭", "✨", "💀", "👀"],
    symbols: ["@", "#", "&", "—", "•", "→", "✓", "©", "™"],
    gaming: ["GG", "GLHF", "W", "L", "AFK", "BRB", "🎮", "🔥"],
  });

  function safeJson(value, fallback) {
    try {
      const parsed = JSON.parse(value);
      return parsed && typeof parsed === "object" ? parsed : fallback;
    } catch {
      return fallback;
    }
  }

  function loadSettings() {
    const stored = safeJson(localStorage.getItem(STORAGE_KEY), {});
    return {
      keyboardEnabled: stored.keyboardEnabled !== false,
      keyboardPreset: ["chat", "symbols", "gaming", "custom"].includes(stored.keyboardPreset)
        ? stored.keyboardPreset
        : "chat",
      customKeys: Array.isArray(stored.customKeys)
        ? stored.customKeys.map((item) => String(item).slice(0, 16)).filter(Boolean).slice(0, 20)
        : ["❤️", "😂", "👍", "🔥", "✨"],
      compactComposer: Boolean(stored.compactComposer),
      // Start v55 with a flatter Discord/WhatsApp-like message shape while
      // keeping the preference reversible for users who prefer softer bubbles.
      squareBubbles: stored.squareBubbles === undefined ? true : Boolean(stored.squareBubbles),
    };
  }

  let settings = loadSettings();

  function saveSettings() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {}
    applyStyleSettings();
    renderKeyboard();
  }

  function applyStyleSettings() {
    const root = document.documentElement;
    root.dataset.v55CompactComposer = settings.compactComposer ? "1" : "0";
    root.dataset.v55SquareBubbles = settings.squareBubbles ? "1" : "0";
  }

  function currentKeys() {
    if (settings.keyboardPreset === "custom") return settings.customKeys;
    return PRESETS[settings.keyboardPreset] || PRESETS.chat;
  }

  function insertAtCaret(text) {
    const input = $("#messageInput");
    if (!input || input.disabled) return;

    input.focus({ preventScroll: true });
    const start = Number.isInteger(input.selectionStart) ? input.selectionStart : input.value.length;
    const end = Number.isInteger(input.selectionEnd) ? input.selectionEnd : start;
    const before = input.value.slice(0, start);
    const after = input.value.slice(end);
    const value = `${before}${text}${after}`.slice(0, Number(input.maxLength || 4000));
    input.value = value;
    const caret = Math.min(value.length, start + text.length);
    try { input.setSelectionRange(caret, caret); } catch {}
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function ensureKeyboardTray() {
    const form = $("#messageForm");
    if (!form) return null;
    let tray = $("#customKeyboardTray");
    if (!tray) {
      tray = document.createElement("div");
      tray.id = "customKeyboardTray";
      tray.className = "custom-keyboard-tray";
      tray.setAttribute("role", "toolbar");
      tray.setAttribute("aria-label", "Custom quick keyboard");
      form.insertAdjacentElement("beforebegin", tray);
    }
    return tray;
  }

  function renderKeyboard() {
    const tray = ensureKeyboardTray();
    if (!tray) return;
    tray.classList.toggle("hidden", !settings.keyboardEnabled);
    tray.replaceChildren();
    if (!settings.keyboardEnabled) return;

    for (const key of currentKeys()) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "custom-keyboard-key";
      button.textContent = key;
      button.setAttribute("aria-label", `Insert ${key}`);
      button.addEventListener("pointerdown", (event) => event.preventDefault());
      button.addEventListener("click", () => insertAtCaret(key));
      tray.appendChild(button);
    }
  }

  function addCheckboxRow(section, id, label, description, checked, onChange) {
    const row = document.createElement("div");
    row.className = "setting-row";
    row.innerHTML = `<div><b></b><small></small></div><label class="switch"><input type="checkbox"><span></span></label>`;
    $("b", row).textContent = label;
    $("small", row).textContent = description;
    const input = $("input", row);
    input.id = id;
    input.checked = checked;
    input.addEventListener("change", () => onChange(input.checked));
    section.appendChild(row);
  }

  function installSettings() {
    if ($("#v55PersonalizationSettings")) return;
    const host = $("#settingsModal .settings-stack, #settingsModal .modal-card");
    if (!host) return;

    const section = document.createElement("section");
    section.id = "v55PersonalizationSettings";
    section.className = "settings-section v55-settings-section";
    section.innerHTML = `
      <div class="section-title"><span>Personal style & keyboard</span></div>
      <label class="field">
        <span>Quick keyboard layout</span>
        <select id="v55KeyboardPreset">
          <option value="chat">Chat reactions</option>
          <option value="symbols">Symbols</option>
          <option value="gaming">Gaming</option>
          <option value="custom">Custom</option>
        </select>
      </label>
      <label class="field">
        <span>Custom keys · separate with commas</span>
        <input id="v55CustomKeys" class="v55-key-input" maxlength="240" placeholder="❤️,😂,👍,🔥,✨">
      </label>
    `;
    host.appendChild(section);

    addCheckboxRow(
      section,
      "v55KeyboardEnabled",
      "Custom quick keyboard",
      "Show your chosen keys directly above the chat composer.",
      settings.keyboardEnabled,
      (value) => { settings.keyboardEnabled = value; saveSettings(); }
    );
    addCheckboxRow(
      section,
      "v55CompactComposer",
      "Compact composer",
      "Use a tighter WhatsApp/Discord-style message bar.",
      settings.compactComposer,
      (value) => { settings.compactComposer = value; saveSettings(); }
    );
    addCheckboxRow(
      section,
      "v55SquareBubbles",
      "Sharper message bubbles",
      "Reduce the extra-rounded AI-chat look.",
      settings.squareBubbles,
      (value) => { settings.squareBubbles = value; saveSettings(); }
    );

    const preset = $("#v55KeyboardPreset");
    const custom = $("#v55CustomKeys");
    preset.value = settings.keyboardPreset;
    custom.value = settings.customKeys.join(",");
    custom.disabled = settings.keyboardPreset !== "custom";

    preset.addEventListener("change", () => {
      settings.keyboardPreset = preset.value;
      custom.disabled = settings.keyboardPreset !== "custom";
      saveSettings();
    });

    custom.addEventListener("change", () => {
      settings.customKeys = custom.value
        .split(",")
        .map((value) => value.trim().slice(0, 16))
        .filter(Boolean)
        .slice(0, 20);
      if (!settings.customKeys.length) settings.customKeys = ["❤️", "😂", "👍"];
      custom.value = settings.customKeys.join(",");
      settings.keyboardPreset = "custom";
      preset.value = "custom";
      saveSettings();
    });
  }

  function installQrActions() {
    const card = $("#profileQrModal .qr-profile-card");
    if (!card || $("#v55ShareProfileQrBtn")) return;
    const button = document.createElement("button");
    button.id = "v55ShareProfileQrBtn";
    button.type = "button";
    button.className = "secondary-btn wide";
    button.textContent = "Share profile link";
    const scan = $("#scanProfileQrBtn");
    scan?.insertAdjacentElement("beforebegin", button);

    button.addEventListener("click", async () => {
      const handle = String($("#profileQrHandle")?.textContent || "").replace(/^@/, "").trim();
      if (!handle) return;
      const url = new URL(location.pathname || "/", location.origin);
      url.searchParams.set("profile", handle);
      try {
        if (navigator.share) {
          await navigator.share({ title: `@${handle} on SilkNex`, url: url.toString() });
        } else {
          await navigator.clipboard.writeText(url.toString());
          app()?.toast?.("Profile link copied.");
        }
      } catch {}
    });
  }

  function tuneMediaNode(node) {
    if (node instanceof HTMLImageElement) {
      if (!node.loading) node.loading = "lazy";
      node.decoding = "async";
      node.fetchPriority = node.closest(".message") ? "auto" : (node.fetchPriority || "low");
    } else if (node instanceof HTMLVideoElement) {
      node.preload = node.closest(".message") ? "metadata" : (node.preload || "none");
      node.playsInline = true;
    }
  }

  function installMediaObserver() {
    document.querySelectorAll("img,video").forEach(tuneMediaNode);
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (node.matches("img,video")) tuneMediaNode(node);
          node.querySelectorAll?.("img,video").forEach(tuneMediaNode);
        }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  function installComposerFocusGuard() {
    const input = $("#messageInput");
    if (!input) return;
    const keepVisible = () => {
      requestAnimationFrame(() => {
        const messages = $("#messages");
        if (messages) {
          messages.scrollTop = Math.max(0, messages.scrollHeight - messages.clientHeight);
        }
      });
    };
    input.addEventListener("focus", keepVisible);
    window.visualViewport?.addEventListener("resize", () => {
      if (document.activeElement === input) keepVisible();
    }, { passive: true });
  }

  function init() {
    if (!app()) {
      window.addEventListener("silknex:core-ready", init, { once: true });
      return;
    }
    applyStyleSettings();
    renderKeyboard();
    installSettings();
    installQrActions();
    installMediaObserver();
    installComposerFocusGuard();

    window.addEventListener("silknex:modal", () => {
      installSettings();
      installQrActions();
    });
    window.addEventListener("resize", renderKeyboard, { passive: true });
  }

  window.SilkNexV55 = Object.freeze({ version: VERSION, renderKeyboard });
  init();
})();