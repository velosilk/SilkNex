(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = () => window.SilknexApp || null;

  const runtime = {
    signedIn: false,
    founder: false,
    pinnedIds: new Set(),
    pinConversationId: 0,
    pinRefreshTimer: null,
    announcementTimer: null,
    messageObserver: null,
    ownerDashboard: null,
  };

  function toast(message) {
    app()?.toast?.(String(message || ""));
  }

  function svgIcon(name) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", "true");
    svg.classList.add("v49-action-icon");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "1.8");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");

    const paths = {
      pin: [
        "M8.5 3.5h7",
        "M9.5 3.5l.8 5.2-3 3v1.8h9.4v-1.8l-3-3 .8-5.2",
        "M12 13.5v7",
      ],
      speaker: [
        "M5 10v4h3l4 3V7l-4 3H5Z",
        "M15 9.2c1 .8 1.5 1.7 1.5 2.8s-.5 2-1.5 2.8",
        "M17.5 7c1.6 1.4 2.5 3 2.5 5s-.9 3.6-2.5 5",
      ],
      link: [
        "M9.5 14.5 14.5 9.5",
        "M7.2 16.8 5.8 18.2a3 3 0 0 1-4.2-4.2L5 10.6a3 3 0 0 1 4.2 0",
        "m14.8 7.2 1.4-1.4a3 3 0 0 1 4.2 4.2L17 13.4a3 3 0 0 1-4.2 0",
      ],
      crown: [
        "m4 8 4 4 4-7 4 7 4-4-2 10H6L4 8Z",
        "M7 21h10",
      ],
      refresh: [
        "M20 7v5h-5",
        "M4 17v-5h5",
        "M6.1 8.2A7 7 0 0 1 18.6 6L20 12",
        "M4 12l1.4 6A7 7 0 0 0 17.9 15.8",
      ],
    };

    for (const d of paths[name] || paths.link) {
      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", d);
      svg.appendChild(path);
    }
    return svg;
  }

  function setSignedIn(value) {
    runtime.signedIn = Boolean(value);
    runtime.founder = Boolean(
      runtime.signedIn &&
      app()?.state?.me?.role === "founder_ceo"
    );

    document.documentElement.dataset.founder = runtime.founder ? "true" : "false";

    if (runtime.founder) {
      ensureOwnerUi();
    } else {
      $("#v49OwnerSettings")?.remove();
      $("#v49OwnerModal")?.remove();
    }

    if (runtime.signedIn) {
      scheduleAnnouncementRefresh(true);
    } else {
      clearTimeout(runtime.announcementTimer);
      runtime.announcementTimer = null;
      hideAnnouncement();
      stopPinRefresh();
      runtime.pinnedIds.clear();
      runtime.pinConversationId = 0;
      updatePinButtons();
    }
  }

  function copyText(text, success = "Copied.") {
    const value = String(text || "");
    if (!value) return Promise.resolve(false);

    if (navigator.clipboard?.writeText) {
      return navigator.clipboard.writeText(value)
        .then(() => {
          toast(success);
          return true;
        })
        .catch(() => fallbackCopy(value, success));
    }

    return Promise.resolve(fallbackCopy(value, success));
  }

  function fallbackCopy(text, success) {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.left = "-9999px";
    document.body.appendChild(area);
    area.select();

    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch {}
    area.remove();

    if (ok) toast(success);
    else toast("Copy is unavailable in this browser.");
    return ok;
  }

  function conversationLink() {
    const id = Number(app()?.state?.activeId || 0);
    if (!id) return "";

    const url = new URL(window.location.href);
    url.search = "";
    url.hash = "";
    url.searchParams.set("conversation", String(id));
    return url.toString();
  }

  async function shareConversation() {
    const url = conversationLink();
    if (!url) {
      toast("Open a conversation first.");
      return;
    }

    const title = String(
      app()?.state?.activeConversation?.title || "SilkNex conversation"
    );

    if (navigator.share) {
      try {
        await navigator.share({ title, url });
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }

    await copyText(url, "Conversation link copied.");
  }

  /* ------------------------------------------------------------------ */
  /* Global founder announcements                                       */
  /* ------------------------------------------------------------------ */

  function announcementDismissKey(id) {
    return `silknex:announcement:dismissed:${String(id || "")}`;
  }

  function announcementWasDismissed(id) {
    if (!id) return false;
    try {
      return sessionStorage.getItem(announcementDismissKey(id)) === "1";
    } catch {
      return false;
    }
  }

  function dismissAnnouncement(id) {
    if (id) {
      try {
        sessionStorage.setItem(announcementDismissKey(id), "1");
      } catch {}
    }
    hideAnnouncement();
  }

  function ensureAnnouncementBar() {
    let bar = $("#systemAnnouncementBar");
    if (bar) return bar;

    bar = document.createElement("aside");
    bar.id = "systemAnnouncementBar";
    bar.className = "system-announcement hidden";
    bar.setAttribute("role", "status");
    bar.setAttribute("aria-live", "polite");

    const badge = document.createElement("span");
    badge.className = "system-announcement-badge";
    badge.textContent = "SILKNEX";

    const text = document.createElement("span");
    text.id = "systemAnnouncementText";
    text.className = "system-announcement-text";

    const close = document.createElement("button");
    close.type = "button";
    close.className = "system-announcement-close";
    close.setAttribute("aria-label", "Dismiss announcement");
    close.textContent = "×";
    close.addEventListener("click", () => {
      dismissAnnouncement(bar.dataset.announcementId || "");
    });

    bar.append(badge, text, close);
    document.body.appendChild(bar);
    return bar;
  }

  function hideAnnouncement() {
    const bar = $("#systemAnnouncementBar");
    if (!bar) return;
    bar.classList.add("hidden");
    bar.dataset.announcementId = "";
  }

  function renderAnnouncement(announcement) {
    const bar = ensureAnnouncementBar();
    const id = String(announcement?.id || "");
    const text = String(announcement?.text || "").trim();
    const expiresAt = Number(announcement?.expires_at || 0);

    if (
      !id ||
      !text ||
      expiresAt <= Math.floor(Date.now() / 1000) ||
      announcementWasDismissed(id)
    ) {
      hideAnnouncement();
      return;
    }

    bar.dataset.announcementId = id;
    $("#systemAnnouncementText", bar).textContent = text;
    bar.classList.remove("hidden");
  }

  async function refreshAnnouncement() {
    if (!runtime.signedIn || !app()?.api || document.visibilityState === "hidden") {
      return;
    }

    try {
      const data = await app().api(
        "system_announcement",
        { showLoader: false, timeoutMs: 5000 }
      );
      renderAnnouncement(data?.announcement || null);
    } catch {
      // Announcements are optional and must never interfere with messaging.
    }
  }

  function scheduleAnnouncementRefresh(immediate = false) {
    clearTimeout(runtime.announcementTimer);
    runtime.announcementTimer = null;
    if (!runtime.signedIn) return;

    const run = async () => {
      await refreshAnnouncement();
      runtime.announcementTimer = setTimeout(run, 5 * 60 * 1000);
    };

    runtime.announcementTimer = setTimeout(run, immediate ? 20 : 5 * 60 * 1000);
  }

  /* ------------------------------------------------------------------ */
  /* Pinned messages                                                     */
  /* ------------------------------------------------------------------ */

  function messageFallback(item) {
    return {
      image: "Photo",
      gif: "GIF",
      video: "Video",
      audio: "Voice message",
      video_note: "Video message",
      sticker: "Sticker",
    }[String(item?.message_type || "text")] || "Encrypted message";
  }

  async function pinPreview(item) {
    const serverPreview = String(item?.preview || "").trim();
    if (serverPreview) return serverPreview;
    if (!item?.e2ee_payload) return messageFallback(item);

    try {
      const decrypted = await window.SilknexE2EE?.decryptMessage?.({
        id: Number(item.message_id || 0),
        conversation_id: Number(item.conversation_id || 0),
        sender_id: Number(item.sender_id || 0),
        e2ee_payload: String(item.e2ee_payload || ""),
        message_type: String(item.message_type || "text"),
        body: "",
      });
      return String(decrypted?.body || "").trim() || messageFallback(item);
    } catch {
      return messageFallback(item);
    }
  }

  function formatShortTime(timestamp) {
    const value = Number(timestamp || 0);
    if (!value) return "";
    try {
      return new Intl.DateTimeFormat(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      }).format(new Date(value * 1000));
    } catch {
      return "";
    }
  }

  function ensurePinsModal() {
    if ($("#v49PinsModal")) return;

    const modal = document.createElement("section");
    modal.id = "v49PinsModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v49PinsHeading");
    modal.innerHTML = `
      <div class="modal-card v49-pins-card">
        <header class="modal-head">
          <div><small>CONVERSATION</small><h2 id="v49PinsHeading">Pinned messages</h2></div>
          <button id="v49PinsClose" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
        </header>
        <div id="v49PinsList" class="v49-pins-list" aria-live="polite"></div>
      </div>
    `;
    document.body.appendChild(modal);
    $("#v49PinsClose", modal)?.addEventListener("click", () => app()?.closeModal?.());
  }

  async function renderPins(items) {
    ensurePinsModal();
    const list = $("#v49PinsList");
    if (!list) return;
    list.replaceChildren();

    if (!items.length) {
      const empty = document.createElement("div");
      empty.className = "v49-pins-empty";
      empty.textContent = "No pinned messages in this conversation.";
      list.appendChild(empty);
      return;
    }

    for (const item of items) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "v49-pin-row";

      const head = document.createElement("span");
      head.className = "v49-pin-row-head";

      const sender = document.createElement("strong");
      sender.textContent = String(item.sender_display_name || "SilkNex");

      const date = document.createElement("small");
      date.textContent = formatShortTime(item.created_at);
      head.append(sender, date);

      const preview = document.createElement("span");
      preview.className = "v49-pin-preview";
      preview.textContent = "Decrypting preview…";

      row.append(head, preview);
      row.addEventListener("click", () => {
        const id = Number(item.message_id || 0);
        app()?.closeModal?.();
        setTimeout(() => {
          const target = document.querySelector(
            `.message[data-message-id="${CSS.escape(String(id))}"]`
          );
          if (!target) {
            toast("That pinned message is outside the currently loaded history.");
            return;
          }
          target.scrollIntoView({ block: "center", behavior: "smooth" });
          target.classList.add("message-jump-highlight");
          setTimeout(() => target.classList.remove("message-jump-highlight"), 1800);
        }, 80);
      });

      list.appendChild(row);
      pinPreview(item)
        .then((text) => {
          preview.textContent = text;
        })
        .catch(() => {
          preview.textContent = messageFallback(item);
        });
    }
  }

  async function refreshPins({ render = false, quiet = true } = {}) {
    const cid = Number(app()?.state?.activeId || 0);
    if (!runtime.signedIn || !cid || !app()?.api) {
      runtime.pinConversationId = 0;
      runtime.pinnedIds.clear();
      updatePinButtons();
      if (render) renderPins([]);
      return [];
    }

    try {
      const data = await app().api(
        "message_pins",
        {
          showLoader: !quiet,
          timeoutMs: 6000,
        },
        { conversation_id: cid }
      );

      if (cid !== Number(app()?.state?.activeId || 0)) return [];

      const items = Array.isArray(data?.pins) ? data.pins : [];
      runtime.pinConversationId = cid;
      runtime.pinnedIds = new Set(
        items.map((item) => Number(item.message_id || 0)).filter(Boolean)
      );
      updatePinButtons();
      if (render) await renderPins(items);
      return items;
    } catch (error) {
      if (render) {
        ensurePinsModal();
        const list = $("#v49PinsList");
        if (list) list.textContent = error?.message || "Could not load pinned messages.";
      }
      return [];
    }
  }

  async function togglePin(messageId, button) {
    const cid = Number(app()?.state?.activeId || 0);
    const id = Number(messageId || 0);
    if (!cid || !id || !app()?.api || button?.disabled) return;

    if (button) button.disabled = true;
    try {
      const data = await app().api("message_pin_toggle", {
        method: "POST",
        body: {
          conversation_id: cid,
          message_id: id,
        },
        showLoader: false,
      });

      if (data?.pinned) runtime.pinnedIds.add(id);
      else runtime.pinnedIds.delete(id);
      updatePinButtons();
      toast(data?.pinned ? "Message pinned." : "Message unpinned.");

      if (!$("#v49PinsModal")?.classList.contains("hidden")) {
        await refreshPins({ render: true });
      }
    } catch (error) {
      toast(error?.message || "Could not update the pin.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  function pinButtonFor(messageId) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "message-action icon-action v49-pin-action";
    button.dataset.pinMessageId = String(messageId);
    button.title = "Pin message";
    button.setAttribute("aria-label", "Pin message");
    button.appendChild(svgIcon("pin"));
    button.addEventListener("click", () => togglePin(messageId, button));
    return button;
  }

  function readButtonFor(messageId) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "message-action icon-action v49-read-action";
    button.title = "Read aloud";
    button.setAttribute("aria-label", "Read message aloud");
    button.appendChild(svgIcon("speaker"));
    button.addEventListener("click", () => {
      const message = app()?.state?.messages?.get?.(Number(messageId));
      const text = String(message?.body || "").trim();
      if (!text || !("speechSynthesis" in window)) return;

      try {
        speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text.slice(0, 4000));
        utterance.rate = 1;
        speechSynthesis.speak(utterance);
      } catch {
        toast("Read aloud is unavailable in this browser.");
      }
    });
    return button;
  }

  function decorateMessages() {
    const state = app()?.state;
    const map = state?.messages;
    if (!(map instanceof Map)) return;

    $$("#messages .message[data-message-id]").forEach((row) => {
      const id = Number(row.dataset.messageId || 0);
      if (!id) return;

      const actions = $(".message-actions", row);
      if (!actions) return;

      if (!$(".v49-pin-action", actions)) {
        actions.appendChild(pinButtonFor(id));
      }

      const message = map.get(id);
      if (
        message?.message_type === "text" &&
        String(message?.body || "").trim() &&
        "speechSynthesis" in window &&
        !$(".v49-read-action", actions)
      ) {
        actions.appendChild(readButtonFor(id));
      }
    });

    updatePinButtons();
  }

  function updatePinButtons() {
    $$("[data-pin-message-id]").forEach((button) => {
      const id = Number(button.dataset.pinMessageId || 0);
      const pinned =
        runtime.pinConversationId === Number(app()?.state?.activeId || 0) &&
        runtime.pinnedIds.has(id);
      button.classList.toggle("selected", pinned);
      button.setAttribute("aria-pressed", pinned ? "true" : "false");
      button.title = pinned ? "Unpin message" : "Pin message";
      button.setAttribute("aria-label", pinned ? "Unpin message" : "Pin message");
    });
  }

  function startPinRefresh() {
    stopPinRefresh();

    const run = async () => {
      if (
        document.visibilityState === "visible" &&
        Number(app()?.state?.activeId || 0) > 0
      ) {
        await refreshPins({ render: false });
      }
      runtime.pinRefreshTimer = setTimeout(run, 45000);
    };

    runtime.pinRefreshTimer = setTimeout(run, 45000);
  }

  function stopPinRefresh() {
    clearTimeout(runtime.pinRefreshTimer);
    runtime.pinRefreshTimer = null;
  }

  function ensureChatUtilityControls() {
    const modal = $("#chatSettingsModal .modal-card");
    if (!modal || $("#v49ChatUtilities")) return;

    const section = document.createElement("section");
    section.id = "v49ChatUtilities";
    section.className = "settings-section v49-chat-utilities";
    section.innerHTML = `
      <div class="section-title"><span>Conversation tools</span></div>
      <div class="v49-utility-grid">
        <button id="v49OpenPinsBtn" class="secondary-btn" type="button">Pinned messages</button>
        <button id="v49CopyChatLinkBtn" class="secondary-btn" type="button">Copy chat link</button>
        <button id="v49ShareChatBtn" class="secondary-btn" type="button">Share conversation</button>
      </div>
    `;

    const header = $(".modal-head", modal);
    header?.insertAdjacentElement("afterend", section);

    $("#v49OpenPinsBtn", section)?.addEventListener("click", () => {
      ensurePinsModal();
      app()?.openModal?.("#v49PinsModal");
      refreshPins({ render: true, quiet: false });
    });

    $("#v49CopyChatLinkBtn", section)?.addEventListener("click", () => {
      const url = conversationLink();
      if (!url) {
        toast("Open a conversation first.");
        return;
      }
      copyText(url, "Conversation link copied.");
    });

    $("#v49ShareChatBtn", section)?.addEventListener("click", shareConversation);
  }

  /* ------------------------------------------------------------------ */
  /* Founder-only control center                                        */
  /* ------------------------------------------------------------------ */

  function ownerStat(label, value) {
    const card = document.createElement("div");
    card.className = "v49-owner-stat";
    const small = document.createElement("small");
    small.textContent = label;
    const strong = document.createElement("strong");
    strong.textContent = String(value ?? "—");
    card.append(small, strong);
    return card;
  }

  function formatInteger(value) {
    const n = Number(value || 0);
    try {
      return new Intl.NumberFormat().format(Number.isFinite(n) ? n : 0);
    } catch {
      return String(Number.isFinite(n) ? n : 0);
    }
  }

  function ensureOwnerUi() {
    if (!runtime.founder) return;

    let section = $("#v49OwnerSettings");
    if (!section) {
      section = document.createElement("section");
      section.id = "v49OwnerSettings";
      section.className = "settings-section v49-owner-settings";
      section.innerHTML = `
        <div class="section-title"><span>Founder controls</span></div>
        <div class="v49-owner-entry">
          <div>
            <b>SilkNex Control Center</b>
            <small>Private operational tools available only to the Founder/CEO account.</small>
          </div>
          <button id="v49OpenOwnerBtn" class="primary" type="button">Open Control Center</button>
        </div>
      `;

      const monetization = $("#monetizationSettings");
      if (monetization) monetization.insertAdjacentElement("afterend", section);
      else $("#settingsModal .settings-card")?.appendChild(section);

      $("#v49OpenOwnerBtn", section)?.addEventListener("click", () => {
        ensureOwnerModal();
        app()?.openModal?.("#v49OwnerModal");
        refreshOwnerDashboard(false);
      });
    }

    ensureOwnerModal();
  }

  function ensureOwnerModal() {
    if (!runtime.founder || $("#v49OwnerModal")) return;

    const modal = document.createElement("section");
    modal.id = "v49OwnerModal";
    modal.className = "modal hidden";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    modal.setAttribute("aria-labelledby", "v49OwnerHeading");
    modal.innerHTML = `
      <div class="modal-card v49-owner-card">
        <header class="modal-head">
          <div>
            <small>FOUNDER / CEO</small>
            <h2 id="v49OwnerHeading">SilkNex Control Center</h2>
          </div>
          <div class="v49-owner-head-actions">
            <button id="v49OwnerRefreshBtn" class="plain-btn icon-only" type="button" aria-label="Refresh dashboard"></button>
            <button id="v49OwnerCloseBtn" class="plain-btn icon-only" type="button" aria-label="Close">×</button>
          </div>
        </header>

        <section class="v49-owner-hero">
          <div class="v49-owner-crown" aria-hidden="true"></div>
          <div>
            <strong>Founder mode</strong>
            <small>Your account is ad-free and has server-side gated operational controls.</small>
          </div>
        </section>

        <section>
          <div class="section-title"><span>Live overview</span></div>
          <div id="v49OwnerStats" class="v49-owner-stats" aria-live="polite"></div>
        </section>

        <section class="v49-owner-block">
          <div class="section-title"><span>Global announcement</span></div>
          <label class="field">
            <span>Message shown to signed-in users</span>
            <textarea id="v49AnnouncementText" maxlength="280" rows="3" placeholder="Service update, new feature, planned maintenance…"></textarea>
          </label>
          <div class="v49-owner-inline">
            <label class="field v49-owner-hours">
              <span>Hours</span>
              <input id="v49AnnouncementHours" type="number" min="1" max="168" value="24">
            </label>
            <button id="v49PublishAnnouncementBtn" class="primary" type="button">Publish</button>
            <button id="v49ClearAnnouncementBtn" class="secondary-btn" type="button">Clear</button>
          </div>
        </section>

        <section class="v49-owner-block">
          <div class="section-title"><span>Registration</span></div>
          <div class="v49-owner-control-row">
            <div>
              <b id="v49RegistrationTitle">Loading…</b>
              <small id="v49RegistrationCopy">Control whether new accounts can be created.</small>
            </div>
            <button id="v49RegistrationToggle" class="secondary-btn" type="button">Toggle</button>
          </div>
        </section>

        <section class="v49-owner-block">
          <div class="section-title"><span>Security</span></div>
          <form id="v49RevokeSessionsForm" class="v49-owner-revoke">
            <label class="field">
              <span>Force a user to sign in again</span>
              <input id="v49RevokeUsername" maxlength="24" autocomplete="off" placeholder="username">
            </label>
            <button class="secondary-btn" type="submit">Revoke sessions</button>
          </form>
          <small class="v49-owner-note">This invalidates the target account's browser sessions and remember tokens without deleting messages or encryption devices.</small>
        </section>
      </div>
    `;

    document.body.appendChild(modal);

    const refreshIcon = $("#v49OwnerRefreshBtn", modal);
    refreshIcon?.appendChild(svgIcon("refresh"));
    const crown = $(".v49-owner-crown", modal);
    crown?.appendChild(svgIcon("crown"));

    $("#v49OwnerCloseBtn", modal)?.addEventListener("click", () => app()?.closeModal?.());
    $("#v49OwnerRefreshBtn", modal)?.addEventListener("click", () => refreshOwnerDashboard(false));
    $("#v49PublishAnnouncementBtn", modal)?.addEventListener("click", publishOwnerAnnouncement);
    $("#v49ClearAnnouncementBtn", modal)?.addEventListener("click", clearOwnerAnnouncement);
    $("#v49RegistrationToggle", modal)?.addEventListener("click", toggleRegistration);
    $("#v49RevokeSessionsForm", modal)?.addEventListener("submit", revokeUserSessions);
  }

  function renderOwnerDashboard(data) {
    const dashboard = data || {};
    runtime.ownerDashboard = dashboard;
    const stats = $("#v49OwnerStats");
    if (stats) {
      stats.replaceChildren(
        ownerStat("Users", formatInteger(dashboard.users_total)),
        ownerStat("Online now", formatInteger(dashboard.online_now)),
        ownerStat("Messages", formatInteger(dashboard.messages_high_water)),
        ownerStat("Conversations", formatInteger(dashboard.conversations_high_water)),
        ownerStat("Uploads", formatInteger(dashboard.uploads_high_water)),
        ownerStat("Scheduled", formatInteger(dashboard.scheduled_pending)),
        ownerStat("Active ads", formatInteger(dashboard.active_ad_campaigns)),
        ownerStat("Schema", `v${String(dashboard.schema_version || "—")}`)
      );
    }

    const registrationOpen = Boolean(dashboard.registration_open);
    const title = $("#v49RegistrationTitle");
    const copy = $("#v49RegistrationCopy");
    const button = $("#v49RegistrationToggle");
    if (title) title.textContent = registrationOpen ? "Registration is open" : "Registration is paused";
    if (copy) {
      copy.textContent = registrationOpen
        ? "New users can create accounts."
        : "Existing users can still sign in; new account creation is blocked.";
    }
    if (button) {
      button.textContent = registrationOpen ? "Pause signups" : "Open signups";
      button.dataset.registrationOpen = registrationOpen ? "true" : "false";
    }

    const announcement = dashboard.announcement;
    const text = $("#v49AnnouncementText");
    if (text && document.activeElement !== text) {
      text.value = String(announcement?.text || "");
    }
  }

  async function refreshOwnerDashboard(quiet = true) {
    if (!runtime.founder || !app()?.api) return;

    const stats = $("#v49OwnerStats");
    if (stats && !quiet) stats.setAttribute("aria-busy", "true");

    try {
      const data = await app().api("owner_dashboard", {
        showLoader: false,
        timeoutMs: 8000,
      });
      renderOwnerDashboard(data?.dashboard || {});
    } catch (error) {
      toast(error?.message || "Could not load founder controls.");
    } finally {
      stats?.removeAttribute("aria-busy");
    }
  }

  async function publishOwnerAnnouncement() {
    if (!runtime.founder) return;
    const text = String($("#v49AnnouncementText")?.value || "").trim();
    const hours = Math.min(168, Math.max(1, Number($("#v49AnnouncementHours")?.value || 24)));
    if (!text) {
      toast("Write an announcement first.");
      return;
    }

    const button = $("#v49PublishAnnouncementBtn");
    if (button) button.disabled = true;
    try {
      const data = await app().api("owner_announcement_set", {
        method: "POST",
        body: { text, hours },
        showLoader: false,
      });
      renderAnnouncement(data?.announcement || null);
      toast("Announcement published.");
      await refreshOwnerDashboard(true);
    } catch (error) {
      toast(error?.message || "Could not publish the announcement.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function clearOwnerAnnouncement() {
    if (!runtime.founder) return;
    const button = $("#v49ClearAnnouncementBtn");
    if (button) button.disabled = true;
    try {
      await app().api("owner_announcement_set", {
        method: "POST",
        body: { text: "", hours: 1 },
        showLoader: false,
      });
      const field = $("#v49AnnouncementText");
      if (field) field.value = "";
      hideAnnouncement();
      toast("Announcement cleared.");
      await refreshOwnerDashboard(true);
    } catch (error) {
      toast(error?.message || "Could not clear the announcement.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function toggleRegistration() {
    if (!runtime.founder) return;

    const currentlyOpen =
      $("#v49RegistrationToggle")?.dataset.registrationOpen === "true";
    const nextOpen = !currentlyOpen;
    const button = $("#v49RegistrationToggle");
    if (button) button.disabled = true;

    try {
      const data = await app().api("owner_registration_set", {
        method: "POST",
        body: { open: nextOpen },
        showLoader: false,
      });
      runtime.ownerDashboard = {
        ...(runtime.ownerDashboard || {}),
        registration_open: Boolean(data?.registration_open),
      };
      renderOwnerDashboard(runtime.ownerDashboard);
      toast(data?.registration_open ? "Registration opened." : "Registration paused.");
    } catch (error) {
      toast(error?.message || "Could not update registration.");
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function revokeUserSessions(event) {
    event.preventDefault();
    if (!runtime.founder) return;

    const input = $("#v49RevokeUsername");
    const username = String(input?.value || "").trim();
    if (!username) {
      toast("Enter a username.");
      return;
    }

    const submit = $("#v49RevokeSessionsForm button[type='submit']");
    if (submit) submit.disabled = true;

    try {
      const data = await app().api("owner_revoke_sessions", {
        method: "POST",
        body: { username },
        showLoader: false,
      });
      if (input) input.value = "";
      toast(`Sessions revoked for @${String(data?.username || username)}.`);
    } catch (error) {
      toast(error?.message || "Could not revoke sessions.");
    } finally {
      if (submit) submit.disabled = false;
    }
  }

  /* ------------------------------------------------------------------ */
  /* Wiring                                                              */
  /* ------------------------------------------------------------------ */

  function bindMessageObserver() {
    const box = $("#messages");
    if (!box || runtime.messageObserver) return;

    runtime.messageObserver = new MutationObserver(() => {
      requestAnimationFrame(decorateMessages);
    });

    runtime.messageObserver.observe(box, {
      childList: true,
      subtree: true,
    });

    decorateMessages();
  }

  function onConversationEvent(event) {
    const id = Number(event.detail?.id || 0);
    const loaded = Boolean(event.detail?.conversation);

    if (!id) {
      runtime.pinConversationId = 0;
      runtime.pinnedIds.clear();
      stopPinRefresh();
      updatePinButtons();
      return;
    }

    if (!loaded) return;

    runtime.pinConversationId = id;
    runtime.pinnedIds.clear();
    decorateMessages();
    refreshPins({ render: false });
    startPinRefresh();
  }

  function boot() {
    ensureAnnouncementBar();
    ensurePinsModal();
    ensureChatUtilityControls();
    bindMessageObserver();

    runtime.signedIn = Boolean(app()?.state?.me);
    runtime.founder = Boolean(app()?.state?.me?.role === "founder_ceo");
    setSignedIn(runtime.signedIn);

    window.addEventListener("silknex:session", (event) => {
      setTimeout(() => {
        setSignedIn(Boolean(event.detail?.signedIn));
      }, 0);
    });

    window.addEventListener("silknex:conversation", onConversationEvent);

    window.addEventListener("silknex:saved-message", () => {
      // Message action rows can be rebuilt around saved-state updates.
      requestAnimationFrame(decorateMessages);
    });

    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible" && runtime.signedIn) {
        refreshAnnouncement();
        if (Number(app()?.state?.activeId || 0) > 0) {
          refreshPins({ render: false });
        }
      }
    });

    window.addEventListener("online", () => {
      if (runtime.signedIn) refreshAnnouncement();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
