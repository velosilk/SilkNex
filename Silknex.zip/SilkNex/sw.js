/* SilkNex notification + fast shell service worker */
const SHELL_CACHE = "silknex-shell-v80.0";
const RUNTIME_CACHE = "silknex-runtime-v80.0";
const CORE_SHELL_ASSETS = [
  "./silknex-v77.js?v=80.0",
  "./profile-banner.js?v=80.0",
  "./reliability.css?v=80.0",
  "./feature-modules.js?v=80.0",
  "./media.js?v=80.0",
  "./compatibility.js?v=80.0",
  "./",
  "./boot.js?v=80.0",
  "./style.css?v=80.0",
  "./e2ee.js?v=80.0",
  "./app.js?v=80.0",
  "./community.js?v=80.0",
  "./school-words.json?v=80.0",
  "./access-block.js?v=80.0",
  "./keyboard-full.js?v=80.0",
  "./silknex-features.js?v=80.0",
  "./silknex-flow.js?v=80.0",
  "./silknex-v76.js?v=80.0",
  "./app-icon-black.png?v=80.0"
];

const OPTIONAL_SHELL_ASSETS = [
  "./manifest.webmanifest",
  "./manifest-dark.webmanifest",
  "./manifest-light.webmanifest",
  "./app-icon-black.png",
  "./app-icon-white.png",
  "./app-icon-black-192.png",
  "./app-icon-white-192.png",
  "./app-icon-black-512.png",
  "./app-icon-white-512.png",
  "./app-icon-black-maskable.png",
  "./app-icon-white-maskable.png",
  "./app-icon-black-maskable-512.png",
  "./app-icon-white-maskable-512.png",
  "./app-icon-dark-192.png",
  "./app-icon-light-192.png",
  "./favicon-dark-32.png",
  "./favicon-light-32.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(SHELL_CACHE);

    // Do not activate a half-installed app shell. Core HTML/CSS/JS/branding
    // must all be present; optional install metadata/icons can recover on the
    // next network request without breaking the app itself.
    await cache.addAll(
      CORE_SHELL_ASSETS.map((asset) => new Request(asset, { cache: "reload" }))
    );
    await Promise.all(
      OPTIONAL_SHELL_ASSETS.map(
        (asset) => cache.add(new Request(asset, { cache: "reload" })).catch(() => undefined)
      )
    );
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter(
          (key) =>
            (key.startsWith("neochat-shell-")) ||
            (key.startsWith("neochat-runtime-")) ||
            (key.startsWith("silknex-shell-") && key !== SHELL_CACHE) ||
            (key.startsWith("silknex-runtime-") && key !== RUNTIME_CACHE)
        )
        .map((key) => caches.delete(key))
    );
    if (self.registration.navigationPreload) {
      await self.registration.navigationPreload.enable().catch(() => {});
    }
    await self.clients.claim();
  })());
});

const STATIC_DESTINATIONS = new Set(["script", "style", "image", "font", "manifest"]);
const STATIC_EXTENSIONS = /\.(?:js|css|webp|png|jpg|jpeg|gif|svg|ico|woff2?|webmanifest)$/i;

function isRuntimeCacheable(request, url) {
  if (url.pathname.endsWith("/school-words.json")) return true;
  if (!STATIC_DESTINATIONS.has(request.destination || "")) {
    return STATIC_EXTENSIONS.test(url.pathname);
  }
  return true;
}

async function trimRuntimeCache(maxEntries = 40) {
  const cache = await caches.open(RUNTIME_CACHE);
  const keys = await cache.keys();
  if (keys.length <= maxEntries) return;

  await Promise.all(
    keys.slice(0, keys.length - maxEntries).map((request) => cache.delete(request))
  );
}

async function cachedResponse(cacheName, request) {
  try { return await (await caches.open(cacheName)).match(request); }
  catch { return undefined; }
}

async function storeResponse(cacheName, request, response) {
  try {
    const cache = await caches.open(cacheName);
    await cache.put(request, response);
    if (cacheName === RUNTIME_CACHE) await trimRuntimeCache();
  } catch {
    // Private browsing, full disks and denied persistence must not block use.
  }
}

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.endsWith("/api.php") || url.pathname.includes("/uploads/") || url.pathname.includes("/private/")) return;

  if (request.mode === "navigate") {
    const root = new URL("./", self.location.href);
    // Never cache unrelated PHP pages as the app's offline shell.
    if (![root.pathname, root.pathname + "index.php", root.pathname + "index.html"].includes(url.pathname)) return;
    event.respondWith((async () => {
      const network = (async () => {
        try {
          let preload;
          try { preload = await event.preloadResponse; } catch {}
          const response = preload || await fetch(request, { cache: "no-cache" });
          if (response.ok) event.waitUntil(storeResponse(SHELL_CACHE, "./", response.clone()));
          return response;
        } catch { return null; }
      })();
      // Finish the cache refresh even when a slow network loses to the shell.
      event.waitUntil(network.then(() => undefined));
      let timer;
      const deadline = new Promise(resolve => { timer = setTimeout(() => resolve(null), 4000); });
      const response = await Promise.race([network, deadline]);
      clearTimeout(timer);
      if (response && response.status < 500) return response;
      const cached = await cachedResponse(SHELL_CACHE, "./");
      if (cached) return cached;
      return response || await network || Response.error();
    })());
    return;
  }

  if (!isRuntimeCacheable(request, url)) return;
  event.respondWith((async () => {
    const shell = await cachedResponse(SHELL_CACHE, request);
    if (shell) return shell;
    const cached = await cachedResponse(RUNTIME_CACHE, request);
    if (cached) return cached;
    const response = await fetch(request);
    // Avoid caching large static media; message files and API responses are
    // already excluded above. Existing entry-count limits still apply.
    const length = Number(response.headers.get("Content-Length") || 0);
    if (response.ok && response.type !== "opaque" && length <= 2 * 1024 * 1024) {
      event.waitUntil(storeResponse(RUNTIME_CACHE, request, response.clone()));
    }
    return response;
  })());
});

self.addEventListener("push", (event) => {
  let data = {};

  try {
    data = event.data?.json?.() || {};
  } catch {
    data = { body: event.data?.text?.() || "New SilkNex message" };
  }

  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({
      type: "window",
      includeUncontrolled: true,
    });

    const kind = data.data?.type || "message";
    const isCall = kind === "call";
    const visibleClient = windows.find(
      (client) => client.visibilityState === "visible"
    );

    // Wake every open SilkNex window for calls so an already-open PWA can
    // begin its in-app ringtone immediately, even before the next poll.
    const wakeTargets = isCall ? windows : (visibleClient ? [visibleClient] : []);
    for (const client of wakeTargets) {
      client.postMessage({
        type: "push-wakeup",
        push: data,
      });
    }

    if (visibleClient) return;

    const options = {
      body: data.body || (isCall ? "Incoming call" : "New message"),
      icon: data.icon || data.data?.avatar_url || "app-icon-black.png",
      badge: data.badge || "app-icon-black.png",
      tag: data.tag || (isCall ? "silknex-call" : "silknex-message"),
      renotify: true,
      silent: false,
      requireInteraction: isCall,
      timestamp: Date.now(),
      vibrate: isCall
        ? [450, 180, 450, 180, 700, 350, 450, 180, 450]
        : [180, 90, 180],
      data: data.data || {},
    };

    if (isCall) {
      options.actions = [
        { action: "open-call", title: "Answer" },
        { action: "dismiss-call", title: "Dismiss" },
      ];
    }

    await self.registration.showNotification(data.title || "SilkNex", options);
  })());
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  if (event.action === "dismiss-call") {
    return;
  }

  const notificationData = event.notification?.data || {};
  const conversationId = Number(notificationData.conversation_id || 0);
  const notificationType = String(notificationData.type || "");

  event.waitUntil((async () => {
    const windows = await self.clients.matchAll({
      type: "window",
      includeUncontrolled: true,
    });

    for (const client of windows) {
      if ("focus" in client) {
        await client.focus();

        if (notificationData.active_call) {
          client.postMessage({
            type: "restore-call",
            call_id: Number(notificationData.call_id || 0),
            conversation_id: conversationId,
          });
        } else if (event.action === "open-call" && notificationType === "call") {
          client.postMessage({
            type: "answer-call",
            call_id: Number(notificationData.call_id || 0),
            conversation_id: conversationId,
          });
        } else if (conversationId) {
          client.postMessage({ conversation_id: conversationId });
        } else if (notificationType === "friend_request" || notificationType === "friend_accepted") {
          client.postMessage({ type: "open-friends" });
        }

        return;
      }
    }

    const params = new URLSearchParams();
    if (conversationId) {
      params.set("conversation", String(conversationId));
    }
    if (
      event.action === "open-call" &&
      notificationType === "call" &&
      Number(notificationData.call_id || 0) > 0
    ) {
      params.set("answer_call", String(Number(notificationData.call_id)));
    } else if (notificationType === "friend_request" || notificationType === "friend_accepted") {
      params.set("friends", "1");
    }

    const startupQuery = params.toString();
    const path = startupQuery
      ? `./?${startupQuery}`
      : "./";

    // Encode startup intent in the URL. A freshly opened document may not have
    // registered its service-worker message handler yet, so delayed
    // postMessage delivery is inherently racy on slower phones.
    await self.clients.openWindow(path);
  })());
});
