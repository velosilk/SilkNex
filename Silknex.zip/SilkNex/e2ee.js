(() => {
  "use strict";

  const DB_NAME = "silknex-e2ee-v1";
  const DB_VERSION = 1;
  const STORE = "identity";
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  let identityPromise = null;
  const deviceCache = new Map();
  const mediaUrlCache = new Map();
  const mediaPromiseCache = new Map();
  const publicKeyCache = new Map();
  const wrappingKeyCache = new Map();
  const DEVICE_MEMORY_GB = Number(navigator.deviceMemory || 0);
  const LOW_MEMORY_DEVICE = DEVICE_MEMORY_GB > 0 && DEVICE_MEMORY_GB <= 4;
  const MAX_CRYPTO_CACHE = LOW_MEMORY_DEVICE ? 64 : 128;
  const MEDIA_CHUNK_BYTES = LOW_MEMORY_DEVICE ? 512 * 1024 : 1024 * 1024;
  const MEDIA_CHUNK_THRESHOLD = 2 * MEDIA_CHUNK_BYTES;

  function b64u(bytes) {
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    let binary = "";
    for (let i = 0; i < u8.length; i += 0x8000) {
      binary += String.fromCharCode(...u8.subarray(i, i + 0x8000));
    }
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }

  function unb64u(value) {
    const raw = String(value || "").replace(/-/g, "+").replace(/_/g, "/");
    const padded = raw + "=".repeat((4 - raw.length % 4) % 4);
    const binary = atob(padded);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }


  function validateB64uBytes(value, { exact = 0, min = 0, max = Infinity } = {}) {
    const raw = String(value || "").replace(/=+$/g, "");
    if (!raw || !/^[A-Za-z0-9_-]+$/.test(raw) || raw.length % 4 === 1) return false;
    try {
      const bytes = unb64u(raw);
      if (exact && bytes.length !== exact) return false;
      if (bytes.length < min || bytes.length > max) return false;
      return b64u(bytes) === raw;
    } catch {
      return false;
    }
  }

  function assertEnvelopeShape(envelope) {
    if (!envelope || envelope.v !== 1) throw new Error("Could not prepare secure message.");
    if (!validateB64uBytes(envelope.iv, { exact: 12 })) {
      throw new Error("Could not prepare secure message IV.");
    }
    if (!validateB64uBytes(envelope.ciphertext, { min: 16, max: 393216 })) {
      throw new Error("Could not prepare secure message ciphertext.");
    }
    if (!Array.isArray(envelope.wraps) || envelope.wraps.length < 1) {
      throw new Error("Secure message has no recipient keys.");
    }
    for (const wrap of envelope.wraps) {
      if (
        !/^[a-f0-9]{32}$/.test(String(wrap?.device_id || "")) ||
        !validateB64uBytes(wrap?.iv, { exact: 12 }) ||
        !validateB64uBytes(wrap?.ciphertext, { exact: 48 })
      ) {
        throw new Error("Could not prepare a recipient encryption key.");
      }
    }
    return envelope;
  }

  function randomBytes(size) {
    const bytes = new Uint8Array(size);
    crypto.getRandomValues(bytes);
    return bytes;
  }

  function randomId(size = 16) {
    return [...randomBytes(size)].map((n) => n.toString(16).padStart(2, "0")).join("");
  }

  function rememberCryptoCache(cache, key, value) {
    if (cache.has(key)) cache.delete(key);
    cache.set(key, value);
    while (cache.size > MAX_CRYPTO_CACHE) {
      const oldest = cache.keys().next().value;
      if (oldest === undefined) break;
      cache.delete(oldest);
    }
    return value;
  }

  async function concurrentMap(items, limit, mapper) {
    const source = Array.isArray(items) ? items : [];
    const results = new Array(source.length);
    let next = 0;

    async function worker() {
      while (true) {
        const index = next++;
        if (index >= source.length) return;
        results[index] = await mapper(source[index], index);
      }
    }

    await Promise.all(
      Array.from(
        { length: Math.min(Math.max(1, Number(limit) || 1), Math.max(1, source.length)) },
        () => worker()
      )
    );
    return results;
  }

  function openDb() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      let settled = false;

      const fail = (error) => {
        if (settled) return;
        settled = true;
        reject(error || new Error("Could not open encrypted key storage."));
      };

      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains(STORE)) {
          request.result.createObjectStore(STORE);
        }
      };
      request.onsuccess = () => {
        if (settled) {
          try { request.result.close(); } catch {}
          return;
        }
        settled = true;
        resolve(request.result);
      };
      request.onerror = () => fail(request.error);
      request.onblocked = () => fail(
        new Error("Secure key storage is busy in another SilkNex tab. Close older tabs and try again.")
      );
    });
  }

  async function idbGet(key) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      let settled = false;
      const tx = db.transaction(STORE, "readonly");
      const req = tx.objectStore(STORE).get(key);

      const finish = (fn, value) => {
        if (settled) return;
        settled = true;
        try { db.close(); } catch {}
        fn(value);
      };

      req.onsuccess = () => finish(resolve, req.result);
      req.onerror = () => finish(reject, req.error || tx.error);
      tx.onabort = () => finish(reject, tx.error || new Error("Secure key storage read was cancelled."));
      tx.onerror = () => finish(reject, tx.error || new Error("Secure key storage read failed."));
    });
  }

  async function idbPut(key, value) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      let settled = false;
      const tx = db.transaction(STORE, "readwrite");

      const finish = (fn, value) => {
        if (settled) return;
        settled = true;
        try { db.close(); } catch {}
        fn(value);
      };

      try {
        tx.objectStore(STORE).put(value, key);
      } catch (error) {
        finish(reject, error);
        return;
      }

      tx.oncomplete = () => finish(resolve);
      tx.onabort = () => finish(reject, tx.error || new Error("Secure key storage write was cancelled."));
      tx.onerror = () => finish(reject, tx.error || new Error("Secure key storage write failed."));
    });
  }

  async function identity() {
    if (identityPromise) return identityPromise;

    const pending = (async () => {
      if (!window.isSecureContext || !crypto?.subtle) {
        throw new Error("End-to-end encryption requires HTTPS.");
      }

      const saved = await idbGet("device");
      if (saved?.device_id && saved?.private_key && saved?.public_jwk) {
        return {
          device_id: saved.device_id,
          privateKey: saved.private_key,
          public_jwk: saved.public_jwk,
        };
      }

      // Older SilkNex builds stored an exportable private JWK. Import it as a
      // non-extractable CryptoKey and immediately overwrite the legacy record.
      if (saved?.device_id && saved?.private_jwk && saved?.public_jwk) {
        const privateKey = await crypto.subtle.importKey(
          "jwk", saved.private_jwk, { name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]
        );
        await idbPut("device", {
          device_id: saved.device_id,
          private_key: privateKey,
          public_jwk: saved.public_jwk,
          created_at: Number(saved.created_at || Date.now()),
          hardened_at: Date.now(),
        });
        return {
          device_id: saved.device_id,
          privateKey,
          public_jwk: saved.public_jwk,
        };
      }

      // WebCrypto needs the freshly generated pair to be extractable long
      // enough to export the public component. Re-import the private component
      // as non-extractable before anything is persisted.
      const pair = await crypto.subtle.generateKey(
        { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]
      );
      const [privateJwk, publicJwk] = await Promise.all([
        crypto.subtle.exportKey("jwk", pair.privateKey),
        crypto.subtle.exportKey("jwk", pair.publicKey),
      ]);
      const privateKey = await crypto.subtle.importKey(
        "jwk", privateJwk, { name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]
      );
      const record = {
        device_id: randomId(16),
        private_key: privateKey,
        public_jwk: publicJwk,
        created_at: Date.now(),
      };
      await idbPut("device", record);
      return { device_id: record.device_id, privateKey, public_jwk: publicJwk };
    })();

    identityPromise = pending;
    try {
      return await pending;
    } catch (error) {
      // IndexedDB can fail transiently after a mobile OS restores a tab. Do
      // not permanently poison every future E2EE operation with one rejection.
      if (identityPromise === pending) identityPromise = null;
      throw error;
    }
  }

  async function register(api) {
    const id = await identity();
    const label = `${navigator.platform || "Web"} · ${navigator.userAgentData?.mobile ? "Mobile" : "Browser"}`;
    await api("e2ee_device_register", {
      method: "POST",
      body: {
        device_id: id.device_id,
        public_key_jwk: id.public_jwk,
        label: label.slice(0, 80),
      },
    });
    return id;
  }

  async function getDevices(api, conversationId, refresh = false) {
    const cid = Number(conversationId || 0);
    if (!cid) throw new Error("Conversation is missing.");
    const cached = deviceCache.get(cid);
    if (!refresh && cached && Date.now() - cached.at < 30000) return cached.data;
    const data = await api("e2ee_devices", {}, { conversation_id: cid });
    deviceCache.set(cid, { at: Date.now(), data });
    return data;
  }

  function publicKeyCacheKey(jwk) {
    return [
      String(jwk?.kty || ""),
      String(jwk?.crv || ""),
      String(jwk?.x || ""),
      String(jwk?.y || ""),
    ].join("|");
  }

  async function importPublic(jwk) {
    const cacheKey = publicKeyCacheKey(jwk);
    if (publicKeyCache.has(cacheKey)) return publicKeyCache.get(cacheKey);
    const key = await crypto.subtle.importKey(
      "jwk", jwk, { name: "ECDH", namedCurve: "P-256" }, false, []
    );
    return rememberCryptoCache(publicKeyCache, cacheKey, key);
  }

  async function deriveWrappingKey(
    id,
    peerJwk,
    conversationId,
    senderDeviceId,
    recipientDeviceId
  ) {
    const peerKeyId = publicKeyCacheKey(peerJwk);
    const cacheKey = [
      Number(conversationId),
      String(senderDeviceId || ""),
      String(recipientDeviceId || ""),
      peerKeyId,
    ].join("|");

    if (wrappingKeyCache.has(cacheKey)) return wrappingKeyCache.get(cacheKey);

    const publicKey = await importPublic(peerJwk);
    const shared = await crypto.subtle.deriveBits(
      { name: "ECDH", public: publicKey }, id.privateKey, 256
    );
    const hkdfBase = await crypto.subtle.importKey("raw", shared, "HKDF", false, ["deriveKey"]);
    const info = encoder.encode(
      `silknex-e2ee-wrap-v1|${Number(conversationId)}|${senderDeviceId}|${recipientDeviceId}`
    );
    const wrappingKey = await crypto.subtle.deriveKey(
      {
        name: "HKDF",
        hash: "SHA-256",
        salt: encoder.encode("SilkNex E2EE v1"),
        info,
      },
      hkdfBase,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );

    return rememberCryptoCache(wrappingKeyCache, cacheKey, wrappingKey);
  }

  async function wrapKeyForDevice(id, recipient, conversationId, contentKeyRaw) {
    const wrappingKey = await deriveWrappingKey(
      id,
      recipient.public_key_jwk,
      conversationId,
      id.device_id,
      recipient.device_id
    );
    const iv = randomBytes(12);
    const aad = encoder.encode(`silknex-key-wrap-v1|${recipient.device_id}`);
    const cipher = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv, additionalData: aad }, wrappingKey, contentKeyRaw
    );
    return {
      device_id: recipient.device_id,
      user_id: Number(recipient.user_id || 0),
      iv: b64u(iv),
      ciphertext: b64u(cipher),
    };
  }

  async function encryptPayload(api, conversationId, nonce, payload) {
    const id = await identity();
    const deviceData = await getDevices(api, conversationId, true);
    const devices = Array.isArray(deviceData.devices) ? deviceData.devices : [];
    const missing = Array.isArray(deviceData.missing_user_ids) ? deviceData.missing_user_ids : [];

    if (missing.length) {
      const err = new Error("Secure messaging is waiting for every participant to open the latest SilkNex once.");
      err.code = "e2ee_missing_devices";
      throw err;
    }
    if (!devices.length) throw new Error("No encryption devices are available for this chat.");

    const contentKeyRaw = randomBytes(32);
    const contentKey = await crypto.subtle.importKey("raw", contentKeyRaw, "AES-GCM", false, ["encrypt"]);
    const iv = randomBytes(12);
    const aadText = `silknex-message-v1|${Number(conversationId)}|${String(nonce || "")}`;
    const plain = encoder.encode(JSON.stringify(payload || {}));
    const cipher = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv, additionalData: encoder.encode(aadText) },
      contentKey,
      plain
    );
    const wraps = await concurrentMap(
      devices,
      8,
      (recipient) => wrapKeyForDevice(id, recipient, conversationId, contentKeyRaw)
    );

    const envelope = assertEnvelopeShape({
      v: 1,
      alg: "P-256+HKDF-SHA256+A256GCM",
      sender_device_id: id.device_id,
      sender_public_jwk: id.public_jwk,
      nonce: String(nonce || ""),
      iv: b64u(iv),
      ciphertext: b64u(cipher),
      wraps,
    });
    return JSON.stringify(envelope);
  }

  async function decryptEnvelope(envelope, conversationId) {
    const id = await identity();
    const parsed = typeof envelope === "string" ? JSON.parse(envelope) : envelope;
    if (!parsed || Number(parsed.v) !== 1 || !parsed.sender_public_jwk) {
      throw new Error("Unsupported encrypted message.");
    }
    const wrap = (Array.isArray(parsed.wraps) ? parsed.wraps : [])
      .find((item) => String(item.device_id || "") === id.device_id);
    if (!wrap) {
      const error = new Error("Encrypted on another device.");
      error.code = "e2ee_no_device_wrap";
      throw error;
    }

    const wrappingKey = await deriveWrappingKey(
      id,
      parsed.sender_public_jwk,
      conversationId,
      parsed.sender_device_id,
      id.device_id
    );
    const rawKey = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: unb64u(wrap.iv),
        additionalData: encoder.encode(`silknex-key-wrap-v1|${id.device_id}`),
      },
      wrappingKey,
      unb64u(wrap.ciphertext)
    );
    const contentKey = await crypto.subtle.importKey("raw", rawKey, "AES-GCM", false, ["decrypt"]);
    const aadText = `silknex-message-v1|${Number(conversationId)}|${String(parsed.nonce || "")}`;
    const plain = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: unb64u(parsed.iv),
        additionalData: encoder.encode(aadText),
      },
      contentKey,
      unb64u(parsed.ciphertext)
    );
    return JSON.parse(decoder.decode(plain));
  }

  async function decryptMessage(message) {
    if (!message?.e2ee_payload) return message;
    try {
      const payload = await decryptEnvelope(message.e2ee_payload, message.conversation_id);
      return {
        ...message,
        body: String(payload?.text || ""),
        e2ee_meta: payload || {},
        e2ee_decryption_error: "",
      };
    } catch (error) {
      return {
        ...message,
        body: error?.code === "e2ee_no_device_wrap"
          ? "🔒 Encrypted on another device"
          : "🔒 Unable to decrypt message",
        e2ee_meta: null,
        e2ee_decryption_error: error?.message || "Unable to decrypt",
      };
    }
  }

  async function decryptMessages(messages) {
    const source = Array.isArray(messages) ? messages : [];
    // Decrypting dozens of ECDH/AES envelopes at once can stall lower-end
    // phones. A small worker pool keeps scrolling/input responsive while still
    // completing a normal page quickly.
    return concurrentMap(source, LOW_MEMORY_DEVICE ? 3 : 6, decryptMessage);
  }

  async function encryptFile(file) {
    if (!(file instanceof Blob)) throw new Error("No file selected.");

    const rawKey = randomBytes(32);
    const key = await crypto.subtle.importKey(
      "raw",
      rawKey,
      "AES-GCM",
      false,
      ["encrypt"]
    );
    const safeName = String(file.name || "attachment").slice(0, 180);
    const commonMeta = {
      key: b64u(rawKey),
      mime: String(file.type || "application/octet-stream").slice(0, 120),
      name: safeName,
      size: Number(file.size || 0),
    };

    if (file.size <= MEDIA_CHUNK_THRESHOLD) {
      const iv = randomBytes(12);
      const source = await file.arrayBuffer();
      const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, source);
      return {
        blob: new Blob([encrypted], { type: "application/octet-stream" }),
        meta: {
          ...commonMeta,
          v: 1,
          iv: b64u(iv),
        },
      };
    }

    // Large video/audio attachments are encrypted a chunk at a time so a
    // 40 MB upload does not require a second 40 MB plaintext ArrayBuffer plus
    // the full ciphertext at the same instant on a phone.
    const parts = [];
    const chunks = [];
    const total = Math.ceil(file.size / MEDIA_CHUNK_BYTES);

    for (let index = 0; index < total; index += 1) {
      const start = index * MEDIA_CHUNK_BYTES;
      const end = Math.min(file.size, start + MEDIA_CHUNK_BYTES);
      const source = await file.slice(start, end).arrayBuffer();
      const iv = randomBytes(12);
      const aad = encoder.encode(
        `silknex-media-v2|${index}|${total}|${Number(file.size || 0)}`
      );
      const encrypted = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv, additionalData: aad },
        key,
        source
      );
      parts.push(new Blob([encrypted], { type: "application/octet-stream" }));
      chunks.push({
        iv: b64u(iv),
        size: encrypted.byteLength,
      });
    }

    return {
      blob: new Blob(parts, { type: "application/octet-stream" }),
      meta: {
        ...commonMeta,
        v: 2,
        chunk_size: MEDIA_CHUNK_BYTES,
        chunks,
      },
    };
  }

  async function decryptMediaToUrlUncached(message) {
    const id = Number(message?.id || 0);
    if (id && mediaUrlCache.has(id)) return mediaUrlCache.get(id);
    const meta = message?.e2ee_meta?.media;
    const url = String(message?.attachment_url || "");
    if (!meta?.key || !url) return url;

    const response = await fetch(url, {
      credentials: "same-origin",
      cache: "force-cache",
    });
    if (!response.ok) throw new Error("Could not load encrypted media.");

    const key = await crypto.subtle.importKey(
      "raw",
      unb64u(meta.key),
      "AES-GCM",
      false,
      ["decrypt"]
    );

    let plainBlob;
    if (Number(meta.v || 1) >= 2 && Array.isArray(meta.chunks) && meta.chunks.length) {
      const encryptedBlob = await response.blob();
      const total = meta.chunks.length;
      const expectedPlainSize = Math.max(0, Number(meta.size || 0));
      const parts = [];
      let offset = 0;

      for (let index = 0; index < total; index += 1) {
        const chunk = meta.chunks[index] || {};
        const encryptedSize = Math.max(17, Number(chunk.size || 0));
        if (!chunk.iv || offset + encryptedSize > encryptedBlob.size) {
          throw new Error("Encrypted media is incomplete.");
        }

        const encrypted = await encryptedBlob
          .slice(offset, offset + encryptedSize)
          .arrayBuffer();
        const aad = encoder.encode(
          `silknex-media-v2|${index}|${total}|${expectedPlainSize}`
        );
        const plain = await crypto.subtle.decrypt(
          {
            name: "AES-GCM",
            iv: unb64u(chunk.iv),
            additionalData: aad,
          },
          key,
          encrypted
        );
        parts.push(new Blob([plain]));
        offset += encryptedSize;
      }

      if (offset !== encryptedBlob.size) {
        throw new Error("Encrypted media has unexpected trailing data.");
      }
      plainBlob = new Blob(parts, {
        type: meta.mime || "application/octet-stream",
      });
    } else {
      if (!meta.iv) throw new Error("Encrypted media metadata is incomplete.");
      const encrypted = await response.arrayBuffer();
      const plain = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: unb64u(meta.iv) },
        key,
        encrypted
      );
      plainBlob = new Blob([plain], {
        type: meta.mime || "application/octet-stream",
      });
    }

    const objectUrl = URL.createObjectURL(plainBlob);
    if (id) mediaUrlCache.set(id, objectUrl);
    return objectUrl;
  }

  async function decryptMediaToUrl(message) {
    const id = Number(message?.id || 0);
    if (id && mediaUrlCache.has(id)) return mediaUrlCache.get(id);
    if (id && mediaPromiseCache.has(id)) return mediaPromiseCache.get(id);

    const pending = decryptMediaToUrlUncached(message);
    if (id) mediaPromiseCache.set(id, pending);

    try {
      return await pending;
    } finally {
      if (id && mediaPromiseCache.get(id) === pending) {
        mediaPromiseCache.delete(id);
      }
    }
  }

  async function decryptFile(url, mediaMeta) {
    return decryptMediaToUrl({
      attachment_url: String(url || ""),
      e2ee_meta: { media: mediaMeta || {} },
    });
  }

  function releaseMediaUrl(messageId) {
    const id = Number(messageId || 0);
    if (!id) return;
    const url = mediaUrlCache.get(id);
    if (url) {
      try { URL.revokeObjectURL(url); } catch {}
      mediaUrlCache.delete(id);
    }
    mediaPromiseCache.delete(id);
  }

  function clearMediaUrls() {
    for (const url of mediaUrlCache.values()) {
      try { URL.revokeObjectURL(url); } catch {}
    }
    mediaUrlCache.clear();
    mediaPromiseCache.clear();
  }

  function clearDeviceKeyCache() {
    deviceCache.clear();
    publicKeyCache.clear();
    wrappingKeyCache.clear();
  }

  function clearMediaCache() {
    clearMediaUrls();
    clearDeviceKeyCache();
  }

  window.SilknexE2EE = Object.freeze({
    ready: identity,
    register,
    getDevices,
    encryptPayload,
    decryptEnvelope,
    decryptMessage,
    decryptMessages,
    encryptFile,
    decryptMediaToUrl,
    decryptFile,
    releaseMediaUrl,
    clearMediaUrls,
    clearDeviceKeyCache,
    clearMediaCache,
  });
})();
