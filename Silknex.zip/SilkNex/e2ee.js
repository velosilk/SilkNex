(() => {
  "use strict";

  const DB_NAME = "silknex-e2ee-v1";
  const DB_VERSION = 1;
  const STORE = "identity";
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  let identityPromise = null;
  const deviceCache = new Map();
  let deviceEpoch = 0;
  const mediaUrlCache = new Map();
  const mediaUrlMetaCache = new Map();
  const playingMedia = new Set();
  const mediaPromiseCache = new Map();
  const mediaTickets = new Map();
  const allMediaTickets = new Set();
  let mediaEpoch = 0;
  let activeMediaJobs = 0;
  const mediaJobs = [];
  const publicKeyCache = new Map();
  const wrappingKeyCache = new Map();
  const DEVICE_MEMORY_GB = Number(navigator.deviceMemory || 0);
  const LOW_MEMORY_DEVICE =
    (DEVICE_MEMORY_GB > 0 && DEVICE_MEMORY_GB <= 4) ||
    navigator.connection?.saveData === true ||
    (DEVICE_MEMORY_GB === 0 && Number(navigator.maxTouchPoints || 0) > 0);
  // v61: keep SilkNex-owned crypto/media caches intentionally small. Decoded
  // image/video surfaces live outside the JS heap, so leaving tens of MB of
  // decrypted blobs cached at the same time causes avoidable mobile pressure.
  const MAX_CRYPTO_CACHE = LOW_MEMORY_DEVICE ? 12 : 24;
  const MAX_MEDIA_CACHE_ITEMS = LOW_MEMORY_DEVICE ? 2 : 4;
  const MAX_MEDIA_CACHE_BYTES = LOW_MEMORY_DEVICE ? 4 * 1024 * 1024 : 8 * 1024 * 1024;
  const MEDIA_CHUNK_BYTES = LOW_MEMORY_DEVICE ? 256 * 1024 : 512 * 1024;
  const MEDIA_CHUNK_THRESHOLD = 2 * MEDIA_CHUNK_BYTES;

  function b64u(bytes) {
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    let binary = "";
    for (let i = 0; i < u8.length; i += 0x8000) {
      binary += String.fromCharCode(...u8.subarray(i, i + 0x8000));
    }
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  }

  function unb64u(value) {
    const raw = String(value || "").replace(/-/g, "+").replace(/_/g, "/");
    const padded = raw + "=".repeat((4 - raw.length % 4) % 4);
    const binary = atob(padded);
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
    return out;
  }


  function validateB64uBytes(value, { exact = 0, min = 0, max = Infinity } = {}) {
    const raw = String(value || "").replace(/=+$/g, "");
    if (!raw || !/^[A-Za-z0-9_-]+$/.test(raw) || raw.length % 4 === 1) return false;
    try {
      const bytes = unb64u(raw);
      if (exact && bytes.length !== exact) return false;
      if (bytes.length < min || bytes.length > max) return false;
      return b64u(bytes) === raw;
    } catch {
      return false;
    }
  }

  function assertEnvelopeShape(envelope) {
    const version = Number(envelope?.v || 0);
    if (!envelope || ![1, 2].includes(version)) {
      throw new Error("Could not prepare secure message.");
    }
    if (String(envelope.alg || "") !== "P-256+HKDF-SHA256+A256GCM") {
      throw new Error("Unsupported secure message algorithm.");
    }
    if (
      !/^[a-f0-9]{32}$/.test(String(envelope.sender_device_id || "")) ||
      !envelope.sender_public_jwk ||
      typeof envelope.sender_public_jwk !== "object"
    ) {
      throw new Error("Could not prepare secure sender identity.");
    }
    if (
      typeof envelope.nonce !== "string" ||
      envelope.nonce.length < 1 ||
      envelope.nonce.length > 128 ||
      /[\x00-\x1F\x7F]/.test(envelope.nonce)
    ) {
      throw new Error("Could not prepare secure message nonce.");
    }
    if (version >= 2 && !validateB64uBytes(envelope.salt, { exact: 16 })) {
      throw new Error("Could not prepare secure message salt.");
    }
    if (!validateB64uBytes(envelope.iv, { exact: 12 })) {
      throw new Error("Could not prepare secure message IV.");
    }
    if (!validateB64uBytes(envelope.ciphertext, { min: 16, max: 393216 })) {
      throw new Error("Could not prepare secure message ciphertext.");
    }
    if (!Array.isArray(envelope.wraps) || envelope.wraps.length < 1 || envelope.wraps.length > 250) {
      throw new Error("Secure message has an invalid recipient-key set.");
    }

    const seen = new Set();
    for (const wrap of envelope.wraps) {
      const deviceId = String(wrap?.device_id || "");
      if (
        !/^[a-f0-9]{32}$/.test(deviceId) ||
        seen.has(deviceId) ||
        !validateB64uBytes(wrap?.iv, { exact: 12 }) ||
        !validateB64uBytes(wrap?.ciphertext, { exact: 48 })
      ) {
        throw new Error("Could not prepare a recipient encryption key.");
      }
      if (version >= 2 && (!Number.isSafeInteger(Number(wrap?.user_id)) || Number(wrap.user_id) <= 0)) {
        throw new Error("Could not bind a recipient encryption key.");
      }
      seen.add(deviceId);
    }
    return envelope;
  }

  function randomBytes(size) {
    const bytes = new Uint8Array(size);
    crypto.getRandomValues(bytes);
    return bytes;
  }

  function randomId(size = 16) {
    return [...randomBytes(size)].map((n) => n.toString(16).padStart(2, "0")).join("");
  }

  function rememberCryptoCache(cache, key, value) {
    if (cache.has(key)) cache.delete(key);
    cache.set(key, value);
    while (cache.size > MAX_CRYPTO_CACHE) {
      const oldest = cache.keys().next().value;
      if (oldest === undefined) break;
      cache.delete(oldest);
    }
    return value;
  }

  async function concurrentMap(items, limit, mapper) {
    const source = Array.isArray(items) ? items : [];
    const results = new Array(source.length);
    let next = 0;

    async function worker() {
      while (true) {
        const index = next++;
        if (index >= source.length) return;
        results[index] = await mapper(source[index], index);
      }
    }

    await Promise.all(
      Array.from(
        { length: Math.min(Math.max(1, Number(limit) || 1), Math.max(1, source.length)) },
        () => worker()
      )
    );
    return results;
  }

  function openDb() {
    return new Promise((resolve, reject) => {
      let settled = false;
      let request;
      const timeout = setTimeout(() => fail(new Error("Secure key storage did not respond. Reopen Silknex and try again.")), 12000);
      const fail = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        reject(error || new Error("Could not open encrypted key storage."));
      };
      try { request = indexedDB.open(DB_NAME, DB_VERSION); }
      catch (error) { fail(error); return; }
      request.onupgradeneeded = () => {
        if (settled) { try { request.transaction.abort(); } catch {} return; }
        if (!request.result.objectStoreNames.contains(STORE)) request.result.createObjectStore(STORE);
      };
      request.onsuccess = () => {
        const db = request.result;
        if (settled) { try { db.close(); } catch {} return; }
        settled = true;
        clearTimeout(timeout);
        // Release older connections when a newer app version upgrades storage.
        db.onversionchange = () => db.close();
        resolve(db);
      };
      request.onerror = () => fail(request.error);
      request.onblocked = () => fail(new Error("Secure key storage is busy in another Silknex tab. Close older tabs and try again."));
    });
  }

  async function keyStoreTransaction(mode, operation) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      let tx;
      let settled = false;
      let result;
      const finish = (error) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        try { db.close(); } catch {}
        if (error) reject(error); else resolve(result);
      };
      const timeout = setTimeout(() => {
        try { tx?.abort(); } catch {}
        finish(new Error("Secure key storage did not respond. Try again."));
      }, 12000);
      try {
        tx = db.transaction(STORE, mode);
        tx.oncomplete = () => finish();
        tx.onabort = () => finish(tx.error || new Error("Secure key storage was cancelled."));
        tx.onerror = () => finish(tx.error || new Error("Secure key storage failed."));
        operation(tx.objectStore(STORE), value => { result = value; });
      } catch (error) {
        try { tx?.abort(); } catch {}
        finish(error);
      }
    });
  }

  function idbGet(key) {
    return keyStoreTransaction("readonly", (store, result) => {
      const request = store.get(key);
      request.onsuccess = () => result(request.result);
    });
  }

  function idbPut(key, value, onlyIfAbsent = false) {
    return keyStoreTransaction("readwrite", (store, result) => {
      if (!onlyIfAbsent) { store.put(value, key); result(value); return; }
      // Multiple first-open tabs may generate keys concurrently. Claim the
      // device record inside one transaction so the losing tab uses the winner.
      const request = store.get(key);
      request.onsuccess = () => {
        if (request.result !== undefined) { result(request.result); return; }
        store.put(value, key);
        result(value);
      };
    });
  }

  async function identity() {
    if (identityPromise) return identityPromise;

    const pending = (async () => {
      if (!window.isSecureContext || !crypto?.subtle) {
        throw new Error("End-to-end encryption requires HTTPS.");
      }

      const saved = await idbGet("device");
      if (saved?.device_id && saved?.private_key && saved?.public_jwk) {
        return {
          device_id: saved.device_id,
          privateKey: saved.private_key,
          public_jwk: saved.public_jwk,
        };
      }

      // Older SilkNex builds stored an exportable private JWK. Import it as a
      // non-extractable CryptoKey and immediately overwrite the legacy record.
      if (saved?.device_id && saved?.private_jwk && saved?.public_jwk) {
        const privateKey = await crypto.subtle.importKey(
          "jwk", saved.private_jwk, { name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]
        );
        await idbPut("device", {
          device_id: saved.device_id,
          private_key: privateKey,
          public_jwk: saved.public_jwk,
          created_at: Number(saved.created_at || Date.now()),
          hardened_at: Date.now(),
        });
        return {
          device_id: saved.device_id,
          privateKey,
          public_jwk: saved.public_jwk,
        };
      }

      // WebCrypto needs the freshly generated pair to be extractable long
      // enough to export the public component. Re-import the private component
      // as non-extractable before anything is persisted.
      const pair = await crypto.subtle.generateKey(
        { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]
      );
      const [privateJwk, publicJwk] = await Promise.all([
        crypto.subtle.exportKey("jwk", pair.privateKey),
        crypto.subtle.exportKey("jwk", pair.publicKey),
      ]);
      const privateKey = await crypto.subtle.importKey(
        "jwk", privateJwk, { name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]
      );
      const record = {
        device_id: randomId(16),
        private_key: privateKey,
        public_jwk: publicJwk,
        created_at: Date.now(),
      };
      const claimed = await idbPut("device", record, true);
      if (!claimed?.device_id || !claimed?.private_key || !claimed?.public_jwk) {
        throw new Error("Secure key storage changed in another tab. Reopen Silknex and try again.");
      }
      return { device_id: claimed.device_id, privateKey: claimed.private_key, public_jwk: claimed.public_jwk };
    })();

    identityPromise = pending;
    try {
      return await pending;
    } catch (error) {
      // IndexedDB can fail transiently after a mobile OS restores a tab. Do
      // not permanently poison every future E2EE operation with one rejection.
      if (identityPromise === pending) identityPromise = null;
      throw error;
    }
  }

  async function register(api) {
    const id = await identity();
    const label = `${navigator.platform || "Web"} · ${navigator.userAgentData?.mobile ? "Mobile" : "Browser"}`;
    await api("e2ee_device_register", {
      method: "POST",
      body: {
        device_id: id.device_id,
        public_key_jwk: id.public_jwk,
        label: label.slice(0, 80),
      },
    });
    return id;
  }

  async function getDevices(api, conversationId, refresh = false) {
    const cid = Number(conversationId || 0);
    if (!cid) throw new Error("Conversation is missing.");
    const cached = deviceCache.get(cid);
    if (!refresh && cached && Date.now() - cached.at < 30000) {
      rememberCryptoCache(deviceCache, cid, cached);
      return cached.data;
    }
    const epoch = deviceEpoch;
    const data = await api("e2ee_devices", {}, { conversation_id: cid });
    if (epoch === deviceEpoch) rememberCryptoCache(deviceCache, cid, { at: Date.now(), data });
    return data;
  }

  function publicKeyCacheKey(jwk) {
    return [
      String(jwk?.kty || ""),
      String(jwk?.crv || ""),
      String(jwk?.x || ""),
      String(jwk?.y || ""),
    ].join("|");
  }

  async function importPublic(jwk) {
    const cacheKey = publicKeyCacheKey(jwk);
    if (publicKeyCache.has(cacheKey)) return publicKeyCache.get(cacheKey);
    const key = await crypto.subtle.importKey(
      "jwk", jwk, { name: "ECDH", namedCurve: "P-256" }, false, []
    );
    return rememberCryptoCache(publicKeyCache, cacheKey, key);
  }

  async function deriveWrappingKey(
    id,
    peerJwk,
    conversationId,
    senderDeviceId,
    recipientDeviceId
  ) {
    const peerKeyId = publicKeyCacheKey(peerJwk);
    const cacheKey = [
      Number(conversationId),
      String(senderDeviceId || ""),
      String(recipientDeviceId || ""),
      peerKeyId,
    ].join("|");

    if (wrappingKeyCache.has(cacheKey)) return wrappingKeyCache.get(cacheKey);

    const publicKey = await importPublic(peerJwk);
    const shared = await crypto.subtle.deriveBits(
      { name: "ECDH", public: publicKey }, id.privateKey, 256
    );
    const hkdfBase = await crypto.subtle.importKey("raw", shared, "HKDF", false, ["deriveKey"]);
    const info = encoder.encode(
      `silknex-e2ee-wrap-v1|${Number(conversationId)}|${senderDeviceId}|${recipientDeviceId}`
    );
    const wrappingKey = await crypto.subtle.deriveKey(
      {
        name: "HKDF",
        hash: "SHA-256",
        salt: encoder.encode("SilkNex E2EE v1"),
        info,
      },
      hkdfBase,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );

    return rememberCryptoCache(wrappingKeyCache, cacheKey, wrappingKey);
  }

  async function wrapKeyForDevice(id, recipient, conversationId, contentKeyRaw) {
    const wrappingKey = await deriveWrappingKey(
      id,
      recipient.public_key_jwk,
      conversationId,
      id.device_id,
      recipient.device_id
    );
    const iv = randomBytes(12);
    const aad = encoder.encode(`silknex-key-wrap-v1|${recipient.device_id}`);
    const cipher = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv, additionalData: aad }, wrappingKey, contentKeyRaw
    );
    return {
      device_id: recipient.device_id,
      user_id: Number(recipient.user_id || 0),
      iv: b64u(iv),
      ciphertext: b64u(cipher),
    };
  }


  async function deriveWrappingKeyV2(
    id,
    peerJwk,
    conversationId,
    nonce,
    senderDeviceId,
    recipientDeviceId,
    saltBytes
  ) {
    const publicKey = await importPublic(peerJwk);
    const shared = await crypto.subtle.deriveBits(
      { name: "ECDH", public: publicKey },
      id.privateKey,
      256
    );
    try {
      const hkdfBase = await crypto.subtle.importKey(
        "raw",
        shared,
        "HKDF",
        false,
        ["deriveKey"]
      );
      const info = encoder.encode(
        `silknex-e2ee-wrap-v2|${Number(conversationId)}|${String(nonce || "")}|${senderDeviceId}|${recipientDeviceId}`
      );
      return await crypto.subtle.deriveKey(
        {
          name: "HKDF",
          hash: "SHA-256",
          salt: saltBytes,
          info,
        },
        hkdfBase,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
      );
    } finally {
      try { new Uint8Array(shared).fill(0); } catch {}
    }
  }

  function wrapAadV2(conversationId, nonce, senderDeviceId, recipientDeviceId, userId, saltText) {
    return encoder.encode(
      `silknex-key-wrap-v2|${Number(conversationId)}|${String(nonce || "")}|${senderDeviceId}|${recipientDeviceId}|${Number(userId || 0)}|${saltText}`
    );
  }

  function messageAadV2(conversationId, nonce, senderDeviceId, saltText) {
    return encoder.encode(
      `silknex-message-v2|${Number(conversationId)}|${String(nonce || "")}|${senderDeviceId}|${saltText}`
    );
  }

  async function wrapKeyForDeviceV2(
    id,
    recipient,
    conversationId,
    nonce,
    saltBytes,
    saltText,
    contentKeyRaw
  ) {
    const recipientDeviceId = String(recipient?.device_id || "");
    const recipientUserId = Number(recipient?.user_id || 0);
    const wrappingKey = await deriveWrappingKeyV2(
      id,
      recipient.public_key_jwk,
      conversationId,
      nonce,
      id.device_id,
      recipientDeviceId,
      saltBytes
    );
    const iv = randomBytes(12);
    const cipher = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv,
        additionalData: wrapAadV2(
          conversationId,
          nonce,
          id.device_id,
          recipientDeviceId,
          recipientUserId,
          saltText
        ),
      },
      wrappingKey,
      contentKeyRaw
    );
    return {
      device_id: recipientDeviceId,
      user_id: recipientUserId,
      iv: b64u(iv),
      ciphertext: b64u(cipher),
    };
  }

  async function encryptPayload(api, conversationId, nonce, payload) {
    const id = await identity();
    const deviceData = await getDevices(api, conversationId, true);
    const devices = Array.isArray(deviceData.devices) ? deviceData.devices : [];
    const missing = Array.isArray(deviceData.missing_user_ids) ? deviceData.missing_user_ids : [];

    if (missing.length) {
      const err = new Error("Secure messaging is waiting for every participant to open the latest SilkNex once.");
      err.code = "e2ee_missing_devices";
      throw err;
    }
    if (!devices.length) throw new Error("No encryption devices are available for this chat.");

    const normalizedNonce = String(nonce || "");
    const contentKeyRaw = randomBytes(32);
    const salt = randomBytes(16);
    const saltText = b64u(salt);
    let plain = null;

    try {
      const contentKey = await crypto.subtle.importKey(
        "raw",
        contentKeyRaw,
        "AES-GCM",
        false,
        ["encrypt"]
      );
      const iv = randomBytes(12);
      plain = encoder.encode(JSON.stringify(payload || {}));
      const cipher = await crypto.subtle.encrypt(
        {
          name: "AES-GCM",
          iv,
          additionalData: messageAadV2(
            conversationId,
            normalizedNonce,
            id.device_id,
            saltText
          ),
        },
        contentKey,
        plain
      );
      const wraps = await concurrentMap(
        devices,
        LOW_MEMORY_DEVICE ? 3 : 6,
        (recipient) => wrapKeyForDeviceV2(
          id,
          recipient,
          conversationId,
          normalizedNonce,
          salt,
          saltText,
          contentKeyRaw
        )
      );

      const envelope = assertEnvelopeShape({
        v: 2,
        alg: "P-256+HKDF-SHA256+A256GCM",
        sender_device_id: id.device_id,
        sender_public_jwk: id.public_jwk,
        nonce: normalizedNonce,
        salt: saltText,
        iv: b64u(iv),
        ciphertext: b64u(cipher),
        wraps,
      });
      return JSON.stringify(envelope);
    } finally {
      contentKeyRaw.fill(0);
      salt.fill(0);
      plain?.fill?.(0);
    }
  }

  async function decryptEnvelope(envelope, conversationId) {
    const id = await identity();
    const parsed = assertEnvelopeShape(
      typeof envelope === "string" ? JSON.parse(envelope) : envelope
    );
    const version = Number(parsed.v || 0);
    const wrap = (Array.isArray(parsed.wraps) ? parsed.wraps : [])
      .find((item) => String(item.device_id || "") === id.device_id);
    if (!wrap) {
      const error = new Error("Encrypted on another device.");
      error.code = "e2ee_no_device_wrap";
      throw error;
    }

    let rawKey = null;
    let plain = null;
    try {
      if (version >= 2) {
        const salt = unb64u(parsed.salt);
        const wrappingKey = await deriveWrappingKeyV2(
          id,
          parsed.sender_public_jwk,
          conversationId,
          parsed.nonce,
          parsed.sender_device_id,
          id.device_id,
          salt
        );
        rawKey = await crypto.subtle.decrypt(
          {
            name: "AES-GCM",
            iv: unb64u(wrap.iv),
            additionalData: wrapAadV2(
              conversationId,
              parsed.nonce,
              parsed.sender_device_id,
              id.device_id,
              Number(wrap.user_id || 0),
              parsed.salt
            ),
          },
          wrappingKey,
          unb64u(wrap.ciphertext)
        );
        salt.fill(0);
      } else {
        const wrappingKey = await deriveWrappingKey(
          id,
          parsed.sender_public_jwk,
          conversationId,
          parsed.sender_device_id,
          id.device_id
        );
        rawKey = await crypto.subtle.decrypt(
          {
            name: "AES-GCM",
            iv: unb64u(wrap.iv),
            additionalData: encoder.encode(`silknex-key-wrap-v1|${id.device_id}`),
          },
          wrappingKey,
          unb64u(wrap.ciphertext)
        );
      }

      const contentKey = await crypto.subtle.importKey(
        "raw",
        rawKey,
        "AES-GCM",
        false,
        ["decrypt"]
      );
      const additionalData = version >= 2
        ? messageAadV2(
            conversationId,
            parsed.nonce,
            parsed.sender_device_id,
            parsed.salt
          )
        : encoder.encode(
            `silknex-message-v1|${Number(conversationId)}|${String(parsed.nonce || "")}`
          );

      plain = await crypto.subtle.decrypt(
        {
          name: "AES-GCM",
          iv: unb64u(parsed.iv),
          additionalData,
        },
        contentKey,
        unb64u(parsed.ciphertext)
      );
      return JSON.parse(decoder.decode(plain));
    } finally {
      if (rawKey) {
        try { new Uint8Array(rawKey).fill(0); } catch {}
      }
      if (plain) {
        try { new Uint8Array(plain).fill(0); } catch {}
      }
    }
  }

  async function decryptMessage(message) {
    if (!message?.e2ee_payload) return message;
    try {
      const payload = await decryptEnvelope(message.e2ee_payload, message.conversation_id);
      return {
        ...message,
        body: String(payload?.text || ""),
        e2ee_meta: payload || {},
        e2ee_decryption_error: "",
      };
    } catch (error) {
      return {
        ...message,
        body: error?.code === "e2ee_no_device_wrap"
          ? "Older message unavailable on this device"
          : "Older message unavailable on this device",
        e2ee_meta: null,
        e2ee_decryption_error: error?.message || "Unable to decrypt",
      };
    }
  }

  async function decryptMessages(messages) {
    const source = Array.isArray(messages) ? messages : [];
    // Decrypting dozens of ECDH/AES envelopes at once can stall lower-end
    // phones. A small worker pool keeps scrolling/input responsive while still
    // completing a normal page quickly.
    return concurrentMap(source, LOW_MEMORY_DEVICE ? 2 : 4, decryptMessage);
  }

  async function encryptFile(file) {
    if (!(file instanceof Blob)) throw new Error("No file selected.");

    const rawKey = randomBytes(32);
    const key = await crypto.subtle.importKey(
      "raw",
      rawKey,
      "AES-GCM",
      false,
      ["encrypt"]
    );
    const safeName = String(file.name || "attachment").slice(0, 180);
    const commonMeta = {
      key: b64u(rawKey),
      mime: String(file.type || "application/octet-stream").slice(0, 120),
      name: safeName,
      size: Number(file.size || 0),
    };

    if (file.size <= MEDIA_CHUNK_THRESHOLD) {
      const iv = randomBytes(12);
      const source = await file.arrayBuffer();
      const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, source);
      return {
        blob: new Blob([encrypted], { type: "application/octet-stream" }),
        meta: {
          ...commonMeta,
          v: 1,
          iv: b64u(iv),
        },
      };
    }

    // Large video/audio attachments are encrypted a chunk at a time so a
    // 40 MB upload does not require a second 40 MB plaintext ArrayBuffer plus
    // the full ciphertext at the same instant on a phone.
    const parts = [];
    const chunks = [];
    const total = Math.ceil(file.size / MEDIA_CHUNK_BYTES);

    for (let index = 0; index < total; index += 1) {
      const start = index * MEDIA_CHUNK_BYTES;
      const end = Math.min(file.size, start + MEDIA_CHUNK_BYTES);
      const source = await file.slice(start, end).arrayBuffer();
      const iv = randomBytes(12);
      const aad = encoder.encode(
        `silknex-media-v2|${index}|${total}|${Number(file.size || 0)}`
      );
      const encrypted = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv, additionalData: aad },
        key,
        source
      );
      parts.push(new Blob([encrypted], { type: "application/octet-stream" }));
      chunks.push({
        iv: b64u(iv),
        size: encrypted.byteLength,
      });
    }

    return {
      blob: new Blob(parts, { type: "application/octet-stream" }),
      meta: {
        ...commonMeta,
        v: 2,
        chunk_size: MEDIA_CHUNK_BYTES,
        chunks,
      },
    };
  }

  function touchMediaUrl(id) {
    const key = Number(id || 0);
    if (!key || !mediaUrlCache.has(key)) return "";
    const url = mediaUrlCache.get(key);
    const meta = mediaUrlMetaCache.get(key) || { bytes: 0 };
    mediaUrlCache.delete(key);
    mediaUrlMetaCache.delete(key);
    mediaUrlCache.set(key, url);
    mediaUrlMetaCache.set(key, meta);
    return url;
  }

  function trimMediaCache({
    maxItems = MAX_MEDIA_CACHE_ITEMS,
    maxBytes = MAX_MEDIA_CACHE_BYTES,
  } = {}) {
    const itemLimit = Math.max(0, Number(maxItems) || 0);
    const byteLimit = Math.max(0, Number(maxBytes) || 0);
    let bytes = 0;
    for (const meta of mediaUrlMetaCache.values()) {
      bytes += Math.max(0, Number(meta?.bytes || 0));
    }

    // One currently requested attachment can exceed the idle cache budget.
    // Never revoke its URL before the caller even receives it.
    while (mediaUrlCache.size > itemLimit || (mediaUrlCache.size > 1 && byteLimit > 0 && bytes > byteLimit)) {
      const candidates = Array.from(mediaUrlCache.keys());
      // Keep the newly requested URL valid even when all older entries play.
      if (itemLimit > 0) candidates.pop();
      const oldest = candidates.find((id) => !playingMedia.has(id));
      if (oldest === undefined) break;
      const url = mediaUrlCache.get(oldest);
      const meta = mediaUrlMetaCache.get(oldest);
      bytes -= Math.max(0, Number(meta?.bytes || 0));
      if (url) {
        try { URL.revokeObjectURL(url); } catch {}
      }
      mediaUrlCache.delete(oldest);
      mediaUrlMetaCache.delete(oldest);
    }
  }

  function rememberMediaUrl(id, url, bytes = 0) {
    const key = Number(id || 0);
    if (!key || !url) return url;
    const previous = mediaUrlCache.get(key);
    if (previous && previous !== url) {
      try { URL.revokeObjectURL(previous); } catch {}
    }
    mediaUrlCache.delete(key);
    mediaUrlMetaCache.delete(key);
    mediaUrlCache.set(key, url);
    mediaUrlMetaCache.set(key, { bytes: Math.max(0, Number(bytes || 0)) });
    trimMediaCache();
    return url;
  }

  function checkMediaTicket(ticket) {
    if (ticket && (ticket.cancelled || ticket.epoch !== mediaEpoch)) {
      const error = new Error("Media request cancelled.");
      error.name = "AbortError";
      throw error;
    }
  }

  function queueMediaJob(job) {
    return new Promise((resolve, reject) => {
      mediaJobs.push({ job, resolve, reject });
      drainMediaJobs();
    });
  }

  function drainMediaJobs() {
    const limit = LOW_MEMORY_DEVICE ? 1 : 2;
    while (activeMediaJobs < limit && mediaJobs.length) {
      const next = mediaJobs.shift();
      activeMediaJobs++;
      Promise.resolve().then(next.job).then(next.resolve, next.reject).finally(() => {
        activeMediaJobs--;
        drainMediaJobs();
      });
    }
  }

  async function decryptMediaToUrlUncached(message, ticket) {
    checkMediaTicket(ticket);
    const id = Number(message?.id || 0);
    if (id && mediaUrlCache.has(id)) return touchMediaUrl(id);
    const meta = message?.e2ee_meta?.media;
    const url = String(message?.attachment_url || "");
    if (!meta?.key || !url) {
      if (message?.e2ee_payload || meta) throw new Error("Attachment encryption key is unavailable on this device.");
      return url;
    }

    const response = await fetch(url, {
      credentials: "same-origin",
      cache: "force-cache",
      signal: ticket?.controller?.signal,
    });
    checkMediaTicket(ticket);
    if (!response.ok) throw new Error("Could not load encrypted media.");

    const key = await crypto.subtle.importKey(
      "raw",
      unb64u(meta.key),
      "AES-GCM",
      false,
      ["decrypt"]
    );

    let plainBlob;
    if (Number(meta.v || 1) >= 2 && Array.isArray(meta.chunks) && meta.chunks.length) {
      const encryptedBlob = await response.blob();
      const total = meta.chunks.length;
      const expectedPlainSize = Math.max(0, Number(meta.size || 0));
      const parts = [];
      let offset = 0;

      for (let index = 0; index < total; index += 1) {
        checkMediaTicket(ticket);
        const chunk = meta.chunks[index] || {};
        const encryptedSize = Math.max(17, Number(chunk.size || 0));
        if (!chunk.iv || offset + encryptedSize > encryptedBlob.size) {
          throw new Error("Encrypted media is incomplete.");
        }

        const encrypted = await encryptedBlob
          .slice(offset, offset + encryptedSize)
          .arrayBuffer();
        const aad = encoder.encode(
          `silknex-media-v2|${index}|${total}|${expectedPlainSize}`
        );
        const plain = await crypto.subtle.decrypt(
          {
            name: "AES-GCM",
            iv: unb64u(chunk.iv),
            additionalData: aad,
          },
          key,
          encrypted
        );
        parts.push(new Blob([plain]));
        offset += encryptedSize;
      }

      if (offset !== encryptedBlob.size) {
        throw new Error("Encrypted media has unexpected trailing data.");
      }
      plainBlob = new Blob(parts, {
        type: meta.mime || "application/octet-stream",
      });
    } else {
      if (!meta.iv) throw new Error("Encrypted media metadata is incomplete.");
      const encrypted = await response.arrayBuffer();
      const plain = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: unb64u(meta.iv) },
        key,
        encrypted
      );
      plainBlob = new Blob([plain], {
        type: meta.mime || "application/octet-stream",
      });
    }

    checkMediaTicket(ticket);
    const objectUrl = URL.createObjectURL(plainBlob);
    if (id) rememberMediaUrl(id, objectUrl, plainBlob.size);
    return objectUrl;
  }

  async function decryptMediaToUrl(message) {
    const id = Number(message?.id || 0);
    if (id && mediaUrlCache.has(id)) return touchMediaUrl(id);
    if (id && mediaPromiseCache.has(id)) return mediaPromiseCache.get(id);

    const ticket = { epoch: mediaEpoch, cancelled: false, controller: null };
    try { if (typeof AbortController === "function") ticket.controller = new AbortController(); } catch {}
    if (id) mediaTickets.set(id, ticket);
    allMediaTickets.add(ticket);
    const pending = queueMediaJob(async () => {
      checkMediaTicket(ticket);
      let timer;
      try {
        return await Promise.race([decryptMediaToUrlUncached(message, ticket), new Promise((_, reject) => {
          timer = setTimeout(() => {
            ticket.cancelled = true;
            ticket.controller?.abort();
            reject(new Error("Encrypted media took too long to open. Try again."));
          }, 120000);
        })]);
      } finally { clearTimeout(timer); }
    });
    if (id) mediaPromiseCache.set(id, pending);

    try {
      return await pending;
    } finally {
      if (id && mediaPromiseCache.get(id) === pending) {
        mediaPromiseCache.delete(id);
      }
      if (id && mediaTickets.get(id) === ticket) mediaTickets.delete(id);
      allMediaTickets.delete(ticket);
    }
  }

  async function decryptFile(url, mediaMeta) {
    return decryptMediaToUrl({
      attachment_url: String(url || ""),
      e2ee_meta: { media: mediaMeta || {} },
    });
  }

  function releaseMediaUrl(messageId) {
    const id = Number(messageId || 0);
    playingMedia.delete(id);
    if (!id) return;
    const ticket = mediaTickets.get(id);
    if (ticket) { ticket.cancelled = true; ticket.controller?.abort(); mediaTickets.delete(id); }
    const url = mediaUrlCache.get(id);
    if (url) {
      try { URL.revokeObjectURL(url); } catch {}
      mediaUrlCache.delete(id);
    }
    mediaUrlMetaCache.delete(id);
    mediaPromiseCache.delete(id);
  }

  function clearMediaUrls() {
    playingMedia.clear();
    mediaEpoch++;
    for (const ticket of allMediaTickets) { ticket.cancelled = true; ticket.controller?.abort(); }
    mediaTickets.clear();
    for (const url of mediaUrlCache.values()) {
      try { URL.revokeObjectURL(url); } catch {}
    }
    mediaUrlCache.clear();
    mediaUrlMetaCache.clear();
    mediaPromiseCache.clear();
  }

  function clearDeviceKeyCache() {
    deviceEpoch++;
    deviceCache.clear();
    publicKeyCache.clear();
    wrappingKeyCache.clear();
  }

  function clearMediaCache() {
    clearMediaUrls();
    clearDeviceKeyCache();
  }

  window.SilknexE2EE = Object.freeze({
    ready: identity,
    register,
    getDevices,
    encryptPayload,
    decryptEnvelope,
    decryptMessage,
    decryptMessages,
    encryptFile,
    decryptMediaToUrl,
    decryptFile,
    releaseMediaUrl,
    setMediaPlaying(messageId, active) {
      const id = Number(messageId || 0);
      if (active) playingMedia.add(id);
      else playingMedia.delete(id);
    },
    trimMediaCache,
    clearMediaUrls,
    clearDeviceKeyCache,
    clearMediaCache,
  });
})();
